@echo off
REM Pet-Videos Service Startup Script (Windows)

echo =========================================
echo Pet-Videos Service API
echo =========================================
echo.
echo [TIP] If service freezes, press Enter or ESC to resume
echo [TIP] Do not click or select text in console window
echo.

REM Set Noah environment variable (Required for Windows)
set _NOAHEE_INSTANCEID=5.android-container.licai-licai

REM Check and activate virtual environment
if exist "backend\venv\Scripts\activate.bat" (
    echo Activating virtual environment...
    call backend\venv\Scripts\activate.bat
) else if exist "service\venv\Scripts\activate.bat" (
    echo Activating service virtual environment...
    call service\venv\Scripts\activate.bat
) else (
    echo [WARN] Virtual environment not found, using system Python
)

REM Check Python
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python not found, please install Python 3
    exit /b 1
)

REM Start service
echo.
echo Starting Service API...
echo ----------------------------------------
echo Listen: http://0.0.0.0:8006
echo Health: http://localhost:8006/pet/health
echo Test: http://localhost:8006/pet/api/test
echo Docs: See service/appdoc/API接口文档.md
echo ----------------------------------------
echo.

cd /d "%~dp0"
python -m service.app
