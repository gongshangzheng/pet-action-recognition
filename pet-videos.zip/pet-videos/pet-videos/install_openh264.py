"""
自动下载并安装 OpenH264 库（Windows）
用于支持 OpenCV 的 H.264 视频编码
"""
import os
import sys
import urllib.request
import bz2
import platform
from pathlib import Path

# OpenH264 下载信息（使用 v1.8.0 以兼容大多数 OpenCV 4.x 版本）
OPENH264_VERSION = "1.8.0"
OPENH264_URL = f"https://github.com/cisco/openh264/releases/download/v{OPENH264_VERSION}/openh264-{OPENH264_VERSION}-win64.dll.bz2"
OPENH264_DLL = f"openh264-{OPENH264_VERSION}-win64.dll"

# 备用下载地址（国内镜像）
MIRROR_URLS = [
    OPENH264_URL,
    f"https://ghproxy.com/{OPENH264_URL}",
    f"https://mirror.ghproxy.com/{OPENH264_URL}",
]

def download_openh264():
    """下载 OpenH264 库"""
    if platform.system() != "Windows":
        print("此脚本仅适用于 Windows 系统")
        return False
    
    # 目标路径：当前用户的 AppData\Local 目录
    app_data = os.path.expandvars(r'%LOCALAPPDATA%')
    dll_path = os.path.join(app_data, OPENH264_DLL)
    
    # 删除其他版本
    import glob
    for old_dll in glob.glob(os.path.join(app_data, "openh264-*.dll")):
        if old_dll != dll_path:
            try:
                os.remove(old_dll)
                print(f"✓ 已删除旧版本: {old_dll}")
            except:
                print(f"⚠ 无法删除: {old_dll}（请手动删除）")
    
    # 检查是否已存在
    if os.path.exists(dll_path):
        print(f"✓ OpenH264 库已存在: {dll_path}")
        return True
    
    print(f"正在下载 OpenH264 v{OPENH264_VERSION}...")
    
    # 尝试多个下载源
    bz2_path = dll_path + ".bz2"
    download_success = False
    
    for i, url in enumerate(MIRROR_URLS, 1):
        try:
            print(f"尝试下载源 {i}/{len(MIRROR_URLS)}: {url}")
            urllib.request.urlretrieve(url, bz2_path)
            print(f"✓ 下载完成: {bz2_path}")
            download_success = True
            break
        except Exception as e:
            print(f"✗ 下载失败: {e}")
            if i < len(MIRROR_URLS):
                print("正在尝试下一个下载源...")
            continue
    
    if not download_success:
        raise Exception("所有下载源均失败")
    
    try:
        
        # 解压 .bz2 文件
        print("正在解压...")
        with open(bz2_path, 'rb') as source:
            with open(dll_path, 'wb') as dest:
                dest.write(bz2.decompress(source.read()))
        
        # 删除 .bz2 文件
        os.remove(bz2_path)
        
        print(f"✓ OpenH264 库已安装到: {dll_path}")
        print(f"✓ 文件大小: {os.path.getsize(dll_path) / 1024:.1f} KB")
        return True
        
    except Exception as e:
        print(f"✗ 安装失败: {e}")
        print("\n手动安装步骤:")
        print(f"1. 访问: {OPENH264_URL}")
        print(f"2. 下载并解压 .bz2 文件")
        print(f"3. 将 {OPENH264_DLL} 复制到: {app_data}")
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("  OpenH264 库安装工具（用于 OpenCV H.264 编码）")
    print("=" * 60)
    print()
    
    success = download_openh264()
    
    print()
    print("=" * 60)
    if success:
        print("  安装成功！现在可以使用 H.264 编码了")
    else:
        print("  安装失败，请手动下载安装")
    print("=" * 60)
    
    sys.exit(0 if success else 1)
