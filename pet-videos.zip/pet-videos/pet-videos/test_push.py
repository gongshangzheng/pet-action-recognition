"""
宠物 Push 消息接口测试脚本
使用 push_service 封装方法进行测试，覆盖两种调用方式：
  1. send_push()        已知 userId，直接发送
  2. send_push_by_did() 只有 did，自动查询 userId 再发送
"""

import asyncio
import sys
import os
import json

# 将 service 目录加入模块搜索路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "service"))

from push_service import send_push, send_push_by_did

# ==================== 配置区 ====================
# 消息服务地址（生产环境通过 BNS）
MESSAGE_SERVICE = "smart.group.message-service.licai-licai"

# user-service 地址（生产环境通过 BNS）
USER_SERVICE = "smart.group.user-service.licai-licai"

TEST_DID     = "20000000060148"
TEST_USER_ID = "29189742"       # 已知 userId（fallback）

TEST_TEMPLATE = "PET_ACTION_NOTICE"
TEMPLATE_PARAMS = {
    "PET_NAME":               "小黄",
    "PET_ACTION":             "吃饭",
    "PET_ACTION_DESCRIPTION": "小黄正在津津有味地享用午餐",
}


def print_result(title: str, result: dict):
    print(f"\n{'='*50}")
    print(f"[{title}]")
    print(f"  success:     {result['success']}")
    print(f"  result_code: {result['result_code']}")
    print(f"  result_msg:  {result['result_msg']}")
    if not result["success"]:
        print(f"  error:       {result['error']}")
    
    # 打印完整的原始响应（便于 debug）
    print(f"\n  原始响应:")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print('='*50)


# ==================== 主流程 ====================
async def main():
    print("========== 宠物 Push 接口测试 ==========")
    print(f"  消息服务: {MESSAGE_SERVICE}")
    print(f"  用户服务: {USER_SERVICE or '(未配置，跳过by_did测试)'}")
    print(f"  模板code: {TEST_TEMPLATE}")

    # --- 测试1：已知 userId 直接发送 ---
    print(f"\n>>> [测试1] send_push (userId={TEST_USER_ID})")
    print(f"  请求参数:")
    print(f"    template_code:   {TEST_TEMPLATE}")
    print(f"    user_id:         {TEST_USER_ID}")
    print(f"    template_params: {json.dumps(TEMPLATE_PARAMS, ensure_ascii=False)}")
    print(f"    service_name:    {MESSAGE_SERVICE}")
    
    result1 = await send_push(
        template_code=TEST_TEMPLATE,
        user_id=TEST_USER_ID,
        template_params=TEMPLATE_PARAMS,
        service_name=MESSAGE_SERVICE,
        verbose=True,
    )
    print_result("测试1 send_push", result1)

    # --- 测试2：通过 did 查询 userId 再发送 ---
    if USER_SERVICE:
        print(f"\n>>> [测试2] send_push_by_did (did={TEST_DID})")
        print(f"  请求参数:")
        print(f"    did:                   {TEST_DID}")
        print(f"    template_code:         {TEST_TEMPLATE}")
        print(f"    template_params:       {json.dumps(TEMPLATE_PARAMS, ensure_ascii=False)}")
        print(f"    message_service_name:  {MESSAGE_SERVICE}")
        print(f"    user_service_name:     {USER_SERVICE}")
        
        result2 = await send_push_by_did(
            did=TEST_DID,
            template_code=TEST_TEMPLATE,
            template_params=TEMPLATE_PARAMS,
            message_service_name=MESSAGE_SERVICE,
            user_service_name=USER_SERVICE,
            verbose=True,
        )
        print_result("测试2 send_push_by_did", result2)
    else:
        print("\n>>> [测试2] send_push_by_did 跳过（USER_SERVICE 未配置）")


if __name__ == "__main__":
    asyncio.run(main())
