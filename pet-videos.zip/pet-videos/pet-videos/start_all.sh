#!/bin/bash
# 同时启动后端和前端

echo "启动 Pet Videos Analysis..."

# 检查是否在项目根目录
if [ ! -d "backend" ] || [ ! -d "frontend" ]; then
    echo "错误: 请在项目根目录运行此脚本"
    exit 1
fi

# 启动后端（后台运行）
echo "启动后端..."
./start_backend.sh > logs/backend.log 2>&1 &
BACKEND_PID=$!
echo "后端进程 PID: $BACKEND_PID"

# 等待后端启动
sleep 3

# 启动前端
echo "启动前端..."
./start_frontend.sh

# 清理：当前端退出时，也停止后端
kill $BACKEND_PID 2>/dev/null
