#!/bin/bash

# Pet-Videos Service 启动脚本

echo "========================================="
echo "Pet-Videos Service API 启动脚本"
echo "========================================="

# 激活虚拟环境
if [ -f "backend/venv/bin/activate" ]; then
    echo "激活虚拟环境..."
    source backend/venv/bin/activate
elif [ -f "service/venv/bin/activate" ]; then
    echo "激活 service 虚拟环境..."
    source service/venv/bin/activate
else
    echo "⚠️  未找到虚拟环境，使用系统 Python"
fi

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 未找到 python3，请先安装 Python 3"
    exit 1
fi

# 检查依赖
echo "检查依赖..."
python3 -c "import fastapi, uvicorn, aiohttp, noah_python_sdk" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "⚠️  缺少依赖"
    echo "请安装: pip install -r service/requirements.txt"
    if [ -f "service/requirements.txt" ]; then
        echo "正在从 requirements.txt 安装..."
        pip3 install -r service/requirements.txt
    fi
fi

# 启动服务
echo ""
echo "🚀 启动 Service API..."
echo "----------------------------------------"
echo "监听地址: http://0.0.0.0:8006"
echo "健康检查: http://localhost:8006/pet/health"
echo "测试接口: http://localhost:8006/pet/api/test"
echo "视频流: http://localhost:8006/pet/api/video/stream"
echo "注意: 所有路由已添加 /pet 前缀"
echo "----------------------------------------"
echo ""

cd "$(dirname "$0")"
python3 -m service.app
