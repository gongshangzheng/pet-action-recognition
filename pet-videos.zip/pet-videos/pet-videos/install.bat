@echo off
setlocal EnableDelayedExpansion
set "ROOT=%~dp0"

echo ===================================================
echo   Pet Videos Analysis System - Installation
echo ===================================================
echo.

:: Check Python
echo [1/4] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Please install Python 3.8+
    exit /b 1
)
echo [OK] Python found

:: Check Node.js
echo.
echo [2/4] Checking Node.js...
node --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js not found. Please install Node.js 16+
    exit /b 1
)
echo [OK] Node.js found

:: Install Backend dependencies
echo.
echo [3/4] Installing Backend dependencies...
cd /d "%ROOT%backend"
if not exist "venv" (
    echo Creating virtual environment...
    python -m venv venv
)
call venv\Scripts\activate.bat
pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Backend installation failed
    exit /b 1
)
echo [OK] Backend dependencies installed

:: Install Frontend dependencies
echo.
echo [4/4] Installing Frontend dependencies...
cd /d "%ROOT%frontend"
call npm install
if errorlevel 1 (
    echo [ERROR] Frontend installation failed
    exit /b 1
)
echo [OK] Frontend dependencies installed

echo.
echo ===================================================
echo   Installation Complete!
echo ===================================================
echo.
echo Next steps:
echo   1. Copy .env.example to .env and configure it
echo   2. Run start_backend.bat to start backend
echo   3. Run start_frontend.bat to start frontend
echo   4. Run start_service.bat to start service API
echo.
