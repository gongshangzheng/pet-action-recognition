#!/bin/bash
# 数据库位置统一脚本 - macOS/Linux版本
# 将backend/database/history.db迁移到根目录database/history.db

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo "========================================"
echo "数据库位置统一迁移"
echo "========================================"
echo ""

# 检查根目录数据库是否存在
if [ ! -f "database/history.db" ]; then
    echo "[ERROR] 根目录数据库不存在: database/history.db"
    echo "请先创建database目录并初始化数据库"
    exit 1
fi

# 检查backend数据库是否存在
if [ ! -f "backend/database/history.db" ]; then
    echo "[INFO] backend/database/history.db 不存在，无需迁移"
    echo "[INFO] 当前已使用根目录数据库"
    # 跳到验证步骤
    skip_migration=true
else
    skip_migration=false
fi

if [ "$skip_migration" = false ]; then
    echo "[1/4] 备份根目录数据库..."
    BACKUP_FILE="database/history.db.backup_$(date +%Y%m%d_%H%M%S)"
    cp "database/history.db" "$BACKUP_FILE"
    if [ $? -ne 0 ]; then
        echo "[ERROR] 备份失败"
        exit 1
    fi
    echo "      备份成功: $BACKUP_FILE"
    echo ""

    echo "[2/4] 比较两个数据库大小..."
    size1=$(stat -f%z "database/history.db" 2>/dev/null || stat -c%s "database/history.db" 2>/dev/null)
    size2=$(stat -f%z "backend/database/history.db" 2>/dev/null || stat -c%s "backend/database/history.db" 2>/dev/null)
    echo "      根目录数据库: $size1 bytes"
    echo "      backend数据库: $size2 bytes"
    echo ""

    # 比较大小，使用较大的数据库
    if [ "$size2" -gt "$size1" ]; then
        echo "[INFO] backend数据库更大，将覆盖根目录数据库"
        cp "backend/database/history.db" "database/history.db"
        if [ $? -ne 0 ]; then
            echo "[ERROR] 复制失败"
            exit 1
        fi
        echo "      复制成功"
    else
        echo "[INFO] 根目录数据库已是最新，无需覆盖"
    fi
    echo ""

    echo "[3/4] 重命名backend数据库目录..."
    BACKUP_DIR="backend/database.backup_$(date +%Y%m%d_%H%M%S)"
    mv "backend/database" "$BACKUP_DIR"
    if [ $? -ne 0 ]; then
        echo "[ERROR] 重命名失败"
        exit 1
    fi
    echo "      重命名成功: $BACKUP_DIR"
    echo ""
fi

echo "[4/4] 验证数据库..."
if [ ! -f "database/history.db" ]; then
    echo "[ERROR] 根目录数据库不存在"
    exit 1
fi

# 检查数据库是否可访问
sqlite3 "database/history.db" "SELECT COUNT(*) FROM sqlite_master WHERE type='table';" > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "[ERROR] 数据库损坏或无法访问"
    if [ -n "$BACKUP_FILE" ]; then
        echo "请从备份恢复: $BACKUP_FILE"
    fi
    exit 1
fi

echo "      数据库验证成功"
echo ""
echo "========================================"
echo "迁移完成!"
echo "========================================"
echo ""
echo "数据库位置: database/history.db"
if [ -n "$BACKUP_FILE" ]; then
    echo "备份位置: $BACKUP_FILE"
fi
if [ -n "$BACKUP_DIR" ]; then
    echo "旧数据库: $BACKUP_DIR"
fi
echo ""
echo "下一步:"
echo "1. 执行pets表ID迁移: backend/migrations/run_migration_002.sh"
echo "2. 重启Backend服务: python3 backend/main.py"
echo "3. 重启Service服务: python3 -m service.app"
echo ""
