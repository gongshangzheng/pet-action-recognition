# Windows Server 部署指南

## 📋 适用环境

- **操作系统**: Windows Server 2016 / 2019 / 2022
- **Python**: 3.8+
- **Node.js**: 16+
- **数据库**: SQLite3

## ⚠️ 重要提示

### 编码问题

Windows 默认使用 GBK 编码，而项目使用 UTF-8 编码。所有批处理脚本已添加：

```batch
@echo off
chcp 65001 >nul
```

这会将控制台切换到 UTF-8 编码，避免中文乱码。

### 路径分隔符

- Windows 使用反斜杠 `\`
- 所有脚本已适配 Windows 路径格式

## 🚀 快速部署

### 方式一：一键部署（推荐）

```batch
cd D:\pet-videos
deploy_latest.bat
```

按提示操作即可完成部署。

### 方式二：手动部署

#### 1. 备份数据库

```batch
cd D:\pet-videos
set TIMESTAMP=%date:~0,4%%date:~5,2%%date:~8,2%_%time:~0,2%%time:~3,2%%time:~6,2%
copy backend\database\history.db backend\database\history.db.backup.%TIMESTAMP%
```

#### 2. 停止服务

```batch
stop_all.bat
```

或手动停止：

```batch
REM 查找并停止 Backend (8002)
for /f "tokens=5" %a in ('netstat -aon ^| findstr ":8002" ^| findstr "LISTENING"') do taskkill /F /PID %a

REM 查找并停止 Service (8006)
for /f "tokens=5" %a in ('netstat -aon ^| findstr ":8006" ^| findstr "LISTENING"') do taskkill /F /PID %a

REM 查找并停止 Frontend (8173)
for /f "tokens=5" %a in ('netstat -aon ^| findstr ":8173" ^| findstr "LISTENING"') do taskkill /F /PID %a
```

#### 3. 执行数据库迁移

**方式 A：使用 PowerShell（推荐，无编码问题）**

```powershell
cd backend
powershell -ExecutionPolicy Bypass -File run_server_migration.ps1
```

**方式 B：使用简化版 BAT（无中文）**

```batch
cd backend
run_server_migration_simple.bat
```

**方式 C：使用原版 BAT（可能有编码问题）**

```batch
cd backend
run_server_migration.bat
```

如果遇到乱码，请使用方式 A 或 B。

#### 4. 修复异常 FPS（可选）

```batch
python migrations\fix_abnormal_fps.py
```

#### 5. 启动服务

```batch
cd ..
start_all.bat
```

#### 6. 验证部署

```batch
REM 检查 Backend
curl http://localhost:8002/api/sources/

REM 检查 Service
curl http://localhost:8006/api/sources/

REM 检查 Frontend
curl http://localhost:8173/

REM 检查数据库表
sqlite3 backend\database\history.db ".tables"
```

## 📦 离线打包部署

### 1. 本地打包

在开发机器上执行：

```batch
cd D:\pet-videos
package.bat
```

生成文件：`output\pet-videos-source-YYYYMMDD-HHMMSS.zip`

### 2. 上传到服务器

使用 FTP、SFTP 或远程桌面将 zip 文件上传到服务器。

### 3. 服务器解压

```batch
REM 备份旧版本
cd D:\
move pet-videos pet-videos-backup-%date:~0,4%%date:~5,2%%date:~8,2%

REM 解压新版本
powershell -command "Expand-Archive -Path 'C:\Temp\pet-videos-source-*.zip' -DestinationPath 'D:\pet-videos'"

cd pet-videos
```

### 4. 恢复配置和数据

```batch
REM 恢复 .env 配置
copy ..\pet-videos-backup-*\backend\.env backend\.env
copy ..\pet-videos-backup-*\service\.env service\.env

REM 恢复数据库
copy ..\pet-videos-backup-*\backend\database\history.db backend\database\history.db

REM 恢复视频文件（如果需要）
xcopy /E /I ..\pet-videos-backup-*\backend\videos backend\videos
```

### 5. 执行迁移并启动

```batch
cd backend
run_server_migration.bat
python migrations\fix_abnormal_fps.py
cd ..
start_all.bat
```

## 🔧 常见问题

### 1. 中文乱码

**问题**: 批处理脚本中文显示乱码，如截图所示

**原因**: Windows 批处理文件需要 UTF-8 with BOM 编码，但文件可能是 UTF-8 without BOM

**解决方案（按优先级）**:

**方案 A：使用 PowerShell 脚本（最推荐）**
```powershell
cd backend
powershell -ExecutionPolicy Bypass -File run_server_migration.ps1
```
PowerShell 对 UTF-8 支持更好，不会有乱码问题。

**方案 B：使用简化版 BAT（无中文）**
```batch
cd backend
run_server_migration_simple.bat
```
该版本完全使用英文，避免编码问题。

**方案 C：修复 BAT 文件编码**
```batch
REM 使用记事本打开 .bat 文件
REM 文件 -> 另存为 -> 编码选择 "UTF-8"（带 BOM）
```

**方案 D：设置控制台编码**
```batch
chcp 65001
```
在执行脚本前运行此命令。

### 2. Python 找不到

**问题**: `'python' 不是内部或外部命令`

**解决**:
```batch
REM 检查 Python 安装
where python
where python3

REM 如果找不到，添加到 PATH
set PATH=%PATH%;C:\Python39
```

或使用完整路径：
```batch
C:\Python39\python.exe migrations\migrate_*.py
```

### 3. 端口被占用

**问题**: `Address already in use` 或 `端口被占用`

**解决**:
```batch
REM 查看端口占用
netstat -ano | findstr ":8002"
netstat -ano | findstr ":8006"
netstat -ano | findstr ":8173"

REM 停止进程（替换 PID）
taskkill /F /PID 12345
```

### 4. 权限不足

**问题**: `拒绝访问` 或 `Access Denied`

**解决**:
- 以管理员身份运行 CMD
- 右键点击脚本 → "以管理员身份运行"

### 5. SQLite3 找不到

**问题**: `'sqlite3' 不是内部或外部命令`

**解决**:
```batch
REM 下载 SQLite3 for Windows
REM https://www.sqlite.org/download.html

REM 解压到项目目录
copy sqlite3.exe backend\
```

或使用 Python 的 sqlite3：
```batch
python -c "import sqlite3; print(sqlite3.version)"
```

### 6. 虚拟环境激活失败

**问题**: 虚拟环境无法激活

**解决**:
```batch
REM 创建虚拟环境
cd backend
python -m venv venv

REM 激活虚拟环境
venv\Scripts\activate.bat

REM 安装依赖
pip install -r requirements.txt
```

### 7. Node.js 模块找不到

**问题**: `Cannot find module` 或模块缺失

**解决**:
```batch
cd frontend
rmdir /s /q node_modules
npm install
```

## 📝 Windows 特定配置

### 1. 环境变量

在 `backend\.env` 中使用 Windows 路径：

```ini
# Windows 路径格式
DATABASE_PATH=database\history.db
VIDEO_DIRS={"alias1": "D:\\videos\\camera1", "alias2": "D:\\videos\\camera2"}

# 或使用正斜杠（Python 支持）
VIDEO_DIRS={"alias1": "D:/videos/camera1", "alias2": "D:/videos/camera2"}
```

### 2. 服务自动启动

创建 Windows 服务或计划任务：

#### 方式 A：使用 NSSM（推荐）

```batch
REM 下载 NSSM: https://nssm.cc/download

REM 安装 Backend 服务
nssm install PetVideosBackend "D:\pet-videos\backend\venv\Scripts\python.exe" "D:\pet-videos\backend\main.py"
nssm set PetVideosBackend AppDirectory "D:\pet-videos\backend"
nssm start PetVideosBackend

REM 安装 Service 服务
nssm install PetVideosService "D:\pet-videos\backend\venv\Scripts\python.exe" "D:\pet-videos\service\app.py"
nssm set PetVideosService AppDirectory "D:\pet-videos\service"
nssm start PetVideosService
```

#### 方式 B：使用计划任务

```batch
REM 创建开机自启动任务
schtasks /create /tn "PetVideos" /tr "D:\pet-videos\start_all.bat" /sc onstart /ru SYSTEM
```

### 3. 防火墙配置

```batch
REM 允许端口 8002 (Backend)
netsh advfirewall firewall add rule name="Pet-Videos Backend" dir=in action=allow protocol=TCP localport=8002

REM 允许端口 8006 (Service)
netsh advfirewall firewall add rule name="Pet-Videos Service" dir=in action=allow protocol=TCP localport=8006

REM 允许端口 8173 (Frontend)
netsh advfirewall firewall add rule name="Pet-Videos Frontend" dir=in action=allow protocol=TCP localport=8173
```

### 4. 日志查看

```batch
REM 实时查看日志（使用 PowerShell）
powershell -command "Get-Content backend\logs\app.log -Wait -Tail 50"

REM 或使用 type（一次性查看）
type backend\logs\app.log

REM 查找错误
findstr /i "error" backend\logs\app.log
```

## 🔒 安全建议

### 1. 文件权限

```batch
REM 限制数据库文件访问
icacls backend\database\history.db /grant Administrators:F /inheritance:r

REM 限制 .env 文件访问
icacls backend\.env /grant Administrators:F /inheritance:r
icacls service\.env /grant Administrators:F /inheritance:r
```

### 2. 备份策略

创建自动备份任务：

```batch
REM backup_database.bat
@echo off
chcp 65001 >nul
set TIMESTAMP=%date:~0,4%%date:~5,2%%date:~8,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set TIMESTAMP=%TIMESTAMP: =0%
copy D:\pet-videos\backend\database\history.db D:\backups\history.db.%TIMESTAMP%

REM 保留最近 7 天的备份
forfiles /p "D:\backups" /s /m history.db.* /d -7 /c "cmd /c del @path"
```

创建计划任务（每天凌晨 2 点备份）：

```batch
schtasks /create /tn "PetVideos-Backup" /tr "D:\pet-videos\backup_database.bat" /sc daily /st 02:00
```

## 📊 性能优化

### 1. 禁用 Windows Defender 实时扫描（可选）

对项目目录添加排除项：

```batch
REM 以管理员身份运行
powershell -command "Add-MpPreference -ExclusionPath 'D:\pet-videos'"
```

### 2. 调整虚拟内存

如果服务器内存不足，增加虚拟内存：

- 控制面板 → 系统 → 高级系统设置 → 性能设置 → 高级 → 虚拟内存

### 3. 使用 SSD 存储数据库

将数据库和视频文件存储在 SSD 上以提高性能。

## ✅ 部署验证清单

- [ ] Python 3.8+ 已安装并在 PATH 中
- [ ] Node.js 16+ 已安装并在 PATH 中
- [ ] SQLite3 可用
- [ ] FFmpeg/FFprobe 已安装
- [ ] 端口 8002, 8006, 8173 未被占用
- [ ] 防火墙已配置允许端口
- [ ] 数据库已备份
- [ ] 迁移脚本执行成功
- [ ] 所有服务正常启动
- [ ] API 可以正常访问
- [ ] 前端页面正常显示
- [ ] FPS 值显示正常（10-30 范围）

## 📚 相关文档

- [通用部署指南](DEPLOY_LATEST.md)
- [数据库迁移指南](SERVER_MIGRATION_GUIDE.md)
- [FPS 修复说明](FPS_FIX.md)
- [表重命名说明](RENAME_VIDEO_PET_ANALYSIS.md)

## 🆘 技术支持

如遇到问题，请提供以下信息：

1. Windows 版本：`winver`
2. Python 版本：`python --version`
3. Node.js 版本：`node --version`
4. 错误日志：`type backend\logs\app.log`
5. 控制台输出截图
