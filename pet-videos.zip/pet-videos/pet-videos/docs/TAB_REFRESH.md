# Tab 切换自动刷新功能

## 问题

切换标签页时，数据不会自动刷新，导致看不到最新数据。

## 解决方案

### 修改内容

在 `frontend/src/App.tsx` 中为所有标签页添加了切换监听和数据刷新逻辑：

1. **添加状态管理**（为每个标签页添加刷新key）
```typescript
const [activeTab, setActiveTab] = useState<string>('analyze');
const [statsRefreshKey, setStatsRefreshKey] = useState(0);
const [historyRefreshKey, setHistoryRefreshKey] = useState(0);
const [promptsRefreshKey, setPromptsRefreshKey] = useState(0);
const [sourcesRefreshKey, setSourcesRefreshKey] = useState(0);
const [tasksRefreshKey, setTasksRefreshKey] = useState(0);
```

2. **添加 Tab 切换处理函数**（统一管理所有页面刷新）
```typescript
const handleTabChange = (key: string) => {
  setActiveTab(key);
  
  // 切换标签页时，根据不同页面执行刷新
  switch (key) {
    case 'analyze':
      // 刷新视频列表
      if (selectedAlias) {
        loadVideos(selectedAlias, videoPage, videoPageSize);
      }
      break;
    case 'stats':
      // 刷新切片统计
      setStatsRefreshKey(prev => prev + 1);
      break;
    case 'history':
      // 刷新调用历史
      setHistoryRefreshKey(prev => prev + 1);
      break;
    case 'prompts':
      // 刷新提示词管理
      setPromptsRefreshKey(prev => prev + 1);
      break;
    case 'sources':
      // 刷新源管理
      setSourcesRefreshKey(prev => prev + 1);
      break;
    case 'tasks':
      // 刷新任务监控
      setTasksRefreshKey(prev => prev + 1);
      break;
  }
};
```

3. **修改 Tabs 组件**
```typescript
<Tabs
  activeKey={activeTab}      // 添加：控制当前Tab
  onChange={handleTabChange}  // 添加：监听切换事件
  items={tabItems}
  size="large"
  style={{ padding: '0 24px' }}
/>
```

4. **为所有组件添加 key 属性**（强制刷新）
```typescript
<SliceStats key={statsRefreshKey} />
<History key={historyRefreshKey} />
<PromptManagement key={promptsRefreshKey} />
<SourceManagement key={sourcesRefreshKey} />
<TaskManagement key={tasksRefreshKey} />
```

### 工作原理

#### 视频分析页（analyze）
- 切换到此页面时，调用 `loadVideos()` 重新加载视频列表
- 会从服务器获取最新的视频数据

#### 其他所有页面（stats、history、prompts、sources、tasks）
- 切换到页面时，对应的 `refreshKey` 值 +1
- React 将带有新 key 的组件视为全新组件
- 触发组件重新 mount（卸载旧组件 → 创建新组件）
- 重新执行组件的 `useEffect` 钩子
- 从服务器获取最新数据

**原理示例**：
```
初始:  <SliceStats key={0} />
切换:  statsRefreshKey: 0 → 1
结果:  <SliceStats key={1} />  ← React认为这是新组件
效果:  组件完全重新加载，执行所有初始化逻辑
```

## 效果

✅ **视频分析** → 刷新视频列表（如果已选择目录）
✅ **切片统计** → 重新加载统计数据
✅ **调用历史** → 重新加载历史记录
✅ **提示词管理** → 重新加载提示词列表
✅ **源管理** → 重新加载源配置
✅ **任务监控** → 重新加载任务状态

## 使用场景

### 1. **录制新视频后**
```
服务器录制了新视频 → 切换到"视频分析"或"切片统计" → 看到最新视频
```

### 2. **修改提示词后**
```
在其他页面修改了提示词 → 切换到"提示词管理" → 看到最新列表
```

### 3. **启动/停止任务后**
```
修改了任务配置 → 切换到"任务监控" → 看到最新任务状态
```

### 4. **添加/编辑源后**
```
在系统中添加新的视频源 → 切换到"源管理" → 看到最新配置
```

### 5. **调用分析接口后**
```
分析了视频 → 切换到"调用历史" → 看到最新的调用记录
```

## 性能考虑

### 优点
✅ 保证数据实时性
✅ 用户体验好，无需手动点击刷新按钮
✅ 实现简单，维护方便

### 注意事项
⚠️ **频繁切换会产生多次API调用**
  - 这是预期行为，确保数据最新
  - 如果担心服务器压力，可以调整为手动刷新按钮

⚠️ **视频分析页只在已选择目录时刷新**
  - 如果没有选择目录，不会触发刷新
  - 避免不必要的API调用

⚠️ **组件状态会完全重置**
  - 表格排序、筛选等状态会丢失
  - 适合需要完全刷新的场景

## 技术细节

### 为什么使用 key 而不是调用刷新方法？

**使用 key 的优点**：
1. ✅ 简单：不需要在组件中暴露刷新方法
2. ✅ 完整：确保组件完全重新初始化
3. ✅ 一致：所有组件使用相同的刷新模式
4. ✅ 可靠：不会遗漏任何初始化逻辑

**缺点**：
- ❌ 状态重置：组件内部状态（如筛选、排序）会丢失
- ❌ 性能：整个组件树会重新渲染

**如果需要保留组件状态**，可以修改为调用组件的刷新方法：
```typescript
// 方案2：保留组件状态的刷新（需要修改子组件）
const historyRef = useRef<any>(null);
<History ref={historyRef} />
// 切换时调用: historyRef.current?.refresh()
```

### 刷新流程图

```
用户点击标签页
    ↓
handleTabChange(key)
    ↓
判断 key 类型
    ↓
├─ analyze → loadVideos() (API调用)
├─ stats → refreshKey + 1 → <Component key={newKey} /> (组件重建)
├─ history → refreshKey + 1 → <Component key={newKey} /> (组件重建)
├─ prompts → refreshKey + 1 → <Component key={newKey} /> (组件重建)
├─ sources → refreshKey + 1 → <Component key={newKey} /> (组件重建)
└─ tasks → refreshKey + 1 → <Component key={newKey} /> (组件重建)
    ↓
组件 useEffect 执行
    ↓
从服务器加载最新数据
    ↓
显示更新后的内容
```
