# FPS 异常值修复

## 📋 问题描述

前端视频列表显示异常高的 FPS 值，例如：
- `11078.0 FPS`
- `21367.0 FPS`
- `1000000.0 FPS`

正常的视频 FPS 应该在 10-30 之间。

## 🔍 问题原因

### 1. 视频元数据问题

视频文件包含两种帧率信息：

```json
{
  "r_frame_rate": "11078/1",        // 声明帧率（错误）
  "avg_frame_rate": "11587588/1175675",  // 实际帧率（正确）
  "time_base": "1/11078"
}
```

- **`r_frame_rate`** (declared frame rate): 声明的帧率，可能不准确
  - 例如：`11078/1 = 11078 FPS` ❌
  
- **`avg_frame_rate`** (actual frame rate): 实际平均帧率，更准确
  - 例如：`11587588/1175675 ≈ 9.86 FPS` ✅

### 2. 代码使用了错误的字段

原代码只使用 `r_frame_rate`：

```python
# 旧代码
fps_str = video_stream['r_frame_rate']
if '/' in fps_str:
    num, den = fps_str.split('/')
    fps = float(num) / float(den)  # 11078/1 = 11078 FPS ❌
```

## ✅ 解决方案

### 1. 修改 FPS 提取逻辑

**文件**: `backend/services/video_service.py`

```python
# 新代码：优先使用 avg_frame_rate，添加合理性校验
def parse_fps(fps_str: str) -> float:
    """解析帧率字符串"""
    if '/' in fps_str:
        num, den = fps_str.split('/')
        return float(num) / float(den) if float(den) != 0 else 0
    return float(fps_str)

# 尝试使用 avg_frame_rate（更准确）
fps = 0
if 'avg_frame_rate' in video_stream and video_stream['avg_frame_rate'] != '0/0':
    fps = parse_fps(video_stream['avg_frame_rate'])

# 如果 avg_frame_rate 不可用或异常，使用 r_frame_rate
if fps <= 0 or fps > 120:  # 合理性检查：FPS 应该在 0-120 之间
    if 'r_frame_rate' in video_stream:
        fps_candidate = parse_fps(video_stream['r_frame_rate'])
        # 只有在合理范围内才使用 r_frame_rate
        if 0 < fps_candidate <= 120:
            fps = fps_candidate
        else:
            # 如果两个都不合理，使用默认值
            logger.warning(f"Abnormal FPS detected, using default 10")
            fps = 10.0
```

### 2. 更新 ffprobe 命令

添加 `avg_frame_rate` 到查询字段：

```python
cmd = [
    'ffprobe', '-v', 'error',
    '-show_entries', 'format=duration,size,bit_rate,tags=creation_time',
    '-show_entries', 'stream=codec_name,width,height,r_frame_rate,avg_frame_rate,bit_rate,codec_type',
    '-of', 'json',
    video_path
]
```

### 3. 修复数据库中的旧数据

创建并执行修复脚本：

```bash
cd backend
python3 migrations/fix_abnormal_fps.py
```

**修复结果**：
- 总记录数: 111
- 成功修复: 57
- 跳过（文件不存在）: 54

## 📊 修复前后对比

| 视频文件 | 修复前 FPS | 修复后 FPS |
|---------|-----------|-----------|
| event_20260204_182445.mp4 | 11078.0 | 9.86 |
| event_20260204_152817.mp4 | 16404.0 | 20.62 |
| event_20260204_153015.mp4 | 13232.0 | 20.54 |
| event_20260204_154014.mp4 | 21367.0 | 20.35 |
| event_20260123_173149.mp4 | 1000000.0 | (文件已删除) |

## 🎯 效果

### 修复前
```
视频列表显示: 11078.0 FPS ❌
```

### 修复后
```
视频列表显示: 9.86 FPS ✅
```

## 🔧 相关文件

1. ✅ `backend/services/video_service.py` - 修改 FPS 提取逻辑
2. ✅ `backend/migrations/fix_abnormal_fps.py` - 修复脚本
3. ✅ `docs/FPS_FIX.md` - 本文档

## ⚠️ 注意事项

### 为什么会出现异常 FPS？

这是录制脚本写入视频元数据时的问题：
- PyAV 或 OpenCV 在某些情况下会错误地设置 `r_frame_rate`
- 可能与时间基准（timebase）的设置有关
- `r_frame_rate` 有时会被设置为时间基准的倒数（如 1/90000 → 90000 FPS）

### 如何避免？

1. **录制脚本改进**：确保正确设置视频流的帧率元数据
2. **提取时校验**：使用 `avg_frame_rate` 并添加合理性检查
3. **定期检查**：监控数据库中的 FPS 值，及时发现异常

## 📝 后续优化

如果需要从源头解决问题，可以检查录制脚本：

```python
# 在 pet_monitor_pyav_hvc1.py 中
self.output_stream.time_base = Fraction(1, 1000000)  # 可能导致问题
self.output_stream.rate = 10  # 应该明确设置帧率
```

建议：
1. 明确设置 `stream.rate` 或 `stream.average_rate`
2. 使用合理的 `time_base`（如 `1/10` 或 `1/30`）
3. 测试不同编码器的元数据写入行为

## ✅ 总结

- ✅ 修复了 FPS 提取逻辑，优先使用 `avg_frame_rate`
- ✅ 添加了合理性校验（0-120 FPS）
- ✅ 修复了数据库中 57 条异常记录
- ✅ 前端现在显示正确的 FPS 值
