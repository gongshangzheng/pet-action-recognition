# 登录问题排查指南

## 问题现象

从终端日志可以看到：
```
[Proxy] → POST /api/login → http://127.0.0.1:8002/api/login
[Proxy] ← 500 /api/login
```

**登录失败，后端返回 500 错误。**

## 根本原因

**后端启动异常**，虽然进程在运行（PID: 29699），但API请求都返回 500 错误。

常见原因：
1. **数据库初始化失败**
2. **环境变量加载失败**
3. **依赖包缺失或版本不兼容**
4. **配置文件错误**
5. **日志目录无法创建**

## 快速诊断

### 1. 检查后端进程

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos

# 查看后端进程
ps aux | grep "python.*main.py\|uvicorn" | grep -v grep

# 检查端口
lsof -i :8002
```

### 2. 查看后端日志

```bash
# 查看应用日志
tail -f logs/app.log

# 如果日志文件不存在，可能是日志目录未创建
mkdir -p logs
```

### 3. 手动重启后端

```bash
# 停止所有进程
pkill -f "python.*main.py"
pkill -f "uvicorn"

# 手动启动（前台运行，可以看到错误）
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos
python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8002 --reload
```

**观察启动时的错误信息**

### 4. 测试API可用性

```bash
# 测试健康检查
curl http://localhost:8002/docs

# 测试登录API
curl -X POST http://localhost:8002/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"petadmin@20260115"}'
```

## 常见问题和解决方案

### 问题1：ModuleNotFoundError

**错误信息**：
```
ModuleNotFoundError: No module named 'fastapi'
```

**解决方法**：
```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/backend

# 检查是否有虚拟环境
ls venv/

# 如果没有，创建虚拟环境
python3 -m venv venv

# 激活虚拟环境
source venv/bin/activate

# 安装依赖
pip install -r requirements.txt

# 重新启动后端
cd ..
python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8002 --reload
```

### 问题2：数据库错误

**错误信息**：
```
sqlite3.OperationalError: unable to open database file
```

**解决方法**：
```bash
# 创建数据库目录
mkdir -p database

# 检查权限
chmod 755 database

# 初始化数据库
python3 backend/models/database.py
```

### 问题3：环境变量未加载

**错误信息**：
```
KeyError: 'DASHSCOPE_API_KEY'
```

**解决方法**：
```bash
# 检查 .env 文件
cat .env

# 确保包含所有必要配置
grep -E "DASHSCOPE_API_KEY|ADMIN_USERNAME|ADMIN_PASSWORD|JWT_SECRET" .env

# 如果缺失，从模板复制
cp env.example .env
vim .env  # 编辑配置
```

### 问题4：端口被占用

**错误信息**：
```
OSError: [Errno 48] Address already in use
```

**解决方法**：
```bash
# 查找占用端口的进程
lsof -i :8002

# 杀死进程
kill -9 <PID>

# 或修改端口
# 编辑 .env 文件，修改 BACKEND_PORT
```

### 问题5：日志目录权限问题

**错误信息**：
```
PermissionError: [Errno 13] Permission denied: './logs/app.log'
```

**解决方法**：
```bash
# 创建日志目录
mkdir -p logs

# 设置权限
chmod 755 logs

# 测试写入
touch logs/test.log && rm logs/test.log
```

## 完整重启流程

### 方案1：使用启动脚本（推荐）

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos

# 停止所有服务
./stop_all.sh

# 等待2秒
sleep 2

# 启动所有服务
./start_all.sh

# 查看日志
tail -f logs/app.log
```

### 方案2：手动启动

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos

# 1. 停止旧进程
pkill -f "uvicorn.*backend.main"
pkill -f "vite"

# 2. 启动后端（新终端）
python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8002 --reload

# 3. 启动前端（另一个新终端）
cd frontend
npm run dev
```

## 详细诊断脚本

运行诊断脚本获取详细信息：

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos

# 运行诊断
python3 test/diagnose_backend.py
```

诊断脚本会检查：
- ✓ 后端端口是否监听
- ✓ API 是否响应
- ✓ 登录功能是否正常
- ✓ 环境变量是否配置
- ✓ 数据库文件是否存在
- ✓ 日志文件内容

## 登录凭证确认

当前配置的登录凭证（来自 `.env`）：

```env
ADMIN_USERNAME=admin
ADMIN_PASSWORD=petadmin@20260115
```

**前端登录时请使用**：
- 用户名：`admin`
- 密码：`petadmin@20260115`

## 前端代理配置

检查前端是否正确配置后端代理：

```bash
# 查看 vite 配置
cat frontend/vite.config.ts | grep -A 10 "proxy"
```

应该包含：
```typescript
proxy: {
  '/api': {
    target: 'http://127.0.0.1:8002',
    changeOrigin: true
  }
}
```

## 网络连接测试

```bash
# 测试后端连接
curl -v http://localhost:8002/docs

# 测试登录API
curl -v -X POST http://localhost:8002/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"petadmin@20260115"}'

# 测试健康检查
curl http://localhost:8002/
```

## 浏览器控制台检查

打开浏览器开发者工具（F12），查看：

### Network 标签
- 查看 `/api/login` 请求的响应
- 状态码：应该是 200，而不是 500
- 响应内容：应该包含 `access_token`

### Console 标签
- 查看是否有 JavaScript 错误
- 查看是否有 CORS 错误

## 终端5的错误分析

从终端日志可以看到：
```
启动后端...
后端进程 PID: 29699
启动前端...
```

**后端启动成功，但：**
```
[Proxy] → POST /api/login → http://127.0.0.1:8002/api/login
[Proxy] ← 500 /api/login
```

**说明**：
1. ✓ 后端进程正在运行
2. ✓ 前端可以连接到后端
3. ✗ 后端处理请求时发生错误（返回500）

**最可能的原因**：
- 数据库初始化失败
- 依赖包问题
- 配置加载错误

## 立即执行的检查步骤

```bash
# 1. 查看后端进程
ps aux | grep 29699

# 2. 手动测试登录
curl -X POST http://localhost:8002/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"petadmin@20260115"}' \
  -v

# 3. 如果返回500，查看错误详情
# 重启后端前台运行查看错误
pkill -f "uvicorn.*backend.main"
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos
python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8002 --reload
```

## 数据库初始化

如果是首次运行，需要初始化数据库：

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos

# 确保数据库目录存在
mkdir -p database

# 运行数据库初始化
python3 -c "
from backend.models.database import init_db
init_db()
print('数据库初始化成功')
"
```

## 检查Python环境

```bash
# 检查Python版本
python3 --version  # 应该是 3.8+

# 检查已安装的包
pip3 list | grep -E "fastapi|uvicorn|python-jose|passlib"

# 如果缺失，安装
pip3 install fastapi uvicorn python-jose[cryptography] passlib[bcrypt]
```

## 相关文档

- [ENV_CONFIG.md](ENV_CONFIG.md) - 环境配置详解
- [DEPLOY.md](DEPLOY.md) - 部署指南
- [SECURITY.md](SECURITY.md) - 安全配置

## 获取帮助

如果以上方法都无法解决，请提供：

1. **后端启动时的完整输出**（前台运行）
2. **日志文件内容**（`logs/app.log`）
3. **curl 测试的完整响应**
4. **Python版本和已安装的包**
   ```bash
   python3 --version
   pip3 list
   ```
5. **操作系统信息**
   ```bash
   uname -a
   ```
