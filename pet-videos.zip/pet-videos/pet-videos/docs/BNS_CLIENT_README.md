# BNS 服务客户端使用指南

## 📚 文件说明

| 文件 | 说明 | 适用场景 |
|------|------|---------|
| `bns_client.py` | **同步版本**（基于 `requests`） | 简单脚本、顺序执行、单次请求 |
| `bns_client_async.py` | **异步版本**（基于 `aiohttp`） | 高并发、批量请求、性能优化 |
| `test_bns_client.py` | 测试示例 | 学习参考 |

---

## 🤔 同步 vs 异步：如何选择？

### ✅ 使用同步版本（`bns_client.py`）的场景：

1. **简单脚本**：一次只发一个请求
2. **顺序执行**：请求之间有依赖关系
3. **快速测试**：代码简单直观，易于调试
4. **低并发**：请求量不大（< 10个/秒）

**示例代码：**
```python
from bns_client import get_bns_client

client = get_bns_client()
result = client.get_session_info(
    open_bduss='xxx',
    uri='/index.html'
)

if result['success']:
    print(result['data'])
```

### ✅ 使用异步版本（`bns_client_async.py`）的场景：

1. **高并发**：需要同时发送多个请求
2. **批量处理**：一次处理几十上百个请求
3. **性能优化**：减少总等待时间（I/O密集型）
4. **Web服务**：FastAPI、aiohttp 等异步框架

**示例代码：**
```python
import asyncio
from bns_client_async import get_async_bns_client

async def main():
    client = get_async_bns_client()
    
    # 并发执行3个请求
    tasks = [
        client.get_session_info(open_bduss='xxx', uri='/page1'),
        client.get_session_info(open_bduss='yyy', uri='/page2'),
        client.get_session_info(open_bduss='zzz', uri='/page3')
    ]
    
    results = await asyncio.gather(*tasks)
    for result in results:
        print(result['success'])

asyncio.run(main())
```

---

## 📊 性能对比

假设每个请求耗时 1 秒：

| 场景 | 同步方式 | 异步方式 |
|------|---------|---------|
| 1个请求 | 1秒 | 1秒 |
| 3个请求（串行） | 3秒 | 1秒（并发） |
| 10个请求（串行） | 10秒 | 1秒（并发） |
| 100个请求（串行） | 100秒 | ~2-3秒（并发） |

---

## 🚀 快速开始

### 方式1：同步方式（推荐新手）

```python
from bns_client import request_bns_service

# 方法1：直接调用
result = request_bns_service(
    service_name="smart.group.user-service.licai-licai",
    api_path="/user/getSessionInfo",
    uri="/index.html",
    params={
        'openBduss': 'your_token_here',
        'bduss': '',
        'from': 'pc'
    }
)

if result['success']:
    print("成功:", result['data'])
else:
    print("失败:", result['error'])
```

```python
from bns_client import get_bns_client

# 方法2：使用客户端对象
client = get_bns_client()

result = client.get_session_info(
    open_bduss='your_token_here',
    uri='/index.html'
)
```

### 方式2：异步方式（高并发场景）

```python
import asyncio
from bns_client_async import get_async_bns_client

async def main():
    client = get_async_bns_client()
    
    # 单个请求
    result = await client.get_session_info(
        open_bduss='your_token_here',
        uri='/index.html'
    )
    
    if result['success']:
        print(result['data'])

# 运行异步函数
asyncio.run(main())
```

### 方式3：异步批量请求

```python
import asyncio
from bns_client_async import batch_request

async def main():
    requests = [
        {
            'service_name': 'smart.group.user-service.licai-licai',
            'api_path': '/user/getSessionInfo',
            'uri': f'/page{i}',
            'params': {'openBduss': f'token_{i}'}
        }
        for i in range(10)  # 10个并发请求
    ]
    
    results = await batch_request(requests)
    
    success_count = sum(1 for r in results if r['success'])
    print(f"成功: {success_count}/{len(results)}")

asyncio.run(main())
```

---

## 🔧 完整参数说明

### `request` 方法参数

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| `service_name` | str | ✅ | - | BNS服务名 |
| `api_path` | str | ✅ | - | API路径 |
| `uri` | str | ✅ | - | 当前接口URI（业务上下文） |
| `params` | dict | ✅ | - | 请求参数 |
| `method` | str | ❌ | `"POST"` | 请求方法（GET/POST） |
| `timeout` | int | ❌ | `5` | 超时时间（秒） |
| `verbose` | bool | ❌ | `True` | 是否打印详细日志 |

### 返回值格式

```python
{
    "success": True,           # 请求是否成功
    "data": {...},            # 响应数据（成功时）
    "error": None,            # 错误信息（失败时）
    "status_code": 200,       # HTTP状态码
    "instance": "10.1.2.3:8080"  # 实际请求的服务实例
}
```

---

## 💡 常见问题

### Q1: `uri` 参数应该传什么？

**A:** `uri` 是业务上下文路径，不是接口本身的路径。

- ✅ **推荐**：`'/index.html'`（模拟从首页调用）
- ✅ **推荐**：`'/user/profile'`（模拟从个人中心调用）
- ✅ **测试**：`'/test'`（测试环境）
- ⚠️ **特殊**：`'/app/sso/token'`（会触发SSO双token逻辑）

### Q2: 同步版本能用在异步代码中吗？

**A:** 可以，但不推荐。如果必须在异步代码中使用同步客户端：

```python
import asyncio
from bns_client import get_bns_client

async def main():
    client = get_bns_client()
    
    # 在线程池中执行同步代码
    result = await asyncio.to_thread(
        client.get_session_info,
        open_bduss='xxx',
        uri='/index.html'
    )
```

### Q3: 如何处理请求失败？

```python
result = client.get_session_info(...)

if not result['success']:
    print(f"错误码: {result['status_code']}")
    print(f"错误信息: {result['error']}")
    print(f"失败实例: {result['instance']}")
    
    # 可以选择重试
    # result = client.get_session_info(...)
```

### Q4: 需要安装哪些依赖？

**同步版本：**
```bash
pip install noah_python_sdk requests
```

**异步版本：**
```bash
pip install noah_python_sdk aiohttp
```

---

## 📝 完整示例

### 同步版本完整示例

```python
from bns_client import get_bns_client
import time

def main():
    client = get_bns_client()
    
    # 获取会话信息
    result = client.get_session_info(
        open_bduss='your_token_here',
        uri='/index.html',
        from='pc',
        os='windows'
    )
    
    if result['success']:
        session_data = result['data']
        print(f"用户DID: {session_data.get('did')}")
        print(f"登录状态: {session_data.get('isLogin')}")
    else:
        print(f"请求失败: {result['error']}")

if __name__ == '__main__':
    main()
```

### 异步版本完整示例

```python
import asyncio
from bns_client_async import get_async_bns_client

async def main():
    client = get_async_bns_client()
    
    # 并发请求多个用户的信息
    tokens = ['token1', 'token2', 'token3']
    
    tasks = [
        client.get_session_info(
            open_bduss=token,
            uri=f'/batch_{i}',
            verbose=False
        )
        for i, token in enumerate(tokens)
    ]
    
    results = await asyncio.gather(*tasks)
    
    # 处理结果
    for i, result in enumerate(results):
        if result['success']:
            print(f"用户{i+1}: 成功")
        else:
            print(f"用户{i+1}: 失败 - {result['error']}")

if __name__ == '__main__':
    asyncio.run(main())
```

---

## 🎯 建议

1. **开发测试阶段**：使用同步版本，代码简单易调试
2. **生产环境低并发**：使用同步版本，稳定可靠
3. **生产环境高并发**：使用异步版本，性能更好
4. **批量数据处理**：使用异步版本 + `batch_request`

---

## 📞 技术支持

遇到问题？
1. 查看 `test_bns_client.py` 中的示例代码
2. 设置 `verbose=True` 查看详细日志
3. 检查 `result['error']` 获取错误信息
