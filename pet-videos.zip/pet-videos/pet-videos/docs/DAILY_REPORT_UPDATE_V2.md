# 日报生成功能升级 V2.0

## 概述

对宠物日报生成功能进行全面升级，优化输出格式和内容质量，增加标签和洞察建议功能。

## 升级内容

### 1. 数据库模型更新

**新增字段**：
- `daily_tag` (VARCHAR(50)): 日报标签（如：精力过剩、岁月静好、饭桶）
- `insight_text` (TEXT): 洞察建议

**表结构**：
```sql
ALTER TABLE daily_reports ADD COLUMN daily_tag VARCHAR(50);
ALTER TABLE daily_reports ADD COLUMN insight_text TEXT;
```

### 2. 提示词升级

**新版提示词特点**：
- **风格转变**：从专业严谨转为风趣幽默
- **格式要求**：
  - 摘要长度：50-80字
  - 使用 Markdown **加粗**标记关键事件（如：跑酷、进食、玩耍）
- **结构化输出**：严格的 JSON 格式
  ```json
  {
    "summary": "Markdown字符串，包含加粗的关键事件",
    "daily_tag": "标签字符串",
    "insight_text": "洞察建议字符串"
  }
  ```

**标签系统**：
- 精力过剩 / 岁月静好 / 饭桶 / 活力满满 / 懒洋洋 / 好奇宝宝 / 安静天使 / 调皮捣蛋

**洞察逻辑**：
- 跑步/玩耍时长 < 10分钟 → 建议增加互动
- 饮水次数 < 2次 → 建议增加饮水点
- 出现呕吐 → 建议健康检查
- 一切正常 → 夸奖并建议保持

### 3. 后端代码更新

#### 模型层 (models/database.py)
```python
class DailyReport(Base):
    # ... existing fields ...
    summary = Column(Text, nullable=True)  # Markdown格式
    daily_tag = Column(String(50), nullable=True)  # 新增
    insight_text = Column(Text, nullable=True)  # 新增
```

#### Schema层 (models/schemas.py)
```python
class DailyReportBase(BaseModel):
    summary: Optional[str] = Field(None, description="日报汇总内容（Markdown格式）")
    daily_tag: Optional[str] = Field(None, max_length=50, description="日报标签")
    insight_text: Optional[str] = Field(None, description="洞察建议")
```

#### 服务层 (services/daily_report_generator.py)
**关键改动**：
1. 提示词模板更新为 JSON 格式要求
2. `_generate_summary_with_llm_retry` 方法增强：
   - 解析 JSON 格式返回
   - 清理可能的 Markdown 代码块标记 (```json)
   - 验证必需字段 (`summary`, `daily_tag`, `insight_text`)
   - 返回字典对象或错误信息
3. `_generate_pet_daily_report` 方法更新：
   - 解析返回的字典对象
   - 分别存储到 `summary`, `daily_tag`, `insight_text` 字段

### 4. 前端UI更新

#### 表格列更新 (components/DailyReports/index.tsx)
**新增"标签"列**：
- 位置：生成状态列之后
- 宽度：120px
- 样式：不同标签显示不同颜色
  - 精力过剩: red
  - 岁月静好: green
  - 饭桶: orange
  - 活力满满: volcano
  - 懒洋洋: blue
  - 好奇宝宝: purple
  - 安静天使: cyan
  - 调皮捣蛋: magenta

#### 详情模态框升级
**结构调整**：
1. **今日标签卡片**（新增）
   - 居中展示标签
   - 大号字体（18px）
   - 彩色标签样式

2. **今日摘要卡片**（优化）
   - 标题从"日报内容"改为"今日摘要"
   - 支持 Markdown 加粗渲染（`**text**` → `<strong>text</strong>`）
   - 加粗文本使用蓝色高亮显示

3. **洞察建议卡片**（新增）
   - 带💡图标的标题
   - 使用 Alert 组件展示
   - Info 类型样式

### 5. 迁移脚本

**文件**：`migrations/migrate_add_daily_report_fields.py`

**功能**：
- 检查并添加 `daily_tag` 列
- 检查并添加 `insight_text` 列
- 验证迁移结果

**执行方式**：
```bash
cd backend
python3 migrations/migrate_add_daily_report_fields.py
```

## 使用的模型

**模型名称**：`qwen-plus` (通义千问Plus)

**配置方式**：
- 默认值：`qwen-plus`
- 可通过环境变量覆盖：`settings.daily_report_model`

## 向后兼容性

- 已有的 `summary` 字段保持不变
- 新字段 `daily_tag` 和 `insight_text` 默认为 NULL
- 旧日报数据不受影响，继续正常展示

## 测试建议

1. **数据库迁移验证**：
   ```bash
   sqlite3 database/history.db "PRAGMA table_info(daily_reports)"
   ```

2. **手动触发日报生成**：
   - 访问前端"宠物日报"页面
   - 点击"立即生成"按钮
   - 检查生成的日报是否包含标签和洞察建议

3. **前端展示验证**：
   - 表格中检查"标签"列是否正确显示
   - 点击"查看详情"，验证三个卡片是否正常展示
   - 检查加粗文本是否正确渲染

## 已知问题

无

## 后续优化方向

1. 提示词可配置化：将提示词存入数据库 `prompts` 表
2. 标签系统扩展：支持自定义标签和颜色映射
3. 洞察逻辑增强：基于更多行为数据的智能分析
4. 多语言支持：标签和洞察建议的国际化

## 更新日期

2026-01-23
