# env.example 更新日志

## 日期：2026-01-29

## 更新原因

根据当前 `.env` 实际配置，更新 `env.example` 模板文件，同时增强安全性和可读性。

## 主要变更

### 1. 增强分组和注释

**修改前**：
```env
# DashScope API Key
DASHSCOPE_API_KEY=your-api-key-here

# 登录配置
ADMIN_USERNAME=admin
```

**修改后**：
```env
# ==================== API 配置 ====================
# DashScope API Key - 用于调用阿里云通义千问视觉模型
# 获取地址: https://dashscope.console.aliyun.com/apiKey
DASHSCOPE_API_KEY=sk-your-api-key-here

# ==================== 登录安全配置 ====================
# 管理员用户名
ADMIN_USERNAME=admin
```

**优势**：
- 清晰的分组标识
- 详细的配置说明
- 包含获取地址等参考信息

### 2. 安全配置优化

#### API Key 格式改进

```diff
- DASHSCOPE_API_KEY=your-api-key-here
+ DASHSCOPE_API_KEY=sk-your-api-key-here
```

**说明**：使用更明确的占位符格式（`sk-` 前缀是实际 Key 的格式）

#### 密码安全提示

```diff
- ADMIN_PASSWORD=admin123
+ # 管理员密码（请修改为强密码！建议包含大小写字母、数字、特殊字符）
+ ADMIN_PASSWORD=your-strong-password-here
```

**优势**：
- 不使用弱密码示例（避免误用）
- 明确提示修改要求
- 给出强密码建议

#### JWT 密钥安全化

```diff
- JWT_SECRET=pet-videos-secret-key-2026
+ # JWT 密钥（用于生成访问令牌，请修改为随机字符串！）
+ # 生成建议: openssl rand -hex 32
+ JWT_SECRET=your-random-secret-key-here
```

**优势**：
- 不使用固定示例（避免安全风险）
- 提供生成命令
- 强调必须修改

### 3. 视频目录配置改进

**修改前**：
```env
VIDEO_DIRS=pet_videos:/Users/dxm/code/ai/pet/videos,records:/Users/dxm/code/ai/records,www:/Users/dxm/code/ai/www
```

**修改后**：
```env
# 格式：别名:路径，多个目录用逗号分隔
# 别名规则：只能包含字母、数字、下划线，用于API访问，不暴露真实路径
# 
# Mac/Linux 示例:
#   VIDEO_DIRS=camera1:/home/user/videos,camera2:/mnt/records,backup:/tmp/backup
# 
# Windows 示例:
#   VIDEO_DIRS=camera1:D:\Videos,camera2:E:\Records,nvr:F:\NVR
#
VIDEO_DIRS=camera1:/path/to/videos1,camera2:/path/to/videos2
```

**优势**：
- 移除真实路径（避免泄露）
- 提供跨平台示例
- 使用通用占位符

### 4. 端口配置更新

```diff
- BACKEND_PORT=8000
+ BACKEND_PORT=8002
```

**说明**：与实际使用的端口保持一致

### 5. 增强所有配置项的说明

每个配置项都增加了：
- 用途说明
- 可选值说明
- 格式要求
- 注意事项

**示例**：
```env
# ==================== 日志配置 ====================
# 日志级别: DEBUG, INFO, WARNING, ERROR, CRITICAL
LOG_LEVEL=INFO

# 日志文件路径（相对于项目根目录）
LOG_FILE=./logs/app.log
```

## 新增内容

### 1. 分组标识

使用 `====================` 分隔符清晰划分配置区域：

1. API 配置
2. 登录安全配置
3. 视频目录配置
4. 服务配置
5. 数据库配置
6. 日志配置
7. API 限制
8. CORS 配置

### 2. 详细注释

每个配置项都包含：
- **用途**：这个配置是干什么的
- **格式**：应该怎么填写
- **示例**：实际的配置例子（跨平台）
- **注意事项**：需要特别关注的地方

### 3. 安全提示

关键配置项包含安全警告：
```env
# 管理员密码（请修改为强密码！建议包含大小写字母、数字、特殊字符）
# JWT 密钥（用于生成访问令牌，请修改为随机字符串！）
```

## 配置对比表

| 配置项 | 旧值 | 新值 | 说明 |
|--------|------|------|------|
| `DASHSCOPE_API_KEY` | `your-api-key-here` | `sk-your-api-key-here` | 更明确的格式 |
| `ADMIN_PASSWORD` | `admin123` | `your-strong-password-here` | 避免弱密码示例 |
| `JWT_SECRET` | `pet-videos-secret-key-2026` | `your-random-secret-key-here` | 避免固定值 |
| `VIDEO_DIRS` | 包含真实路径 | 通用占位符 | 不泄露路径信息 |
| `BACKEND_PORT` | `8000` | `8002` | 与实际一致 |

## 新增文档

创建了详细的配置文档：`docs/ENV_CONFIG.md`

### 内容包括：

1. **配置项详解**
   - 每个配置项的详细说明
   - 可选值和格式要求
   - 示例和建议

2. **配置检查清单**
   - 必须修改的配置
   - 可选修改的配置
   - 通常不需要修改的配置

3. **安全建议**
   - 保护敏感配置的方法
   - 生产环境强化建议
   - 生成随机密钥的多种方法

4. **故障排查**
   - 常见问题和解决方法
   - 端口占用
   - CORS 错误
   - 视频目录访问
   - API Key 问题

5. **配置示例**
   - 开发环境完整配置
   - 生产环境完整配置

## 安全改进

### 1. 移除真实信息

**不再包含**：
- ❌ 真实的 API Key
- ❌ 真实的密码
- ❌ 真实的文件路径
- ❌ 固定的 JWT Secret

### 2. 使用安全占位符

**现在使用**：
- ✅ `sk-your-api-key-here` - 明确的格式提示
- ✅ `your-strong-password-here` - 强密码要求
- ✅ `your-random-secret-key-here` - 随机密钥要求
- ✅ `/path/to/videos` - 通用路径占位符

### 3. 增加安全警告

所有敏感配置都包含：
```env
# ⚠️ 这是敏感信息，不要提交到 Git！
# ⚠️ 生产环境必须使用强密码！
# ⚠️ 请修改为随机字符串！
```

## 使用指南

### 首次配置

```bash
# 1. 复制模板
cp env.example .env

# 2. 编辑配置
vim .env

# 3. 修改必要配置
# - DASHSCOPE_API_KEY: 填入真实 API Key
# - ADMIN_PASSWORD: 修改为强密码
# - JWT_SECRET: 生成随机密钥
# - VIDEO_DIRS: 配置实际视频目录

# 4. 生成 JWT 密钥（示例）
openssl rand -hex 32

# 5. 设置文件权限（Linux/Mac）
chmod 600 .env
```

### 配置验证

```bash
# 检查 .env 是否被 Git 忽略
git check-ignore .env
# 应该输出: .env

# 检查必要的配置项是否已设置
grep -E "^DASHSCOPE_API_KEY=sk-" .env
grep -E "^ADMIN_PASSWORD=.{12,}" .env
grep -E "^VIDEO_DIRS=.+:.+" .env
```

### 迁移旧配置

如果你有旧的 `.env` 文件：

```bash
# 1. 备份旧配置
cp .env .env.backup

# 2. 查看差异
diff .env env.example

# 3. 手动合并新配置项
vim .env

# 4. 验证配置
python backend/config.py  # 或启动服务测试
```

## 兼容性

### 向后兼容

✅ **所有配置项保持兼容**
- 配置项名称未改变
- 配置格式未改变
- 默认值保持合理

### 注意事项

⚠️ **端口变更**
- 如果之前使用 `BACKEND_PORT=8000`，现在改为 `8002`
- 需要更新前端 API 地址配置或使用新端口

## 验证测试

### 测试 1：敏感信息检查

```bash
$ grep -E "sk-[a-f0-9]{32}|petadmin|pet-videos-secret" env.example
# 应该无输出（不包含真实敏感信息）✓
```

### 测试 2：格式检查

```bash
$ cat env.example | grep "^[A-Z_]*=" | wc -l
13  # 13个配置项 ✓
```

### 测试 3：注释完整性

```bash
$ grep -c "^#" env.example
41  # 41行注释，详细说明 ✓
```

## 检查清单

部署前请确认：

### env.example 文件 ✅

- [x] 不包含真实 API Key
- [x] 不包含真实密码
- [x] 不包含真实路径
- [x] 不包含固定 JWT Secret
- [x] 包含详细注释说明
- [x] 包含跨平台示例
- [x] 包含安全警告

### 实际 .env 文件 ⚠️

使用前必须修改：
- [ ] `DASHSCOPE_API_KEY` - 填入真实值
- [ ] `ADMIN_PASSWORD` - 修改为强密码
- [ ] `JWT_SECRET` - 生成随机密钥
- [ ] `VIDEO_DIRS` - 配置实际路径

### 文档完整性 ✅

- [x] `env.example` - 配置模板
- [x] `docs/ENV_CONFIG.md` - 详细配置说明
- [x] `CHANGELOG_ENV.md` - 变更日志（本文档）
- [x] `.gitignore` - 确保 `.env` 被忽略

## 相关文档

- [env.example](env.example) - 配置模板文件
- [docs/ENV_CONFIG.md](docs/ENV_CONFIG.md) - 详细配置说明（新增）
- [docs/SECURITY.md](docs/SECURITY.md) - 安全配置指南
- [docs/DEPLOY.md](docs/DEPLOY.md) - 部署指南
- [.gitignore](.gitignore) - Git 忽略规则

## 更新记录

| 日期 | 版本 | 说明 |
|------|------|------|
| 2026-01-29 | v2.0 | 重大更新：增强安全性、详细注释、新增配置文档 |
| 2026-01-15 | v1.0 | 初始版本 |

---

**注意**：更新后请记得：
1. 复制 `env.example` 为 `.env`
2. 填入真实配置值
3. 确保 `.env` 不被提交到 Git
4. 阅读 `docs/ENV_CONFIG.md` 了解详细配置
