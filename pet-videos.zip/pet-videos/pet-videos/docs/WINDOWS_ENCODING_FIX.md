# Windows 编码问题修复指南

## 问题现象

执行 `run_server_migration.bat` 时出现乱码，如下图所示：

```
'server_history.db' 不是内部或外部命令，也不是可运行的程序
或批处理文件。
't' 不是内部或外部命令，也不是可运行的程序
或批处理文件。
```

## 问题原因

Windows 批处理文件（.bat）对 UTF-8 编码支持不完善：
- 需要 **UTF-8 with BOM** 编码
- 控制台默认使用 GBK 编码
- 文件可能是 UTF-8 without BOM

## 解决方案

### ✅ 方案 1：使用 PowerShell（最推荐）

PowerShell 对 UTF-8 支持更好，完全避免编码问题。

```powershell
# 进入 backend 目录
cd D:\pet-videos\backend

# 执行 PowerShell 迁移脚本
powershell -ExecutionPolicy Bypass -File run_server_migration.ps1
```

**优点**：
- ✅ 无编码问题
- ✅ 彩色输出
- ✅ 更好的错误处理

---

### ✅ 方案 2：使用简化版 BAT（无中文）

使用完全英文的批处理脚本，避免中文编码问题。

```batch
cd D:\pet-videos\backend
run_server_migration_simple.bat
```

**优点**：
- ✅ 无编码问题
- ✅ 兼容性好
- ✅ 无需 PowerShell

---

### ⚠️ 方案 3：手动执行 Python 脚本

直接执行 Python 脚本，跳过批处理。

```batch
cd D:\pet-videos\backend

REM 设置数据库路径
set DATABASE_PATH=database\server_history.db

REM 手动执行每个迁移脚本
python migrations\migrate_add_did_to_stream_sources.py
python migrations\migrate_unify_video_records.py
python migrations\migrate_add_pets_table.py
python migrations\migrate_add_weight_to_pets.py
python migrations\migrate_add_avatar_color_to_pets.py
python migrations\migrate_add_video_pet_analysis_table.py
python migrations\migrate_rename_video_pet_analysis_to_pet_behaviors.py
python migrations\migrate_add_daily_reports_table.py

REM 修复 FPS
python migrations\fix_abnormal_fps.py
```

**优点**：
- ✅ 完全避免批处理问题
- ✅ 可以看到每个脚本的详细输出

**缺点**：
- ❌ 需要手动执行多条命令
- ❌ 没有自动备份

---

### 方案 4：修复 BAT 文件编码

如果必须使用原版 `.bat` 文件，需要修复编码。

#### 步骤 1：使用记事本打开

```batch
notepad D:\pet-videos\backend\run_server_migration.bat
```

#### 步骤 2：另存为 UTF-8 with BOM

1. 点击 **文件** → **另存为**
2. 在 **编码** 下拉框中选择 **UTF-8**（注意：不是 UTF-8 without BOM）
3. 点击 **保存**，覆盖原文件

#### 步骤 3：重新执行

```batch
cd D:\pet-videos\backend
run_server_migration.bat
```

---

## 快速对比

| 方案 | 难度 | 推荐度 | 优点 | 缺点 |
|------|------|--------|------|------|
| PowerShell | ⭐ | ⭐⭐⭐⭐⭐ | 无编码问题，功能完整 | 需要 PowerShell |
| 简化版 BAT | ⭐ | ⭐⭐⭐⭐ | 无编码问题，兼容性好 | 输出是英文 |
| 手动执行 Python | ⭐⭐ | ⭐⭐⭐ | 完全避免批处理 | 命令多，无自动备份 |
| 修复编码 | ⭐⭐⭐ | ⭐⭐ | 保留原版功能 | 操作复杂，可能失败 |

---

## 推荐流程

### Windows Server 2016 部署流程

```powershell
# 1. 进入项目目录
cd D:\pet-videos

# 2. 备份数据库（手动）
copy backend\database\history.db backend\database\history.db.backup.20260204

# 3. 停止服务
stop_all.bat

# 4. 执行迁移（使用 PowerShell）
cd backend
powershell -ExecutionPolicy Bypass -File run_server_migration.ps1

# 5. 修复 FPS
python migrations\fix_abnormal_fps.py

# 6. 返回根目录并启动服务
cd ..
start_all.bat

# 7. 验证
curl http://localhost:8002/api/sources/
```

---

## 常见错误及解决

### 错误 1：PowerShell 执行策略限制

```
无法加载文件，因为在此系统上禁止运行脚本
```

**解决**：
```powershell
# 临时允许执行
powershell -ExecutionPolicy Bypass -File run_server_migration.ps1

# 或永久设置（管理员权限）
Set-ExecutionPolicy RemoteSigned
```

### 错误 2：找不到 Python

```
'python' 不是内部或外部命令
```

**解决**：
```batch
REM 检查 Python 安装
where python

REM 使用完整路径
C:\Python39\python.exe migrations\migrate_*.py

REM 或添加到 PATH
set PATH=%PATH%;C:\Python39
```

### 错误 3：数据库文件不存在

```
Database file not found: database\server_history.db
```

**解决**：
```batch
REM 检查文件是否存在
dir backend\database\

REM 如果是首次部署，创建目录
mkdir backend\database

REM 如果是迁移，确保数据库文件在正确位置
```

---

## 验证部署成功

执行以下命令验证：

```batch
REM 检查数据库表
sqlite3 backend\database\history.db ".tables"

REM 应该看到：
REM   pet_behaviors
REM   pets
REM   daily_reports
REM   video_records
REM   stream_sources

REM 检查服务
curl http://localhost:8002/api/sources/
curl http://localhost:8006/api/sources/

REM 检查 FPS 是否正常（应该在 10-30 范围）
sqlite3 backend\database\history.db "SELECT file_name, fps FROM video_records WHERE fps > 100 LIMIT 5;"
REM 应该没有结果或很少
```

---

## 总结

**最佳实践**：
1. ✅ 使用 **PowerShell 脚本**（`run_server_migration.ps1`）
2. ✅ 或使用 **简化版 BAT**（`run_server_migration_simple.bat`）
3. ❌ 避免使用原版 BAT（除非修复编码）

**记住**：
- Windows Server 2016 完全支持 PowerShell
- PowerShell 对 UTF-8 支持更好
- 批处理文件编码问题是 Windows 的历史遗留问题
