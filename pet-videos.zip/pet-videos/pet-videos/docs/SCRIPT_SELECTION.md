# 脚本文件选择功能

## 功能说明

任务管理现在支持为每个切片任务选择不同的 Python 脚本文件。这允许您为不同的摄像头源使用不同的处理逻辑。

## 使用方法

### 1. 新建任务时选择脚本

1. 打开 **系统管理 → 任务监控**
2. 点击 **新建任务** 按钮
3. 在表单中：
   - 选择摄像头源
   - **选择脚本文件**（从 `scripts` 目录）
   - 选择检测模式（宠物检测/运动检测）
4. 点击确定，任务将使用选定的脚本启动

### 2. 查看任务使用的脚本

在任务列表中，**脚本文件** 列显示每个任务当前使用的脚本名称。

### 3. 修改任务脚本

- 停止任务
- 重新启动时会使用数据库中保存的脚本文件
- 如需更换脚本，需要先删除任务，然后新建任务并选择新的脚本

## 添加自定义脚本

### 脚本要求

所有可选的脚本必须：

1. **位置**：放在 `scripts/` 目录下
2. **扩展名**：必须是 `.py` 文件
3. **第一行注释**：添加描述性注释（可选，但推荐）

```python
# 脚本描述 - 简短说明脚本的功能

import ...
```

### 脚本接口规范

脚本应该接受以下命令行参数：

```python
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--source-id', type=int, required=True, help='Stream source ID')
parser.add_argument('--stream-url', type=str, required=True, help='RTSP stream URL')
parser.add_argument('--save-dir', type=str, required=True, help='Video save directory')
parser.add_argument('--model', type=str, default='yolov13n.pt', help='YOLO model path')
parser.add_argument('--api-base-url', type=str, required=True, help='Backend API base URL')
parser.add_argument('--enable-yolo', action='store_true', help='Enable YOLO detection')
args = parser.parse_args()
```

### 脚本示例

**`scripts/custom_monitor.py`:**

```python
# 自定义监控脚本 - 使用不同的检测算法

import cv2
import argparse
# ... 其他导入 ...

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-id', type=int, required=True)
    parser.add_argument('--stream-url', type=str, required=True)
    parser.add_argument('--save-dir', type=str, required=True)
    parser.add_argument('--api-base-url', type=str, required=True)
    parser.add_argument('--enable-yolo', action='store_true')
    args = parser.parse_args()
    
    # 您的自定义逻辑
    print(f"开始监控 source_id={args.source_id}")
    # ...

if __name__ == "__main__":
    main()
```

### 心跳和视频记录

脚本需要定期：

1. **发送心跳**：每 10 秒调用心跳 API
   ```python
   import requests
   response = requests.post(
       f"{api_base_url}/tasks/{source_id}/heartbeat",
       timeout=5,
       proxies={'http': None, 'https': None}
   )
   ```

2. **记录视频**：每次录制完成后通知后端
   ```python
   response = requests.post(
       f"{api_base_url}/videos/record",
       json={
           "source_id": source_id,
           "filename": filename,
           "dir_alias": dir_alias
       },
       timeout=5,
       proxies={'http': None, 'https': None}
   )
   ```

## 数据库变更

### 数据库迁移

**首次部署时需要运行迁移：**

```bash
cd /path/to/pet-videos
python backend/migrations/add_script_file_to_tasks.py
```

这将在 `slicing_tasks` 表中添加 `script_file` 字段。

### 字段说明

- **script_file** (VARCHAR(200), NOT NULL, DEFAULT 'pet_monitor.py')
  - 任务使用的 Python 脚本文件名
  - 默认值为 `pet_monitor.py`

## API 更新

### 获取可用脚本

```http
GET /api/tasks/scripts
```

**响应：**

```json
[
  {
    "filename": "pet_monitor.py",
    "path": "/path/to/scripts/pet_monitor.py",
    "description": "宠物监控脚本 - 支持宠物检测(YOLO)和运动检测，使用H.264编码"
  },
  {
    "filename": "custom_monitor.py",
    "path": "/path/to/scripts/custom_monitor.py",
    "description": "自定义监控脚本"
  }
]
```

### 启动任务（更新）

```http
POST /api/tasks/{source_id}/start
Content-Type: application/json

{
  "enable_yolo": true,
  "script_file": "pet_monitor.py"
}
```

## 常见问题

### Q: 如何更换任务的脚本？

**A:** 目前需要删除任务并重新创建。未来可能添加"编辑任务"功能。

### Q: 脚本出错怎么办？

**A:** 任务状态会显示为"异常"，可以查看错误信息。检查：
1. 脚本文件是否存在
2. 脚本语法是否正确
3. 依赖是否安装
4. 日志文件 `backend/logs/tasks/task_{source_id}.log`

### Q: 可以动态加载脚本吗？

**A:** 是的！新添加的 `.py` 文件会立即出现在脚本选择列表中，无需重启后端。

### Q: 脚本需要使用虚拟环境吗？

**A:** 是的，所有脚本都在 `backend/venv` 虚拟环境中运行。确保所需的依赖已安装在虚拟环境中。

```bash
backend/venv/Scripts/pip.exe install your-package  # Windows
backend/venv/bin/pip install your-package          # Linux/macOS
```

## 部署检查清单

- [ ] 运行数据库迁移脚本
- [ ] 确认 `scripts/` 目录存在
- [ ] 确认 `pet_monitor.py` 在 `scripts/` 目录
- [ ] 重启后端服务
- [ ] 刷新前端页面
- [ ] 测试创建任务时可以看到脚本选择器
- [ ] 测试任务列表显示脚本文件名

## 技术细节

### 后端改动

1. **数据库模型** (`backend/models/database.py`)
   - `SlicingTask` 添加 `script_file` 字段

2. **API 路由** (`backend/api/tasks.py`)
   - `GET /api/tasks/scripts` - 获取脚本列表
   - `POST /api/tasks/{source_id}/start` - 接受 `script_file` 参数

3. **任务服务** (`backend/services/task_service.py`)
   - `start_task()` 使用 `task.script_file` 启动脚本

### 前端改动

1. **类型定义** (`frontend/src/types/index.ts`)
   - `SlicingTask` 添加 `script_file` 字段
   - 新增 `ScriptFileInfo` 接口

2. **API 服务** (`frontend/src/services/api.ts`)
   - `getAvailableScripts()` - 获取脚本列表
   - `startTask()` - 添加 `scriptFile` 参数

3. **任务管理组件** (`frontend/src/components/System/TaskManagement.tsx`)
   - 表格添加"脚本文件"列
   - 新建任务表单添加脚本选择器
   - 加载并显示可用脚本

---

**更新日期：** 2026-01-21  
**版本：** v1.5.0
