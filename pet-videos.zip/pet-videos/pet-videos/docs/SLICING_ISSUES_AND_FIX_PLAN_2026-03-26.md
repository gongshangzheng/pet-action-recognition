# 切片问题分析与修复清单（2026-03-26）

## 背景
线上切片任务脚本：`scripts/pet_monitor_pyav_hvc1.py`

本文件用于记录当前已确认问题、可能根因、修复优先级与执行清单，防止对话中断导致信息丢失。

## 当前进展（已实施）

已在 `scripts/pet_monitor_pyav_hvc1.py` 完成一轮修复（仅改单脚本）：

1. 调参缓解
- `MOTION_THRESHOLD`: `4000 -> 2500`
- `PRE_BUFFER_SECONDS`: `15 -> 6`
- `MOTION_TRIGGER_COOLDOWN`: `180 -> 30`
- `AI_CHECK_INTERVAL`: `2.0 -> 1.0`

2. 卡顿/跳帧根因修复（结构改动）
- 录制与检测不再共享同一 `packet` 对象（decode 侧使用独立 packet 副本）
- `mux_queue` 满时不再静默丢包，改为背压等待并输出告警日志
- 心跳上报改为异步线程触发，避免阻塞录制主循环

3. 新增排查日志指标
- `mux_backpressure`（录制队列背压次数）
- `decode_drop`（检测队列丢弃数）
- `decode_clone_fail`（检测副本创建失败数）
- `invalid_skip`（无效 packet 跳过数）
- `write_fail`（mux 写入失败数）
- `first_cat_frame_sec`（录制开始后首次新检测时延）

## 用户反馈问题汇总

### 1) 视频播放卡顿 / 掉帧
现象：
- 点开视频后画面静止，时间戳不动
- 过十几秒突然跳到后续画面（如猫突然闪现/消失）
- 新生成切片更容易出现

用户原话：
- “点开之后会一直不动，上面的时间也是不动的，隔十几秒突然跳到另一个视频。”

### 2) 关键瞬间漏抓
现象：
- 想看猫飞奔去猫粮机过程，但没抓到
- 反而抓到了吃完慢悠悠回来

用户原话：
- “我想看他飞奔的过程，但没抓到。”
- “对着门，猫从门里跑出来跑到猫粮机那没有抓，吃完往回走慢悠悠走回去才抓。”

### 3) 视频前几秒无猫画面
现象：
- 视频前 6-10 秒经常无猫，之后猫才进入镜头
- 体验上像“切片起点不对”

用户原话：
- “每次看视频的时候，可能前面几秒都是没有小猫脸的。”
- “基本上会过个五六秒小猫才会到镜头里。”

### 4) 通知推送问题（安卓）
现象：
- 通知中心无推送
- 打开 APP 后一次性弹出未读通知

已知信息：
- 安卓已知问题
- 当前只接云推，未接厂商通道，保活能力弱
- 需要用户手动锁定 APP 防止系统杀进程

## 当前代码层面结论（与反馈的对应关系）

### A. 卡顿/跳帧的高风险根因（P0）
1. `mux_queue` 满时静默丢包
- 位置：`scripts/pet_monitor_pyav_hvc1.py`（`self.mux_queue.put(packet, timeout=0.1)` 失败直接 `pass`）
- 影响：录制链路丢包（尤其关键帧相关包）后，播放器可能表现为“画面不动后跳变”。

2. 录制与检测共享同一 `packet` 对象
- 位置：同脚本双队列架构，`decode` 与 `mux` 共享原始 packet
- 已知：项目文档 `docs/PACKET_STREAM_FIX.md` 已说明 `decode(packet)` 会破坏包状态（如 `packet.stream`）。
- 影响：mux 时跳过坏包/写入失败，增加时间轴不连续概率。

3. 主循环内同步心跳请求
- 位置：`update_heartbeat()` 在主循环中调用，`requests.post(..., timeout=5)`
- 影响：网络抖动会阻塞主循环，reader 继续进包，队列更容易满并丢包。

### B. 漏抓关键瞬间的高风险根因（P0）
1. 触发链路延迟
- 机制：先运动检测，再 YOLO；`AI_CHECK_INTERVAL=2.0s`
- 影响：猫快速冲刺类短瞬时动作容易在采样间隔内漏掉。

2. 冷却时间过长
- 当前 `MOTION_TRIGGER_COOLDOWN=180s`（hvc1 版本）
- 影响：短时间内第二次事件被抑制，容易“去程没抓，回程才抓”。

3. 运动阈值偏高
- 当前 `MOTION_THRESHOLD=4000`
- 影响：远景小目标/局部快速移动可能触发不到。

### C. 前几秒无猫的主要原因（P1）
- 当前前摇 `PRE_BUFFER_SECONDS=15`，触发后会回写前摇缓存
- 这是“防漏抓策略”的副作用：更稳但会带来空镜头前段。

### D. 通知问题定位（与切片解耦）
- 安卓推送问题主要在客户端通道与保活，不是切片脚本主因。
- 服务端还存在静默时段与冷却策略，会影响“实时到达感”。

## 修复清单（优先级）

### P0（先止血）
1. 消除录制链路静默丢包
- `mux_queue` 满时不再 `pass` 静默丢弃
- 优先保证录制链路，必要时只丢检测侧数据
- 增加明确日志与计数指标（drop counters）

2. 解除共享 packet 并发风险
- 不再让 `decode` 与 `mux` 共享同一 packet 对象
- 方案可选：
  - 检测侧使用独立副本/字节重建
  - 或检测侧改独立拉流（资源更高）

3. 心跳从主录制循环剥离
- 改异步线程/定时器上报心跳，避免阻塞 mux 主循环

4. 降低漏抓概率参数（先给默认值）
- `MOTION_TRIGGER_COOLDOWN`: 180 -> 30（建议起步）
- `AI_CHECK_INTERVAL`: 2.0 -> 0.5~1.0（按设备压测）
- `MOTION_THRESHOLD`: 4000 -> 2000~3000（按机位调参）

### P1（体验优化）
5. 缩短空镜头前段
- `PRE_BUFFER_SECONDS`: 15 -> 5~8（建议默认 6）
- 增加“动态前摇裁剪”策略（可选）

6. 参数化与后端透传
- 将以下参数从脚本常量改为任务配置可下发：
  - pre_buffer_seconds
  - post_event_seconds
  - motion_cooldown
  - ai_check_interval
  - motion_threshold
- 避免每次改代码上线调参

7. 增强观测性
- 新增指标/日志：
  - `mux_queue_drop`
  - `decode_queue_drop`
  - `packet_invalid_skip`
  - `record_start_delay_ms`
  - `first_cat_frame_sec`

### P2（并行项）
8. 安卓通知专项
- 客户端接入厂商通道 + 保活策略
- 服务端补发送失败重试与送达监控看板

## 发布建议
1. 先灰度 1~2 路摄像头，观察 24 小时
2. 对比灰度前后关键指标：
- 卡顿投诉数
- 漏抓投诉数
- 平均前空镜秒数
- 推送到达率（安卓）
3. 再逐步全量

## 建议执行顺序
1. P0-1/2/3（链路稳定性）
2. P0-4（漏抓快速改善）
3. P1-5/6/7（体验和可运维性）
4. P2-8（安卓通知专项）

## 相关代码位置
- `scripts/pet_monitor_pyav_hvc1.py`
- `backend/services/task_service.py`
- `backend/api/tasks.py`
- `backend/models/database.py`
- `backend/models/schemas.py`
- `backend/services/push_notification_service.py`
- `service/push_service.py`
- `docs/PACKET_STREAM_FIX.md`
