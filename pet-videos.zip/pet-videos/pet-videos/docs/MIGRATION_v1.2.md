# Pet-Videos v1.2 安全架构升级指南

## 版本: v1.2.0 - 别名系统

### 🔒 核心改进

**不再直接传递路径，使用目录别名系统**

#### 改进前 (v1.1.x)
```
❌ API参数直接暴露服务器路径
GET /api/videos?directory=D:\video_demo01
GET /api/video/stream?token=base64(D:\video_demo01\file.mp4)
```

#### 改进后 (v1.2.0)
```
✅ 使用别名，完全隐藏服务器路径
GET /api/videos?alias=demo1
GET /api/video/stream?token=base64(demo1:file.mp4)
```

---

## 📝 配置文件变更

### 旧格式 (.env)
```ini
# 直接配置路径（不安全）
VIDEO_DIRS=D:\Videos,E:\Records
```

### 新格式 (.env) - 必须使用别名
```ini
# 格式: 别名:路径
# 别名只能包含: 字母、数字、下划线
VIDEO_DIRS=camera1:D:\Videos,camera2:E:\Records,demo:D:\demo_videos
```

**别名规则**：
- ✅ 允许: `demo1`, `camera_1`, `test_dir`
- ❌ 禁止: `中文别名`, `demo-1`, `demo.1`

### 向后兼容（可选）

如果不想立即修改，旧格式仍然支持（自动生成别名）：
```ini
VIDEO_DIRS=D:\Videos,E:\Records
# 自动生成: dir1 -> D:\Videos, dir2 -> E:\Records
```

---

## 🔧 API变更

### 1. 目录列表API

#### 旧API (v1.1.x)
```json
GET /api/directories

响应:
{
  "path": "D:\\Videos",
  "name": "Videos",
  "video_count": 10,
  "exists": true
}
```

#### 新API (v1.2.0)
```json
GET /api/directories

响应:
{
  "alias": "camera1",
  "name": "Videos",
  "video_count": 10,
  "exists": true
}
```

**变更点**：
- ❌ 移除: `path` 字段
- ✅ 新增: `alias` 字段

### 2. 视频列表API

#### 旧API
```
GET /api/videos?directory=D:\Videos&page=1&page_size=10
```

#### 新API
```
GET /api/videos?alias=camera1&page=1&page_size=10
```

**变更点**：
- ❌ 移除: `directory` 参数
- ✅ 新增: `alias` 参数

### 3. 视频播放API

#### 旧Token格式
```
Token内容: base64(D:\Videos\test.mp4) + 签名
解码后: D:\Videos\test.mp4 (暴露路径)
```

#### 新Token格式
```
Token内容: base64(camera1:test.mp4) + 签名
解码后: camera1:test.mp4 (只有别名)
```

**变更点**：
- Token不再包含完整路径
- Token包含: `别名:文件名`

### 4. 视频信息返回

####旧格式
```json
{
  "filename": "test.mp4",
  "path": "D:\\Videos\\test.mp4",
  "stream_token": "..."
}
```

#### 新格式
```json
{
  "filename": "test.mp4",
  "dir_alias": "camera1",
  "path": "D:\\Videos\\test.mp4",  // 仅后端使用，前端应忽略
  "stream_token": "..."  // 基于alias:filename生成
}
```

**变更点**：
- ✅ 新增: `dir_alias` 字段
- ⚠️ `path` 字段保留（仅后端分析用，前端不使用）

---

## 🚫 文件类型限制

### v1.2.0 只允许 MP4 文件

```python
# 旧配置 (v1.1.x)
ALLOWED_VIDEO_EXTENSIONS = {'.mp4', '.avi', '.mkv', ...}

# 新配置 (v1.2.0)
ALLOWED_VIDEO_EXTENSIONS = {'.mp4'}  # 只允许MP4
```

**非MP4文件将被拒绝**：
- 播放API: 403 Forbidden
- 视频列表: 自动过滤
- 上传功能: 403 Forbidden

**如需支持其他格式**：
修改 `backend/utils/security.py` 中的 `ALLOWED_VIDEO_EXTENSIONS`

---

## 📊 安全性对比

| 功能 | v1.1.x | v1.2.0 |
|------|--------|--------|
| 路径暴露 | ⚠️ Token可解码出路径 | ✅ 只暴露别名 |
| API参数 | ⚠️ 直接传递路径 | ✅ 传递别名 |
| 目录遍历 | ✅ 白名单验证 | ✅ 别名验证 |
| 文件类型 | ✅ 多格式支持 | ✅ 仅MP4 |
| 路径穿越 | ✅ 防护 | ✅ 增强防护 |

---

## 🔄 迁移步骤

### 步骤1: 更新代码（开发环境）

```bash
# Mac/Linux
cd /path/to/pet-videos
git pull  # 或解压新版本源码
```

### 步骤2: 更新配置文件

编辑 `.env` 文件：

```ini
# 旧配置
VIDEO_DIRS=D:\Videos,E:\Records

# 改为新配置（添加别名）
VIDEO_DIRS=camera1:D:\Videos,camera2:E:\Records
```

### 步骤3: 重启服务

```bat
# Windows
stop_all.bat
start_all.bat
```

### 步骤4: 验证

1. 访问 `http://localhost:5173`
2. 查看目录列表（应显示别名而不是路径）
3. 选择视频播放（检查是否正常）
4. 查看网络请求（URL中应该只有别名）

---

## 🧪 测试Token系统

```bash
cd backend
source venv/bin/activate  # Mac/Linux
# 或 call venv\Scripts\activate.bat  # Windows

python3
```

```python
from utils.security import encode_video_token, decode_video_token

# 生成Token
token = encode_video_token("camera1", "test.mp4")
print(f"Token: {token}")
# 输出: Y2FtZXJhMTp0ZXN0Lm1wNA==.a1b2c3d4e5f6g7h8

# 解码Token
alias, filename = decode_video_token(token)
print(f"别名: {alias}, 文件名: {filename}")
# 输出: 别名: camera1, 文件名: test.mp4

# ✅ 不再暴露完整路径！
```

---

## ⚠️ 重要提示

### 前端改动（如果自定义了前端）

需要修改前端代码：

```typescript
// 旧代码
getVideos(directory: string)  // 传递路径

// 新代码
getVideos(alias: string)  // 传递别名
```

```typescript
// 类型定义更新
interface DirectoryInfo {
  alias: string;  // 新增
  name: string;
  video_count: number;
}

interface VideoInfo {
  filename: string;
  dir_alias: string;  // 新增
  stream_token: string;
  // ...其他字段
}
```

### 数据库无需迁移

历史记录表无需修改，继续使用`path`字段存储完整路径（用于分析）。

### 与旧版本的兼容性

- ✅ 配置向后兼容（旧格式自动转换）
- ✅ Token系统向后兼容（优先使用新格式）
- ⚠️ API参数不兼容（必须使用别名）

---

## 📋 配置示例

### 开发环境 (.env.example)
```ini
VIDEO_DIRS=pet_videos:/Users/dxm/code/ai/pet/videos,records:/Users/dxm/code/ai/records
```

### 生产环境 (Windows)
```ini
VIDEO_DIRS=camera1:D:\Camera1Videos,camera2:E:\Camera2Videos,demo:D:\DemoVideos
```

### 多摄像头场景
```ini
VIDEO_DIRS=front_door:D:\Cameras\Front,back_door:D:\Cameras\Back,garage:D:\Cameras\Garage
```

---

## 🐛 常见问题

### Q1: 别名已存在怎么办？
A: 每个别名必须唯一。如果重复，后端会报错。

### Q2: 可以修改别名吗？
A: 可以，但需要重启后端服务。

### Q3: 旧的Token还能用吗？
A: v1.2保留了向后兼容，旧Token仍然有效（会尝试自动转换）。

### Q4: 前端必须修改吗？
A: 是的。API参数从`directory`改为`alias`，必须修改。

### Q5: 非MP4文件被过滤了？
A: v1.2只允许MP4。如需其他格式，修改`ALLOWED_VIDEO_EXTENSIONS`。

---

## 📚 相关文档

- [SECURITY.md](SECURITY.md) - 完整安全说明
- [DEPLOY.md](DEPLOY.md) - 部署指南
- [CHANGELOG.md](CHANGELOG.md) - 版本更新日志

---

**升级日期**: 2026-01-15  
**版本**: v1.2.0 - 别名系统  
**安全等级**: ⭐⭐⭐⭐⭐ (显著提升)
