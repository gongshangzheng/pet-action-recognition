# 视频编码说明

## ✅ 自动编码器选择（当前方案）

切片脚本会根据操作系统**自动选择最佳编码器**，无需手动配置。

### 编码器优先级

**Windows:**
1. avc1 (H.264) - 最优，无警告
2. mp4v (MPEG-4) - 备选

**macOS:**
1. avc1 (H.264) - 最优
2. mp4v (MPEG-4) - 备选

**Linux:**
1. X264 (H.264) - 最优
2. avc1 (H.264) - 备选
3. mp4v (MPEG-4) - 保底

### 优势

1. ✅ **自动适配平台**
2. ✅ **无需额外依赖**
3. ✅ **CPU 占用低**
4. ✅ **代码简洁**
5. ✅ **压缩率高**

### 依赖

需要系统安装 FFmpeg：

**Windows:**
```bash
# 方式 1: 使用 Chocolatey
choco install ffmpeg

# 方式 2: 手动下载
# 访问 https://ffmpeg.org/download.html
# 下载后添加到系统 PATH
```

**Linux:**
```bash
sudo apt install ffmpeg  # Ubuntu/Debian
sudo yum install ffmpeg  # CentOS/RHEL
```

**macOS:**
```bash
brew install ffmpeg
```

验证安装：
```bash
ffmpeg -version

# 或运行自动测试脚本
python test_ffmpeg.py
# Windows: 双击 test_ffmpeg.bat
```

## 性能优化

### CPU 占用优化

如果 CPU 占用过高，可以调整编码参数（修改 `scripts/pet_monitor.py`）：

```python
# 当前配置（最低 CPU 占用）
'-preset', 'ultrafast',

# 可选配置（根据 CPU 能力选择）
'-preset', 'veryfast',   # 稍高 CPU，文件稍小
'-preset', 'fast',       # 中等 CPU，文件更小
'-preset', 'medium',     # 平衡 CPU 和文件大小
```

### 文件大小优化

如果文件过大，可以调整质量参数：

```python
# 在 command 数组中添加 CRF 参数
'-crf', '23',  # 默认值，平衡质量和大小
# 可选: 18-28，数值越小质量越高（文件越大）
```

### 分辨率优化

如果不需要高分辨率，可以添加缩放：

```python
# 在 command 数组中添加（在 '-c:v' 之前）
'-vf', 'scale=1280:-1',  # 宽度 1280，高度自动
'-vf', 'scale=960:-1',   # 宽度 960，高度自动
```

## 故障排查

### 问题 1: 脚本报错 "启动 FFmpeg 失败"

**原因**: FFmpeg 未安装或不在 PATH 中

**解决**:
1. 运行 `test_ffmpeg.bat` 检查安装
2. 确认 FFmpeg 在系统 PATH 中
3. 或将 `ffmpeg.exe` 复制到 `scripts/` 目录

### 问题 2: 日志显示 "写入FFmpeg管道失败"

**原因**: FFmpeg 进程异常终止

**解决**:
1. 检查磁盘空间是否充足
2. 检查视频目录写入权限
3. 查看任务日志：`backend/logs/tasks/task_X.log`
4. 临时启用 FFmpeg 错误输出（调试用）：
   ```python
   # 将 stderr=subprocess.DEVNULL 改为
   stderr=None
   ```

### 问题 3: FFmpeg 进程一直运行，文件未生成

**原因**: 管道未正确关闭

**解决**: 脚本已处理此问题。如果仍然遇到：
1. 检查任务是否正常停止
2. 手动终止 FFmpeg 进程：
   ```bash
   # Windows
   taskkill /F /IM ffmpeg.exe
   
   # Linux/macOS
   killall ffmpeg
   ```

### 问题 4: 视频播放卡顿或黑屏

**原因**: 编码参数不兼容

**解决**: 确认使用了以下参数（脚本已包含）：
- `-pix_fmt yuv420p`（必需）
- `-c:v libx264`（必需）
- 容器格式为 `.mp4`

### 问题 5: CPU 占用过高

**原因**: `ultrafast` 虽然编码快，但对某些配置仍可能占用高

**解决**:
1. 降低帧率（15 fps）
2. 降低分辨率（见上方"分辨率优化"）
3. 减少同时运行的切片任务数量
4. 使用硬件加速（需要 GPU 支持，配置较复杂）

## 技术细节

### 编码流程

```
OpenCV 读取帧 (BGR24)
    ↓
frame.tobytes()
    ↓
FFmpeg stdin 管道
    ↓
libx264 编码 (H.264)
    ↓
yuv420p 色彩转换
    ↓
MP4 容器封装
    ↓
写入磁盘
```

### 参数说明

| 参数 | 说明 | 作用 |
|------|------|------|
| `-f rawvideo` | 输入格式 | 告诉 FFmpeg 输入是原始帧数据 |
| `-pix_fmt bgr24` | 输入色彩空间 | OpenCV 默认格式 |
| `-c:v libx264` | 视频编码器 | 使用 H.264 编码 |
| `-pix_fmt yuv420p` | 输出色彩空间 | 浏览器兼容格式 |
| `-preset ultrafast` | 编码速度 | 最快速度，最低 CPU |
| `-f mp4` | 输出格式 | MP4 容器 |

## 对比：FFmpeg vs OpenCV VideoWriter

| 特性 | FFmpeg | OpenCV VideoWriter |
|------|--------|-------------------|
| 兼容性 | ✅ 优秀 | ❌ 经常出问题 |
| 浏览器播放 | ✅ 100% | ⚠️ 不稳定 |
| CPU 占用 | +5-10% | 基准 |
| 配置难度 | 需安装 FFmpeg | 无需额外依赖 |
| 参数控制 | ✅ 灵活 | ❌ 受限 |
| 跨平台 | ✅ 一致 | ⚠️ 平台差异大 |

## 总结

**推荐使用 FFmpeg 方案**，原因：
1. 彻底解决编解码器兼容性问题
2. 浏览器播放兼容性 100%
3. 5-10% 的 CPU 开销在监控场景下完全可接受
4. 编码参数灵活可控
5. 跨平台一致性好

## 编码器对比

| 编码器 | 压缩率 | 兼容性 | 依赖 | Windows 支持 |
|--------|--------|--------|------|--------------|
| avc1 (OpenH264) | 最高 | 好 | OpenH264.dll | ⚠️ 版本兼容问题 |
| X264 (x264) | 高 | 好 | 无 | ✅ 原生支持 |
| H264 (通用) | 高 | 好 | 系统编码器 | ✅ 原生支持 |
| mp4v (MPEG-4) | 中 | 最好 | 无 | ✅ 原生支持 |

## 文件大小参考

基于 1080x1920 分辨率、21fps 的监控视频：

| 编码器 | 比特率 | 15秒视频大小 |
|--------|--------|--------------|
| H.264 | ~1.6 Mbps | 13-18 MB |
| MPEG-4 | ~1.6-2.0 Mbps | 15-20 MB |

## 如何查看使用的编码器？

查看任务日志：
```
D:\pet-videos\backend\logs\tasks\task_1.log
```

会看到类似输出：
```
[2026-01-21 20:00:00] 使用编码器: H.264 (x264) (X264)
```

## 强制使用特定编码器

如果需要强制使用特定编码器，修改 `scripts/pet_monitor.py`：

```python
# 只使用 MPEG-4
codecs = [
    ('mp4v', 'MPEG-4'),
]
```

## OpenH264 问题排查

如果想使用 OpenH264（avc1），需要：

### 1. 确认 OpenCV 版本
```bash
python -c "import cv2; print(cv2.__version__)"
```

### 2. 安装匹配的 OpenH264 版本

| OpenCV 版本 | OpenH264 版本 |
|-------------|---------------|
| 4.8.x - 4.10.x | v2.3.1 |
| 4.11.x - 4.12.x | v2.4.1 或 v2.5.1 |

### 3. 下载并安装

访问：https://github.com/cisco/openh264/releases

下载对应版本的 `openh264-x.x.x-win64.dll.bz2`，解压后复制到：
```
C:\Users\你的用户名\AppData\Local\
```

## 常见问题

### Q: 看到 "Incorrect library version loaded"
A: OpenH264 版本不匹配。**推荐方案：让脚本自动选择其他编码器（无需修改）**。

### Q: 看到 "Failed to initialize VideoWriter"
A: 所有编码器都不可用。检查：
- OpenCV 是否正确安装：`pip install opencv-python --upgrade`
- 磁盘空间是否充足
- 视频目录是否有写入权限

### Q: 如何获得最小的文件大小？
A: 使用 H.264 编码器（avc1、X264 或 H264），它们的压缩率最高。

### Q: 视频无法播放？
A: MPEG-4 (mp4v) 的兼容性最好，所有浏览器和播放器都支持。

## 推荐配置

### Windows 服务器（当前配置）
```python
# 自动选择（推荐）
# 脚本会自动尝试 avc1 → X264 → H264 → mp4v
```

无需手动配置，开箱即用！

### Linux/macOS
```python
# 通常 avc1 即可正常工作
codecs = [
    ('avc1', 'H.264 (OpenH264)'),
]
```
