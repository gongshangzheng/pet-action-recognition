# 登录问题快速修复指南

## 当前问题

从终端5的日志显示：
```
[Proxy] → POST /api/login → http://127.0.0.1:8002/api/login
[Proxy] ← 500 /api/login
```

**后端运行中，但返回500错误。**

## 立即执行的命令

### 1. 打开新终端

在项目目录打开新终端：
```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos
```

### 2. 停止现有后端

```bash
# 停止所有后端进程
pkill -f "python.*main.py"
pkill -f "uvicorn.*backend.main"

# 确认已停止
ps aux | grep -E "python.*main|uvicorn" | grep -v grep
```

### 3. 创建必要目录

```bash
mkdir -p logs database
chmod 755 logs database
```

### 4. 测试后端启动（前台模式）

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos
python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8002 --reload
```

**观察输出！**会显示：
- ✓ 成功：看到 "Application startup complete"
- ✗ 失败：会显示具体错误信息

## 常见错误及解决方法

### 错误1：ModuleNotFoundError

```
ModuleNotFoundError: No module named 'fastapi'
```

**解决**：
```bash
cd backend
pip3 install -r requirements.txt
```

### 错误2：数据库错误

```
sqlite3.OperationalError: unable to open database file
```

**解决**：
```bash
mkdir -p database
python3 -c "from backend.models.database import init_db; init_db(); print('数据库初始化成功')"
```

### 错误3：环境变量错误

```
KeyError: 'DASHSCOPE_API_KEY'
```

**解决**：
```bash
# 检查 .env 文件
cat .env

# 确保包含所有必要配置
grep -E "ADMIN_USERNAME|ADMIN_PASSWORD" .env
```

### 错误4：导入错误

```
ImportError: cannot import name 'xxx'
```

**解决**：
```bash
# 更新所有依赖
cd backend
pip3 install --upgrade -r requirements.txt
```

## 如果前台启动成功

看到类似输出：
```
INFO:     Uvicorn running on http://0.0.0.0:8002 (Press CTRL+C to quit)
INFO:     Started reloader process
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
```

### 测试登录

打开**另一个新终端**：
```bash
curl -X POST http://localhost:8002/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"petadmin@20260115"}'
```

**应该返回**：
```json
{
  "access_token":"eyJ0eXAiOiJKV1QiLC...",
  "token_type":"bearer"
}
```

### 后台启动

如果测试成功，可以后台运行：
```bash
# 停止前台进程（Ctrl+C）

# 后台启动
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos
nohup python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8002 --reload > logs/backend.log 2>&1 &

# 查看日志
tail -f logs/backend.log
```

## 使用启动脚本

如果手动启动成功，可以使用：
```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos
./start_all.sh
```

## 诊断工具

运行完整诊断：
```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos
python3 test/diagnose_backend.py
```

或运行简单测试：
```bash
python3 test_backend_simple.py
```

## 检查虚拟环境

如果使用虚拟环境：
```bash
cd backend

# 激活虚拟环境
source venv/bin/activate

# 检查依赖
pip list | grep -E "fastapi|uvicorn"

# 如果缺失，安装
pip install -r requirements.txt

# 退出虚拟环境
deactivate
```

## 登录凭证

根据 `.env` 配置：
- **用户名**：`admin`  
- **密码**：`petadmin@20260115`

## 浏览器测试

后端启动成功后，打开浏览器：

1. **API 文档**：http://localhost:8002/docs
2. **健康检查**：http://localhost:8002/health
3. **根路径**：http://localhost:8002/

## 前端访问

确保前端也在运行：
```bash
# 如果前端未启动
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/frontend
npm run dev
```

然后访问：http://localhost:8173/

## 完整重启流程

如果问题持续：
```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos

# 1. 停止所有服务
./stop_all.sh
sleep 2

# 2. 清理进程
pkill -f "uvicorn"
pkill -f "vite"

# 3. 重新启动
./start_all.sh

# 4. 查看日志
tail -f logs/app.log
# 或
tail -f logs/backend.log
```

## 需要的信息

如果还是无法解决，请提供：

1. **前台启动的完整输出**（最重要！）
```bash
python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8002 --reload
```

2. **Python版本**
```bash
python3 --version
```

3. **已安装的包**
```bash
pip3 list | grep -E "fastapi|uvicorn|pydantic"
```

4. **.env 内容**（隐藏敏感信息）
```bash
cat .env | sed 's/=.*/=***/'
```

5. **端口占用情况**
```bash
lsof -i :8002
```

## 最可能的原因

根据500错误，最常见的原因是：

1. **数据库未初始化** - 首次运行需要初始化
2. **依赖包版本不兼容** - 需要重新安装
3. **配置文件错误** - 检查 .env 和 backend/config.py
4. **Python环境问题** - 确保使用 Python 3.8+

## 紧急临时方案

如果急需使用，可以：

1. 检查是否有旧的工作备份
2. 重新 git clone 干净的代码
3. 使用 Docker 容器运行（如果有 Dockerfile）

## 相关文档

- [LOGIN_TROUBLESHOOTING.md](docs/LOGIN_TROUBLESHOOTING.md) - 完整故障排查
- [ENV_CONFIG.md](docs/ENV_CONFIG.md) - 环境配置说明
- [DEPLOY.md](docs/DEPLOY.md) - 部署指南
