# Pet-Videos 部署指南

## 📦 打包和部署流程

### 方案一：完整打包（推荐用于新环境部署）

#### 1. 在开发机器上打包源码

**Mac/Linux 开发环境**：
```bash
./package.sh
```

**Windows 开发环境**：
```bat
package.bat
```

脚本会：
- ✅ 打包所有源码文件
- ✅ 包含配置脚本（*.bat）
- ✅ 包含配置示例（env.example）
- ❌ 排除虚拟环境（venv/）
- ❌ 排除依赖包（node_modules/）
- ❌ 排除数据库和日志文件
- ❌ 排除所有缓存文件

生成文件示例：`pet-videos-source-20260115-154030.zip`

文件大小：约 100KB - 5MB（相比完整打包节省 500+ MB）

**注意**：
- Mac/Linux 使用 `package.sh`
- Windows 使用 `package.bat`
- 两个脚本功能完全相同，只是适配不同操作系统

#### 2. 在目标服务器上部署

1. **上传压缩包**到目标服务器（如 `D:\`）

2. **解压文件**
   ```
   右键 → 解压到 pet-videos\
   ```

3. **配置环境变量**
   ```bat
   cd D:\pet-videos
   copy env.example .env
   notepad .env
   ```
   
   编辑 `.env` 文件，配置：
   - `DASHSCOPE_API_KEY` - 你的API密钥
   - `ADMIN_USERNAME` / `ADMIN_PASSWORD` - 登录账号密码
   - `VIDEO_DIRS` - 视频目录路径（Windows格式，如 `D:\Videos,E:\Records`）

4. **安装依赖**
   ```bat
   install.bat
   ```
   
   这个脚本会自动：
   - 检测并安装 FFmpeg
   - 创建 Python 虚拟环境并安装后端依赖
   - 检测 Node.js 版本，必要时安装本地 Node.js v18
   - 安装前端依赖

5. **启动服务**
   ```bat
   start_all.bat
   ```

---

### 方案二：快速更新（用于已部署环境的代码更新）

适用场景：
- ✅ 服务器上已经运行过 `install.bat`
- ✅ 依赖环境都已安装好
- ✅ 只需要更新源码

步骤：

1. **在开发机器上打包**
   
   Mac/Linux:
   ```bash
   ./package.sh
   ```
   
   Windows:
   ```bat
   package.bat
   ```

2. **上传到服务器并解压**（覆盖旧文件）

3. **运行快速部署**
   ```bat
   quick_deploy.bat
   ```
   
   这个脚本会：
   - 停止现有服务
   - 清理缓存文件
   - 备份日志
   - 验证配置
   - 可选：更新依赖（如果检测到问题）

4. **启动服务**
   ```bat
   start_all.bat
   ```

---

## 🚀 服务管理脚本

### install.bat - 环境安装
- 自动安装 FFmpeg（如果缺失）
- 创建 Python 虚拟环境
- 安装后端依赖
- 处理 Node.js 版本兼容性
- 安装前端依赖

### start_all.bat - 启动所有服务
- 同时启动后端和前端
- 每个服务在独立窗口运行
- 显示访问地址

### start_backend.bat - 仅启动后端
- 端口：8002
- 支持热重载

### start_frontend.bat - 仅启动前端  
- 端口：5173
- 自动使用本地 Node.js（如果已安装）

### stop_all.bat - 停止所有服务
- 强制关闭 8002 和 5173 端口的进程
- 关闭相关命令窗口

---

## 🔧 配置文件说明

### .env（必须配置）

```ini
# API密钥（必填）
DASHSCOPE_API_KEY=sk-your-api-key-here

# 登录凭据
ADMIN_USERNAME=admin
ADMIN_PASSWORD=your-secure-password
JWT_SECRET=your-random-secret-key

# 视频目录（Windows路径，用逗号分隔）
VIDEO_DIRS=D:\Videos,E:\Records

# 服务端口
BACKEND_PORT=8002
FRONTEND_PORT=5173
```

**注意事项：**
- Windows 路径使用反斜杠 `\` 或双反斜杠 `\\`
- 修改配置后必须重启服务才能生效
- 密码前后不要有空格
- 文件编码必须是 UTF-8

---

## 📝 常见问题

### 1. 登录失败

**症状**：输入正确的账号密码仍然提示"登录失败"

**解决方法**：
```bat
cd D:\pet-videos\backend
call venv\Scripts\activate.bat
python debug_login.py
```
按提示输入账号密码，查看是否匹配。

**可能原因**：
- `.env` 文件编码问题（应该是 UTF-8）
- 密码中有特殊字符或空格
- 修改配置后未重启后端服务

### 2. 前端请求 500 错误

**症状**：所有API请求都返回 500 Internal Server Error

**解决方法**：
1. 检查后端窗口的错误日志
2. 验证 `.env` 配置：
   ```bat
   cd backend
   call venv\Scripts\activate.bat
   python -c "from config import settings; print('配置加载成功')"
   ```

**可能原因**：
- `.env` 缺少必需配置（DASHSCOPE_API_KEY, VIDEO_DIRS）
- 视频目录路径不存在
- Python依赖缺失

### 3. Vite 代理连接失败

**症状**：前端显示 `ECONNREFUSED ::1:8002`

**解决方法**：
- 后端和前端配置已统一使用 `127.0.0.1`（IPv4）
- 确保后端服务已启动
- 检查防火墙是否阻止了 8002 端口

### 4. Node.js 版本过低

**症状**：前端启动时报语法错误（如 `Unexpected token '??='`）

**解决方法**：
- 重新运行 `install.bat`
- 脚本会自动下载并配置 Node.js v18 到项目目录
- 使用 `start_frontend.bat` 会自动使用本地 Node.js

---

## 📊 目录结构

```
pet-videos/
├── backend/                  # 后端源码
│   ├── api/                 # API路由
│   ├── models/              # 数据模型
│   ├── services/            # 业务逻辑
│   ├── database/            # 数据库文件（自动创建）
│   ├── logs/                # 日志文件（自动创建）
│   ├── venv/                # Python虚拟环境（install.bat创建）
│   ├── main.py              # 入口文件
│   ├── config.py            # 配置管理
│   └── requirements.txt     # Python依赖
│
├── frontend/                # 前端源码
│   ├── src/                 # 源代码
│   │   ├── components/      # React组件
│   │   ├── services/        # API服务
│   │   └── types/           # TypeScript类型
│   ├── node_modules/        # Node依赖（npm install创建）
│   ├── package.json         # 前端依赖配置
│   └── vite.config.ts       # Vite配置
│
├── .env                     # 环境配置（需手动创建）
├── env.example              # 配置示例
│
├── install.bat              # 环境安装脚本
├── package.bat              # 源码打包脚本
├── quick_deploy.bat         # 快速部署脚本
├── start_all.bat            # 启动所有服务
├── start_backend.bat        # 启动后端
├── start_frontend.bat       # 启动前端
├── stop_all.bat             # 停止所有服务
│
├── debug_login.py           # 登录调试工具
├── fix_env_encoding.py      # .env编码修复工具
│
└── DEPLOY.md                # 本文档
```

---

## 🛠️ 技术栈

**后端**：
- Python 3.9+
- FastAPI
- SQLAlchemy
- DashScope API
- JWT认证

**前端**：
- React 18
- TypeScript
- Ant Design
- Vite
- Axios

**部署环境**：
- Windows Server 2016+
- FFmpeg（自动安装）
- Node.js v18（自动安装本地版本）

---

## 📞 技术支持

如遇到问题：
1. 查看后端窗口的错误日志
2. 查看 `backend/logs/app.log`
3. 运行调试脚本：`debug_login.py` 或 `fix_env_encoding.py`
4. 检查 `.env` 配置文件格式

---

**最后更新**：2026-01-15
