# 统一视频分析记录方案

## 📋 概述

将原来分散的两套视频分析存储系统（`analysis_history` 和 `video_records`）统一到 `video_records` 表。

**目标**：
- ✅ 统一手动分析和自动分析的数据存储
- ✅ 通过 `did` 和 `call_type` 字段区分不同调用场景
- ✅ 保存 LLM 原始返回和结构化结果
- ✅ 统一查询接口，简化数据管理

---

## 🔄 架构变更

### **变更前**

```
前端手动分析 → analysis_history 表
  - 包含：完整参数、Token、费用
  - 特点：独立存储，无 did 关联

切片自动分析 → video_records 表
  - 包含：切片信息、LLM队列状态
  - 特点：关联 source_id，无详细参数
```

### **变更后**

```
前端手动分析 → video_records 表（did="0", call_type="manual"）
切片自动分析 → video_records 表（did=用户ID, call_type="auto"）

统一存储：
  ✅ 基础信息（文件名、路径、时长等）
  ✅ 分析参数（prompt、model、fps、pixels等）
  ✅ Token统计（input/output/total_tokens、cost）
  ✅ LLM结果（llm_raw_response、llm_result）
  ✅ 队列状态（llm_status、retry_count等）
```

---

## 📊 数据库表结构

### 新增字段

| 字段名 | 类型 | 默认值 | 索引 | 说明 |
|--------|------|--------|------|------|
| `did` | VARCHAR(50) | "0" | ✅ | 用户ID，手动调用时为"0" |
| `call_type` | VARCHAR(20) | "auto" | ✅ | 调用类型：auto/manual |
| `llm_raw_response` | TEXT | NULL | ❌ | LLM完整原始返回（JSON） |
| `prompt` | TEXT | NULL | ❌ | 提示词内容 |
| `model_name` | VARCHAR(100) | NULL | ✅ | 模型名称 |
| `analysis_fps` | FLOAT | NULL | ❌ | 分析FPS（区别于视频fps） |
| `max_pixels` | INTEGER | NULL | ❌ | 最大像素 |
| `min_pixels` | INTEGER | NULL | ❌ | 最小像素 |
| `vl_high_resolution_images` | BOOLEAN | NULL | ❌ | 高分辨率模式 |
| `input_tokens` | INTEGER | NULL | ❌ | 输入Token数 |
| `output_tokens` | INTEGER | NULL | ❌ | 输出Token数 |
| `total_tokens` | INTEGER | NULL | ❌ | 总Token数 |
| `analysis_cost` | FLOAT | NULL | ❌ | 分析费用（元） |
| `analysis_duration_sec` | FLOAT | NULL | ❌ | LLM执行耗时（秒） |

### 完整表结构

```sql
CREATE TABLE video_records (
    -- 主键
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id INTEGER NOT NULL,  -- 手动调用时为0
    
    -- 🆕 用户和调用类型
    did VARCHAR(50) NOT NULL DEFAULT '0',
    call_type VARCHAR(20) NOT NULL DEFAULT 'auto',
    
    -- 文件信息
    file_name VARCHAR(500) NOT NULL,
    file_path VARCHAR(1000) NOT NULL,
    file_size INTEGER,
    
    -- 视频元信息
    duration FLOAT,
    width INTEGER,
    height INTEGER,
    fps FLOAT,  -- 视频原始帧率
    codec VARCHAR(50),
    detection_type VARCHAR(20),
    
    -- 🆕 LLM 分析参数
    prompt TEXT,
    model_name VARCHAR(100),
    analysis_fps FLOAT,  -- 分析FPS
    max_pixels INTEGER,
    min_pixels INTEGER,
    vl_high_resolution_images BOOLEAN,
    
    -- 🆕 Token 统计和费用
    input_tokens INTEGER,
    output_tokens INTEGER,
    total_tokens INTEGER,
    analysis_cost FLOAT,
    analysis_duration_sec FLOAT,
    
    -- LLM 任务队列
    llm_status VARCHAR(20) NOT NULL DEFAULT 'pending',
    llm_prompt_id INTEGER,
    llm_result TEXT,  -- 结构化结果
    llm_raw_response TEXT,  -- 🆕 原始返回
    llm_error TEXT,
    llm_analysis_id INTEGER,
    llm_started_at DATETIME,
    llm_completed_at DATETIME,
    llm_retry_count INTEGER DEFAULT 0,
    
    -- 时间戳
    recorded_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
);

-- 索引
CREATE INDEX idx_video_records_source_id ON video_records(source_id);
CREATE INDEX idx_video_records_did ON video_records(did);
CREATE INDEX idx_video_records_call_type ON video_records(call_type);
CREATE INDEX idx_video_records_model_name ON video_records(model_name);
CREATE INDEX idx_video_records_llm_status ON video_records(llm_status);
CREATE INDEX idx_video_records_recorded_at ON video_records(recorded_at);
```

---

## 🔄 使用规则

### 1️⃣ 手动调用（前端视频分析）

```python
# 前端分析 API：POST /api/analyze
video_record = VideoRecord(
    source_id=0,                 # ✅ 手动调用固定为0
    did="0",                     # ✅ 手动调用固定为"0"
    call_type="manual",          # ✅ 调用类型
    file_name="test.mp4",
    file_path="/path/to/test.mp4",
    duration=30.5,
    fps=30.0,                    # 视频原始帧率
    
    # 分析参数
    prompt="分析这个视频中的宠物行为",
    model_name="qwen3-vl-plus",
    analysis_fps=1.0,            # 用户配置的分析FPS
    max_pixels=1280*28*28,
    min_pixels=224*224,
    vl_high_resolution_images=False,
    
    # LLM 结果
    llm_status="completed",
    llm_raw_response='{"pets": [...], "behaviors": [...]}',  # 原始返回
    llm_result='{"pets": [...]}',  # 可选的结构化结果
    
    # Token 统计
    input_tokens=1234,
    output_tokens=567,
    total_tokens=1801,
    analysis_cost=0.025,
    analysis_duration_sec=3.5,
    
    recorded_at=datetime.now(),
    created_at=datetime.now(),
    updated_at=datetime.now()
)
```

**查询手动分析记录**：
```python
# 查询所有手动分析记录
records = db.query(VideoRecord).filter(
    VideoRecord.call_type == 'manual'
).order_by(VideoRecord.created_at.desc()).all()
```

### 2️⃣ 自动调用（切片脚本）

```python
# 切片脚本生成视频后
video_record = VideoRecord(
    source_id=123,               # ✅ 流源ID
    did="user_did_123",          # ✅ 实际用户ID（从 stream_sources 获取）
    call_type="auto",            # ✅ 自动调用
    file_name="20260123_120000.mp4",
    file_path="/videos/user_did_123/20260123_120000.mp4",
    duration=60.0,
    
    # 分析参数（从提示词配置读取）
    llm_status="pending",
    llm_prompt_id=5,
    
    recorded_at=datetime.now(),
    created_at=datetime.now(),
    updated_at=datetime.now()
)

# LLM Worker 处理后更新
video_record.llm_status = "completed"
video_record.llm_raw_response = '{"pets": [...], "behaviors": [...]}'
video_record.input_tokens = 5000
video_record.output_tokens = 1200
video_record.total_tokens = 6200
video_record.analysis_cost = 0.08
video_record.analysis_duration_sec = 8.5
video_record.llm_completed_at = datetime.now()
```

**查询自动分析记录**：
```python
# 查询某个用户的所有自动分析记录
records = db.query(VideoRecord).filter(
    VideoRecord.did == "user_did_123",
    VideoRecord.call_type == 'auto'
).order_by(VideoRecord.recorded_at.desc()).all()
```

---

## 📝 API 调整

### Backend API（后端内部）

**无需变更**，`video_records` 表的 CRUD API 保持不变，新字段会自动支持。

### Service API（前端调用）

#### ❌ 废弃接口

```python
# 原调用历史接口（analysis_history）
GET /api/history
GET /api/history/{id}
DELETE /api/history/{id}
```

#### ✅ 新统一接口

```python
# 查询所有分析记录（手动+自动）
GET /api/video-records
  ?did=xxx           # 按用户过滤
  &call_type=manual  # 按类型过滤：manual/auto
  &page=1
  &page_size=20

# 响应示例
{
  "records": [
    {
      "id": 123,
      "did": "0",
      "call_type": "manual",
      "file_name": "test.mp4",
      "model_name": "qwen3-vl-plus",
      "input_tokens": 1234,
      "analysis_cost": 0.025,
      "llm_status": "completed",
      "llm_raw_response": "{...}",
      "created_at": "2026-01-23T12:00:00"
    }
  ],
  "total": 100
}

# 查询单条记录
GET /api/video-records/{id}

# 删除记录
DELETE /api/video-records/{id}
```

---

## 🔨 代码修改清单

### 1. ✅ **Database Model** - 已完成

- [x] 更新 `backend/models/database.py`：`VideoRecord` 类添加新字段
- [x] 更新 `backend/models/schemas.py`：`VideoRecordBase`、`VideoRecordUpdate` 添加新字段

### 2. ⏳ **Migration Script** - 需执行

```bash
# 执行迁移脚本
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/backend
python migrations/migrate_unify_video_records.py
```

**迁移脚本功能**：
- ✅ 添加新字段到 `video_records` 表
- ✅ 创建索引（did, call_type, model_name）
- ✅ 迁移 `analysis_history` 数据到 `video_records`（did="0", call_type="manual"）
- ✅ 为自动调用记录补充 did（从 stream_sources 获取）

### 3. ⏳ **Backend API** - 需修改

**`backend/api/analysis.py`** - 前端分析接口

```python
@router.post("/analyze", response_model=AnalysisResponse)
async def analyze_video(request: AnalysisRequest, db: Session = Depends(get_db)):
    # ... 现有的分析逻辑 ...
    
    # 🔥 修改：保存到 video_records 而不是 analysis_history
    video_record = VideoRecord(
        source_id=0,                 # 手动调用固定为0
        did="0",                     # 手动调用固定为"0"
        call_type="manual",
        file_name=video_info['filename'],
        file_path=request.video_path,
        duration=video_info['duration_sec'],
        
        # 分析参数
        prompt=request.prompt,
        model_name=request.model_name,
        analysis_fps=request.fps,
        max_pixels=request.max_pixels,
        min_pixels=request.min_pixels,
        vl_high_resolution_images=request.vl_high_resolution_images,
        
        # Token统计
        input_tokens=actual_input_tokens,
        output_tokens=actual_output_tokens,
        total_tokens=actual_total_tokens,
        analysis_cost=actual_cost,
        analysis_duration_sec=api_result['duration_sec'],
        
        # LLM结果
        llm_status="completed",
        llm_prompt_id=request.prompt_id,
        llm_raw_response=api_result['model_response'],  # 原始返回
        llm_result=api_result['model_response'],  # 兼容保留
        
        recorded_at=datetime.now(),
        created_at=datetime.now(),
        updated_at=datetime.now()
    )
    
    db.add(video_record)
    db.commit()
    db.refresh(video_record)
    
    # 返回结果
    return AnalysisResponse(
        id=video_record.id,  # 返回 video_records.id
        # ...
    )
```

### 4. ⏳ **Service API** - 需新增

**`service/app.py`** - 新增统一查询接口

```python
@app.get("/api/video-records")
async def get_video_records(
    did: Optional[str] = None,
    call_type: Optional[str] = None,
    page: int = 1,
    page_size: int = 20,
    current_user: dict = Depends(get_current_user)
):
    """查询分析记录（统一接口）"""
    params = {
        "page": page,
        "page_size": page_size
    }
    if did:
        params["did"] = did
    if call_type:
        params["call_type"] = call_type
    
    # 调用 Backend API
    response = await backend_client.get(
        f"{BACKEND_API_URL}/api/video-records",
        params=params,
        headers={"Authorization": f"Bearer {current_user['token']}"}
    )
    return response.json()

@app.delete("/api/video-records/{record_id}")
async def delete_video_record(
    record_id: int,
    current_user: dict = Depends(get_current_user)
):
    """删除分析记录"""
    response = await backend_client.delete(
        f"{BACKEND_API_URL}/api/video-records/{record_id}",
        headers={"Authorization": f"Bearer {current_user['token']}"}
    )
    return response.json()
```

### 5. ⏳ **Frontend** - 需修改

**`frontend/src/components/AnalysisHistory/index.tsx`**

```typescript
// 修改 API 调用
const fetchHistory = async () => {
  // 旧：GET /api/history
  // 新：GET /api/video-records?call_type=manual
  const response = await axios.get('/api/video-records', {
    params: {
      call_type: 'manual',  // 只查询手动分析记录
      page,
      page_size: 20
    }
  });
  
  setRecords(response.data.records);
  setTotal(response.data.total);
};

// 修改删除逻辑
const handleDelete = async (id: number) => {
  // 旧：DELETE /api/history/{id}
  // 新：DELETE /api/video-records/{id}
  await axios.delete(`/api/video-records/${id}`);
  message.success('删除成功');
  fetchHistory();
};
```

### 6. ⏳ **Worker** - 需调整

**切片自动分析 Worker**

```python
# 创建切片记录时
video_record = VideoRecord(
    source_id=source_id,
    did=stream_source.alias,     # 🔥 从 stream_sources 获取 did
    call_type="auto",
    # ...
)

# 处理完成后更新
video_record.llm_raw_response = llm_result  # 🔥 保存原始返回
video_record.input_tokens = tokens_info['input']
video_record.output_tokens = tokens_info['output']
video_record.analysis_cost = cost
video_record.llm_status = "completed"
```

---

## 📊 数据迁移

### 迁移流程

```bash
# 1. 备份数据库
cp pet_videos.db pet_videos.db.backup

# 2. 执行迁移脚本
python backend/migrations/migrate_unify_video_records.py
```

### 迁移内容

1. **添加新字段**
   - 为 `video_records` 表添加14个新字段
   - 创建3个新索引（did, call_type, model_name）

2. **迁移历史数据**
   - 将 `analysis_history` 的所有记录迁移到 `video_records`
   - 设置 `did="0"`, `call_type="manual"`
   - 映射字段：`model_response` → `llm_raw_response`

3. **补充 did 字段**
   - 为所有 `call_type='auto'` 的记录补充 did
   - 通过 `source_id` 关联 `stream_sources.alias` 获取

### 迁移后验证

```sql
-- 验证数据完整性
SELECT call_type, COUNT(*) as count 
FROM video_records 
GROUP BY call_type;

-- 验证 did 关联
SELECT COUNT(*) 
FROM video_records 
WHERE call_type = 'auto' AND (did = '0' OR did IS NULL);
-- 应该为 0

-- 验证原始返回保存
SELECT COUNT(*) 
FROM video_records 
WHERE llm_status = 'completed' AND llm_raw_response IS NOT NULL;
```

---

## 🎯 优势

### 1. **统一管理**
- ✅ 所有分析记录在一个表中
- ✅ 统一的查询、统计、导出接口
- ✅ 简化数据维护和备份

### 2. **灵活查询**
```sql
-- 查询所有手动分析
SELECT * FROM video_records WHERE call_type = 'manual';

-- 查询某用户的自动分析
SELECT * FROM video_records WHERE did = 'user_123' AND call_type = 'auto';

-- 查询所有分析（不区分类型）
SELECT * FROM video_records ORDER BY created_at DESC;

-- 统计费用
SELECT 
    did, 
    call_type, 
    SUM(analysis_cost) as total_cost,
    COUNT(*) as count
FROM video_records 
WHERE analysis_cost IS NOT NULL
GROUP BY did, call_type;
```

### 3. **完整信息**
- ✅ 保存 LLM 原始返回（`llm_raw_response`）
- ✅ 保存结构化结果（`llm_result`）
- ✅ 完整的 Token 统计和费用记录
- ✅ 分析参数可追溯

### 4. **向后兼容**
- ✅ 保留 `llm_analysis_id` 字段（可废弃）
- ✅ 保留 `llm_result` 字段（兼容旧代码）
- ✅ 迁移脚本自动处理历史数据

---

## ⚠️ 注意事项

### 1. **数据迁移**
- ✅ **务必备份数据库**：`cp pet_videos.db pet_videos.db.backup`
- ✅ 迁移后验证数据完整性
- ✅ 可以保留 `analysis_history` 表作为备份，不影响使用

### 2. **API 兼容性**
- ⚠️ 前端的 `GET /api/history` 接口需要改为 `GET /api/video-records?call_type=manual`
- ⚠️ 删除接口 URL 需要调整
- ⚠️ 返回字段名称可能有变化，需测试

### 3. **Worker 调整**
- ⚠️ 切片脚本创建 `video_records` 时需要设置 `did` 和 `call_type`
- ⚠️ LLM Worker 处理完成后需要保存 `llm_raw_response`

### 4. **性能考虑**
- ✅ 添加了 `did`, `call_type`, `model_name` 索引，查询性能不会下降
- ✅ 手动分析记录 `did="0"`，可以快速过滤

---

## 📚 相关文档

- 数据库模型：`backend/models/database.py`
- 数据模型：`backend/models/schemas.py`
- 迁移脚本：`backend/migrations/migrate_unify_video_records.py`
- 切片分析设计：`docs/DAILY_REPORT_DESIGN.md`

---

## 🚀 执行计划

1. ✅ **更新数据库模型**（已完成）
2. ⏳ **执行迁移脚本**
3. ⏳ **修改 Backend API**（`backend/api/analysis.py`）
4. ⏳ **修改 Service API**（`service/app.py`）
5. ⏳ **修改 Frontend**（`frontend/src/components/AnalysisHistory/`）
6. ⏳ **调整 Worker**（切片脚本和 LLM Worker）
7. ⏳ **测试验证**
8. ⏳ **更新文档**

---

## ✅ 总结

统一方案将 `analysis_history` 和 `video_records` 合并为一个表，通过 `did` 和 `call_type` 字段区分不同场景：

- **手动调用**：`did="0"`, `call_type="manual"`
- **自动调用**：`did=用户ID`, `call_type="auto"`

这个方案：
- ✅ 简化了数据管理
- ✅ 统一了查询接口
- ✅ 保留了完整信息（原始返回 + 结构化结果）
- ✅ 向后兼容，可平滑迁移
