# Pet-Videos 安全加固说明

## 1. 视频流API安全改进

### 问题描述

原实现存在严重安全隐患：
- ❌ 前端直接传递服务器文件路径
- ❌ 没有路径验证，可能被路径穿越攻击
- ❌ 可读取服务器上任意文件
- ❌ 没有文件类型限制

## 2. 目录列表API安全加固

### 问题描述 (v1.1.1 修复)

`/api/videos` 和 `/api/videos/by_date` 接口存在**目录遍历漏洞**：
- ❌ 只验证目录存在性，未验证目录在白名单内
- ❌ 攻击者可读取任意目录的视频列表
- ❌ 可能泄露服务器目录结构

### 攻击示例

```bash
# 攻击者可以遍历任意目录
GET /api/videos?directory=C:\Windows
GET /api/videos?directory=D:\other_project
GET /api/videos?directory=../../../etc
```

### 修复方案

#### 添加目录白名单验证

```python
def validate_directory_access(directory: str) -> Path:
    """验证目录访问权限（白名单检查）"""
    # 1. 规范化路径
    dir_path = Path(directory).resolve()
    
    # 2. 验证目录必须在 VIDEO_DIRS 白名单内
    allowed_dirs = [Path(d).resolve() for d in settings.get_video_dirs()]
    is_allowed = any(
        str(dir_path).startswith(str(allowed_dir)) or 
        str(dir_path) == str(allowed_dir)
        for allowed_dir in allowed_dirs
    )
    
    if not is_allowed:
        raise HTTPException(403, "Access denied")
    
    # 3. 检查目录存在性
    # 4. 防止路径穿越
    
    return dir_path
```

#### 受影响的API端点

- ✅ `/api/videos` - 已加固
- ✅ `/api/videos/by_date` - 已加固
- ✅ `/api/video/stream` - 已加固（使用token）

### 安全方案

#### 1. 使用加密Token代替文件路径

**原方式**（不安全）：
```
GET /api/video/stream?path=/var/www/videos/test.mp4
GET /api/video/stream?path=../../etc/passwd  ❌ 路径穿越攻击
```

**新方式**（安全）：
```
GET /api/video/stream?token=L3Zhci93d3cvdmlkZW9zL3Rlc3QubXA0.a1b2c3d4e5f6g7h8
```

Token格式：`base64(path).signature`
- base64编码隐藏真实路径
- 使用HMAC签名防止篡改
- 签名密钥为 `JWT_SECRET`

#### 2. 多层安全验证

**后端验证流程**：

```python
# 1. 解码并验证签名
file_path = decode_video_path(token)  # 签名验证失败 → 400

# 2. 验证文件存在性
path.exists() and path.is_file()  # 失败 → 404

# 3. 验证文件类型
path.suffix in ALLOWED_VIDEO_EXTENSIONS  # 失败 → 403

# 4. 验证路径在允许的目录内
path.startswith(VIDEO_DIRS)  # 失败 → 403

# 5. 防止路径穿越
'..' not in path  # 失败 → 403
```

#### 3. 白名单机制

**允许的视频格式**：
```python
ALLOWED_VIDEO_EXTENSIONS = {
    '.mp4', '.avi', '.mkv', '.mov', 
    '.flv', '.wmv', '.webm'
}
```

**允许的目录**（配置文件中定义）：
```ini
VIDEO_DIRS=D:\Videos,D:\Records
```

只有这些目录下的视频文件可以访问。

## 安全特性总结

| 攻击类型 | 防护措施 | 示例 |
|---------|---------|------|
| **路径穿越** | 路径规范化 + 前缀检查 | `../../etc/passwd` → 403 |
| **任意文件读取** | 目录白名单 + 类型检查 | `/etc/shadow` → 403 |
| **Token伪造** | HMAC签名验证 | 修改token → 400 |
| **目录遍历** | 只返回已知目录 | 无法列举其他目录 |
| **敏感信息泄露** | 前端不显示完整路径 | 只显示文件名 |

## API变更

### 旧API（已废弃）

```
GET /api/video/stream?path=<文件路径>
```

### 新API

```
GET /api/video/stream?token=<加密token>
```

**Token获取**：
- 通过 `/api/videos` 接口获取视频列表
- 每个 `VideoInfo` 对象包含 `stream_token` 字段
- 前端使用 `stream_token` 播放视频

## 代码示例

### 后端生成Token

```python
from utils.security import encode_video_path

# 在返回视频信息时自动生成token
video_info = {
    'filename': 'test.mp4',
    'path': '/var/www/videos/test.mp4',  # 仅用于分析
    'stream_token': encode_video_path('/var/www/videos/test.mp4'),  # 用于播放
    ...
}
```

### 前端使用Token

```typescript
// 播放视频
<video src={`/api/video/stream?token=${encodeURIComponent(video.stream_token)}`} />

// ❌ 不要直接使用path
<video src={`/api/video/stream?path=${video.path}`} />
```

## 配置要求

`.env` 文件必须配置：

```ini
# JWT密钥（用于token签名）
JWT_SECRET=your-random-secret-key-here

# 允许访问的视频目录
VIDEO_DIRS=/path/to/videos1,/path/to/videos2
```

**重要提示**：
- `JWT_SECRET` 必须保密，不要泄露
- 修改 `JWT_SECRET` 后，所有现有token会失效
- 确保 `VIDEO_DIRS` 只包含实际需要的目录

## 测试安全性

### 1. 测试路径穿越防护

```bash
# 尝试访问系统文件（应该失败）
curl "http://localhost:8002/api/video/stream?token=fake-token"
# 预期：400 Bad Request

# 生成包含..的路径（应该被拒绝）
# 后端会检测并拒绝
```

### 2. 测试目录限制

```bash
# 尝试访问非VIDEO_DIRS目录的文件
# 即使token正确，也会被403拒绝
```

### 3. 测试Token篡改

```bash
# 修改token中的任意字符
curl "http://localhost:8002/api/video/stream?token=modified-token"
# 预期：400 Bad Request - Invalid video token
```

## 日志监控

所有安全事件会记录到日志：

```
WARNING - Attempted to access file outside allowed directories: /etc/passwd
WARNING - Potential path traversal attempt: ../../etc/passwd
ERROR - Failed to decode video token: Invalid signature
```

建议定期检查日志中的安全警告。

## 升级指南

### 对现有部署的影响

1. **后端变更**：
   - 添加了 `utils/security.py` 模块
   - 修改了 `api/videos.py` 的 `/video/stream` 端点
   - 修改了 `services/video_service.py` 的 `extract_info` 方法

2. **前端变更**：
   - 使用 `stream_token` 替代 `path`
   - 修改了 `VideoList` 和 `SliceStats` 组件

3. **数据库**：
   - 历史记录仍保存 `path` 字段（用于分析）
   - 不影响现有数据

### 升级步骤

1. **备份数据**
2. **更新代码**（使用 `package.bat` 打包新版本）
3. **确保 `.env` 包含 `JWT_SECRET` 配置**
4. **重启服务**
5. **测试视频播放功能**

无需修改数据库，无需数据迁移。

---

**最后更新**：2026-01-15
**版本**：v1.1.0（安全加固版）
