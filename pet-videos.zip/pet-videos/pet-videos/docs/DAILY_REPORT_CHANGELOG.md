# 日报功能变更记录

## 2026-01-23 移除用户触发生成接口

### 变更原因

日报应由后端系统按策略自动生成，不需要用户手动触发。

### 变更内容

#### 1. 移除接口

从 `service/app.py` 移除：
- ❌ `POST /api/daily-report/generate` - 用户触发生成日报接口

#### 2. 保留接口

用户只能查看日报（只读）：
- ✅ `GET /api/daily-report` - 获取日报列表
- ✅ `GET /api/daily-report/{date}/{pet_name}` - 获取指定日报

#### 3. 日报生成策略

后端系统自动生成日报的方式：

**方式 1：定时任务**
- 每天凌晨自动生成前一天的日报
- 遍历所有活跃宠物
- 调用 Backend 内部方法生成日报

**方式 2：实时更新**
- 视频分析完成后自动触发
- 重新生成当日该宠物的日报
- 汇总该日所有分析记录

### 用户权限总结

| 操作 | 权限 | 说明 |
|------|------|------|
| 查看日报 | ✅ 允许 | 只能查看自己的日报 |
| 触发生成 | ❌ 禁止 | 由后端按策略自动生成 |
| 编辑日报 | ❌ 禁止 | 日报由 LLM 生成，不可编辑 |
| 删除日报 | ❌ 禁止 | 只有系统管理员可删除 |

### 文档更新

已更新以下文档：
- ✅ `service/app.py` - 移除 generate 接口
- ✅ `service/README.md` - 更新接口说明
- ✅ `docs/DAILY_REPORT.md` - 更新使用说明
- ✅ `docs/DAILY_REPORT_DESIGN.md` - 更新设计文档

### 影响范围

**前端影响**：
- 移除"生成日报"按钮（如果有）
- 保留日报查看功能
- 添加提示：日报由系统自动生成

**后端影响**：
- Service 层移除 generate 接口
- Backend API 保持不变（内部接口）
- 需要实现定时任务脚本
- 需要实现视频分析完成的回调逻辑

### 迁移指南

如果前端已经实现了"生成日报"功能，需要：

1. **移除前端触发按钮**：
```typescript
// 移除这类代码
async function generateReport() {
  await fetch('/api/daily-report/generate', { method: 'POST', ... });
}
```

2. **添加说明提示**：
```typescript
// 在日报页面添加提示
<Alert type="info">
  日报由系统每天自动生成，视频分析完成后实时更新
</Alert>
```

3. **保留查看功能**：
```typescript
// 保留查看日报的代码
async function viewReports(date, petName) {
  const response = await fetch(`/api/daily-report?date=${date}&pet_name=${petName}`);
  // 展示日报内容
}
```

### 后续待实现

后端需要实现：
- [ ] 定时任务脚本（每天自动生成日报）
- [ ] 视频分析完成后的回调触发
- [ ] LLM 日报摘要生成逻辑
- [ ] 日报生成失败的重试机制
- [ ] 日报生成日志和监控

### API 对比

#### 变更前
```bash
# 用户可以触发生成
POST /api/daily-report/generate
{
  "date": "2026-01-23",
  "pet_name": "毛毛"
}
```

#### 变更后
```bash
# 用户只能查看（只读）
GET /api/daily-report?date=2026-01-23&pet_name=毛毛

# 日报由后端系统自动生成：
# - 定时任务每天生成
# - 视频分析完成后更新
```

### 测试建议

1. **验证查看功能**：
   - 测试获取日报列表接口
   - 测试获取指定日报接口
   - 验证权限控制（只能查看自己的）

2. **验证接口移除**：
   - 确认 POST /api/daily-report/generate 返回 404
   - 确认前端没有调用该接口

3. **后端生成测试**（待实现）：
   - 测试定时任务生成日报
   - 测试视频分析后自动更新
   - 验证 LLM 生成内容质量
