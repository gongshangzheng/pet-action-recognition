# 服务器数据库迁移指南

## 概述

本指南说明如何将服务器上的旧数据库迁移到新的数据库结构，以支持 App 端的新功能。

## 迁移内容

### 新增表
1. **pets** - 宠物信息表
2. **daily_reports** - 宠物日报表
3. **video_pet_analysis** - 视频宠物分析表

### 表结构变更
1. **stream_sources** - 添加 `did` 字段（用户ID）
2. **video_records** - 添加多个字段：
   - `did` - 用户ID
   - `call_type` - 调用类型（auto/manual）
   - `model_name` - 模型名称
   - `llm_raw_response` - 原始响应
   - `prompt` - 提示词
   - `analysis_fps` - 分析帧率
   - Token 统计字段等

3. **pets** - 添加字段：
   - `weight` - 体重
   - `avatar_color` - 头像背景色

## 迁移步骤

### 1. 测试迁移（本地）

```bash
# 1. 从服务器下载数据库
scp user@server:/path/to/history.db database/server_history.db

# 2. 运行测试脚本
cd backend
python3 test_server_migration.py
```

测试脚本会：
- 创建测试数据库副本
- 执行所有迁移脚本
- 验证数据库结构
- 生成测试报告

### 2. 执行迁移

如果测试通过，执行实际迁移：

```bash
cd backend
./run_server_migration.sh
```

或者手动指定数据库路径：

```bash
DATABASE_PATH=/path/to/server_history.db ./run_server_migration.sh
```

### 3. 验证迁移结果

```bash
# 检查表结构
sqlite3 database/server_history.db ".tables"

# 检查关键字段
sqlite3 database/server_history.db "PRAGMA table_info(pets);"
sqlite3 database/server_history.db "PRAGMA table_info(video_records);"
```

### 4. 上传到服务器

```bash
# 备份服务器原数据库
ssh user@server "cp /path/to/history.db /path/to/history.db.backup"

# 上传迁移后的数据库
scp database/server_history.db user@server:/path/to/history.db

# 重启服务
ssh user@server "systemctl restart pet-videos-backend"
```

## 迁移脚本列表

按执行顺序：

1. `migrate_add_did_to_stream_sources.py` - 添加用户ID到摄像头表
2. `migrate_unify_video_records.py` - 统一视频记录表
3. `migrate_add_pets_table.py` - 创建宠物表
4. `migrate_add_weight_to_pets.py` - 添加体重字段
5. `migrate_add_avatar_color_to_pets.py` - 添加头像颜色字段
6. `migrate_add_video_pet_analysis_table.py` - 创建视频宠物分析表
7. `migrate_add_daily_reports_table.py` - 创建日报表

## 数据兼容性

### 自动数据迁移
- `analysis_history` 表的数据会自动迁移到 `video_records`
- 现有的 `stream_sources` 记录会使用 `alias` 作为初始 `did`
- 自动调用的视频记录会自动关联 `did`

### 需要手动处理
- 如果有多个用户共享同一个摄像头，需要手动更新 `stream_sources.did`
- 宠物信息需要通过 App 端或管理界面添加

## 回滚方案

如果迁移失败或出现问题：

```bash
# 使用自动备份恢复
cp database/server_history.db.backup.YYYYMMDD_HHMMSS database/server_history.db

# 或从服务器备份恢复
scp user@server:/path/to/history.db.backup /path/to/history.db
```

## 验证清单

迁移完成后，检查以下项目：

- [ ] 所有新表已创建（pets, daily_reports, video_pet_analysis）
- [ ] stream_sources 表有 did 字段
- [ ] video_records 表有 did, call_type, model_name 等字段
- [ ] pets 表有 weight, avatar_color 字段
- [ ] 现有视频记录数据完整
- [ ] Backend API 正常启动
- [ ] Service API 正常启动
- [ ] 可以通过 API 查询视频记录
- [ ] 可以添加和查询宠物信息

## 注意事项

1. **备份重要性**：迁移前务必备份数据库
2. **测试优先**：先在测试数据库上验证迁移脚本
3. **停机时间**：建议在低峰期执行，预计停机时间 < 5 分钟
4. **数据量**：如果数据量很大（>1GB），迁移时间可能较长
5. **索引创建**：大数据量时索引创建可能耗时，请耐心等待

## 故障排查

### 问题：迁移脚本找不到数据库

```bash
# 确认数据库路径
ls -lh database/server_history.db

# 使用绝对路径
DATABASE_PATH=/absolute/path/to/server_history.db ./run_server_migration.sh
```

### 问题：某个迁移脚本失败

```bash
# 查看详细错误信息
DATABASE_PATH=database/server_history.db python3 migrations/migrate_xxx.py

# 检查数据库是否锁定
lsof database/server_history.db
```

### 问题：迁移后 API 报错

```bash
# 检查数据库结构
sqlite3 database/server_history.db ".schema pets"

# 检查日志
tail -f backend/logs/app.log
```

## 联系支持

如遇到问题，请提供：
1. 错误日志
2. 数据库大小和记录数
3. 执行的迁移步骤
4. 系统环境信息
