# OpenH264 库安装指南（Windows）

OpenCV 在 Windows 上使用 H.264 编码需要 OpenH264 库。

## 方案 1：自动安装（推荐）

### 步骤：
```bash
# 在项目根目录运行
python install_openh264.py
```

或双击运行：
```
install_openh264.bat
```

## 方案 2：手动安装

如果自动安装失败，请按以下步骤手动安装：

### 步骤 1：下载 OpenH264 库

访问 GitHub 下载页面（**使用 v2.4.1 版本，兼容 OpenCV 4.x**）：
```
https://github.com/cisco/openh264/releases/download/v2.4.1/openh264-2.4.1-win64.dll.bz2
```

或使用国内镜像：
```
https://ghproxy.com/https://github.com/cisco/openh264/releases/download/v2.4.1/openh264-2.4.1-win64.dll.bz2
```

### 步骤 2：解压文件

使用 7-Zip 或 WinRAR 解压 `.bz2` 文件，得到：
```
openh264-2.4.1-win64.dll
```

### 步骤 3：复制到系统目录

将 `openh264-2.4.1-win64.dll` 复制到以下任意位置之一：

**选项 1（推荐）：**
```
C:\Users\你的用户名\AppData\Local\openh264-2.4.1-win64.dll
```

**选项 2：**
```
C:\Windows\System32\openh264-2.4.1-win64.dll
```

**选项 3：**
```
D:\pet-videos\scripts\openh264-2.4.1-win64.dll
```

### ⚠️ 重要：删除旧版本

如果之前安装过 v1.8.0，请先删除：
```
del %LOCALAPPDATA%\openh264-1.8.0-win64.dll
```

### 步骤 4：验证安装

运行切片任务，如果不再出现以下错误，说明安装成功：
```
Failed to load OpenH264 library: openh264-1.8.0-win64.dll
```

## 常见问题

### Q: 下载速度慢？
A: 使用国内镜像或使用迅雷等下载工具。

### Q: 没有 7-Zip 或 WinRAR？
A: 
- 下载 7-Zip：https://www.7-zip.org/
- 或使用 Python 解压：`python -c "import bz2; open('openh264-1.8.0-win64.dll','wb').write(bz2.decompress(open('openh264-1.8.0-win64.dll.bz2','rb').read()))"`

### Q: 复制到哪个目录？
A: 按优先级尝试：
1. `%LOCALAPPDATA%\openh264-1.8.0-win64.dll`（推荐）
2. `%SystemRoot%\System32\openh264-1.8.0-win64.dll`
3. 与脚本同一目录

### Q: 如何查找 AppData 目录？
A: 在资源管理器地址栏输入：`%LOCALAPPDATA%` 并回车

## 技术说明

- **库版本**：OpenH264 v2.4.1（兼容 OpenCV 4.x）
- **文件大小**：约 1.5MB
- **授权协议**：BSD License（Cisco 开源）
- **用途**：提供 H.264 视频编解码能力

## 版本说明

- ❌ **v1.8.0**：不兼容 OpenCV 4.12.0（会报错 "Incorrect library version loaded"）
- ✅ **v2.4.1**：兼容 OpenCV 4.x 及更高版本

## 参考链接

- OpenH264 官方仓库：https://github.com/cisco/openh264
- OpenCV 文档：https://docs.opencv.org/
