# 宠物日报功能说明

## 功能概述

日报功能用于根据当日 LLM 分析结果汇总生成宠物的每日行为报告。

**重要说明**：
- ✅ 日报由**后端系统按策略自动生成**（调用 LLM），不是用户手动编辑
- ✅ 用户**只能查看**日报，不能手动触发生成、编辑或删除
- ✅ 后端定时任务自动生成日报
- ✅ 视频分析完成后自动触发更新日报
- ✅ 同一日期同一宠物的日报会自动更新（UPSERT）

## 数据库设计

### daily_reports 表结构

```sql
CREATE TABLE daily_reports (
    did VARCHAR(50) NOT NULL,          -- 用户ID
    date VARCHAR(10) NOT NULL,         -- 日期 YYYY-MM-DD
    pet_name VARCHAR(100) NOT NULL,    -- 宠物名称
    summary TEXT,                      -- 日报汇总内容
    analysis_data TEXT,                -- 原始分析数据（JSON格式）
    video_count INTEGER DEFAULT 0,     -- 分析的视频切片数量
    total_duration FLOAT DEFAULT 0.0,  -- 总时长（秒）
    created_at DATETIME NOT NULL,      -- 创建时间
    updated_at DATETIME NOT NULL,      -- 更新时间
    PRIMARY KEY (did, date, pet_name)  -- 联合主键
);
```

**联合主键设计**：
- `did + date + pet_name` 确保每个用户的每只宠物每天只有一条日报记录
- 重复提交会自动更新（UPSERT）

## 使用流程

### 1. 运行数据库迁移

首次使用前需要创建表：

```bash
cd backend/migrations
python migrate_add_daily_reports_table.py
```

### 2. API 调用示例

#### 查看日报

#### 获取指定日期的所有日报

```bash
curl -X GET "http://localhost:8006/api/daily-report?date=2026-01-23" \
  -H "Cookie: OPENBDUSS=xxx; STOKEN=xxx"
```

#### 获取指定宠物的日报

```bash
curl -X GET "http://localhost:8006/api/daily-report/2026-01-23/毛毛" \
  -H "Cookie: OPENBDUSS=xxx; STOKEN=xxx"
```

#### 查看用户所有宠物的日报

```bash
# 获取所有日期的所有宠物日报
curl -X GET "http://localhost:8006/api/daily-report" \
  -H "Cookie: OPENBDUSS=xxx; STOKEN=xxx"

# 获取指定宠物的所有日报
curl -X GET "http://localhost:8006/api/daily-report?pet_name=毛毛" \
  -H "Cookie: OPENBDUSS=xxx; STOKEN=xxx"
```

## 典型使用场景

### 场景1：前端查看日报

用户在前端查看宠物的历史日报：

```typescript
// 前端获取日报列表
async function getDailyReports(date?: string, petName?: string) {
  const params = new URLSearchParams();
  if (date) params.append('date', date);
  if (petName) params.append('pet_name', petName);
  
  try {
    const response = await fetch(`/api/daily-report?${params}`, {
      credentials: 'include'
    });
    
    const result = await response.json();
    
    if (result.errno === 0) {
      console.log('日报列表:', result.data.reports);
      return result.data.reports;
    } else {
      console.error('获取失败:', result.errmsg);
    }
  } catch (error) {
    console.error('请求失败:', error);
  }
}

// 获取今天所有宠物的日报
const today = new Date().toISOString().split('T')[0];
getDailyReports(today);

// 获取指定宠物的所有日报
getDailyReports(undefined, '毛毛');
```

### 场景2：后端定时任务自动生成

每天晚上定时任务自动生成所有宠物的日报：

```python
import asyncio
import aiohttp
from datetime import datetime, date

async def auto_generate_daily_reports():
    """定时任务：为所有用户的所有宠物生成日报"""
    yesterday = (date.today() - timedelta(days=1)).strftime('%Y-%m-%d')
    
    # 1. 获取所有用户的宠物列表
    # （需要内部接口或数据库查询）
    all_pets = await get_all_active_pets()
    
    # 2. 为每只宠物调用 backend 内部接口生成日报
    for pet in all_pets:
        try:
            # 直接调用 backend 内部接口（绕过 service 层）
            report_data = await generate_report_internal(
                did=pet['did'],
                date=yesterday,
                pet_name=pet['pet_name']
            )
            print(f"✅ 生成日报成功: {pet['did']} / {pet['pet_name']}")
        except Exception as e:
            print(f"❌ 生成日报失败: {pet['did']} / {pet['pet_name']}, {e}")

# 在定时任务中运行
# 例如使用 APScheduler 或 Celery
asyncio.run(auto_generate_daily_reports())
```

### 场景3：视频分析完成后自动更新

视频切片分析完成后，系统自动更新当日日报：

```python
async def on_video_analysis_complete(video_id: int, pet_name: str):
    """视频分析完成回调：自动更新当日日报"""
    video = await get_video_record(video_id)
    
    # 系统自动调用内部方法重新生成日报
    # （会自动汇总该日所有分析记录）
    await generate_report_for_pet(
        did=video.did,
        date=video.date,
        pet_name=pet_name
    )
    
    logger.info(f"日报已自动更新: {video.did} / {pet_name} / {video.date}")
```

### 场景3：前端展示日报

在前端页面展示宠物的历史日报：

```typescript
// 获取最近7天的日报
async function getPetReports(petName: string) {
  const reports = [];
  
  for (let i = 0; i < 7; i++) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    
    try {
      const response = await fetch(
        `/api/daily-report/${dateStr}/${petName}`,
        { credentials: 'include' }
      );
      const result = await response.json();
      
      if (result.errno === 0) {
        reports.push(result.data);
      }
    } catch (error) {
      console.error(`获取 ${dateStr} 日报失败:`, error);
    }
  }
  
  return reports;
}
```

## 注意事项

1. **权限控制**：
   - 用户接口：只能查看自己的日报（只读）
   - 内部接口：系统自动调用 backend API 生成日报

2. **日期格式**：日期必须使用 `YYYY-MM-DD` 格式

3. **UPSERT 行为**：相同 `did+date+pet_name` 会自动更新而不是创建新记录

4. **生成策略**：
   - 定时任务：每天自动生成前一天的日报
   - 实时更新：视频分析完成后自动更新当日日报
   - 系统自动查询 `video_pet_analysis` 表获取分析数据
   - 调用 LLM 生成日报摘要并保存

5. **用户权限限制**：
   - 用户只能查看日报，不能创建/编辑/删除
   - 用户不能手动触发生成
   - 所有日报由后端系统按策略自动生成
   - 确保日报内容由 LLM 基于真实数据生成

6. **并发控制**：如有并发生成需求，建议在应用层加锁

## Backend API (内部)

Backend 提供了以下内部 API（需要 JWT 认证）：

- `GET /api/daily-reports/` - 获取日报列表
- `GET /api/daily-reports/{did}/{date}/{pet_name}` - 获取指定日报
- `POST /api/daily-reports/` - 创建或更新日报
- `PUT /api/daily-reports/{did}/{date}/{pet_name}` - 更新指定日报
- `DELETE /api/daily-reports/{did}/{date}/{pet_name}` - 删除日报

## Service API (对外)

Service 层封装了登录态校验，提供统一响应格式：

- `GET /api/daily-report` - 获取日报列表（用户只读）
- `GET /api/daily-report/{date}/{pet_name}` - 获取指定日报（用户只读）

**权限说明**：
- 用户只能查看自己的日报
- 不能手动触发生成、创建、编辑或删除日报
- 所有日报由后端系统按策略自动生成
- 日报内容完全由 LLM 生成

## 扩展功能建议

- [ ] 添加日报模板功能
- [ ] 支持导出日报为 PDF
- [ ] 支持多宠物对比日报
- [ ] 添加周报、月报汇总
- [ ] 日报分享功能
- [ ] 日报评论功能
