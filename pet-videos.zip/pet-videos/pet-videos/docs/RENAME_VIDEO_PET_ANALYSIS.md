# 重命名 video_pet_analysis → pet_behaviors

## 📋 变更说明

将表名 `video_pet_analysis` 重命名为 `pet_behaviors`，同时更新相关代码。

### 原因

- ❌ `video_pet_analysis` 语义不清晰，听起来像整体分析结果
- ❌ 与 `video_records` 容易混淆（都带 video 前缀）
- ❌ 没有体现"行为记录"的核心含义

- ✅ `pet_behaviors` 简洁明了，直接表达"宠物行为记录"
- ✅ 一条记录 = 一个宠物的一次行为
- ✅ 符合命名规范，与其他表风格一致

## 🔄 变更内容

### 1. 数据库表

```sql
-- 旧表名
video_pet_analysis

-- 新表名
pet_behaviors
```

### 2. 数据库模型

**文件**: `backend/models/database.py`

```python
# 旧类名
class VideoPetAnalysis(Base):
    __tablename__ = "video_pet_analysis"
    ...

# 新类名
class PetBehavior(Base):
    __tablename__ = "pet_behaviors"
    ...

# 向后兼容别名
VideoPetAnalysis = PetBehavior
```

### 3. API 代码

**文件**: `backend/api/video_records.py`

```python
# 旧导入
from models.database import VideoRecord, VideoPetAnalysis, StreamSource

# 新导入
from models.database import VideoRecord, PetBehavior, StreamSource

# 旧查询
pet_analyses = db.query(VideoPetAnalysis).filter(...)

# 新查询
pet_behaviors = db.query(PetBehavior).filter(...)
```

**文件**: `backend/api/videos.py`

```python
# 旧导入
from models.database import StreamSource, VideoPetAnalysis

# 新导入
from models.database import StreamSource, PetBehavior
```

**文件**: `backend/services/video_service.py`

```python
# 旧导入
from models.database import VideoPetAnalysis

# 新导入
from models.database import PetBehavior

# 旧查询
query = query.join(
    VideoPetAnalysis,
    (VideoRecord.id == VideoPetAnalysis.video_id) &
    (VideoPetAnalysis.pet_name == pet_name)
)

# 新查询
query = query.join(
    PetBehavior,
    (VideoRecord.id == PetBehavior.video_id) &
    (PetBehavior.pet_name == pet_name)
)
```

## 📊 表结构对比

### 字段保持不变

| 字段名 | 类型 | 说明 |
|--------|------|------|
| video_id | INTEGER | 视频ID（主键） |
| pet_name | STRING(100) | 宠物名称（主键） |
| did | STRING(50) | 用户ID |
| actions | STRING(200) | 行为列表 |
| description | TEXT | 描述 |
| status | STRING(200) | 状态 |
| location | STRING(200) | 位置 |
| score | INTEGER | 评分 |
| raw_result | TEXT | 原始结果 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

### 索引变更

```sql
-- 旧索引（自动删除）
idx_video_pet_analysis_video_id
idx_video_pet_analysis_pet_name
idx_video_pet_analysis_did

-- 新索引
idx_pet_behaviors_video_id
idx_pet_behaviors_pet_name
idx_pet_behaviors_did
```

## 🚀 迁移步骤

### 1. 执行迁移脚本

```bash
cd backend
python3 migrations/migrate_rename_video_pet_analysis_to_pet_behaviors.py
```

或者使用完整迁移脚本：

```bash
./run_server_migration.sh
```

### 2. 重启服务

```bash
# 重启 Backend
systemctl restart pet-videos-backend

# 或手动重启
cd backend
python main.py
```

### 3. 验证

```bash
# 检查表是否存在
sqlite3 database/history.db ".tables"

# 应该看到 pet_behaviors，不应该看到 video_pet_analysis

# 检查数据
sqlite3 database/history.db "SELECT COUNT(*) FROM pet_behaviors;"
```

## ⚠️ 向后兼容

为了保证平滑迁移，代码中保留了别名：

```python
# 在 models/database.py 中
VideoPetAnalysis = PetBehavior
```

这意味着：
- ✅ 旧代码中的 `VideoPetAnalysis` 仍然可以工作
- ✅ 新代码应该使用 `PetBehavior`
- ✅ 迁移后可以逐步更新所有引用

## 📝 影响范围

### 已更新的文件

1. ✅ `backend/models/database.py` - 模型定义
2. ✅ `backend/api/video_records.py` - API 接口
3. ✅ `backend/api/videos.py` - API 接口
4. ✅ `backend/services/video_service.py` - 服务层
5. ✅ `backend/migrations/migrate_rename_video_pet_analysis_to_pet_behaviors.py` - 迁移脚本
6. ✅ `backend/test_server_migration.py` - 测试脚本
7. ✅ `backend/run_server_migration.sh` - 执行脚本

### 不受影响的部分

- ❌ Frontend - 前端不直接访问表名
- ❌ Service API - 使用 Backend API，不直接访问数据库
- ❌ 现有数据 - 迁移脚本会保留所有数据

## ✅ 测试验证

### 测试结果

```
执行的迁移脚本: 8
成功: 8
失败: 0

迁移后的表:
  ✓ stream_sources: 9 个字段
  ✓ video_records: 36 个字段
  ✓ pets: 13 个字段
  ✓ daily_reports: 9 个字段
  ✓ pet_behaviors: 11 个字段  ← 新表名
```

### API 测试

```bash
# 测试查询视频记录（包含宠物行为）
curl "http://localhost:8002/api/video-records/?did=test_did&date=2026-02-04"

# 应该正常返回，包含 pets 字段
```

## 📚 相关文档

- 数据库模型：`backend/models/database.py`
- 迁移脚本：`backend/migrations/migrate_rename_video_pet_analysis_to_pet_behaviors.py`
- 服务器迁移指南：`docs/SERVER_MIGRATION_GUIDE.md`

## 🎯 总结

- ✅ 表名更清晰：`pet_behaviors` 直观表达宠物行为记录
- ✅ 代码已更新：所有相关代码已使用新类名
- ✅ 向后兼容：保留别名确保平滑迁移
- ✅ 测试通过：所有迁移脚本执行成功
- ✅ 数据完整：迁移过程不丢失任何数据
