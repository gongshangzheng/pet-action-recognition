# FPS 计算修复

## 问题现象

视频播放正常，但显示 FPS 为 `1000000.0` 这种异常值。

## 根本原因

某些RTSP摄像头报告的 `average_rate` 元数据不准确：

```python
video_stream.average_rate  # 返回 1000000/1 (即 1000000.0 fps)
```

虽然**视频时间戳正确**（所以播放正常），但**元数据错误**。

使用 `add_stream_from_template()` 会复制这个错误的元数据到输出文件。

## 解决方案

**从实际 packet 时间戳计算真实 FPS**，而不是信任元数据。

### 计算方法

1. **取样本**：从 buffer 中获取最后 30 个 packet
2. **过滤**：只保留有效的 packet（`dts` 不为 None）
3. **计算时间跨度**：
   ```python
   duration_seconds = (last_dts - first_dts) * time_base
   ```
4. **计算帧率**：
   ```python
   fps = packet_count / duration_seconds
   ```

### 决策逻辑

```
源流元数据FPS
    ├── 合理范围（1-120）？
    │   ├── 是
    │   │   ├── 与计算值差异 > 5？
    │   │   │   ├── 是 → 使用计算值（元数据不准）
    │   │   │   └── 否 → 使用元数据（一致）
    │   └── 否（异常如1000000.0）
    │       ├── 有计算值？
    │       │   ├── 是 → 使用计算值
    │       │   └── 否 → 使用默认20fps
```

## 代码实现

```python
# 从buffer中最后30个packet计算实际FPS
valid_packets = [p for p in list(self.packet_buffer)[-30:] if p.dts is not None]
if len(valid_packets) >= 10:
    first_dts = valid_packets[0].dts
    last_dts = valid_packets[-1].dts
    time_base = input_video_stream.time_base
    
    duration_seconds = (last_dts - first_dts) * float(time_base)
    if duration_seconds > 0:
        calculated_fps = len(valid_packets) / duration_seconds

# 使用计算的FPS设置输出流
self.output_stream.rate = Fraction(int(calculated_fps * 1000), 1000)
```

## 效果

### 修复前
```
ffprobe event_xxx.mp4
...
Stream #0:0: Video: hevc, 2560x1440, 1000000.0 fps  ← 异常
```

### 修复后
```
ffprobe event_xxx.mp4
...
Stream #0:0: Video: hevc, 2560x1440, 20.5 fps      ← 正确
```

## 日志示例

### 场景1：元数据合理
```
[录制配置] 从时间戳计算实际FPS: 20.3 (30帧/1.48秒)
[录制配置] 使用源流FPS: 20/1
```

### 场景2：元数据异常，成功计算
```
[录制配置] 从时间戳计算实际FPS: 18.7 (28帧/1.50秒)
[录制配置] 源流FPS异常(1000000/1)，使用计算值: 18.7fps
```

### 场景3：元数据异常，无法计算（buffer太小）
```
[录制配置] 源流FPS异常(1000000/1)且无法计算，使用默认: 20fps
```

### 场景4：元数据与实际差异大
```
[录制配置] 从时间戳计算实际FPS: 25.2 (30帧/1.19秒)
[录制配置] 元数据FPS(15/1)与实际差异大，使用计算值: 25.2fps
```

## 技术细节

### 为什么需要 10 个以上的 packet？

- **统计意义**：样本太少误差大
- **跨越GOP**：确保覆盖多个关键帧周期
- **精度**：10帧约0.5秒，足够准确

### 为什么用 Fraction？

PyAV 的 `rate` 是 `Fraction` 类型：

```python
# 正确
stream.rate = Fraction(20, 1)       # 20/1 = 20.0 fps
stream.rate = Fraction(2997, 100)   # 29.97 fps

# 错误
stream.rate = 20.0  # TypeError
```

### time_base 是什么？

视频流的时间单位：

```python
time_base = Fraction(1, 90000)  # H.264常见值
# dts=90000 表示 1秒
# dts=1 表示 1/90000 秒

duration_seconds = dts_diff * float(time_base)
```

## 影响范围

- ✅ **视频播放**：无影响（时间戳始终正确）
- ✅ **元数据显示**：修正为实际FPS
- ✅ **编辑软件**：能正确识别帧率
- ✅ **后期处理**：`ffmpeg` 等工具读取正确

## 为什么不直接删除rate设置？

如果不设置 `rate`，容器格式可能：
1. 使用默认值（通常25fps）
2. 根据时间戳推断（可能不准）
3. 留空（某些播放器不支持）

**主动设置**更可靠，确保所有播放器都能正确显示。

## 测试

### 1. 查看视频帧率
```bash
ffprobe -v error -select_streams v:0 -show_entries stream=r_frame_rate,avg_frame_rate event_xxx.mp4
```

### 2. 查看详细信息
```bash
ffprobe -v error -show_streams event_xxx.mp4 | grep -i "fps\|rate\|time_base"
```

### 3. 播放验证
```bash
ffplay event_xxx.mp4  # 观察是否流畅，无加速/减速
```

## 已知限制

1. **首次录制**：如果 buffer 太小（<10帧），可能用默认值
2. **可变帧率**：如果源流是VFR（可变帧率），计算的是平均值
3. **短时录制**：录制时长<1秒时，FPS可能不准（但影响不大）

## 相关问题

- [SHORT_RECORDING_FIX.md](SHORT_RECORDING_FIX.md) - 录制只有2秒问题
- [PACKET_STREAM_FIX.md](PACKET_STREAM_FIX.md) - packet.stream 损坏问题
- [RECORDING_COOLDOWN.md](RECORDING_COOLDOWN.md) - 运动触发冷却机制
