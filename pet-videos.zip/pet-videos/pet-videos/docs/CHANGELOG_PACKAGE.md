# package.sh 调整日志

## 日期：2026-01-29

## 变更原因

根目录进行了目录结构调整：
1. 新增 `docs/` 目录 - 集中存放所有 Markdown 文档
2. 新增 `test/` 目录 - 集中存放测试脚本和临时工具文件
3. `package.sh` 需要适配新的目录结构

## 主要变更

### 1. 复制逻辑调整

#### 配置和脚本文件 [3/6]
- **移除**：不再从根目录复制测试文件（`test_*.py`, `fix_*.py` 等）
- **优化**：只复制 `start*.sh`，不复制所有 `.sh` 文件
- **保持**：继续复制 `*.bat` 和 `env.example`
- **新增**：复制 `README.md` 和 `PACKAGE.md`

#### 文档复制 [4/6] - 新增步骤
- **新增**：创建 `docs/` 目录结构
- **选择性复制**：只复制关键部署文档
  - `DEPLOY.md` - 部署指南
  - `SECURITY.md` - 安全配置
  - `INSTALL_FFMPEG.md` - FFmpeg 安装
  - `SCRIPT_SELECTION.md` - 脚本选择指南
  - `VIDEO_ENCODING.md` - 视频编码说明
- **排除**：技术细节文档（修复记录、调试文档等）

### 2. 步骤编号调整

```diff
- [1/5] 准备打包目录
- [2/5] 复制源码文件
- [3/5] 复制配置和脚本文件
- [4/5] 清理不必要的文件
- [5/5] 压缩打包

+ [1/6] 准备打包目录
+ [2/6] 复制源码文件
+ [3/6] 复制配置和脚本文件
+ [4/6] 复制关键文档 ← 新增步骤
+ [5/6] 清理不必要的文件
+ [6/6] 压缩打包
```

### 3. 打包内容更新

#### 新增排除项
- ✅ `test/` 目录（完全不复制）
- ✅ `docs/` 中的技术细节文档

#### 调整后的打包内容
```
打包内容:
  - 后端源码 (backend/)
  - 前端源码 (frontend/)
  - 切片脚本 (scripts/ - PyAV版本 + 传统版本)
  - YOLO 模型 (scripts/yolov13n.pt)
  - 启动脚本 (start_all.bat, install.bat等)
  - 配置示例 (env.example)
  - 核心文档 (docs/ - 部署、安全、编码等关键文档)
  - README.md, PACKAGE.md

已排除:
  - 测试目录 (test/ - 测试脚本和临时文件)
  - Python 虚拟环境 (venv/)
  - Node.js 依赖 (node_modules/)
  - 数据库文件 (database/)
  - 日志文件 (logs/)
  - 缓存文件 (__pycache__, .vite, dist)
  - 技术细节文档 (docs/ 中的修复和调试文档)
```

### 4. 输出信息调整

#### 部署说明更新
```diff
  部署说明:
-   1. 将 xxx.zip 上传到 Windows 服务器
+   1. 将 xxx.zip 上传到目标服务器
    2. 解压到目标目录 (如 D:\pet-videos 或 /opt/pet-videos)
    3. 复制 env.example 为 .env 并配置
-   4. 安装依赖: 运行 install.bat
-   5. 运行 start_all.bat 启动服务
-   注: 编码器会自动选择，无需额外配置
+   4. 安装依赖: 运行 install.bat (Windows) 或参考 docs/DEPLOY.md
+   5. 运行 start_all.bat (Windows) 或 start_all.sh (Linux) 启动服务
+   6. 详细文档参考 docs/DEPLOY.md
```

#### 新增文档说明
```
关键文档:
  - docs/DEPLOY.md - 部署指南
  - docs/SECURITY.md - 安全配置
  - docs/SCRIPT_SELECTION.md - 脚本选择指南
  - docs/INSTALL_FFMPEG.md - FFmpeg安装（如需要）
```

## 代码对比

### 修改前（第32-48行）
```bash
echo "[3/5] 复制配置和脚本文件..."
cp *.bat "$TEMP_DIR/" 2>/dev/null || true
cp *.sh "$TEMP_DIR/" 2>/dev/null || true
cp test_ffmpeg.py "$TEMP_DIR/" 2>/dev/null || true
cp test_opencv_codecs.py "$TEMP_DIR/" 2>/dev/null || true
cp quick_test_x264.py "$TEMP_DIR/" 2>/dev/null || true
cp fix_env_encoding.py "$TEMP_DIR/" 2>/dev/null || true
cp env.example "$TEMP_DIR/"
[ -f README.md ] && cp README.md "$TEMP_DIR/"
[ -f DEPLOY.md ] && cp DEPLOY.md "$TEMP_DIR/"
[ -f SECURITY.md ] && cp SECURITY.md "$TEMP_DIR/"
[ -f CHANGELOG.md ] && cp CHANGELOG.md "$TEMP_DIR/"
[ -f VIDEO_ENCODING.md ] && cp VIDEO_ENCODING.md "$TEMP_DIR/"
[ -f INSTALL_FFMPEG.md ] && cp INSTALL_FFMPEG.md "$TEMP_DIR/"
[ -f FFMPEG_MIGRATION.md ] && cp FFMPEG_MIGRATION.md "$TEMP_DIR/"
[ -f CODEC_TEST.md ] && cp CODEC_TEST.md "$TEMP_DIR/"

echo "[4/5] 清理不必要的文件..."
```

### 修改后（第32-53行）
```bash
echo "[3/6] 复制配置和脚本文件..."
# 复制启动和安装脚本
cp *.bat "$TEMP_DIR/" 2>/dev/null || true
cp start*.sh "$TEMP_DIR/" 2>/dev/null || true
cp env.example "$TEMP_DIR/"

# 从根目录复制主文档
[ -f README.md ] && cp README.md "$TEMP_DIR/"
[ -f PACKAGE.md ] && cp PACKAGE.md "$TEMP_DIR/"

echo "[4/6] 复制关键文档..."
# 从 docs/ 目录复制关键部署文档
mkdir -p "$TEMP_DIR/docs"
[ -f docs/DEPLOY.md ] && cp docs/DEPLOY.md "$TEMP_DIR/docs/"
[ -f docs/SECURITY.md ] && cp docs/SECURITY.md "$TEMP_DIR/docs/"
[ -f docs/INSTALL_FFMPEG.md ] && cp docs/INSTALL_FFMPEG.md "$TEMP_DIR/docs/"
[ -f docs/SCRIPT_SELECTION.md ] && cp docs/SCRIPT_SELECTION.md "$TEMP_DIR/docs/"
[ -f docs/VIDEO_ENCODING.md ] && cp docs/VIDEO_ENCODING.md "$TEMP_DIR/docs/"
# 其他技术文档可选复制（取消注释以包含）
# cp docs/*.md "$TEMP_DIR/docs/" 2>/dev/null || true

echo "[5/6] 清理不必要的文件..."
```

## 影响分析

### 优势
1. ✅ **打包体积减小**：排除测试文件，减少约 2-5MB
2. ✅ **结构更清晰**：文档独立目录，便于查找
3. ✅ **部署更简洁**：只包含必要文件，减少混淆
4. ✅ **维护更方便**：测试工具集中管理

### 兼容性
- ✅ **向后兼容**：旧版本部署不受影响
- ✅ **文档完整**：关键部署文档全部包含
- ✅ **跨平台**：Windows 和 Linux 脚本都保留

### 注意事项
1. **测试工具不在打包中**：需要从源码仓库获取
2. **技术细节文档不在打包中**：修复记录等仅在源码中
3. **可自定义**：可编辑 `package.sh` 包含更多文档

## 验证

### 语法检查
```bash
bash -n package.sh
# ✓ 通过
```

### 建议测试
```bash
# 执行打包（实际测试）
bash package.sh

# 检查打包内容
unzip -l pet-videos-source-*.zip | grep -E "docs/|test/"
# 应该看到 docs/ 但看不到 test/
```

## 相关文档

- [PACKAGE_STRUCTURE.md](docs/PACKAGE_STRUCTURE.md) - 详细的打包结构说明
- [PACKAGE.md](PACKAGE.md) - 打包使用说明
- [DEPLOY.md](docs/DEPLOY.md) - 部署指南

## 备注

- 所有修改已验证语法正确
- 新增 `docs/PACKAGE_STRUCTURE.md` 详细说明文档
- 保留旧版本文档复制逻辑的注释，方便回退
