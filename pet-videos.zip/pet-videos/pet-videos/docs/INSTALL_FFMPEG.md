# FFmpeg 安装指南

切片脚本使用 FFmpeg 进行视频编码，需要在系统中安装 FFmpeg。

## Windows 安装

### 方式 1：使用 Chocolatey（推荐）

如果已安装 Chocolatey：

```bash
choco install ffmpeg
```

### 方式 2：手动安装

1. **下载 FFmpeg**

访问官方网站：https://ffmpeg.org/download.html

或使用国内镜像：
```
https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip
```

2. **解压文件**

解压到任意目录，例如：
```
C:\ffmpeg\
```

3. **添加到系统 PATH**

- 右键 "此电脑" → "属性" → "高级系统设置"
- 点击 "环境变量"
- 在 "系统变量" 中找到 `Path`，点击 "编辑"
- 点击 "新建"，添加：
  ```
  C:\ffmpeg\bin
  ```
- 点击 "确定" 保存

4. **验证安装**

打开新的命令提示符窗口：
```bash
ffmpeg -version
```

应该看到版本信息输出。

### 方式 3：便携式安装（无需 PATH）

1. 下载 `ffmpeg.exe`
2. 复制到项目目录：
   ```
   D:\pet-videos\scripts\ffmpeg.exe
   ```
3. 脚本会自动使用同目录下的 `ffmpeg.exe`

## Linux 安装

### Ubuntu/Debian

```bash
sudo apt update
sudo apt install ffmpeg
```

### CentOS/RHEL

```bash
# CentOS 8/RHEL 8
sudo dnf install ffmpeg

# CentOS 7/RHEL 7（需要 EPEL 仓库）
sudo yum install epel-release
sudo yum install ffmpeg
```

### 验证安装

```bash
ffmpeg -version
```

## macOS 安装

### 使用 Homebrew

```bash
brew install ffmpeg
```

### 验证安装

```bash
ffmpeg -version
```

## 常见问题

### Q: 找不到 ffmpeg 命令？

A: 检查以下事项：
1. 是否已添加到系统 PATH
2. 是否在**新的**命令提示符窗口中运行（旧窗口不会加载新的 PATH）
3. 使用 `where ffmpeg`（Windows）或 `which ffmpeg`（Linux/macOS）确认路径

### Q: Windows 上如何确认 PATH 配置正确？

A: 打开命令提示符，运行：
```bash
echo %PATH%
```

检查输出中是否包含 FFmpeg 的 bin 目录路径。

### Q: 需要什么版本的 FFmpeg？

A: 任何现代版本（4.x 或 5.x）都可以。推荐使用最新稳定版。

### Q: FFmpeg 占用 CPU 高？

A: 脚本已使用 `-preset ultrafast` 参数，CPU 占用已是最低。如果仍然过高：
1. 降低视频分辨率
2. 降低帧率（15 fps）
3. 减少同时运行的切片任务数量

### Q: 视频文件很大？

A: 可以调整脚本中的 FFmpeg 参数：

```python
# 在 start_recording 方法中找到 command 数组
# 将 'ultrafast' 改为 'veryfast' 或 'fast'
'-preset', 'veryfast',  # 文件更小，但 CPU 占用稍高

# 或添加 CRF 参数控制质量
'-crf', '23',  # 18-28，数值越小质量越高，文件越大
```

### Q: FFmpeg 报错 "Broken pipe"？

A: 通常是脚本异常终止导致。检查：
1. 磁盘空间是否充足
2. 视频目录是否有写入权限
3. 查看任务日志：`backend/logs/tasks/task_X.log`

## 验证 FFmpeg 功能

运行以下命令测试 FFmpeg 是否正常工作：

```bash
# 生成 5 秒测试视频
ffmpeg -f lavfi -i testsrc=duration=5:size=640x480:rate=20 -c:v libx264 -pix_fmt yuv420p test.mp4
```

如果成功生成 `test.mp4` 文件，说明 FFmpeg 安装正确。

## 技术说明

- **编码器**: libx264（H.264 编码器）
- **色彩空间**: yuv420p（浏览器兼容）
- **输入格式**: rawvideo (bgr24)
- **输出格式**: MP4 容器

## 参考链接

- FFmpeg 官网：https://ffmpeg.org/
- FFmpeg Windows 构建：https://www.gyan.dev/ffmpeg/builds/
- FFmpeg 文档：https://ffmpeg.org/documentation.html
