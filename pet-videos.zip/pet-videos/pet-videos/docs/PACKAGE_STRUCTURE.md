# 打包结构调整说明

## 目录结构变更

### 新增目录

1. **docs/** - 文档目录
   - 所有 `.md` 文档统一放置在此目录
   - 包括部署、安全、编码、修复等各类文档

2. **test/** - 测试目录
   - 测试脚本（`test_*.py`）
   - 临时性文件（`diagnose_*.py`, `check_*.py`）
   - 调试工具（`fix_*.py`, `reset_*.py`）
   - 打包相关（`package.bat`, `deploy_*.sh`）
   - API测试（`test-api.html`）

### 目录结构

```
pet-videos/
├── backend/              # 后端源码
├── frontend/             # 前端源码
├── scripts/              # 监控脚本
│   ├── pet_monitor_pyav.py    # PyAV版本（推荐）
│   ├── pet_monitor.py         # 传统版本
│   └── yolov13n.pt           # YOLO模型
├── docs/                 # 文档（新增）
│   ├── DEPLOY.md              # 部署指南
│   ├── SECURITY.md            # 安全配置
│   ├── SCRIPT_SELECTION.md    # 脚本选择
│   ├── VIDEO_ENCODING.md      # 编码说明
│   ├── INSTALL_FFMPEG.md      # FFmpeg安装
│   ├── FPS_CALCULATION_FIX.md # FPS修复
│   ├── SHORT_RECORDING_FIX.md # 录制时长修复
│   ├── PACKET_STREAM_FIX.md   # Packet错误修复
│   └── ...                    # 其他技术文档
├── test/                 # 测试和工具（新增）
│   ├── test_*.py              # 测试脚本
│   ├── check_*.py             # 检查工具
│   ├── diagnose_*.py          # 诊断工具
│   ├── fix_*.py               # 修复工具
│   ├── reset_task.py          # 任务重置
│   └── ...                    # 其他工具
├── README.md             # 项目说明
├── PACKAGE.md            # 打包说明
├── env.example           # 配置示例
├── start_all.bat         # 启动脚本（Windows）
├── start_all.sh          # 启动脚本（Linux）
├── install.bat           # 安装脚本
└── package.sh            # 打包脚本
```

## package.sh 调整内容

### 1. 复制逻辑调整

#### 修改前（旧版本）
```bash
# 从根目录复制测试文件
cp test_ffmpeg.py "$TEMP_DIR/"
cp test_opencv_codecs.py "$TEMP_DIR/"
cp quick_test_x264.py "$TEMP_DIR/"
cp fix_env_encoding.py "$TEMP_DIR/"

# 从根目录复制文档
cp README.md "$TEMP_DIR/"
cp DEPLOY.md "$TEMP_DIR/"
cp SECURITY.md "$TEMP_DIR/"
cp *.md "$TEMP_DIR/"
```

#### 修改后（新版本）
```bash
# 只复制启动脚本，不复制测试文件
cp start*.sh "$TEMP_DIR/"

# 从 docs/ 目录复制关键文档
mkdir -p "$TEMP_DIR/docs"
cp docs/DEPLOY.md "$TEMP_DIR/docs/"
cp docs/SECURITY.md "$TEMP_DIR/docs/"
cp docs/INSTALL_FFMPEG.md "$TEMP_DIR/docs/"
cp docs/SCRIPT_SELECTION.md "$TEMP_DIR/docs/"
cp docs/VIDEO_ENCODING.md "$TEMP_DIR/docs/"
```

### 2. 排除内容

**新增排除**：
- `test/` 目录完全排除（不会被复制）
- `docs/` 中的技术细节文档（如修复文档）仅在源码中保留

**继续排除**：
- Python 虚拟环境 (`venv/`)
- Node.js 依赖 (`node_modules/`)
- 数据库文件 (`database/`)
- 日志文件 (`logs/`)
- 缓存文件 (`__pycache__`, `.vite`, `dist`)

### 3. 打包内容

#### 核心源码
- ✅ `backend/` - 后端源码
- ✅ `frontend/` - 前端源码
- ✅ `scripts/` - 监控脚本 + YOLO模型

#### 配置和启动
- ✅ `env.example` - 配置模板
- ✅ `start_all.bat/sh` - 启动脚本
- ✅ `install.bat` - 安装脚本（Windows）

#### 文档
- ✅ `README.md` - 项目说明（根目录）
- ✅ `PACKAGE.md` - 打包说明（根目录）
- ✅ `docs/DEPLOY.md` - 部署指南
- ✅ `docs/SECURITY.md` - 安全配置
- ✅ `docs/SCRIPT_SELECTION.md` - 脚本选择
- ✅ `docs/VIDEO_ENCODING.md` - 编码说明
- ✅ `docs/INSTALL_FFMPEG.md` - FFmpeg安装

#### 不打包
- ❌ `test/` - 测试和工具脚本
- ❌ `docs/` 中的修复文档（如 `FPS_CALCULATION_FIX.md`）
- ❌ 开发相关文件（`.git`, `.vscode`, `.env`）
- ❌ 构建产物和缓存

## 使用方法

### 打包

```bash
# 执行打包脚本
bash package.sh

# 或在 Windows 上
./package.sh
```

### 打包输出

```
[1/6] 准备打包目录...
[2/6] 复制源码文件...
  复制后端源码...
  复制前端源码...
  复制切片脚本...
[3/6] 复制配置和脚本文件...
[4/6] 复制关键文档...
[5/6] 清理不必要的文件...
[6/6] 压缩打包...

============================================================
  打包成功！
============================================================
  文件位置: /path/to/pet-videos-source-20260129-133000.zip
  文件大小: 15M

  打包内容:
    - 后端源码 (backend/)
    - 前端源码 (frontend/)
    - 切片脚本 (scripts/ - PyAV版本 + 传统版本)
    - YOLO 模型 (scripts/yolov13n.pt)
    - 启动脚本 (start_all.bat, install.bat等)
    - 配置示例 (env.example)
    - 核心文档 (docs/ - 部署、安全、编码等关键文档)
    - README.md, PACKAGE.md

  已排除:
    - 测试目录 (test/ - 测试脚本和临时文件)
    - Python 虚拟环境 (venv/)
    - Node.js 依赖 (node_modules/)
    - 数据库文件 (database/)
    - 日志文件 (logs/)
    - 缓存文件 (__pycache__, .vite, dist)
    - 技术细节文档 (docs/ 中的修复和调试文档)
```

## 优势

### 1. 清晰的目录结构
- 文档集中管理（`docs/`）
- 测试工具独立（`test/`）
- 源码目录更简洁

### 2. 精简的打包产物
- 只包含部署必需的文件
- 排除开发和测试文件
- 减小打包体积

### 3. 易于维护
- 文档统一位置，便于查找和更新
- 测试工具集中，开发更方便
- 打包脚本逻辑更清晰

## 迁移指南

如果你有旧版本的部署，需要注意：

### 文档位置变更
```bash
# 旧位置 → 新位置
DEPLOY.md → docs/DEPLOY.md
SECURITY.md → docs/SECURITY.md
VIDEO_ENCODING.md → docs/VIDEO_ENCODING.md
```

### 测试脚本位置变更
```bash
# 旧位置 → 新位置
test_*.py → test/test_*.py
fix_*.py → test/fix_*.py
check_*.py → test/check_*.py
```

### Git 忽略调整

如果使用 Git，确保 `.gitignore` 适配新结构：

```gitignore
# 测试生成的文件
test/deploy_*.tar.gz
test/*.log

# 文档构建产物（如果有）
docs/build/
```

## 常见问题

### Q: 为什么不打包所有文档？
**A**: 技术细节文档（如修复记录）主要用于开发和调试，部署时不需要。只打包关键的部署、配置、使用文档。

### Q: 如何获取完整文档？
**A**: 从 Git 仓库克隆完整源码，或解压源码包后查看 `docs/` 目录。

### Q: 测试脚本如何使用？
**A**: 测试脚本仅用于开发环境，从源码仓库获取。部署环境不需要。

### Q: 可以自定义打包内容吗？
**A**: 可以。编辑 `package.sh` 中的复制逻辑：
```bash
# 包含所有技术文档
cp docs/*.md "$TEMP_DIR/docs/"

# 包含特定测试工具
cp test/reset_task.py "$TEMP_DIR/"
```

## 相关文档

- [PACKAGE.md](../PACKAGE.md) - 打包说明
- [DEPLOY.md](DEPLOY.md) - 部署指南
- [README.md](../README.md) - 项目说明
