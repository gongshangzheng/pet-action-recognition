# 提示词变量系统

## 📋 概述

提示词变量系统允许在提示词模板中使用动态变量，这些变量会在实际使用时自动替换为对应的值。

## 🏗️ 系统架构

### 核心组件

1. **变量配置系统** (`frontend/src/utils/variableConfig.ts`)
   - 定义所有可用变量
   - 管理变量分类和规则
   - 提供动态变量生成逻辑

2. **变量替换引擎** (`frontend/src/utils/promptUtils.ts`)
   - 检测提示词中的变量
   - 执行变量替换
   - 处理无法替换的变量

3. **变量列表组件** (`frontend/src/components/VariableList/`)
   - 展示所有可用变量
   - 支持一键复制
   - 显示使用说明和示例

### 变量类型

- **静态变量**：固定的变量名，例如 `{{current_date}}`
- **动态变量**：根据数据生成多个实例，例如 `{{pet1_name}}`、`{{pet2_name}}`

### 变量分类

| 分类 | 标识 | 说明 |
|------|------|------|
| 🐾 宠物相关 | `VariableCategory.PET` | 宠物信息相关变量 |
| ⚙️ 系统变量 | `VariableCategory.SYSTEM` | 系统时间、日期等 |
| 👤 用户相关 | `VariableCategory.USER` | 用户信息相关 |

## 📚 可用变量列表

### 🐾 宠物相关变量

#### `{{pets_info_list}}`
完整的宠物信息列表（JSON 格式）

**示例输出：**
```json
[
  {
    "pet_name": "毛毛",
    "pet_type": "猫",
    "breed": "英短",
    "gender": "公",
    "age": "3年6个月",
    "color": "黑白相间",
    "description": "性格温顺"
  }
]
```

#### `{{pet{N}_name}}` 动态变量
第 N 只宠物的名称

- `{{pet1_name}}` → "毛毛"
- `{{pet2_name}}` → "咪咪"

#### `{{pet{N}_type}}` 动态变量
第 N 只宠物的类型

- `{{pet1_type}}` → "猫"

#### `{{pet{N}_breed}}` 动态变量
第 N 只宠物的品种

- `{{pet1_breed}}` → "英短"

#### `{{pet{N}_gender}}` 动态变量
第 N 只宠物的性别

- `{{pet1_gender}}` → "公"

#### `{{pet{N}_age}}` 动态变量
第 N 只宠物的年龄（自动计算）

- `{{pet1_age}}` → "3年6个月"

#### `{{pet{N}_weight}}` 动态变量
第 N 只宠物的体重（单位：kg）

- `{{pet1_weight}}` → "3.5"

#### `{{pet{N}_color}}` 动态变量
第 N 只宠物的颜色

- `{{pet1_color}}` → "黑白相间"

#### `{{pet{N}_description}}` 动态变量
第 N 只宠物的描述

- `{{pet1_description}}` → "性格温顺，喜欢晒太阳"

### ⚙️ 系统变量

#### `{{current_date}}`
当前日期（YYYY-MM-DD）

**示例：** `2026-01-23`

#### `{{current_time}}`
当前时间（HH:mm:ss）

**示例：** `14:30:25`

#### `{{current_datetime}}`
当前日期时间

**示例：** `2026-01-23 14:30:25`

### 👤 用户变量

#### `{{user_name}}`
当前用户的显示名称

**示例：** `张三`

## 📖 使用方法

### 1. 编辑提示词

在「提示词管理」Tab 中创建或编辑提示词：

1. 点击「新建提示词」或「编辑」
2. 右侧会显示所有可用变量
3. 点击变量名或「复制」按钮
4. 粘贴到提示词内容中

### 2. 使用变量语法

在提示词中使用 `{{变量名}}` 格式：

```text
请分析视频中 {{pet1_name}}（{{pet1_type}}）的行为。

宠物详情：
- 名称：{{pet1_name}}
- 类型：{{pet1_type}}
- 年龄：{{pet1_age}}
- 颜色：{{pet1_color}}

分析时间：{{current_datetime}}
```

### 3. 查看替换结果

在「视频分析」Tab 的「提示词」区域：
- 原始模板中的变量会被自动检测
- 显示「检测到变量」提示
- 完整提示词中会显示替换后的实际值

## 💡 最佳实践

### ✅ 推荐用法

```text
分析 {{pet1_name}} 的行为：
- 类型：{{pet1_type}}
- 年龄：{{pet1_age}}
- 特征：{{pet1_description}}

当前时间：{{current_datetime}}
```

### ❌ 不推荐

```text
分析宠物行为  # 缺少具体信息
{{pet999_name}}  # 使用不存在的序号
{{ pet1_name }}  # 变量名两侧有空格
```

### 📝 提示词模板示例

#### 示例 1：单宠物分析
```text
请详细分析视频中 {{pet1_name}} 的行为。

宠物信息：
- 名称：{{pet1_name}}
- 类型：{{pet1_type}}
- 品种：{{pet1_breed}}
- 年龄：{{pet1_age}}
- 外观特征：{{pet1_color}}

请重点关注：
1. 活动内容和频率
2. 情绪状态
3. 是否有异常行为

分析时间：{{current_datetime}}
```

#### 示例 2：多宠物对比
```text
请对比分析视频中两只宠物的行为：

【宠物A】
- 名称：{{pet1_name}}
- 类型：{{pet1_type}}
- 年龄：{{pet1_age}}

【宠物B】
- 名称：{{pet2_name}}
- 类型：{{pet2_type}}
- 年龄：{{pet2_age}}

分析要点：
1. 两只宠物的互动情况
2. 各自的活动偏好
3. 性格差异体现
```

#### 示例 3：使用完整列表
```text
宠物数据库：
{{pets_info_list}}

请根据以上数据：
1. 识别视频中出现的宠物（根据外观匹配）
2. 描述每只宠物的行为
3. 记录异常情况

用户：{{user_name}}
分析日期：{{current_date}}
```

## 🔧 技术实现

### 添加新变量

在 `variableConfig.ts` 的 `VARIABLE_DEFINITIONS` 数组中添加：

```typescript
{
  name: 'new_variable',               // 变量名
  displayName: '新变量',               // 界面显示名称
  description: '变量的详细说明',        // 说明文本
  category: VariableCategory.SYSTEM,  // 分类
  isDynamic: false,                   // 是否动态生成
  example: '示例值',                   // 示例
  getValue: (context) => {            // 值获取函数
    return '实际值';
  },
}
```

### 动态变量实现

动态变量使用 `{N}` 占位符：

```typescript
{
  name: 'pet{N}_name',                // {N} 会被替换为 1, 2, 3...
  displayName: '第N只宠物名称',
  isDynamic: true,                    // 标记为动态
  getValue: (context, index) => {     // 接收 index 参数
    if (!context.pets || index === undefined) return '';
    return context.pets[index].pet_name || '';
  },
}
```

系统会根据实际宠物数量自动生成：
- 有 3 只宠物 → 生成 `pet1_name`, `pet2_name`, `pet3_name`

## ❓ 常见问题

### Q: 变量没有被替换？

**检查清单：**
1. ✅ 变量名拼写正确
2. ✅ 变量两侧有 `{{` 和 `}}`
3. ✅ 已添加对应数据（如宠物信息）
4. ✅ 变量名没有多余空格

### Q: 动态变量序号从几开始？

从 **1** 开始（`pet1_name`, `pet2_name`...），不是从 0 开始。

### Q: 超出范围的动态变量会怎样？

例如只有 2 只宠物，使用 `{{pet3_name}}`：
- 会返回空字符串 `""`
- 不会报错

### Q: 如何查看所有可用变量？

在「提示词管理」Tab：
1. 点击「新建提示词」或「编辑」
2. 右侧面板显示所有可用变量
3. 按分类展示：宠物/系统/用户

### Q: 变量值包含特殊字符怎么办？

变量替换保持原始值，不转义。如果宠物名称是 `"Tom & Jerry"`，替换后就是 `Tom & Jerry`。

## 🚀 未来规划

### 计划支持

- **变量过滤器**：`{{pet1_name|upper}}` 转大写
- **条件变量**：`{{#if pets}}有宠物{{else}}无宠物{{/if}}`
- **循环变量**：`{{#each pets}}{{name}}{{/each}}`
- **自定义变量**：用户自定义变量和值
- **变量导出**：导出/导入变量配置

## 📂 相关文件

- [变量配置](../frontend/src/utils/variableConfig.ts) - 变量定义
- [变量替换](../frontend/src/utils/promptUtils.ts) - 替换逻辑
- [变量列表组件](../frontend/src/components/VariableList/index.tsx) - UI 组件
- [提示词管理](../frontend/src/components/PromptManagement/index.tsx) - 编辑界面
