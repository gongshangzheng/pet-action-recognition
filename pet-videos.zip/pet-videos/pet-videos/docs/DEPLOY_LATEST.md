# 最新版部署指南

## 📋 本次更新内容

### 1. 数据库变更
- ✅ 重命名表：`video_pet_analysis` → `pet_behaviors`
- ✅ 新增表：`pets`, `daily_reports`
- ✅ 扩展表：`video_records` 新增 14 个字段（LLM 调用信息）
- ✅ 修复：异常 FPS 值（11078 → 9.86）

### 2. 代码变更
- ✅ 更新所有 API 使用新表名 `PetBehavior`
- ✅ 修复 FPS 提取逻辑（优先使用 `avg_frame_rate`）
- ✅ 向后兼容：保留 `VideoPetAnalysis` 别名

### 3. 新增功能
- ✅ App API 完整实现（宠物管理、日报等）
- ✅ 数据库迁移脚本完善
- ✅ FPS 异常值自动修复

## 🚀 部署步骤

### 方案一：服务器在线部署（推荐）

#### 1. 备份当前数据

```bash
# 备份数据库
cp database/history.db database/history.db.backup.$(date +%Y%m%d_%H%M%S)

# 备份代码
cd ..
tar -czf pet-videos-backup-$(date +%Y%m%d_%H%M%S).tar.gz pet-videos/
```

#### 2. 拉取最新代码

```bash
cd /path/to/pet-videos
git pull origin dev
```

#### 3. 执行数据库迁移

```bash
cd backend

# 方式 A：使用一键脚本（推荐）
./run_server_migration.sh

# 方式 B：手动执行各个脚本
python3 migrations/migrate_add_did_to_stream_sources.py
python3 migrations/migrate_unify_video_records.py
python3 migrations/migrate_add_pets_table.py
python3 migrations/migrate_add_weight_to_pets.py
python3 migrations/migrate_add_avatar_color_to_pets.py
python3 migrations/migrate_add_video_pet_analysis_table.py
python3 migrations/migrate_rename_video_pet_analysis_to_pet_behaviors.py
python3 migrations/migrate_add_daily_reports_table.py

# 修复异常 FPS 值（可选，但推荐）
python3 migrations/fix_abnormal_fps.py
```

#### 4. 重启服务

```bash
# 停止所有服务
./stop_all.sh

# 启动所有服务
./start_all.sh

# 或者单独重启
./start_backend.sh
./start_service.sh
./start_frontend.sh
```

#### 5. 验证部署

```bash
# 检查 Backend 服务
curl http://localhost:8002/api/sources/

# 检查 Service API
curl http://localhost:8006/api/sources/

# 检查数据库表结构
sqlite3 backend/database/history.db ".tables"
# 应该看到：pet_behaviors, pets, daily_reports 等
```

---

### 方案二：离线打包部署

#### 1. 本地打包

```bash
# 在本地开发机器上
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos

# 执行打包脚本
./package.sh

# 生成的文件：output/pet-videos-source-YYYYMMDD-HHMMSS.zip
```

#### 2. 上传到服务器

```bash
# 使用 scp 上传
scp output/pet-videos-source-*.zip user@server:/tmp/

# 或使用 FTP/SFTP 工具上传
```

#### 3. 服务器上解压

```bash
# 登录服务器
ssh user@server

# 备份旧版本
cd /opt
mv pet-videos pet-videos-backup-$(date +%Y%m%d)

# 解压新版本
unzip /tmp/pet-videos-source-*.zip -d pet-videos
cd pet-videos
```

#### 4. 恢复配置和数据

```bash
# 恢复 .env 配置
cp ../pet-videos-backup-*/backend/.env backend/.env
cp ../pet-videos-backup-*/service/.env service/.env

# 恢复数据库
cp ../pet-videos-backup-*/backend/database/history.db backend/database/history.db

# 恢复视频文件（如果需要）
cp -r ../pet-videos-backup-*/backend/videos backend/
```

#### 5. 执行数据库迁移

```bash
cd backend
./run_server_migration.sh

# 修复 FPS（推荐）
python3 migrations/fix_abnormal_fps.py
```

#### 6. 安装依赖（如果是新环境）

```bash
# 安装 Python 依赖
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 安装 Node.js 依赖
cd ../frontend
npm install
```

#### 7. 启动服务

```bash
cd ..
./start_all.sh
```

---

### 方案三：Docker 部署（未来支持）

```bash
# TODO: 待实现
docker-compose up -d
```

---

## 📝 数据库迁移详细说明

### 迁移脚本执行顺序

```
1. migrate_add_did_to_stream_sources.py       # 添加用户ID字段
2. migrate_unify_video_records.py             # 统一视频记录表
3. migrate_add_pets_table.py                  # 创建宠物表
4. migrate_add_weight_to_pets.py              # 添加体重字段
5. migrate_add_avatar_color_to_pets.py        # 添加头像颜色
6. migrate_add_video_pet_analysis_table.py    # 创建行为分析表
7. migrate_rename_video_pet_analysis_to_pet_behaviors.py  # 重命名表
8. migrate_add_daily_reports_table.py         # 创建日报表
```

### 迁移脚本特点

- ✅ **自动备份**：执行前自动备份数据库
- ✅ **幂等性**：可以重复执行，不会重复创建
- ✅ **错误回滚**：失败时提示回滚命令
- ✅ **详细日志**：输出每一步的执行结果

### 手动回滚

如果迁移失败需要回滚：

```bash
# 找到备份文件
ls -lt backend/database/*.backup.*

# 回滚到备份
cp backend/database/history.db.backup.20260204_190000 backend/database/history.db
```

---

## ⚠️ 注意事项

### 1. 数据库备份

**务必在迁移前备份数据库！**

```bash
# 自动备份（迁移脚本会自动执行）
cp database/history.db database/history.db.backup.$(date +%Y%m%d_%H%M%S)

# 手动备份到安全位置
scp database/history.db backup-server:/backups/pet-videos/
```

### 2. 服务停机时间

- 数据库迁移时间：约 1-5 分钟（取决于数据量）
- FPS 修复时间：约 5-10 分钟（取决于视频文件数量）
- 建议在低峰期部署

### 3. 依赖检查

```bash
# 检查 Python 版本
python3 --version  # 需要 >= 3.8

# 检查 Node.js 版本
node --version     # 需要 >= 16

# 检查 FFmpeg
ffmpeg -version
ffprobe -version
```

### 4. 端口占用

确保以下端口未被占用：
- `8002` - Backend API
- `8006` - Service API
- `8173` - Frontend

```bash
# 检查端口占用
lsof -i:8002
lsof -i:8006
lsof -i:8173
```

### 5. 环境变量

确保 `.env` 文件配置正确：

```bash
# backend/.env
DATABASE_PATH=database/history.db
VIDEO_DIRS={"alias1": "/path/to/videos"}

# service/.env
BACKEND_URL=http://localhost:8002
```

---

## 🔍 部署验证清单

### 1. 数据库验证

```bash
cd backend

# 检查表是否存在
sqlite3 database/history.db ".tables"
# 应该看到：pet_behaviors, pets, daily_reports, video_records, stream_sources

# 检查 pet_behaviors 表结构
sqlite3 database/history.db "PRAGMA table_info(pet_behaviors);"

# 检查 FPS 值是否正常
sqlite3 database/history.db "SELECT id, file_name, fps FROM video_records WHERE fps > 100 LIMIT 5;"
# 应该没有结果或很少
```

### 2. API 验证

```bash
# Backend API
curl http://localhost:8002/api/sources/
curl http://localhost:8002/api/videos/?date=2026-02-04

# Service API
curl http://localhost:8006/api/sources/
curl http://localhost:8006/api/pet/list

# Frontend
curl http://localhost:8173/
```

### 3. 功能验证

- [ ] 视频列表显示正常
- [ ] FPS 值显示正常（10-30 范围）
- [ ] 宠物管理功能正常
- [ ] 视频分析功能正常
- [ ] 日报生成功能正常

### 4. 日志检查

```bash
# Backend 日志
tail -f backend/logs/app.log

# Service 日志
tail -f service/logs/app.log

# 检查是否有错误
grep -i error backend/logs/app.log
```

---

## 🆘 常见问题

### 1. 迁移脚本报错 "table already exists"

**原因**：表已经存在，可能已经执行过迁移

**解决**：
```bash
# 检查表是否已存在
sqlite3 database/history.db ".tables"

# 如果表已存在，跳过该脚本或删除表后重新执行
```

### 2. FPS 修复脚本找不到视频文件

**原因**：视频文件已被删除或路径不正确

**解决**：这是正常的，脚本会跳过不存在的文件

### 3. 服务启动失败 "Address already in use"

**原因**：端口被占用

**解决**：
```bash
# 找到占用进程
lsof -ti:8002 | xargs kill -9
lsof -ti:8006 | xargs kill -9
lsof -ti:8173 | xargs kill -9

# 重新启动
./start_all.sh
```

### 4. 前端显示 "Network Error"

**原因**：Backend 或 Service 未启动

**解决**：
```bash
# 检查服务状态
ps aux | grep uvicorn
ps aux | grep vite

# 重启服务
./start_backend.sh
./start_service.sh
```

---

## 📚 相关文档

- [数据库迁移指南](SERVER_MIGRATION_GUIDE.md)
- [表重命名说明](RENAME_VIDEO_PET_ANALYSIS.md)
- [FPS 修复说明](FPS_FIX.md)
- [App API 实施报告](../service/appdoc/APP_API_实施完成报告.md)
- [统一视频记录表](UNIFY_VIDEO_RECORDS.md)

---

## 🎯 快速部署命令（服务器在线）

```bash
# 一键部署脚本
cd /path/to/pet-videos

# 1. 备份
cp backend/database/history.db backend/database/history.db.backup.$(date +%Y%m%d_%H%M%S)

# 2. 拉取代码
git pull origin dev

# 3. 停止服务
./stop_all.sh

# 4. 执行迁移
cd backend
./run_server_migration.sh
python3 migrations/fix_abnormal_fps.py
cd ..

# 5. 启动服务
./start_all.sh

# 6. 验证
sleep 5
curl http://localhost:8002/api/sources/
curl http://localhost:8006/api/sources/
```

---

## ✅ 部署完成

部署完成后，你应该看到：

1. ✅ 所有服务正常运行
2. ✅ 数据库表结构已更新
3. ✅ FPS 值显示正常
4. ✅ 新功能（宠物管理、日报）可用
5. ✅ 旧数据完整保留

如有问题，请查看日志或联系开发团队。
