# .gitignore 配置说明

## 更新日期：2026-01-29

## 变更原因

适配新的目录结构（`docs/` 和 `test/` 目录），优化版本控制策略。

## 忽略规则详解

### 1. Python 相关
```gitignore
__pycache__/          # Python 字节码缓存
*.py[cod]             # 编译的 Python 文件
*$py.class            # Python 类文件
*.so                  # 共享对象文件
.Python               # Python 环境标记
venv/                 # 虚拟环境
env/                  # 环境目录
ENV/                  # 环境目录
*.egg-info/           # Python 包信息
dist/                 # 分发目录
build/                # 构建目录
```

**说明**：标准 Python 项目忽略规则，避免提交环境和编译产物。

### 2. 环境配置
```gitignore
.env                  # 生产环境配置（包含敏感信息）
.env.local            # 本地环境配置
.env.*.local          # 各环境的本地配置
```

**说明**：
- ✅ **提交** `env.example` - 配置模板（无敏感信息）
- ❌ **忽略** `.env` - 实际配置（包含密钥、密码等）

### 3. 数据库
```gitignore
*.db                  # SQLite 数据库文件
*.sqlite              # SQLite 数据库
*.sqlite3             # SQLite 数据库
backend/database/     # 数据库目录
```

**说明**：数据库文件包含运行时数据，不应版本控制。

### 4. 日志文件
```gitignore
logs/                 # 日志目录
*.log                 # 所有日志文件
```

**说明**：日志文件是运行时产生的，体积大且无版本控制意义。

### 5. IDE 和编辑器
```gitignore
.vscode/              # VS Code 配置
.idea/                # JetBrains IDEs 配置
*.swp                 # Vim 交换文件
*.swo                 # Vim 交换文件
*~                    # 备份文件
.DS_Store             # macOS 元数据
Thumbs.db             # Windows 缩略图
desktop.ini           # Windows 文件夹配置
```

**说明**：IDE 配置因人而异，不应强制提交。团队可选择性提交共享配置。

### 6. 缓存
```gitignore
*.cache               # 通用缓存文件
.cache/               # 缓存目录
data/                 # 数据缓存
database/video_cache/ # 视频缓存
```

**说明**：缓存文件可以重新生成，不需要版本控制。

### 7. 打包输出 ⭐ 新增
```gitignore
pet-videos-source-*.zip       # 源码打包输出
pet-videos-deploy-*.tar.gz    # 部署打包输出
*.tar.gz                      # 通用压缩包
*.rar                         # RAR 压缩包
```

**说明**：
- 打包文件由 `package.sh` 生成
- 带时间戳，如 `pet-videos-source-20260129-133000.zip`
- 体积大（15-30MB），不适合 Git

### 8. test/ 目录 ⭐ 新增
```gitignore
test/*.tar.gz         # test 目录中的压缩包
test/*.zip            # test 目录中的 zip 包
test/*.log            # test 目录中的日志
test/deploy_*.tar.gz  # 部署测试生成的包
test/output/          # 测试输出目录
test/temp/            # 临时文件目录
test/__pycache__/     # Python 缓存
```

**说明**：
- ✅ **提交** `test/*.py` - 测试脚本源码
- ✅ **提交** `test/*.sh`, `test/*.bat` - 测试和工具脚本
- ❌ **忽略** 测试生成的临时文件和打包产物

**示例**：
```
test/
├── test_ffmpeg.py           ✅ 提交（测试脚本）
├── reset_task.py            ✅ 提交（工具脚本）
├── deploy_fix.sh            ✅ 提交（部署脚本）
├── deploy_files.tar.gz      ❌ 忽略（临时打包）
└── output/                  ❌ 忽略（测试输出）
```

### 9. docs/ 目录 ⭐ 新增
```gitignore
docs/build/           # 文档构建输出（如 Sphinx）
docs/_build/          # 文档构建输出
docs/.doctrees/       # Sphinx 缓存
docs/site/            # MkDocs 构建输出
```

**说明**：
- ✅ **提交** `docs/*.md` - Markdown 源文档
- ❌ **忽略** 文档工具的构建产物（如果使用 Sphinx/MkDocs）

**当前状态**：
- 项目使用纯 Markdown，无构建工具
- 所有 `.md` 文件都应提交
- 如果未来使用文档生成工具，这些规则会起作用

### 10. 前端相关
```gitignore
frontend/node_modules/        # npm 依赖
frontend/dist/                # 构建输出
frontend/build/               # 构建输出
frontend/.next/               # Next.js 缓存
frontend/out/                 # Next.js 静态导出
frontend/.vite/               # Vite 缓存
frontend/.env.local           # 本地环境配置
frontend/.env.*.local         # 各环境本地配置
frontend/npm-debug.log*       # npm 调试日志
frontend/yarn-debug.log*      # Yarn 调试日志
frontend/yarn-error.log*      # Yarn 错误日志
```

**说明**：
- `node_modules/` 通过 `package.json` 可重新安装
- 构建产物通过 `npm run build` 可重新生成

### 11. 后端临时文件 ⭐ 新增
```gitignore
backend/logs/         # 后端日志
backend/temp/         # 后端临时文件
backend/__pycache__/  # Python 缓存
```

**说明**：后端运行时产生的临时文件。

### 12. 脚本临时文件 ⭐ 新增
```gitignore
scripts/__pycache__/  # Python 缓存
scripts/*.pyc         # 编译的 Python 文件
scripts/temp/         # 临时文件
```

**说明**：监控脚本运行时产生的缓存。

### 13. 视频文件
```gitignore
videos/*.mp4          # MP4 视频
videos/*.avi          # AVI 视频
videos/*.mov          # MOV 视频
videos/*.mkv          # MKV 视频
```

**说明**：
- 视频文件体积大（几百MB）
- 不适合 Git，建议使用 Git LFS 或外部存储
- 如需版本控制视频，注释掉这些规则

### 14. 备份文件 ⭐ 新增
```gitignore
*.bak                 # .bak 备份文件
*.backup              # .backup 备份文件
*.old                 # .old 旧版本文件
*_副本.py             # 中文副本文件
*_copy.py             # 英文副本文件
```

**说明**：
- 编辑器或手动创建的备份文件
- 例如：`pet_monitor_pyav.py.bak`、`config_副本.py`

### 15. 临时文件 ⭐ 新增
```gitignore
*.tmp                 # .tmp 临时文件
*.temp                # .temp 临时文件
.tmp/                 # 临时目录
.temp/                # 临时目录
```

**说明**：通用临时文件规则。

## 版本控制策略

### 应该提交的文件 ✅

#### 源码
- `backend/**/*.py` - 后端 Python 代码
- `frontend/src/**/*` - 前端源码
- `scripts/*.py` - 监控脚本（除了备份）
- `test/*.py` - 测试脚本
- `test/*.sh`, `test/*.bat` - 工具脚本

#### 配置模板
- `env.example` - 环境配置模板
- `backend/config.py` - 配置代码（不含敏感信息）
- `frontend/package.json` - 前端依赖声明
- `backend/requirements.txt` - 后端依赖声明

#### 文档
- `README.md` - 项目说明
- `PACKAGE.md` - 打包说明
- `docs/*.md` - 所有文档
- `CHANGELOG*.md` - 变更日志

#### 脚本
- `*.sh` - Shell 脚本（根目录）
- `*.bat` - Windows 批处理脚本（根目录）
- `package.sh` - 打包脚本
- `start_all.sh/bat` - 启动脚本
- `install.bat` - 安装脚本

#### 其他
- `.gitignore` - Git 忽略规则
- `yolov13n.pt` - YOLO 模型（如果不太大）

### 不应提交的文件 ❌

#### 环境和配置
- `.env` - 实际环境配置（**包含密钥！**）
- `backend/database/` - 数据库文件
- `logs/` - 日志文件

#### 依赖和缓存
- `venv/`, `node_modules/` - 依赖包
- `__pycache__/` - Python 缓存
- `frontend/.vite/` - Vite 缓存

#### 构建产物
- `frontend/dist/` - 前端构建输出
- `*.zip`, `*.tar.gz` - 打包文件
- `test/*.tar.gz` - 测试打包文件

#### 临时文件
- `*.log` - 日志文件
- `*.tmp`, `*.temp` - 临时文件
- `*.bak`, `*_副本.py` - 备份文件

#### 大文件
- `videos/*.mp4` - 录制的视频
- 大型模型文件（除非必要）

## 常见场景

### 场景1：新增测试脚本

```bash
# 创建测试脚本
cd test/
vim test_new_feature.py

# 会被 Git 跟踪（✅ 正常）
git status
# 显示: test/test_new_feature.py

# 执行测试产生输出
./test_new_feature.py > output.log

# 输出文件被忽略（✅ 正常）
git status
# 不显示 output.log
```

### 场景2：打包源码

```bash
# 执行打包
bash package.sh

# 生成的 zip 被忽略（✅ 正常）
git status
# 不显示 pet-videos-source-*.zip
```

### 场景3：新增文档

```bash
# 创建新文档
cd docs/
vim NEW_FEATURE.md

# 会被 Git 跟踪（✅ 正常）
git status
# 显示: docs/NEW_FEATURE.md

git add docs/NEW_FEATURE.md
git commit -m "docs: 新增功能文档"
```

### 场景4：修改配置

```bash
# 修改配置模板（✅ 应该提交）
vim env.example
git add env.example
git commit -m "config: 更新配置模板"

# 修改实际配置（❌ 不应该提交）
vim .env
git status
# 不显示 .env（被 .gitignore 忽略）
```

### 场景5：清理备份文件

```bash
# 查看被忽略的备份文件
git status --ignored

# 批量删除备份文件
find . -name "*.bak" -delete
find . -name "*_副本.py" -delete
```

## 检查忽略状态

### 查看被忽略的文件
```bash
git status --ignored
```

### 测试文件是否会被忽略
```bash
# 测试单个文件
git check-ignore -v test/output.log
# 输出: .gitignore:45:test/*.log    test/output.log

# 测试多个文件
git check-ignore -v *.zip *.log test/*.tar.gz
```

### 强制添加被忽略的文件（谨慎使用）
```bash
# 如果确实需要提交某个被忽略的文件
git add -f test/important.log
```

## 团队协作建议

### 1. 配置文件管理
```bash
# ❌ 错误：直接提交 .env
git add .env
git commit -m "add config"  # 可能泄露密钥！

# ✅ 正确：更新配置模板
vim env.example  # 添加新配置项（不含实际值）
git add env.example
git commit -m "config: 添加新配置项"
```

### 2. 文档更新
```bash
# 所有文档都应该提交
git add docs/*.md
git commit -m "docs: 更新部署文档"
```

### 3. 测试脚本
```bash
# 提交测试脚本源码
git add test/test_new.py
git commit -m "test: 添加新功能测试"

# 但不提交测试输出
# test/*.log 已被自动忽略
```

## 故障排查

### 问题1：文件应该被忽略但没有被忽略

**原因**：文件已经被 Git 跟踪了（在添加 .gitignore 规则之前）

**解决**：
```bash
# 从 Git 中移除但保留本地文件
git rm --cached path/to/file

# 例如：移除已跟踪的 .env
git rm --cached .env
git commit -m "fix: 移除敏感配置文件"
```

### 问题2：修改 .gitignore 后不生效

**解决**：
```bash
# 清除 Git 缓存
git rm -r --cached .
git add .
git commit -m "fix: 更新 .gitignore 规则"
```

### 问题3：意外提交了大文件

**解决**：
```bash
# 如果还没推送到远程
git reset HEAD~1  # 撤销最后一次提交

# 如果已经推送
# 需要使用 git filter-branch 或 BFG Repo-Cleaner
```

## 相关文档

- [PACKAGE_STRUCTURE.md](PACKAGE_STRUCTURE.md) - 项目结构说明
- [DEPLOY.md](DEPLOY.md) - 部署指南
- [SECURITY.md](SECURITY.md) - 安全配置

## 最佳实践

1. ✅ **提交前检查**：`git status` 确认没有敏感文件
2. ✅ **使用模板**：配置用 `env.example`，不提交 `.env`
3. ✅ **及时清理**：定期删除备份和临时文件
4. ✅ **谨慎 force add**：避免使用 `git add -f`
5. ✅ **团队规范**：统一使用项目的 `.gitignore`
