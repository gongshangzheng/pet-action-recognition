# 日报功能设计说明

## 核心原则

**日报由 LLM 自动生成，用户只能查看，不能手动编辑。**

## 权限设计

### 用户权限（通过 Service API）

| 操作 | 接口 | 权限 | 说明 |
|------|------|------|------|
| 查看日报列表 | `GET /api/daily-report` | ✅ 允许 | 只能查看自己的日报 |
| 查看指定日报 | `GET /api/daily-report/{date}/{pet_name}` | ✅ 允许 | 只能查看自己的日报 |
| 触发生成日报 | ~~POST /api/daily-report/generate~~ | ❌ 禁止 | 已移除，由后端按策略自动生成 |
| 手动编辑日报 | ~~POST /api/daily-report/save~~ | ❌ 禁止 | 已移除 |
| 删除日报 | ~~POST /api/daily-report/delete~~ | ❌ 禁止 | 已移除 |

### 系统权限（通过 Backend API）

| 操作 | 接口 | 权限 | 说明 |
|------|------|------|------|
| 查询日报 | `GET /api/daily-reports/` | ✅ 允许 | 内部接口，需 JWT |
| 创建/更新日报 | `POST /api/daily-reports/` | ✅ 允许 | 由系统自动调用 |
| 更新日报 | `PUT /api/daily-reports/{did}/{date}/{pet_name}` | ✅ 允许 | 由系统自动调用 |
| 删除日报 | `DELETE /api/daily-reports/{did}/{date}/{pet_name}` | ✅ 允许 | 由系统管理员操作 |

## 日报生成流程

```mermaid
graph TD
    A[触发生成] --> B{触发方式}
    B -->|定时任务| D[系统定时调用 Backend 内部方法]
    B -->|实时更新| E[视频分析完成后触发]
    
    D --> G[Backend 内部方法]
    E --> G
    
    G --> I[查询 video_pet_analysis 表]
    
    I --> J[获取指定日期该宠物的所有分析记录]
    J --> K[统计数据: video_count, total_duration]
    K --> L[调用 LLM 生成日报摘要]
    L --> M[保存到 daily_reports 表 UPSERT]
    M --> N[日报生成完成]
    
    U[用户] --> V[前端查看日报]
    V --> W[调用 Service API]
    W --> X[返回日报数据]
```

## 接口调整对比

### 调整前（❌ 错误设计）

```bash
# 用户可以手动编辑日报内容
POST /api/daily-report/save
{
  "date": "2026-01-23",
  "pet_name": "毛毛",
  "summary": "用户自己编写的内容...",  # ❌ 不应该由用户编写
  "video_count": 15,
  "total_duration": 3600.0
}
```

### 调整后（✅ 正确设计）

```bash
# 用户只能查看日报（只读）
GET /api/daily-report?date=2026-01-23

# 日报由后端系统按策略自动生成：
# 1. 定时任务每天自动生成前一天的日报
# 2. 视频分析完成后自动更新当日日报
# 3. 系统内部调用：查询分析记录 -> 调用 LLM -> 保存日报
```

## 实现要点

### 1. Service 层 (`service/app.py`)

**用户接口**（只读）：
- `GET /api/daily-report` - 查询日报列表
- `GET /api/daily-report/{date}/{pet_name}` - 查询指定日报

**实现逻辑**：
```python
@app.get("/api/daily-report")
async def get_daily_reports(
    date: Optional[str] = None,
    pet_name: Optional[str] = None,
    user_info: Dict = Depends(require_login)
):
    """获取日报列表（只读）"""
    did = user_info.get("did")
    
    # 调用 backend API 查询日报
    params = {"did": did}
    if date:
        params["date"] = date
    if pet_name:
        params["pet_name"] = pet_name
    
    # 返回日报数据
    ...
```

### 2. Backend 层 (`backend/api/daily_reports.py`)

**内部接口**（需 JWT）：
- `GET /api/daily-reports/` - 查询日报
- `GET /api/daily-reports/{did}/{date}/{pet_name}` - 查询指定日报
- `POST /api/daily-reports/` - 创建/更新日报（UPSERT）
- `PUT /api/daily-reports/{did}/{date}/{pet_name}` - 更新日报
- `DELETE /api/daily-reports/{did}/{date}/{pet_name}` - 删除日报

**生成日报的内部方法**（待实现）：
```python
async def generate_report_for_pet(did: str, date: str, pet_name: str):
    """内部方法：生成日报"""
    # 1. 查询该日该宠物的所有视频分析记录
    analysis_records = db.query(VideoPetAnalysis).join(VideoRecord).filter(
        VideoPetAnalysis.did == did,
        VideoPetAnalysis.pet_name == pet_name,
        VideoRecord.date == date
    ).all()
    
    # 2. 统计数据
    video_count = len(analysis_records)
    total_duration = sum(r.duration for r in analysis_records)
    
    # 3. 调用 LLM 生成摘要
    summary = await call_llm_to_generate_summary(analysis_records)
    
    # 4. 保存日报（UPSERT）
    report = DailyReport(
        did=did,
        date=date,
        pet_name=pet_name,
        summary=summary,
        analysis_data=json.dumps([r.to_dict() for r in analysis_records]),
        video_count=video_count,
        total_duration=total_duration
    )
    
    db.merge(report)  # UPSERT
    db.commit()
    
    return report
```

## 使用场景

### 场景 1：用户查看日报

用户在前端查看宠物日报：

```typescript
// 前端代码
async function viewTodayReport(petName: string) {
  const today = new Date().toISOString().split('T')[0];
  
  const response = await fetch(`/api/daily-report?date=${today}&pet_name=${petName}`, {
    credentials: 'include'
  });
  
  const result = await response.json();
  if (result.errno === 0) {
    console.log('日报数据:', result.data.reports);
    // 展示日报内容
  }
}
```

### 场景 2：后端定时任务自动生成

每天凌晨自动生成前一天的日报：

```python
# 定时任务脚本
import asyncio
from datetime import date, timedelta

async def auto_generate_yesterday_reports():
    """自动生成昨日所有宠物的日报"""
    yesterday = (date.today() - timedelta(days=1)).strftime('%Y-%m-%d')
    
    # 从数据库获取所有活跃宠物
    pets = await get_all_active_pets()
    
    for pet in pets:
        try:
            # 调用内部方法生成日报
            await generate_report_for_pet(
                did=pet.did,
                date=yesterday,
                pet_name=pet.pet_name
            )
            print(f"✅ {pet.pet_name} 的日报生成成功")
        except Exception as e:
            print(f"❌ {pet.pet_name} 的日报生成失败: {e}")

# 在 crontab 中配置：每天 01:00 执行
# 0 1 * * * cd /path/to/project && python generate_daily_reports.py
```

### 场景 3：视频分析完成后实时更新

每次视频分析完成后，自动更新当日日报：

```python
async def on_video_analysis_complete(video_id: int, pet_name: str):
    """视频分析完成回调"""
    video = db.query(VideoRecord).filter(VideoRecord.id == video_id).first()
    
    # 触发重新生成当日日报（会自动汇总所有分析记录）
    await generate_report_for_pet(
        did=video.did,
        date=video.date,
        pet_name=pet_name
    )
```

## 数据流向

### 日报生成流程（后端自动）

```
定时任务/视频分析完成
    ↓
Backend 内部方法
    ↓
查询 video_pet_analysis 表
    ↓
调用 LLM 生成摘要
    ↓
保存到 daily_reports 表（UPSERT）
```

### 用户查看流程（只读）

```
用户请求
    ↓
Service API (登录校验)
    ↓
Backend API (查询接口)
    ↓
查询 daily_reports 表
    ↓
返回日报数据
    ↓
用户查看
```

## 安全性

1. **用户不能篡改**：日报内容完全由 LLM 生成，用户无法修改
2. **权限隔离**：用户只能查看自己的日报
3. **数据真实性**：日报基于 `video_pet_analysis` 表的真实分析数据
4. **审计追踪**：`created_at` 和 `updated_at` 记录生成和更新时间

## 后续优化

- [ ] 实现 Backend 内部日报生成方法
- [ ] 添加 LLM 调用模块生成日报摘要
- [ ] 实现定时任务脚本（每天自动生成前一天日报）
- [ ] 实现视频分析完成后的自动触发逻辑
- [ ] 添加日报生成失败的重试机制
- [ ] 支持日报模板配置
- [ ] 添加日报生成日志和监控
