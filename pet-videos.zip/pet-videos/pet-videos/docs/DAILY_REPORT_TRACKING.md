# 日报追踪机制说明 (V3.0)

## 概述

从V3.0开始，`daily_reports`表支持**多版本记录**，每次LLM请求都会插入新记录，用于追踪和问题分析。

## 核心变更

### 1. 数据库表结构调整

**旧设计（V2.0）：**
- 联合主键：`(did, date, pet_name)`
- 每个宠物每天只有一条唯一记录
- 采用 UPSERT 逻辑（存在则更新）

**新设计（V3.0）：**
- 自增主键：`id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `(did, date, pet_name)` 可重复
- 每次LLM请求都插入新记录（不再UPSERT）

### 2. 新增追踪字段

| 字段名 | 类型 | 说明 |
|--------|------|------|
| `llm_request` | TEXT | LLM请求的原始提示词（完整prompt） |
| `llm_response` | TEXT | LLM返回的原始JSON内容 |

### 3. 查询逻辑调整

**展示时只返回最新记录：**

使用子查询按 `(did, date, pet_name)` 分组，取 `MAX(id)` 获取最新记录：

```sql
WITH latest_reports AS (
    SELECT 
        did, 
        date, 
        pet_name, 
        MAX(id) as max_id
    FROM daily_reports
    WHERE did = ? AND date = ?
    GROUP BY did, date, pet_name
)
SELECT dr.* 
FROM daily_reports dr
JOIN latest_reports lr ON dr.id = lr.max_id
ORDER BY dr.created_at DESC;
```

**关键点：**
- `id` 越大表示越新插入的记录
- 即使 `created_at` 相同或更早，`id` 更大的记录也是"最新版本"
- 这确保了追踪链的完整性：id序列 = 时间顺序

## 使用场景

### 场景1：正常生成流程

```
用户: 0, 宠物: 妹妹, 日期: 2026-02-11

第一次生成（早上5:00）:
  - 插入 id=1, summary="活力充沛...", llm_request="...", llm_response="..."
  
第二次生成（中午12:00）:
  - 插入 id=5, summary="中午休息...", llm_request="...", llm_response="..."
  
第三次生成（晚上20:00）:
  - 插入 id=12, summary="疲惫瘫倒...", llm_request="...", llm_response="..."

查询展示：
  - 返回 id=12（最新）
  
问题追踪：
  - 可以查看 id=1, 5, 12 的完整历史记录
```

### 场景2：失败重试流程

```
第一次生成失败:
  - 插入 id=10, generation_status='failed', error_message="超时"

重试成功:
  - 插入 id=11, generation_status='completed', summary="..."

查询展示：
  - 返回 id=11（成功的记录）
  
问题追踪：
  - id=10 保留失败原因，便于分析
```

### 场景3：问题追踪

开发者可以通过以下SQL查询完整历史：

```sql
-- 查看某只宠物某天的所有生成记录
SELECT 
    id,
    generation_status,
    daily_tag,
    created_at,
    length(llm_request) as request_len,
    length(llm_response) as response_len
FROM daily_reports
WHERE did='0' AND date='2026-02-11' AND pet_name='妹妹'
ORDER BY id;

-- 查看具体某次生成的完整请求和响应
SELECT 
    llm_request,
    llm_response,
    error_message
FROM daily_reports
WHERE id = 10;
```

## API变更

### `/api/daily-reports/` 

**参数：**
- `did` (optional): 用户ID
- `date` (optional): 日期 (YYYY-MM-DD)
- `pet_name` (optional): 宠物名称

**返回：**
- 每只宠物返回**最新的一条记录**（按 `MAX(id)` 筛选）

**响应示例：**

```json
{
  "reports": [
    {
      "id": 12,
      "did": "0",
      "date": "2026-02-11",
      "pet_name": "妹妹",
      "summary": "妹妹今天**休息**时警觉又惬意...",
      "daily_tag": "活力满满",
      "insight_text": "妹妹今日行为均衡...",
      "llm_request": "你是一个专业的宠物行为分析师...",
      "llm_response": "{\"summary\": \"...\", \"daily_tag\": \"...\"}",
      "generation_status": "completed",
      "created_at": "2026-02-11T18:14:56.919677"
    }
  ],
  "total": 1
}
```

## 前端变更

### 表格 `rowKey`

```typescript
// 旧（V2.0）
rowKey={(record) => `${record.did}-${record.date}-${record.pet_name}`}

// 新（V3.0）
rowKey={(record) => record.id}
```

### 数据接口

```typescript
interface DailyReport {
  id: number;  // 新增：自增ID
  did: string;
  date: string;
  pet_name: string;
  summary: string;
  daily_tag?: string;
  insight_text?: string;
  llm_request?: string;   // 新增：LLM请求
  llm_response?: string;  // 新增：LLM响应
  video_count: number;
  total_duration: number;
  generation_status: string;
  created_at: string;
  updated_at: string;
}
```

## 迁移说明

执行迁移脚本：

```bash
cd backend
python3 migrations/migrate_rebuild_daily_reports.py
```

**迁移步骤：**
1. 备份旧表到 `daily_reports_backup`
2. 删除旧表
3. 创建新表结构（带自增主键和新字段）
4. 迁移数据（旧记录的 `llm_request` 和 `llm_response` 为 NULL）
5. 创建索引（`did`, `date`, `pet_name`, `created_at`）
6. 删除备份表

**注意事项：**
- 旧数据会保留，但 `llm_request` 和 `llm_response` 为空
- 迁移后新生成的日报才会包含完整的追踪信息

## 优势

1. **完整追踪**：每次LLM调用都有记录，便于问题排查
2. **历史查询**：可以查看同一天多次生成的历史版本
3. **失败分析**：失败记录不会被覆盖，保留完整错误信息
4. **性能监控**：可统计每次LLM调用的提示词长度、响应时间等
5. **无损展示**：用户看到的始终是最新版本，不影响体验

## 注意事项

1. **存储空间**：每次生成都插入新记录，需定期清理旧数据
2. **查询性能**：使用子查询会略微增加查询开销，但已优化索引
3. **数据一致性**：`id` 的自增顺序即时间顺序，不要手动修改id

## 未来优化方向

1. 添加数据清理任务（保留最近N天的完整历史，旧数据只保留最新版本）
2. 添加统计分析接口（LLM调用成功率、平均响应时间等）
3. 添加历史版本查看功能（前端展示同一天的多次生成记录）
