# 录制只有2秒问题修复

## 问题现象

服务器日志显示：
```
[2026-01-28 08:36:14] 录制已保存: event_20260128_083611.mp4, 时长 2秒
[2026-01-28 08:36:14] [录制结束] 总时长 2.8秒 (后摇 15秒已满)
```

配置明明是15秒后摇，为什么只录了2秒？

## 根本原因

**运动触发冷却机制与后摇时间冲突**。

### 问题流程

```
时间轴分析：

08:36:01 - YOLO检测到猫 → 更新 last_pet_time = 08:36:01
           ↓
           检查是否可以录制
           ↓
           发现在冷却期（剩余9.8秒）→ 不触发录制
           ↓
           但 last_pet_time 已经被更新！
           
08:36:11 - 冷却期结束（10秒后）
           ↓
           检查是否可以录制
           ↓
           可以录制！触发录制
           ↓
           但此时 last_pet_time 还是 08:36:01
           ↓
           距离 last_pet_time 已经 10秒了
           
08:36:11 - [录制开始] 距上次运动 12.2秒
           ↓
           POST_EVENT_SECONDS = 15秒
           ↓
           只能再录 15 - 12 = 3秒
           
08:36:14 - [录制结束] (15秒已满)
           ↓
           实际只录了 2.8秒
```

### 核心问题

1. **检测到运动** → 立即更新 `last_pet_time`
2. **但在冷却期** → 不触发录制
3. **冷却结束后** → 触发录制
4. **但 `last_pet_time`** → 已经是很久之前
5. **录制很快结束** → 因为"后摇15秒已满"

## 解决方案

### 方案：录制触发时重置时间戳（已实施）

在触发录制时，重置 `shared_last_pet_time`，确保有完整的后摇时长：

```python
# pet_monitor_pyav.py 第581-588行
else:
    # 🔑 触发新录制，记录触发时间
    self.last_motion_trigger_time = current_time
    # 🔑 重置运动时间，确保有完整的后摇时长
    self.shared_last_pet_time.value = current_time  # ← 新增
    buffer_duration = len(self.packet_buffer) / 15.0
    log(f"[录制开始] 距上次运动 {time_since_last_pet:.1f}秒 (已重置), 前摇缓存 {buffer_duration:.1f}秒")
    self.start_recording(video_stream)
```

### 效果

#### 修复前
```
08:36:01 - 检测到运动 → last_pet_time = 08:36:01
08:36:11 - 触发录制（冷却结束）→ 距上次运动12秒
08:36:14 - 录制结束 → 只录了3秒（因为15-12=3）
```

#### 修复后
```
08:36:01 - 检测到运动 → last_pet_time = 08:36:01
08:36:11 - 触发录制（冷却结束）→ last_pet_time = 08:36:11 (重置)
08:36:26 - 录制结束 → 录了15秒（完整后摇）
```

## 其他已修复问题

### 1. packet stream 错误

大量 "写入 Packet 失败: stream is NoneType" 错误已通过添加检查机制修复：

```python
# 检查packet有效性
if packet.stream is None:
    continue  # 跳过损坏的packet

# 检查时间戳
if packet.dts is None and packet.pts is None:
    continue

# 检查属性访问
try:
    orig_stream = packet.stream
except AttributeError:
    continue  # packet对象本身损坏
```

## 部署

### 更新代码

```bash
# 1. 上传修改后的脚本到服务器
scp pet_monitor_pyav.py user@server:/path/to/pet-videos/scripts/

# 2. 停止当前任务
cd /path/to/pet-videos
python reset_task.py --source_id=3

# 3. 重新启动任务（通过Web界面）
```

## 验证

启动任务后，观察日志：

### 1. 冷却期日志
```
[运动触发冷却] 距上次运动触发 50.2秒，剩余冷却 9.8秒
```

### 2. 录制开始日志
```
[录制开始] 距上次运动 X秒 (已重置), 前摇缓存 X秒
```
注意：应该看到 "(已重置)" 字样

### 3. 录制结束日志
```
[录制结束] 总时长 XX秒 (后摇 15秒已满)
录制已保存: event_xxx.mp4, 时长 XX秒
```
注意：时长应该接近 15秒（前摇+后摇）

### 4. packet错误
应该**不再出现**大量 "写入 Packet 失败" 错误

## 配置说明

如果想调整行为：

### 关闭冷却（每次运动都触发）
```python
MOTION_TRIGGER_COOLDOWN = 0
```

### 增加后摇时长
```python
POST_EVENT_SECONDS = 30  # 30秒后摇
```

### 增加冷却时长
```python
MOTION_TRIGGER_COOLDOWN = 120  # 2分钟冷却
```

## 技术细节

### 为什么重置 last_pet_time？

**后摇机制**是通过比较当前时间和 `last_pet_time` 来判断是否停止录制：

```python
time_since_last_pet = current_time - last_pet_time
should_record = (time_since_last_pet < POST_EVENT_SECONDS)

if not should_record and is_recording:
    stop_recording()  # 后摇时间已满
```

如果 `last_pet_time` 是很久之前的，录制会很快停止。

**解决方法**：录制开始时重置 `last_pet_time = current_time`，让录制有完整的后摇时长。

### 为什么不在检测时就判断冷却？

如果在检测到运动时就判断冷却，不更新 `last_pet_time`：

**问题**：
- 冷却期间的运动会丢失
- 如果持续有运动，`last_pet_time` 不更新
- 录制可能提前结束

**当前方案更好**：
- 始终记录最新的运动时间
- 只在录制触发时重置
- 确保录制有完整时长
