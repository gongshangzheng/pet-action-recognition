# 宠物监控脚本使用指南

## 环境说明

监控脚本需要使用 `backend/venv` 虚拟环境中的 Python，因为：
- PyAV (av) 用于视频流处理
- OpenCV (cv2) 用于运动检测
- NumPy 用于图像数组处理
- requests 用于 API 调用

## 快速启动

### 方式一：使用启动脚本（推荐）

```bash
# 监控 RTSP 流
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/scripts
./run_monitor.sh --url rtsp://admin:password@192.168.1.100:554/stream --source_id 1

# 监控本地视频文件
./run_monitor.sh --path /path/to/video.mp4 --source_id 2

# 启用 YOLO 检测
./run_monitor.sh --url rtsp://camera-url --source_id 1 --enable-yolo true --model yolov11s.pt
```

### 方式二：直接使用 venv Python

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos
backend/venv/bin/python3 scripts/pet_monitor_pyav.py --help
```

## 参数说明

| 参数 | 说明 | 示例 |
|------|------|------|
| `--url` | RTSP 流地址 | `rtsp://admin:pass@192.168.1.100:554/stream` |
| `--path` | 本地视频文件路径 | `/Users/dxm/videos/test.mp4` |
| `--source_id` | 数据库中的源 ID | `1` |
| `--api-url` | 后端 API 地址 | `http://localhost:8002`（默认） |
| `--model` | YOLO 模型文件 | `yolov11s.pt`（默认） |
| `--enable-yolo` | 启用 YOLO 检测 | `true` 或 `false`（默认） |

## 故障排除

### ModuleNotFoundError: No module named 'av'

**原因**：没有使用 venv 中的 Python

**解决**：使用 `run_monitor.sh` 或明确指定 `backend/venv/bin/python3`

### libavdevice 重复警告

这是 PyAV 和 OpenCV 共享 FFmpeg 库导致的警告，不影响功能，可以忽略。

### urllib3 OpenSSL 警告

系统使用的是 LibreSSL 而非 OpenSSL 1.1.1+，不影响功能。

## 依赖版本

```
PyAV: 15.1.0
OpenCV: 4.13.0
NumPy: 2.0.2
Python: 3.9.6
```

## 已安装的关键依赖

✅ av (PyAV)
✅ opencv-python
✅ numpy
✅ requests
✅ fastapi
✅ uvicorn
✅ sqlalchemy
✅ dashscope

## 注意事项

1. **首次运行前确保后端服务已启动**：
   ```bash
   cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/backend
   python3 -m uvicorn main:app --host 0.0.0.0 --port 8002 --reload
   ```

2. **YOLO 检测需要单独安装 ultralytics**：
   ```bash
   # 在 yolov13 项目中
   pip install -e .
   ```

3. **确保 source_id 在数据库中存在**

4. **RTSP 流需要网络可达性**
