# 统一视频记录迁移 - 测试指南

## ✅ 迁移结果

### 已完成
- ✅ **新字段添加**：14个新字段全部添加成功
- ✅ **索引创建**：3个索引全部创建成功
- ✅ **手动分析记录迁移**：9条记录迁移成功，did全部为"0"
- ✅ **自动分析记录更新**：36条记录did更新成功
- ✅ **数据完整性**：已完成记录100%有原始返回

### 数据统计

| 类型 | 总数 | 不同用户 | 有原始返回 | 有Token统计 |
|------|------|----------|-----------|------------|
| `manual` | 8 | 1 | 8 | 8 |
| `auto` | 124 | 2 | 1 | 1 |

### 注意事项

⚠️ **88条自动记录的 did 未设置**
- 原因：这些记录的 `source_id` 没有对应的 `stream_sources`，或者对应的 `stream_sources` 没有 `alias` 字段
- 影响：不影响功能使用，但无法按用户过滤这些记录
- 解决：后续可以手动修复，或者在创建新记录时确保设置正确的 did

---

## 🧪 本地测试步骤

### 1. 执行测试脚本

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/backend
python3 test_unify_migration.py
```

**预期输出**：
- ✅ 所有新字段检查通过
- ✅ 所有索引创建成功
- ✅ 手动分析记录迁移成功
- ⚠️ 部分自动记录 did 未设置（不影响使用）

### 2. SQL 查询验证

#### 验证表结构
```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/backend
sqlite3 database/history.db "PRAGMA table_info(video_records);"
```

#### 查看手动分析记录
```sql
sqlite3 database/history.db "
SELECT 
    id, did, call_type, file_name, 
    input_tokens, analysis_cost, llm_status
FROM video_records
WHERE call_type = 'manual'
LIMIT 5;
"
```

#### 查看自动分析记录
```sql
sqlite3 database/history.db "
SELECT 
    did, COUNT(*) as count
FROM video_records
WHERE call_type = 'auto'
GROUP BY did
ORDER BY count DESC;
"
```

#### 验证原始返回字段
```sql
sqlite3 database/history.db "
SELECT 
    call_type,
    COUNT(*) as total,
    SUM(CASE WHEN llm_raw_response IS NOT NULL THEN 1 ELSE 0 END) as has_raw
FROM video_records
GROUP BY call_type;
"
```

---

## 🔄 后续代码修改测试

### 1. Backend API 测试

需要修改 `backend/api/analysis.py`：

```python
# 测试修改前
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/backend
python3 -m pytest tests/test_analysis_api.py -v
```

**修改要点**：
- 第136-161行：改为保存到 `video_records` 而不是 `AnalysisHistory`
- 设置 `did="0"`, `call_type="manual"`
- 保存 `llm_raw_response` 字段

### 2. 前端 API 测试

#### 2.1 启动 Backend 服务

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/backend
python3 main.py
```

**预期**：服务启动在 `http://localhost:8000`

#### 2.2 测试调用历史查询

```bash
# 获取 JWT Token
TOKEN=$(curl -X POST "http://localhost:8000/api/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}' \
  | jq -r '.access_token')

# 查询手动分析记录
curl "http://localhost:8000/api/video-records?call_type=manual&page=1&page_size=10" \
  -H "Authorization: Bearer $TOKEN" | jq .

# 查询自动分析记录
curl "http://localhost:8000/api/video-records?call_type=auto&page=1&page_size=10" \
  -H "Authorization: Bearer $TOKEN" | jq .
```

**预期输出**：
```json
{
  "records": [
    {
      "id": 124,
      "did": "0",
      "call_type": "manual",
      "file_name": "VIDEO_1767494155724.mp4",
      "llm_status": "completed",
      "input_tokens": 30316,
      "analysis_cost": 0.033946,
      "llm_raw_response": "{...}",
      ...
    }
  ],
  "total": 8
}
```

#### 2.3 测试视频分析功能

```bash
# 分析一个测试视频
curl -X POST "http://localhost:8000/api/analyze" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "video_path": "/path/to/test/video.mp4",
    "prompt": "分析视频中的宠物行为",
    "model_name": "qwen3-vl-plus",
    "fps": 1.0,
    "max_pixels": 1003520,
    "min_pixels": 50176
  }' | jq .
```

**预期**：
1. 返回 `id` 字段（video_records.id）
2. 数据库中新增一条记录：
   - `did="0"`
   - `call_type="manual"`
   - 有 `llm_raw_response`
   - 有 Token 统计和费用

**验证**：
```bash
sqlite3 database/history.db "
SELECT id, did, call_type, file_name, input_tokens, analysis_cost
FROM video_records
ORDER BY id DESC
LIMIT 1;
"
```

### 3. 前端 UI 测试

#### 3.1 启动 Frontend 服务

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/frontend
npm run dev
```

**预期**：服务启动在 `http://localhost:5173`

#### 3.2 测试"调用历史"Tab

1. 打开浏览器访问 `http://localhost:5173`
2. 登录系统
3. 点击"调用历史"Tab
4. **预期**：
   - ✅ 能看到历史分析记录
   - ✅ 显示Token、费用等信息
   - ✅ 删除功能正常

⚠️ **如果失败**：需要修改前端代码：
- 修改 API 调用从 `/api/history` 改为 `/api/video-records?call_type=manual`
- 修改删除接口从 `/api/history/{id}` 改为 `/api/video-records/{id}`

#### 3.3 测试"视频分析"功能

1. 点击"视频分析"Tab
2. 选择一个测试视频
3. 配置参数并点击"开始分析"
4. **预期**：
   - ✅ 分析成功完成
   - ✅ "调用历史"Tab 中看到新记录
   - ✅ 新记录的 `did="0"`, `call_type="manual"`

---

## 📋 测试检查清单

### 数据库层
- [ ] 14个新字段已添加
- [ ] 3个索引已创建
- [ ] 手动分析记录已迁移（did="0"）
- [ ] 原始返回字段正确保存

### Backend API 层
- [ ] `backend/api/analysis.py` 已修改使用 `video_records`
- [ ] 新分析记录设置正确的 `did` 和 `call_type`
- [ ] `llm_raw_response` 正确保存
- [ ] Token 统计和费用正确保存

### Service API 层
- [ ] 新增 `GET /api/video-records` 接口
- [ ] 支持 `call_type` 参数过滤
- [ ] 删除接口 URL 已更新

### Frontend 层
- [ ] 调用历史查询 API 已更新
- [ ] 删除功能 API 已更新
- [ ] 视频分析功能正常
- [ ] 新记录正确显示在调用历史中

---

## 🐛 常见问题

### Q1: 迁移后前端调用历史显示为空？

**原因**：前端仍在调用旧的 `/api/history` 接口

**解决**：修改前端代码，改为调用 `/api/video-records?call_type=manual`

### Q2: 新分析记录 did 不是 "0"？

**原因**：`backend/api/analysis.py` 未更新

**解决**：确保 `VideoRecord` 创建时设置了 `did="0", call_type="manual"`

### Q3: llm_raw_response 为空？

**原因**：未保存 LLM 原始返回

**解决**：
```python
video_record.llm_raw_response = api_result['model_response']
```

### Q4: 部分自动记录 did 为空？

**原因**：这些记录没有对应的 stream_sources

**影响**：不影响功能，只是无法按用户过滤

**解决**：可选，手动修复或忽略

---

## 📊 性能验证

### 查询性能测试

```bash
# 测试索引性能
sqlite3 database/history.db "
EXPLAIN QUERY PLAN
SELECT * FROM video_records WHERE did = 'RasyGBD-898985';
"

# 预期：使用 idx_video_records_did 索引
# SCAN TABLE video_records USING INDEX idx_video_records_did (did=?)
```

```bash
# 测试 call_type 过滤性能
sqlite3 database/history.db "
EXPLAIN QUERY PLAN
SELECT * FROM video_records WHERE call_type = 'manual';
"

# 预期：使用 idx_video_records_call_type 索引
```

---

## ✅ 验收标准

### 数据迁移验收
- [x] 所有手动分析记录迁移成功（9条）
- [x] 所有手动记录 did="0"
- [x] 所有手动记录有 Token 统计和费用
- [x] 所有手动记录有 llm_raw_response

### API 功能验收
- [ ] 新视频分析记录正确写入 video_records
- [ ] 查询接口支持按 call_type 过滤
- [ ] 删除接口正常工作

### 前端功能验收
- [ ] 调用历史正常显示
- [ ] 视频分析功能正常
- [ ] 删除功能正常

---

## 🔄 回滚方案

如果迁移出现问题，可以回滚：

```bash
# 恢复备份数据库
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/backend
cp database/history.db.backup_20260203_104817 database/history.db

# 验证恢复
sqlite3 database/history.db "
SELECT COUNT(*) FROM video_records;
"
```

---

## 📝 测试记录

### 测试环境
- 数据库：SQLite 3.x
- Python：3.9
- 迁移时间：2026-02-03 10:48:17

### 测试结果
- ✅ 数据库迁移成功
- ✅ 测试脚本验证通过
- ⚠️ 88条自动记录 did 未设置（可接受）

### 下一步
1. 修改 Backend API（`backend/api/analysis.py`）
2. 测试前端分析功能
3. 如无问题，可考虑删除 `analysis_history` 表
