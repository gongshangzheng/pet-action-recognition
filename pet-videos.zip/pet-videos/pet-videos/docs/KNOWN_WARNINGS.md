# 已知警告信息说明

## ✅ 可以安全忽略的警告

### 1. OpenH264 库警告

**警告内容：**
```
Failed to load OpenH264 library: openh264-1.8.0-win64.dll
Please check environment and/or download library: https://github.com/cisco/openh264/releases

[libopenh264 @ xxx] Incorrect library version loaded
[ERROR:0@x.xxx] global cap_ffmpeg_impl.hpp:3268 open Could not open codec libopenh264, error: Unspecified error (-22)
[ERROR:0@x.xxx] global cap_ffmpeg_impl.hpp:3285 open VIDEOIO/FFMPEG: Failed to initialize VideoWriter
```

**含义：**
- OpenCV 尝试使用 OpenH264 库实现 H.264 编码
- 因为库缺失或版本不匹配，加载失败
- OpenCV **自动回退到系统的 H.264 编码器**
- 最终录制成功

**判断标准：**

✅ **成功标志（看到这些说明正常）：**
```
[时间] ✓ 视频编码器初始化成功 (H.264)
[时间] 视频编码器已释放
[时间] 视频已记录: event_xxx.mp4
```

❌ **失败标志（看到这些说明有问题）：**
```
[时间] 错误: 无法初始化视频编码器
```

**是否影响功能：** ❌ 不影响，可以完全忽略

**如何验证：**
```bash
# 检查视频是否正常生成
python verify_recording.py D:\pet-videos\videos\chfi7hg
```

---

### 2. X264 标签不支持警告

**警告内容：**
```
OpenCV: FFMPEG: tag 0x34363258/'X264' is not supported with codec id 27 and format 'mp4 / MP4 (MPEG-4 Part 14)'
OpenCV: FFMPEG: fallback to use tag 0x31637661/'avc1'
```

**含义：**
- X264 fourcc 标签与 MP4 容器不完全兼容
- OpenCV 自动切换到 avc1 标签
- 仍然是 H.264 编码

**是否影响功能：** ❌ 不影响，自动回退成功

**解决方案：** 直接使用 avc1（当前方案）

---

## 🔧 为什么不屏蔽这些警告？

### 原因 1: 技术限制

这些警告来自 OpenCV 的 C++ 代码层，通过 stderr 直接输出，Python 无法拦截。

### 原因 2: 诊断价值

如果真的有问题，这些信息有助于诊断：
- 如果录制失败，能看到具体原因
- 如果编码器真的不可用，能及时发现

### 原因 3: 屏蔽副作用

如果屏蔽 stderr，会丢失**所有**错误信息：
- Python 异常
- OpenCV 真实错误
- 其他重要警告

---

## ✅ 推荐做法

### 1. 观察关键日志

**重要的日志：**
```
✓ 视频编码器初始化成功  ✅ 看到这个就OK
视频已记录: xxx.mp4       ✅ 录制成功的证明
心跳已更新                ✅ 进程健康
```

**可忽略的日志：**
```
Failed to load OpenH264  ⚠️ 警告，可忽略
Incorrect library version  ⚠️ 警告，可忽略
```

### 2. 定期验证

```bash
# 每天或每周运行一次
python verify_recording.py D:\pet-videos\videos\chfi7hg
```

### 3. 监控指标

**真正需要关注的：**
- ✅ 视频文件持续生成
- ✅ 文件大小正常（> 0）
- ✅ 浏览器可以播放
- ✅ 心跳正常更新

---

## 📊 验证清单

运行 `verify_recording.py` 应该看到：

- [ ] 文件大小 > 0
- [ ] 可以读取视频属性
- [ ] 编码格式为 avc1
- [ ] 可以读取第一帧
- [ ] 看到 "✓✓✓ 视频录制成功！"

**只要这些都通过，OpenCV 的警告就完全可以忽略。**

---

## 🎯 总结

**当前状态：** ✅ 完全正常

- ✅ 视频录制成功
- ✅ H.264 编码
- ✅ 心跳正常
- ⚠️ 有警告但无害

**警告来源：** OpenCV 尝试 OpenH264，失败后自动回退到系统编码器

**是否需要修复：** ❌ 不需要，功能正常

**验证方法：** 运行 `verify_recording.py` 确认

---

**现在运行验证脚本，确认录制真的成功了！**