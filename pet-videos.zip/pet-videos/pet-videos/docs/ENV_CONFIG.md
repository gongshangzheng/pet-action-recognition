# 环境配置说明

## 配置文件

项目使用 `.env` 文件进行环境配置。

### 快速开始

```bash
# 1. 复制配置模板
cp env.example .env

# 2. 编辑配置文件
vim .env

# 3. 修改必要的配置项（见下方说明）
```

## 配置项详解

### 1. API 配置

#### DASHSCOPE_API_KEY

**说明**：阿里云通义千问视觉模型的 API 密钥

**获取方式**：
1. 访问 https://dashscope.console.aliyun.com/apiKey
2. 登录阿里云账号
3. 创建或复制 API Key

**示例**：
```env
DASHSCOPE_API_KEY=sk-61a73e84b3a2405dbaa6d35ccd51ebcc
```

**注意**：
- ⚠️ **这是敏感信息，不要提交到 Git！**
- 该密钥用于视频分析功能
- 如果不使用 AI 分析，可以留空

---

### 2. 登录安全配置

#### ADMIN_USERNAME

**说明**：管理员登录用户名

**默认值**：`admin`

**建议**：
- 生产环境建议修改为不常见的用户名
- 只能包含字母、数字、下划线

**示例**：
```env
ADMIN_USERNAME=myadmin
```

#### ADMIN_PASSWORD

**说明**：管理员登录密码

**默认值**：`admin123`（仅示例，**必须修改**！）

**强密码建议**：
- 至少 12 位字符
- 包含大小写字母
- 包含数字
- 包含特殊字符（如 `@`, `!`, `#`, `$` 等）

**示例**：
```env
ADMIN_PASSWORD=MyP@ssw0rd2026!
```

**注意**：
- ⚠️ **这是敏感信息，不要提交到 Git！**
- ⚠️ **生产环境必须使用强密码！**

#### JWT_SECRET

**说明**：JWT（JSON Web Token）签名密钥，用于生成和验证访问令牌

**默认值**：`pet-videos-secret-key-2026`（仅示例，**必须修改**！）

**生成建议**：
```bash
# 使用 openssl 生成随机密钥
openssl rand -hex 32

# 或使用 Python
python -c "import secrets; print(secrets.token_hex(32))"
```

**示例**：
```env
JWT_SECRET=a1b2c3d4e5f6...（64位随机十六进制字符串）
```

**注意**：
- ⚠️ **这是敏感信息，不要提交到 Git！**
- ⚠️ **修改此值会导致所有现有 Token 失效，用户需要重新登录**
- 建议至少 32 字节（64 个十六进制字符）

---

### 3. 视频目录配置

#### VIDEO_DIRS

**说明**：配置可访问的视频目录，支持多个目录

**格式**：`别名1:路径1,别名2:路径2,...`

**别名规则**：
- 只能包含字母、数字、下划线
- 用于 API 访问，不暴露真实路径
- 例如：别名 `camera1` 映射到 `/home/user/videos`

**Mac/Linux 示例**：
```env
VIDEO_DIRS=camera1:/home/user/videos,camera2:/mnt/nvr,backup:/tmp/records
```

**Windows 示例**：
```env
VIDEO_DIRS=camera1:D:\Videos,camera2:E:\NVR\Records,backup:F:\Backup
```

**实际配置示例**：
```env
VIDEO_DIRS=pet_videos:/Users/dxm/code/ai/pet/videos,records:/Users/dxm/code/ai/records,www:/Users/dxm/code/ai/www
```

**注意**：
- 路径必须存在且可读
- 使用绝对路径
- Windows 路径使用反斜杠 `\` 或正斜杠 `/`
- 别名在前端选择视频目录时显示

---

### 4. 服务配置

#### BACKEND_HOST

**说明**：后端服务绑定的 IP 地址

**可选值**：
- `0.0.0.0` - 监听所有网卡（默认）
- `127.0.0.1` - 仅本机访问
- 具体 IP - 绑定到指定网卡

**示例**：
```env
BACKEND_HOST=0.0.0.0
```

**建议**：
- 开发环境：`0.0.0.0`（方便局域网访问）
- 生产环境：根据实际情况配置

#### BACKEND_PORT

**说明**：后端服务监听端口

**默认值**：`8002`

**示例**：
```env
BACKEND_PORT=8002
```

**注意**：
- 确保端口未被占用
- 1024 以下的端口需要 root 权限（Linux/Mac）
- Windows 防火墙可能需要放行该端口

#### FRONTEND_PORT

**说明**：前端开发服务器端口

**默认值**：`5173`（Vite 默认端口）

**示例**：
```env
FRONTEND_PORT=5173
```

**注意**：
- 仅用于开发环境
- 生产环境使用构建后的静态文件

---

### 5. 数据库配置

#### DATABASE_PATH

**说明**：SQLite 数据库文件路径

**默认值**：`./database/history.db`（相对路径，相对于项目根目录）

**示例**：
```env
# 相对路径
DATABASE_PATH=./database/history.db

# 绝对路径（如果需要）
DATABASE_PATH=/var/lib/pet-videos/history.db
```

**注意**：
- 目录必须可写
- 建议使用相对路径
- 数据库文件会自动创建

---

### 6. 日志配置

#### LOG_LEVEL

**说明**：日志记录级别

**可选值**：
- `DEBUG` - 调试信息（最详细）
- `INFO` - 一般信息（默认）
- `WARNING` - 警告信息
- `ERROR` - 错误信息
- `CRITICAL` - 严重错误

**示例**：
```env
LOG_LEVEL=INFO
```

**建议**：
- 开发环境：`DEBUG` 或 `INFO`
- 生产环境：`INFO` 或 `WARNING`

#### LOG_FILE

**说明**：日志文件路径

**默认值**：`./logs/app.log`（相对路径）

**示例**：
```env
# 相对路径
LOG_FILE=./logs/app.log

# 绝对路径（如果需要）
LOG_FILE=/var/log/pet-videos/app.log
```

**注意**：
- 目录必须可写
- 日志会自动轮转（避免文件过大）

---

### 7. API 限制

#### MAX_VIDEO_SIZE_MB

**说明**：单个视频文件最大大小（MB）

**默认值**：`100`

**示例**：
```env
MAX_VIDEO_SIZE_MB=100
```

**建议**：
- 根据服务器性能和网络带宽调整
- 过大可能导致上传超时或内存不足

#### API_TIMEOUT_SECONDS

**说明**：API 请求超时时间（秒）

**默认值**：`300`（5 分钟）

**示例**：
```env
API_TIMEOUT_SECONDS=300
```

**说明**：
- 视频分析等耗时操作需要较长超时时间
- 根据实际视频大小和模型速度调整

---

### 8. CORS 配置

#### CORS_ORIGINS

**说明**：允许跨域访问的前端地址

**格式**：逗号分隔的 URL 列表

**示例**：
```env
# 开发环境
CORS_ORIGINS=http://localhost:3000,http://localhost:5173,http://127.0.0.1:3000,http://127.0.0.1:5173

# 生产环境
CORS_ORIGINS=https://pet-videos.example.com

# 多个域名
CORS_ORIGINS=https://pet-videos.example.com,https://admin.example.com
```

**注意**：
- 必须包含协议（`http://` 或 `https://`）
- 不要在末尾添加 `/`
- 生产环境只配置实际使用的域名
- 开发环境需要同时支持 `localhost` 和 `127.0.0.1`

---

## 配置检查清单

部署前请确认：

### 必须修改的配置 ⚠️

- [ ] `DASHSCOPE_API_KEY` - 填入真实的 API Key
- [ ] `ADMIN_PASSWORD` - 修改为强密码
- [ ] `JWT_SECRET` - 修改为随机密钥
- [ ] `VIDEO_DIRS` - 配置实际的视频目录路径

### 可选修改的配置

- [ ] `ADMIN_USERNAME` - 修改用户名（提高安全性）
- [ ] `BACKEND_PORT` - 根据服务器端口规划调整
- [ ] `CORS_ORIGINS` - 生产环境配置实际域名
- [ ] `LOG_LEVEL` - 生产环境建议 `INFO` 或 `WARNING`
- [ ] `MAX_VIDEO_SIZE_MB` - 根据需求调整
- [ ] `API_TIMEOUT_SECONDS` - 根据视频大小调整

### 通常不需要修改

- [ ] `BACKEND_HOST` - 保持 `0.0.0.0`
- [ ] `FRONTEND_PORT` - 保持 `5173`
- [ ] `DATABASE_PATH` - 保持 `./database/history.db`
- [ ] `LOG_FILE` - 保持 `./logs/app.log`

---

## 安全建议

### 1. 保护敏感配置

```bash
# .env 文件权限（Linux/Mac）
chmod 600 .env

# 确保 .env 在 .gitignore 中
grep "^\.env$" .gitignore
```

### 2. 生产环境强化

- ✅ 使用强密码（至少 12 位，包含大小写、数字、特殊字符）
- ✅ 定期更换密码和密钥
- ✅ 限制 CORS_ORIGINS 为实际域名
- ✅ 使用 HTTPS（配合 Nginx 等反向代理）
- ✅ 启用防火墙，只开放必要端口

### 3. 生成随机密钥的方法

```bash
# 方法 1: openssl
openssl rand -hex 32

# 方法 2: Python
python -c "import secrets; print(secrets.token_hex(32))"

# 方法 3: Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# 方法 4: 在线工具
# https://www.random.org/strings/
```

---

## 故障排查

### 问题 1：后端无法启动 - 端口被占用

**错误信息**：
```
Error: Address already in use: 0.0.0.0:8002
```

**解决方法**：
```bash
# 查找占用端口的进程
lsof -i :8002  # Mac/Linux
netstat -ano | findstr :8002  # Windows

# 杀死进程或修改 BACKEND_PORT
```

### 问题 2：前端无法连接后端 - CORS 错误

**错误信息**：
```
Access to XMLHttpRequest at 'http://...' from origin 'http://localhost:5173' 
has been blocked by CORS policy
```

**解决方法**：
```env
# 确保 CORS_ORIGINS 包含前端地址
CORS_ORIGINS=http://localhost:5173,http://127.0.0.1:5173
```

### 问题 3：视频目录无法访问

**错误信息**：
```
Video directory not found: /path/to/videos
```

**解决方法**：
```bash
# 检查路径是否存在
ls -la /path/to/videos

# 检查权限
ls -ld /path/to/videos

# 修正 VIDEO_DIRS 配置
```

### 问题 4：API Key 无效

**错误信息**：
```
Invalid API key
```

**解决方法**：
1. 确认 API Key 复制完整（无空格）
2. 检查 API Key 是否过期
3. 访问阿里云控制台验证 Key 状态

---

## 配置示例

### 开发环境配置

```env
# API 配置
DASHSCOPE_API_KEY=sk-test-key-for-development

# 登录配置
ADMIN_USERNAME=admin
ADMIN_PASSWORD=dev123456
JWT_SECRET=dev-secret-key

# 视频目录
VIDEO_DIRS=test:/tmp/test-videos,demo:/home/user/demo

# 服务配置
BACKEND_HOST=0.0.0.0
BACKEND_PORT=8002
FRONTEND_PORT=5173

# 数据库
DATABASE_PATH=./database/dev.db

# 日志
LOG_LEVEL=DEBUG
LOG_FILE=./logs/dev.log

# API 限制
MAX_VIDEO_SIZE_MB=50
API_TIMEOUT_SECONDS=300

# CORS
CORS_ORIGINS=http://localhost:3000,http://localhost:5173,http://127.0.0.1:5173
```

### 生产环境配置

```env
# API 配置
DASHSCOPE_API_KEY=sk-your-production-api-key

# 登录配置
ADMIN_USERNAME=prod_admin
ADMIN_PASSWORD=YourStrongP@ssw0rd2026!
JWT_SECRET=a1b2c3d4e5f6...（随机生成的64位字符）

# 视频目录
VIDEO_DIRS=camera1:/mnt/nvr/camera1,camera2:/mnt/nvr/camera2,backup:/mnt/backup

# 服务配置
BACKEND_HOST=0.0.0.0
BACKEND_PORT=8002
FRONTEND_PORT=5173

# 数据库
DATABASE_PATH=./database/history.db

# 日志
LOG_LEVEL=INFO
LOG_FILE=./logs/app.log

# API 限制
MAX_VIDEO_SIZE_MB=200
API_TIMEOUT_SECONDS=600

# CORS
CORS_ORIGINS=https://pet-videos.example.com
```

---

## 相关文档

- [DEPLOY.md](DEPLOY.md) - 部署指南
- [SECURITY.md](SECURITY.md) - 安全配置详解
- [README.md](../README.md) - 项目说明
- [.gitignore](.gitignore) - Git 忽略规则（确保 .env 被忽略）

---

## 更新日志

| 日期 | 版本 | 说明 |
|------|------|------|
| 2026-01-29 | v1.0 | 初始版本，完整的配置说明文档 |
