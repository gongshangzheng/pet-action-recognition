# 环境变量配置说明

本文档说明后端服务支持的环境变量配置项。

## 配置方式

配置通过 `backend/config.py` 中的 `Settings` 类管理，支持两种方式：

1. **环境变量**：设置环境变量（优先级最高）
2. **默认值**：使用代码中定义的默认值

### 设置环境变量

```bash
# Linux/Mac
export LLM_WORKER_AUTO_START=false

# Windows
set LLM_WORKER_AUTO_START=false
```

或者创建 `.env` 文件（需要安装 python-dotenv）：

```bash
# backend/.env
LLM_WORKER_AUTO_START=false
DAILY_REPORT_AUTO_START=false
```

## 配置项列表

### LLM Worker 配置

#### `LLM_WORKER_ENABLED`
- **类型**: Boolean
- **默认值**: `true`
- **说明**: 系统级开关，控制是否允许启用 LLM Worker（自动调用服务）
- **示例**: `export LLM_WORKER_ENABLED=false`

#### `LLM_WORKER_AUTO_START`
- **类型**: Boolean
- **默认值**: `true`
- **说明**: 应用启动时是否自动启动 LLM Worker
- **示例**: `export LLM_WORKER_AUTO_START=false`
- **效果**: 
  - `true`: 后端启动时自动启动 LLM Worker，开始处理视频切片分析队列
  - `false`: 后端启动时不启动 LLM Worker，需要手动通过API启动

#### `LLM_WORKER_MAX_CONCURRENT`
- **类型**: Integer
- **默认值**: `2`
- **说明**: LLM Worker 最大并发处理数量

#### `LLM_WORKER_POLL_INTERVAL`
- **类型**: Integer
- **默认值**: `10`
- **说明**: LLM Worker 轮询间隔（秒）

#### `LLM_WORKER_MAX_RETRIES`
- **类型**: Integer
- **默认值**: `3`
- **说明**: LLM调用失败时的最大重试次数

#### `LLM_WORKER_TIME_WINDOW_HOURS`
- **类型**: Integer
- **默认值**: `25`
- **说明**: 队列时间窗口，只处理最近N小时的记录

#### `LLM_WORKER_RETRY_DELAYS`
- **类型**: String
- **默认值**: `"60,300,900"`
- **说明**: 重试延迟时间（秒），逗号分隔，分别对应第1、2、3次重试的延迟

---

### 日报生成器配置

#### `DAILY_REPORT_ENABLED`
- **类型**: Boolean
- **默认值**: `true`
- **说明**: 系统级开关，控制是否允许启用日报生成器
- **示例**: `export DAILY_REPORT_ENABLED=false`

#### `DAILY_REPORT_AUTO_START`
- **类型**: Boolean
- **默认值**: `true`
- **说明**: 应用启动时是否自动启动日报生成器
- **示例**: `export DAILY_REPORT_AUTO_START=false`
- **效果**: 
  - `true`: 后端启动时自动启动日报生成器，开始定时生成宠物日报
  - `false`: 后端启动时不启动日报生成器，需要手动通过API启动

---

### 自动分析默认参数

#### `AUTO_ANALYSIS_FPS`
- **类型**: Float
- **默认值**: `1.0`
- **说明**: 自动分析时的采样帧率

#### `AUTO_ANALYSIS_MAX_PIXELS`
- **类型**: Integer
- **默认值**: `640 * 32 * 32` (655360)
- **说明**: 自动分析时的最大像素数

#### `AUTO_ANALYSIS_MIN_PIXELS`
- **类型**: Integer
- **默认值**: `4 * 32 * 32` (4096)
- **说明**: 自动分析时的最小像素数

#### `AUTO_ANALYSIS_MODEL`
- **类型**: String
- **默认值**: `"qwen3-vl-plus"`
- **说明**: 自动分析使用的默认模型

#### `AUTO_ANALYSIS_HIGH_RES`
- **类型**: Boolean
- **默认值**: `false`
- **说明**: 是否启用高分辨率模式

---

## 使用场景

### 场景1：开发环境 - 禁用自动任务

开发调试时可能不希望自动任务干扰，可以禁用自动启动：

```bash
export LLM_WORKER_AUTO_START=false
export DAILY_REPORT_AUTO_START=false
python3 main.py
```

启动后，可以通过前端界面或API手动启动需要的服务。

### 场景2：生产环境 - 完全禁用某个功能

如果生产环境不需要日报功能，可以完全禁用：

```bash
export DAILY_REPORT_ENABLED=false
python3 main.py
```

这样即使通过API也无法启动日报生成器。

### 场景3：测试环境 - 调整并发和重试

测试环境可以调整并发数和重试策略：

```bash
export LLM_WORKER_MAX_CONCURRENT=1
export LLM_WORKER_MAX_RETRIES=1
export LLM_WORKER_RETRY_DELAYS="30"
python3 main.py
```

---

## API 控制

除了环境变量，还可以通过API动态控制服务的启动/停止：

### LLM Worker

```bash
# 启动
POST /api/llm/worker/start

# 停止
POST /api/llm/worker/stop

# 状态
GET /api/llm/queue/stats
```

### 日报生成器

```bash
# 启动
POST /api/daily-report-generator/start

# 停止
POST /api/daily-report-generator/stop

# 状态
GET /api/daily-report-generator/status
```

**注意**: 这些API需要JWT认证。

---

## 查看当前配置

启动后端时，可以通过状态API查看当前配置：

### LLM Worker 配置

```bash
GET /api/llm/queue/stats
```

返回示例：
```json
{
  "config": {
    "max_concurrent": 2,
    "poll_interval": 10,
    "max_retries": 3,
    "auto_start": true,
    ...
  },
  "system_enabled": true
}
```

### 日报生成器配置

```bash
GET /api/daily-report-generator/status
```

返回示例：
```json
{
  "config": {
    "auto_start": true,
    "peak_interval_minutes": 90,
    "off_peak_interval_minutes": 180,
    ...
  },
  "system_enabled": true,
  "worker_running": true
}
```

---

## 注意事项

1. **环境变量命名**: 使用大写+下划线格式（如 `LLM_WORKER_AUTO_START`）
2. **Boolean值**: 环境变量中使用 `true`/`false` (小写)
3. **生效时机**: 环境变量在应用启动时读取，运行时修改不会生效（需重启）
4. **优先级**: 环境变量 > 默认值
5. **API控制**: 通过API启动/停止的操作是临时的，重启后按配置决定是否自动启动
