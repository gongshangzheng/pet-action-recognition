# .gitignore 调整日志

## 日期：2026-01-29

## 变更原因

适配新的目录结构（`docs/` 和 `test/` 目录），完善版本控制策略。

## 主要变更

### 1. 打包输出规则（新增）

```gitignore
# Package outputs (生成的打包文件)
pet-videos-source-*.zip       # 源码打包输出
pet-videos-deploy-*.tar.gz    # 部署打包输出
*.tar.gz                      # 通用压缩包
*.rar                         # RAR 压缩包
```

**原因**：
- `package.sh` 生成的打包文件带时间戳
- 文件体积大（15-30MB），不适合 Git
- 可以随时重新生成

### 2. test/ 目录规则（新增）

```gitignore
# Test directory temporary files (test/ 目录临时文件)
test/*.tar.gz         # test 目录中的压缩包
test/*.zip            # test 目录中的 zip 包
test/*.log            # test 目录中的日志
test/deploy_*.tar.gz  # 部署测试生成的包
test/output/          # 测试输出目录
test/temp/            # 临时文件目录
test/__pycache__/     # Python 缓存
```

**说明**：
- ✅ **提交**：`test/*.py`, `test/*.sh`, `test/*.bat` - 测试和工具脚本源码
- ❌ **忽略**：测试运行时产生的临时文件和打包产物

**验证通过**：
```bash
$ git check-ignore test/deploy_files.tar.gz
test/deploy_files.tar.gz  ✓ 被正确忽略
```

### 3. docs/ 目录规则（新增）

```gitignore
# Docs build artifacts (文档构建产物)
docs/build/           # 文档构建输出
docs/_build/          # 文档构建输出
docs/.doctrees/       # Sphinx 缓存
docs/site/            # MkDocs 构建输出
```

**说明**：
- ✅ **提交**：`docs/*.md` - 所有 Markdown 文档
- ❌ **忽略**：文档工具的构建产物（如果使用）

**当前状态**：
- 项目使用纯 Markdown，无构建工具
- 所有 `.md` 文档都被提交
- 规则为未来使用文档生成工具预留

### 4. 环境配置优化

```diff
  # Environment
  .env
+ .env.local
+ .env.*.local
```

**增加**：
- `.env.local` - 本地环境配置
- `.env.*.local` - 各环境的本地配置（如 `.env.development.local`）

### 5. 数据库规则优化

```diff
  # Database
  *.db
  *.sqlite
  *.sqlite3
+ backend/database/
```

**增加**：
- `backend/database/` - 整个数据库目录
- 避免误提交数据库文件

### 6. 前端缓存（新增）

```diff
  # Frontend
  frontend/node_modules/
  frontend/dist/
  frontend/build/
  frontend/.next/
  frontend/out/
+ frontend/.vite/         # Vite 缓存
  frontend/.env.local
```

**原因**：项目使用 Vite，需要忽略其缓存目录。

### 7. 后端临时文件（新增）

```gitignore
# Backend temporary files
backend/logs/
backend/temp/
backend/__pycache__/
```

**说明**：后端运行时产生的临时文件和日志。

### 8. 脚本临时文件（新增）

```gitignore
# Scripts temporary files
scripts/__pycache__/
scripts/*.pyc
scripts/temp/
```

**说明**：监控脚本运行时产生的 Python 缓存。

### 9. 备份文件规则（新增）

```gitignore
# Backup files (备份文件)
*.bak
*.backup
*.old
*_副本.py
*_copy.py
```

**说明**：
- 编辑器或手动创建的备份文件
- 例如：`pet_monitor_pyav.py.bak`
- 中文副本文件：`config_副本.py`

**实际案例**：
```
scripts/
├── pet_monitor_pyav.py        ✅ 提交（当前版本）
├── pet_monitor_pyav.py.bak    ❌ 忽略（备份文件）
└── pet_monitor_pyav_副本.py   ❌ 忽略（副本文件）
```

### 10. OS 特定文件（新增）

```gitignore
# OS specific
Thumbs.db             # Windows 缩略图
desktop.ini           # Windows 文件夹配置
```

**说明**：Windows 系统生成的元数据文件。

### 11. 临时文件规则（新增）

```gitignore
# Temporary files
*.tmp
*.temp
.tmp/
.temp/
```

**说明**：通用临时文件规则。

## 完整对比

### 新增的规则（18条）

1. `pet-videos-source-*.zip` - 源码打包输出
2. `pet-videos-deploy-*.tar.gz` - 部署打包输出
3. `test/*.tar.gz` - test 目录压缩包
4. `test/*.zip` - test 目录 zip 包
5. `test/*.log` - test 目录日志
6. `test/deploy_*.tar.gz` - 部署测试包
7. `test/output/` - 测试输出目录
8. `test/temp/` - 测试临时目录
9. `test/__pycache__/` - test Python 缓存
10. `docs/build/`, `docs/_build/`, `docs/.doctrees/`, `docs/site/` - 文档构建产物
11. `frontend/.vite/` - Vite 缓存
12. `backend/database/` - 数据库目录
13. `backend/logs/`, `backend/temp/`, `backend/__pycache__/` - 后端临时文件
14. `scripts/__pycache__/`, `scripts/*.pyc`, `scripts/temp/` - 脚本临时文件
15. `*.bak`, `*.backup`, `*.old`, `*_副本.py`, `*_copy.py` - 备份文件
16. `Thumbs.db`, `desktop.ini` - Windows 系统文件
17. `*.tmp`, `*.temp`, `.tmp/`, `.temp/` - 临时文件
18. `.env.local`, `.env.*.local` - 本地环境配置

### 优化的规则（1条）

- `*.sh` → `start*.sh`（只忽略 start 开头的 sh 文件，保留其他）

## 影响分析

### 文件移动后的状态

由于文件从根目录移动到 `docs/` 和 `test/`，Git 显示为删除（D）：

```bash
# Git 检测到的变更
D BNS_CLIENT_README.md          → 移动到 docs/
D CODEC_TEST.md                 → 移动到 docs/
D DEPLOY.md                     → 移动到 docs/
D test_ffmpeg.py                → 移动到 test/
D fix_env_encoding.py           → 移动到 test/
...
```

**后续操作**：
```bash
# 1. 添加移动后的文件
git add docs/
git add test/

# 2. 提交变更
git commit -m "refactor: 重组项目结构，移动文档到 docs/，测试文件到 test/"
```

### 验证测试结果

#### ✅ 通过的测试

1. **打包文件被忽略**
   ```bash
   pet-videos-source-20260129-133000.zip ✓
   ```

2. **test/ 临时文件被忽略**
   ```bash
   test/deploy_files.tar.gz ✓
   test/*.log ✓
   ```

3. **备份文件被忽略**
   ```bash
   scripts/pet_monitor_pyav.py.bak ✓
   scripts/config_副本.py ✓
   ```

#### ✅ 应该提交的文件

1. **测试脚本源码**
   ```bash
   test/test_ffmpeg.py ✓
   test/reset_task.py ✓
   test/deploy_fix.sh ✓
   ```

2. **文档**
   ```bash
   docs/*.md ✓
   README.md ✓
   CHANGELOG_PACKAGE.md ✓
   ```

3. **配置模板**
   ```bash
   env.example ✓
   ```

## 使用示例

### 场景1：执行打包后

```bash
$ bash package.sh
[1/6] 准备打包目录...
[2/6] 复制源码文件...
...
[6/6] 压缩打包...
打包成功！
文件位置: /path/to/pet-videos-source-20260129-133000.zip

$ git status
# .zip 文件不显示（被自动忽略） ✓
```

### 场景2：运行测试脚本

```bash
$ cd test/
$ python test_ffmpeg.py > output.log

$ git status
modified:   test/test_ffmpeg.py  # 源码修改会显示 ✓
# output.log 不显示（被忽略） ✓
```

### 场景3：创建备份文件

```bash
$ cp scripts/pet_monitor_pyav.py scripts/pet_monitor_pyav.py.bak

$ git status
# .bak 文件不显示（被忽略） ✓
```

### 场景4：新增文档

```bash
$ vim docs/NEW_FEATURE.md

$ git status
??  docs/NEW_FEATURE.md  # 新文档会显示 ✓

$ git add docs/NEW_FEATURE.md
$ git commit -m "docs: 新增功能文档"
```

## 后续建议

### 1. 清理旧的备份文件

```bash
# 查找并删除备份文件
find . -name "*.bak" -type f
find . -name "*_副本.py" -type f

# 确认后删除
find . -name "*.bak" -type f -delete
find . -name "*_副本.py" -type f -delete
```

### 2. 清理 Git 已跟踪的忽略文件

如果某些文件在添加 `.gitignore` 规则前已经被 Git 跟踪：

```bash
# 从 Git 移除但保留本地文件
git rm --cached <file>

# 例如：移除已跟踪的 .env
git rm --cached .env
git commit -m "fix: 移除敏感配置文件"
```

### 3. 验证忽略规则

```bash
# 查看被忽略的文件
git status --ignored

# 测试特定文件是否会被忽略
git check-ignore -v test/output.log
git check-ignore -v *.zip
```

## 相关文档

- [docs/GITIGNORE_GUIDE.md](docs/GITIGNORE_GUIDE.md) - .gitignore 详细使用指南
- [docs/PACKAGE_STRUCTURE.md](docs/PACKAGE_STRUCTURE.md) - 项目结构说明
- [CHANGELOG_PACKAGE.md](CHANGELOG_PACKAGE.md) - package.sh 调整日志

## 检查清单

在提交前，请确认：

- [ ] `.env` 文件未被提交（包含敏感信息）
- [ ] `backend/database/` 未被提交（数据库文件）
- [ ] `*.log` 文件未被提交（日志文件）
- [ ] `node_modules/` 未被提交（npm 依赖）
- [ ] 打包文件（`*.zip`, `*.tar.gz`）未被提交
- [ ] 备份文件（`*.bak`, `*_副本.py`）未被提交
- [ ] 所有源码文件正常提交
- [ ] 所有文档（`docs/*.md`）正常提交
- [ ] 配置模板（`env.example`）正常提交
