"""
Service API 测试脚本
用于测试登录态校验功能
"""

import requests
import asyncio
from service.bns_client_async import get_async_bns_client


def test_health():
    """测试健康检查接口（不需要登录）"""
    print("\n" + "="*60)
    print("测试 1: 健康检查接口（不需要登录）")
    print("="*60)
    
    url = "http://localhost:8001/health"
    response = requests.get(url)
    
    print(f"请求 URL: {url}")
    print(f"响应状态码: {response.status_code}")
    print(f"响应内容: {response.json()}")
    
    assert response.status_code == 200
    assert response.json()["ret"] == "0"
    print("✅ 测试通过")


def test_without_login():
    """测试需要登录的接口（不带 Cookie）"""
    print("\n" + "="*60)
    print("测试 2: 访问需要登录的接口（不带 Cookie）")
    print("="*60)
    
    url = "http://localhost:8001/api/test"
    response = requests.get(url)
    
    print(f"请求 URL: {url}")
    print(f"响应状态码: {response.status_code}")
    print(f"响应内容: {response.json()}")
    
    assert response.status_code == 401
    assert response.json()["ret"] == "50000"
    assert response.json()["ret_msg"] == "not_login"
    print("✅ 测试通过（正确返回未登录）")


def test_with_login():
    """测试需要登录的接口（带正确的 Cookie）"""
    print("\n" + "="*60)
    print("测试 3: 访问需要登录的接口（带正确的 Cookie）")
    print("="*60)
    
    # 这里使用你的真实 OPENBDUSS 和 STOKEN
    cookies = {
        "OPENBDUSS": "QAAAAEAAABvolHSbgEXzlY5jZ4N-gelOs1GcMEYPl3-HR6zSRV3Jd_xp6q_R_5AvZl_5Km17xQo9_M4BrJmGmZsHrNp28eV0a3bEOsEiHBOSRCMiWLee9GpnmjRqTfagm9zB6DxQroh0-wnOW40tb2-qZhva5P5jTEGL3ogVLPZHObfAonZZgA",
        "STOKEN": ""  # 可选
    }
    
    url = "http://localhost:8001/api/test"
    response = requests.get(url, cookies=cookies)
    
    print(f"请求 URL: {url}")
    print(f"请求 Cookies: OPENBDUSS={bool(cookies['OPENBDUSS'])}, STOKEN={bool(cookies['STOKEN'])}")
    print(f"响应状态码: {response.status_code}")
    print(f"响应内容:")
    import pprint
    pprint.pprint(response.json())
    
    if response.status_code == 200:
        assert response.json()["ret"] == "0"
        assert "user" in response.json()
        print("✅ 测试通过（登录态校验成功）")
    else:
        print("⚠️  测试失败（可能是 Cookie 已过期或无效）")


async def test_bns_client_direct():
    """直接测试 BNS 客户端"""
    print("\n" + "="*60)
    print("测试 4: 直接测试 BNS 异步客户端")
    print("="*60)
    
    client = get_async_bns_client()
    
    result = await client.get_session_info(
        open_bduss="QAAAAEAAABvolHSbgEXzlY5jZ4N-gelOs1GcMEYPl3-HR6zSRV3Jd_xp6q_R_5AvZl_5Km17xQo9_M4BrJmGmZsHrNp28eV0a3bEOsEiHBOSRCMiWLee9GpnmjRqTfagm9zB6DxQroh0-wnOW40tb2-qZhva5P5jTEGL3ogVLPZHObfAonZZgA",
        stoken=None,
        uri="/api/test",
        verbose=True
    )
    
    print("\nBNS 客户端响应:")
    import pprint
    pprint.pprint(result)
    
    if result["success"]:
        print("✅ BNS 客户端测试通过")
    else:
        print("⚠️  BNS 客户端测试失败")


def main():
    """运行所有测试"""
    print("\n" + "="*60)
    print("Pet-Videos Service API 测试套件")
    print("="*60)
    
    try:
        # 检查服务是否启动
        try:
            requests.get("http://localhost:8001/health", timeout=2)
        except requests.exceptions.ConnectionError:
            print("\n❌ 错误：服务未启动")
            print("请先运行: python -m service.app")
            print("或者运行: ./start_service.sh")
            return
        
        # 运行测试
        test_health()
        test_without_login()
        test_with_login()
        
        # 测试异步 BNS 客户端
        print("\n正在测试异步 BNS 客户端...")
        asyncio.run(test_bns_client_direct())
        
        print("\n" + "="*60)
        print("所有测试完成")
        print("="*60)
        
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
    except Exception as e:
        print(f"\n❌ 测试异常: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
