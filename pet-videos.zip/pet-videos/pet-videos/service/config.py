"""
Service 配置
简单的 Python 配置文件，直接修改即可
"""

import os
from typing import List


class ServiceConfig:
    """Service 服务配置"""
    
    # ==================== 服务配置 ====================
    # 服务监听地址（0.0.0.0 监听所有网卡，127.0.0.1 仅本地）
    SERVICE_HOST = "0.0.0.0"
    
    # 服务端口
    SERVICE_PORT = 8006
    
    # ==================== 日志配置 ====================
    # 日志级别: DEBUG, INFO, WARNING, ERROR, CRITICAL
    LOG_LEVEL = "INFO"
    
    # 日志文件路径（None 表示只输出到控制台）
    LOG_FILE = "logs/service.log"
    
    # ==================== 认证配置 ====================
    # 不需要登录校验的公开路径（逗号分隔）
    # 注意：Service 直接对外时，中间件收到的是完整路径（包含 /pet mount 前缀）
    PUBLIC_PATHS = "/pet/health,/pet/api/video/stream,/pet/api/video/thumbnail"
    
    # ==================== 存储配置 ====================
    # 视频存储基础路径（优先从环境变量读取）
    # Windows 示例: D:\pet-videos\videos
    # Linux 示例: /data/pet-videos/videos
    STORAGE_BASE_PATH = os.getenv("SERVICE_STORAGE_BASE_PATH", "D:\\pet-videos\\videos")
    
    # RTSP 服务器基础地址（优先从环境变量读取）
    RTSP_SERVER_BASE_URL = os.getenv("SERVICE_RTSP_BASE_URL", "rtsp://59.110.63.88:8554/rtp")
    
    # Backend API 地址（优先从环境变量读取）
    BACKEND_API_URL = os.getenv("SERVICE_BACKEND_API_URL", "http://localhost:8002")
    
    # 外部访问地址（优先从环境变量读取）
    # 用于生成客户端可访问的完整URL
    # 生产环境示例: https://pre.dxmbaoxian.com
    # 开发环境示例: http://localhost:8006
    EXTERNAL_BASE_URL = os.getenv("SERVICE_EXTERNAL_BASE_URL", "https://pre.dxmbaoxian.com")
    
    # ==================== 属性方法 ====================
    @property
    def service_host(self) -> str:
        """服务监听地址"""
        return self.SERVICE_HOST
    
    @property
    def service_port(self) -> int:
        """服务端口"""
        return self.SERVICE_PORT
    
    @property
    def log_level(self) -> str:
        """日志级别"""
        return self.LOG_LEVEL
    
    @property
    def log_file(self) -> str:
        """日志文件路径"""
        return self.LOG_FILE
    
    @property
    def public_paths(self) -> str:
        """公开路径字符串"""
        return self.PUBLIC_PATHS
    
    @property
    def public_paths_list(self) -> List[str]:
        """公开路径列表"""
        return [path.strip() for path in self.PUBLIC_PATHS.split(",")]
    
    @property
    def storage_base_path(self) -> str:
        """存储基础路径"""
        return self.STORAGE_BASE_PATH
    
    @property
    def rtsp_server_base_url(self) -> str:
        """RTSP 服务器基础地址"""
        return self.RTSP_SERVER_BASE_URL
    
    @property
    def backend_api_url(self) -> str:
        """Backend API 地址"""
        return self.BACKEND_API_URL
    
    @property
    def external_base_url(self) -> str:
        """外部访问地址"""
        return self.EXTERNAL_BASE_URL


# 全局配置实例
settings = ServiceConfig()
