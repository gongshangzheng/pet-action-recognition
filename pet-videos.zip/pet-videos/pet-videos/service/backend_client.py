"""
Backend HTTP 客户端封装
统一管理 Service -> Backend 的所有 HTTP 请求
"""

import time
import aiohttp
from typing import Optional, Dict, Any, Union
from fastapi import Request
import logging

logger = logging.getLogger(__name__)


class BackendResponse:
    """Backend 响应包装类"""
    
    def __init__(self, status: int, headers: Dict[str, str], body: bytes):
        self.status = status
        self.headers = headers
        self._body = body
        self._json_cache = None
    
    async def json(self) -> Dict[str, Any]:
        """解析 JSON 响应"""
        if self._json_cache is None:
            import json
            self._json_cache = json.loads(self._body.decode('utf-8'))
        return self._json_cache
    
    async def text(self) -> str:
        """获取文本响应"""
        return self._body.decode('utf-8')
    
    async def read(self) -> bytes:
        """获取原始字节响应"""
        return self._body


class BackendClient:
    """Backend HTTP 客户端，支持性能追踪"""
    
    def __init__(self, base_url: str):
        """
        初始化 Backend 客户端
        
        Args:
            base_url: Backend API 基础地址，如 http://localhost:8000
        """
        self.base_url = base_url.rstrip('/')
    
    async def request(
        self,
        method: str,
        path: str,
        request: Request,
        description: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        timeout: int = 10,
        **kwargs
    ) -> BackendResponse:
        """
        发送 HTTP 请求到 Backend
        
        Args:
            method: HTTP 方法 (GET/POST/PUT/DELETE)
            path: API 路径 (如 /api/internal/pets/)，可以包含查询字符串
            request: FastAPI Request 对象，用于记录性能追踪
            description: 接口描述（用于性能日志）
            params: URL 查询参数
            json: JSON 请求体
            timeout: 超时时间（秒）
            **kwargs: 其他 aiohttp 参数
            
        Returns:
            BackendResponse 对象
        """
        url = f"{self.base_url}{path}"
        start_time = time.time()
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    method=method,
                    url=url,
                    params=params,
                    json=json,
                    timeout=aiohttp.ClientTimeout(total=timeout),
                    **kwargs
                ) as resp:
                    # 读取响应数据
                    body = await resp.read()
                    status = resp.status
                    headers = dict(resp.headers)
                    
                    # 记录性能
                    elapsed = (time.time() - start_time) * 1000
                    
                    # 追加到 request.state.perf_traces
                    if hasattr(request, 'state') and hasattr(request.state, 'perf_traces'):
                        request.state.perf_traces.append(f"{description}: {elapsed:.0f}ms")
                    
                    # 日志记录
                    logger.debug(
                        f"Backend请求 {method} {path} | "
                        f"状态: {status} | 耗时: {elapsed:.0f}ms"
                    )
                    
                    return BackendResponse(status, headers, body)
        except aiohttp.ClientError as e:
            elapsed = (time.time() - start_time) * 1000
            logger.error(f"Backend请求失败 {method} {path} | 耗时: {elapsed:.0f}ms | 错误: {e}")
            raise
        except Exception as e:
            elapsed = (time.time() - start_time) * 1000
            logger.error(f"Backend请求异常 {method} {path} | 耗时: {elapsed:.0f}ms | 错误: {e}")
            raise
    
    async def get(
        self,
        path: str,
        request: Request,
        description: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: int = 10,
        **kwargs
    ) -> BackendResponse:
        """GET 请求"""
        return await self.request(
            method="GET",
            path=path,
            request=request,
            description=description,
            params=params,
            timeout=timeout,
            **kwargs
        )
    
    async def post(
        self,
        path: str,
        request: Request,
        description: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: int = 10,
        **kwargs
    ) -> BackendResponse:
        """POST 请求"""
        return await self.request(
            method="POST",
            path=path,
            request=request,
            description=description,
            params=params,
            json=json,
            timeout=timeout,
            **kwargs
        )
    
    async def put(
        self,
        path: str,
        request: Request,
        description: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: int = 10,
        **kwargs
    ) -> BackendResponse:
        """PUT 请求"""
        return await self.request(
            method="PUT",
            path=path,
            request=request,
            description=description,
            params=params,
            json=json,
            timeout=timeout,
            **kwargs
        )
    
    async def delete(
        self,
        path: str,
        request: Request,
        description: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: int = 10,
        **kwargs
    ) -> BackendResponse:
        """DELETE 请求"""
        return await self.request(
            method="DELETE",
            path=path,
            request=request,
            description=description,
            params=params,
            timeout=timeout,
            **kwargs
        )
