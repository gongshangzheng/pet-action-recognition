"""
Pet-Videos Service API
提供独立的服务接口，支持登录态校验
"""

import os
import re
import asyncio
import json
import time
from datetime import datetime
from fastapi import FastAPI, Depends, Request, HTTPException, Query
from fastapi.responses import JSONResponse, StreamingResponse
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field, field_validator
import logging
import uvicorn
from pathlib import Path
import aiohttp

from service.config import settings
from service.auth import get_auth, require_login
from service.response import Response, ErrorCode
from service.backend_client import BackendClient

# 设置 Noah 环境变量（Windows 服务器必需，否则日志会有错误）
if "_NOAHEE_INSTANCEID" not in os.environ:
    os.environ["_NOAHEE_INSTANCEID"] = "5.android-container.licai-licai"

# 初始化 Backend 客户端（在配置加载后初始化）
backend_client: Optional[BackendClient] = None

# 配置日志
def setup_logging():
    """配置日志，同时输出到控制台和文件"""
    log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    # 创建 logger
    root_logger = logging.getLogger()
    root_logger.setLevel(settings.log_level)
    
    # 清除已有的 handlers
    root_logger.handlers.clear()
    
    # 创建格式化器
    formatter = logging.Formatter(log_format)
    
    # 1. 控制台 handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(settings.log_level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # 2. 文件 handler（如果配置了日志文件）
    if settings.log_file:
        log_file_path = Path(settings.log_file)
        # 确保日志目录存在
        log_file_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_file_path, encoding='utf-8')
        file_handler.setLevel(settings.log_level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

setup_logging()
logger = logging.getLogger(__name__)

# 配置独立的性能日志
performance_logger = logging.getLogger("performance")
performance_logger.setLevel(logging.INFO)
performance_logger.handlers.clear()  # 清除已有 handlers，防止重复添加
if settings.log_file:
    performance_log_path = Path(settings.log_file).parent / "performance.log"
    performance_log_path.parent.mkdir(parents=True, exist_ok=True)
    performance_handler = logging.FileHandler(performance_log_path, encoding='utf-8')
    performance_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
    performance_logger.addHandler(performance_handler)
    performance_logger.propagate = False  # 不传播到根 logger

# 创建子应用（包含所有业务路由）
sub_app = FastAPI(
    title="Pet-Videos Service API",
    description="提供独立的服务接口，支持登录态校验",
    version="1.0.0",
    docs_url=None,       # 禁用 /docs
    redoc_url=None,      # 禁用 /redoc
    openapi_url=None     # 禁用 /openapi.json
)

# 创建主应用（将子应用挂载到 /pet 路径）
app = FastAPI(
    title="Pet-Videos Service (Main)",
    docs_url=None,
    redoc_url=None,
    openapi_url=None
)


# 全局登录态校验中间件
@sub_app.middleware("http")
async def auth_middleware(request: Request, call_next):
    """
    全局登录态校验中间件
    
    自动根据 PUBLIC_PATHS 配置决定是否校验登录态
    """
    import time
    start_time = time.time()
    
    # 初始化性能追踪列表
    request.state.perf_traces = []
    
    auth = get_auth()
    
    # 调试：打印路径信息
    request_path = request.url.path
    is_public = auth.is_public_path(request_path)
    # logger.info(f"[中间件] 路径: {request_path}, 是否公开: {is_public}, 公开列表: {auth.public_paths}")
    
    # 如果路径在公开列表中，跳过登录校验
    if not is_public:
        auth_start = time.time()
        try:
            # 校验登录态并将用户信息存储到 request.state
            user_info = await auth.verify_session(request, raise_exception=True)
            request.state.user_info = user_info
            auth_elapsed = (time.time() - auth_start) * 1000
            request.state.perf_traces.append(f"登录态校验: {auth_elapsed:.0f}ms")
        except HTTPException as e:
            # 返回统一的错误响应
            return JSONResponse(
                status_code=200,
                content=e.detail
            )
    
    response = await call_next(request)
    
    total_elapsed = (time.time() - start_time) * 1000
    
    # 收集所有性能追踪信息
    perf_traces = getattr(request.state, 'perf_traces', [])
    
    # 记录到独立的性能日志（包含调用链路）
    if perf_traces:
        trace_str = " | ".join(perf_traces)
        performance_logger.info(
            f"{request.method} {request_path} | 总耗时: {total_elapsed:.0f}ms | 调用链: {trace_str}"
        )
    else:
        performance_logger.info(
            f"{request.method} {request_path} | 总耗时: {total_elapsed:.0f}ms"
        )
    
    # 慢请求告警（超过 2 秒）
    if total_elapsed > 2000:
        log_msg = f"[慢请求] {request.method} {request_path} | 总耗时: {total_elapsed:.0f}ms"
        if perf_traces:
            log_msg += f" | 调用链: {trace_str}"
        logger.warning(log_msg)
    
    return response


# 初始化认证配置（模块加载时立即执行）
def init_auth_config():
    """初始化认证配置"""
    global backend_client
    
    # 初始化 Backend 客户端
    backend_client = BackendClient(settings.backend_api_url)
    
    auth = get_auth()
    
    # 打印到标准输出（确保可见）
    print("=" * 60)
    print("Service 启动配置:")
    print(f"  监听端口: {settings.service_port}")
    print(f"  外部地址: {settings.external_base_url}")
    print(f"  Backend API: {settings.backend_api_url}")
    print(f"  日志文件: {settings.log_file}")
    print("  公开路径列表:")
    
    # 配置公开路径（不需要登录）
    for path in settings.public_paths_list:
        auth.add_public_path(path)
        print(f"    - {path}")
        logger.info(f"添加公开路径: {path}")
    
    print("=" * 60)
    
    logger.info(f"Service API 启动配置完成")
    logger.info(f"Backend客户端初始化完成: {settings.backend_api_url}")
    if settings.log_file:
        logger.info(f"日志文件: {settings.log_file}")

# 立即执行初始化
init_auth_config()


# ==================== 工具函数 ====================

def get_current_user(request: Request) -> Dict[str, Any]:
    """
    从 request.state 获取当前登录用户信息（中间件已校验）
    
    Args:
        request: FastAPI 请求对象
        
    Returns:
        用户信息字典
    """
    return getattr(request.state, "user_info", {})


def map_pet_to_app_format(pet: Dict[str, Any], simple: bool = False) -> Dict[str, Any]:
    """
    将宠物数据库格式映射为App端格式
    
    Args:
        pet: 数据库中的宠物数据
        simple: 是否返回简化格式（只包含petId, petName, avatarColor）
        
    Returns:
        App端格式的宠物数据
    """
    # 基础映射
    result = {
        "petId": str(pet.get("id", "")),  # 使用数据库自增ID
        "petName": pet.get("pet_name", ""),
        "avatarColor": pet.get("avatar_color") or "#E5E7EB"  # 默认灰色
    }
    
    if not simple:
        # 详细信息映射
        result.update({
            "species": pet.get("pet_type", ""),
            "petType": pet.get("breed", ""),
            "weight": str(pet.get("weight") or ""),
            "features": pet.get("description", ""),
            "gender": pet.get("gender", ""),
            "birthDate": pet.get("birth_date", ""),
            "color": pet.get("color", ""),
            "avatarUrl": pet.get("avatar_url", "")
        })
    
    return result


def map_app_to_db_format(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    将App端请求数据映射为数据库格式
    
    Args:
        data: App端请求数据
        
    Returns:
        数据库格式的数据
    """
    result = {}
    
    # App端字段 -> 数据库字段映射
    mapping = {
        "petName": "pet_name",
        "species": "pet_type",
        "petType": "breed",
        "weight": "weight",
        "features": "description",
        "avatarColor": "avatar_color",
        "gender": "gender",
        "birthDate": "birth_date",
        "color": "color",
        "avatarUrl": "avatar_url"
    }
    
    for app_field, db_field in mapping.items():
        if app_field in data and data[app_field] is not None:
            result[db_field] = data[app_field]
    
    return result


def mask_display_name(name: str) -> str:
    """
    对用户昵称进行打码混淆
    
    规则：
    - 长度 <= 1: 首字符 + 3个星号
    - 长度 >= 2: 保留首尾字符，中间固定 3个星号
    - 不透露真实位数信息
    
    示例：
    - "A" -> "A***"
    - "张三" -> "张***三"
    - "李四王" -> "李***王"
    - "欧阳修道" -> "欧***道"
    """
    if not name:
        return "***"
    
    length = len(name)
    if length <= 1:
        return name[0] + "***"
    else:
        return name[0] + "***" + name[-1]


# ==================== 公开接口（不需要登录） ====================

@sub_app.get("/health")
async def health_check() -> Dict[str, Any]:
    """
    健康检查接口（不需要登录）
    """
    return Response.success({
        "service": "pet-videos-service",
        "status": "healthy",
        "version": "1.0.0"
    })


@sub_app.get("/")
async def root() -> Dict[str, Any]:
    """
    根路径（不需要登录）
    """
    return Response.success({
        "message": "Pet-Videos Service API",
        "health": "/health"
    })


# ==================== 需要登录的接口 ====================

@sub_app.get("/api/test")
async def test_api(request: Request) -> Dict[str, Any]:
    """
    测试接口（需要登录）
    
    登录态由全局中间件自动校验
    """
    user_info = get_current_user(request)
    display_name = user_info.get("displayName", "")
    return Response.success({
        "displayName": mask_display_name(display_name),
        "isLogin": user_info.get("isLogin")
    })


@sub_app.get("/api/user/info")
async def get_user_info(request: Request) -> Dict[str, Any]:
    """
    获取用户信息（需要登录）
    返回 displayName（打码）和 isLogin 字段
    """
    user_info = get_current_user(request)
    display_name = user_info.get("displayName", "")
    return Response.success({
        "displayName": mask_display_name(display_name),
        "isLogin": user_info.get("isLogin")
    })


# ==================== 数据模型 ====================

class CameraAddRequest(BaseModel):
    """添加摄像头请求"""
    stream_identifier: str = Field(..., pattern=r'^[a-zA-Z0-9_-]{1,50}$', description="流标识")
    name: str = Field(..., min_length=1, max_length=100, description="摄像头名称")


class DeviceBindRequest(BaseModel):
    """设备绑定请求（App端）"""
    qrCode: str = Field(..., description="设备二维码内容")


class DeviceUnbindRequest(BaseModel):
    """设备解绑请求（App端）"""
    deviceId: str = Field(..., description="设备ID")


class CameraUpdateRequest(BaseModel):
    """更新摄像头请求"""
    name: Optional[str] = Field(None, max_length=100, description="显示名称")
    is_active: Optional[bool] = Field(None, description="是否启用")


class PetCreateRequest(BaseModel):
    """添加宠物请求（App端格式）"""
    petName: str = Field(..., min_length=1, max_length=100, description="宠物名称")
    species: Optional[str] = Field(None, max_length=50, description="物种（狗/猫/兔子等）")
    petType: Optional[str] = Field(None, max_length=100, description="品种（金毛/英短等）")
    weight: Optional[str] = Field(None, max_length=20, description="体重")
    features: Optional[str] = Field(None, description="外观特征")
    avatarColor: Optional[str] = Field(None, max_length=10, description="头像背景色")
    gender: Optional[str] = Field(None, max_length=10, description="性别")
    birthDate: Optional[str] = Field(None, pattern=r'^\d{4}-\d{2}-\d{2}$', description="出生日期")
    color: Optional[str] = Field(None, max_length=100, description="颜色")
    avatarUrl: Optional[str] = Field(None, max_length=500, description="头像URL")

    @field_validator('birthDate', 'gender', 'species', 'petType', 'weight',
                     'features', 'avatarColor', 'color', 'avatarUrl', mode='before')
    @classmethod
    def empty_str_to_none(cls, v):
        if v == '':
            return None
        return v


class PetUpdateRequest(BaseModel):
    """更新宠物请求（App端格式）"""
    petId: str = Field(..., description="宠物ID（必填）")
    petName: Optional[str] = Field(None, min_length=1, max_length=100, description="宠物名称")
    species: Optional[str] = Field(None, max_length=50, description="物种（狗/猫/兔子等）")
    petType: Optional[str] = Field(None, max_length=100, description="品种（金毛/英短等）")
    weight: Optional[str] = Field(None, max_length=20, description="体重")
    features: Optional[str] = Field(None, description="外观特征")
    avatarColor: Optional[str] = Field(None, max_length=10, description="头像背景色")
    gender: Optional[str] = Field(None, max_length=10, description="性别")
    birthDate: Optional[str] = Field(None, pattern=r'^\d{4}-\d{2}-\d{2}$', description="出生日期")
    color: Optional[str] = Field(None, max_length=100, description="颜色")
    avatarUrl: Optional[str] = Field(None, max_length=500, description="头像URL")


class PetDeleteRequest(BaseModel):
    """删除宠物请求（App端格式）"""
    petId: str = Field(..., description="宠物ID（必填）")


# ==================== 设备管理接口 ====================

async def _add_source_to_backend(did: str, stream_identifier: str, name: str, request: Request) -> tuple[bool, dict, str]:
    """
    内部函数：添加摄像头到 Backend
    
    Returns:
        (success: bool, data: dict, error_msg: str)
    """
    # 确保 did 是字符串类型
    did = str(did)
    
    # 生成字段
    alias = f"{did}_{stream_identifier}"
    stream_url = f"{settings.rtsp_server_base_url}/{stream_identifier}"
    storage_path = os.path.join(settings.storage_base_path, alias)
    
    # 创建存储目录
    try:
        Path(storage_path).mkdir(parents=True, exist_ok=True)
    except Exception as e:
        logger.error(f"创建存储目录失败: {storage_path}, 错误: {e}")
        return False, {}, "创建存储目录失败"
    
    # 调用 Backend API 创建源
    payload = {
        "name": name,
        "alias": alias,
        "stream_url": stream_url,
        "storage_path": storage_path,
        "is_active": True,
        "did": did
    }
    
    # logger.info(f"[Backend调用] 添加摄像头 Payload: {payload}")
    
    try:
        resp = await backend_client.post(
            path="/api/internal/sources/",
            request=request,
            description="Backend添加摄像头",
            json=payload,
            timeout=10
        )
        response_text = await resp.text()
        # logger.info(f"[Backend响应] Status: {resp.status}")
        # logger.info(f"[Backend响应] Body: {response_text[:500]}")
        
        if resp.status == 200:
            source = await resp.json()
            logger.info(f"添加摄像头成功: did={did}, stream_identifier={stream_identifier}")
            return True, source, ""
        elif resp.status == 400:
            if "already registered" in response_text.lower():
                return False, {}, "already_exists"
            return False, {}, "参数错误"
        else:
            logger.error(f"Backend API 错误: {resp.status}, 响应: {response_text}")
            return False, {}, "Backend API 错误"
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return False, {}, "网络请求失败"
    except Exception as e:
        logger.error(f"添加摄像头异常: {e}")
        return False, {}, "系统错误"


@sub_app.post("/api/device/bind")
async def bind_device(
    req_data: DeviceBindRequest,
    request: Request
) -> Dict[str, Any]:
    """设备绑定（App端 - 通过二维码）"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", "50010")
    
    # 二维码内容就是流标识符（如 chyr316）
    stream_identifier = req_data.qrCode.strip()
    device_name = f"摄像头-{stream_identifier[-4:]}"
    
    # 调用内部函数添加摄像头
    success, source, error_msg = await _add_source_to_backend(did, stream_identifier, device_name, request)
    
    if not success:
        if error_msg == "already_exists":
            return Response.error("设备已绑定", "50011")
        elif error_msg == "创建存储目录失败":
            return Response.error(error_msg, "50010")
        else:
            return Response.error(error_msg or "设备绑定失败", "50010")
    
    # 返回App端格式
    # 解析 created_at 时间戳
    bind_time = 0
    created_at_str = source.get("created_at")
    if created_at_str:
        try:
            from datetime import datetime
            dt = datetime.fromisoformat(created_at_str.replace('Z', '+00:00'))
            bind_time = int(dt.timestamp())
        except Exception as e:
            logger.warning(f"解析 created_at 失败: {e}, 使用当前时间")
            from datetime import datetime
            bind_time = int(datetime.now().timestamp())
    
    device_info = {
        "deviceId": stream_identifier,
        "deviceName": device_name,
        "deviceType": "camera",
        "bindTime": bind_time
    }
    return Response.success(device_info)


@sub_app.get("/api/device/query")
async def query_devices(request: Request) -> Dict[str, Any]:
    """查询用户已绑定的设备列表"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", "50010")
    
    # 确保 did 是字符串
    did = str(did)
    
    logger.info(f"[Service] 查询设备 - 当前用户 did={did}")
    
    # 调用 Backend API 查询该用户的所有源
    logger.info(f"[Service] 查询设备列表: did={did}")
    
    try:
        resp = await backend_client.get(
            path=f"/api/internal/sources/",
            request=request,
            description="Backend查询设备列表",
            params={"did": did},
            timeout=10
        )
        if resp.status == 200:
            sources = await resp.json()
            logger.info(f"[Service] Backend 返回 {len(sources)} 个设备")
            # if sources:
            #     logger.info(f"[Service] Backend 原始数据: {sources}")
            
            # 转换为App端格式
            devices = []
            for source in sources:
                devices.append({
                    "deviceId": str(source.get("id", "")),  # 添加设备ID
                    "deviceName": source.get("name", ""),
                    "isActive": source.get("is_active", True)
                })
            
            # logger.info(f"用户 {did} 的设备列表: {devices}")
            
            # 返回结果
            result = {
                "isbind": 1 if len(devices) > 0 else 0,
                "devices": devices,
                "total": len(devices)
            }
            return Response.success(result)
        else:
            logger.error(f"Backend API 错误: {resp.status}")
            return Response.error("查询设备失败", "50010")
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", "50010")
    except Exception as e:
        logger.error(f"查询设备异常: {e}")
        return Response.error("系统错误", "50010")


@sub_app.post("/api/device/unbind")
async def unbind_device(
    req_data: DeviceUnbindRequest,
    request: Request
) -> Dict[str, Any]:
    """解绑设备（只能解绑自己的设备）"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", "50010")
    
    # 确保 did 和 deviceId 是字符串
    did = str(did)
    device_id = req_data.deviceId
    
    logger.info(f"用户 {did} 请求解绑设备: {device_id}")
    
    # 调用 Backend API 删除设备（带权限校验）
    backend_url = f"{settings.backend_api_url}/api/internal/sources/{device_id}?requesting_did={did}"
    
    try:
        resp = await backend_client.delete(
            path=f"/api/internal/sources/{device_id}",
            request=request,
            description="Backend解绑设备",
            params={"requesting_did": did},
            timeout=10
        )
        if resp.status == 200:
            logger.info(f"设备 {device_id} 解绑成功（用户: {did}）")
            return Response.success({"message": "解绑成功"})
        elif resp.status == 403:
            logger.warning(f"用户 {did} 无权解绑设备 {device_id}")
            return Response.error("无权解绑此设备", "50003")
        elif resp.status == 404:
            logger.warning(f"设备 {device_id} 不存在")
            return Response.error("设备不存在", "50004")
        elif resp.status == 400:
            # 设备有关联任务，无法删除
            error_text = await resp.text()
            logger.warning(f"设备 {device_id} 无法删除: {error_text}")
            # 尝试解析错误信息
            try:
                error_data = json.loads(error_text)
                error_msg = error_data.get("detail", "设备有关联任务，无法删除")
            except:
                error_msg = "设备有关联任务，无法删除"
            return Response.error(error_msg, "50010")
        else:
            error_text = await resp.text()
            logger.error(f"Backend API 错误: {resp.status}, {error_text}")
            return Response.error("解绑设备失败", "50010")
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", "50010")
    except Exception as e:
        logger.error(f"解绑设备异常: {e}")
        return Response.error("系统错误", "50010")


@sub_app.get("/api/device/online")
async def check_device_online(request: Request) -> Dict[str, Any]:
    """检测用户设备流是否在线"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", "50010")
    
    # 确保 did 是字符串
    did = str(did)
    
    # 调用 Backend API 查询该用户的所有源
    try:
        resp = await backend_client.get(
            path=f"/api/internal/sources/",
            request=request,
            description="Backend查询设备状态",
            params={"did": did},
            timeout=10
        )
        if resp.status != 200:
            logger.error(f"Backend API 错误: {resp.status}")
            return Response.error("查询设备失败", "50010")
        
        sources = await resp.json()
        
        # 如果没有设备，返回空结果
        if not sources:
            return Response.success({
                "deviceName": "",
                "isOnline": False
            })
        
        # 只检测第一个设备
        first_source = sources[0]
        logger.info(f"检测用户 {did} 的第一个设备: {first_source.get('name', '')}")
        
        # 检测设备在线状态
        import asyncio
        import socket
        from urllib.parse import urlparse
        
        async def check_rtsp_online(stream_url: str, timeout: float = 3.0) -> bool:
            """通过TCP连接测试RTSP流是否在线"""
            try:
                parsed = urlparse(stream_url)
                host = parsed.hostname
                port = parsed.port or 554  # RTSP默认端口
                
                if not host:
                    return False
                
                # 在线程池中执行阻塞的socket连接
                loop = asyncio.get_event_loop()
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(timeout)
                
                def connect():
                    try:
                        sock.connect((host, port))
                        sock.close()
                        return True
                    except:
                        return False
                
                result = await loop.run_in_executor(None, connect)
                return result
            except Exception as e:
                logger.debug(f"检测流在线状态失败: {stream_url}, 错误: {e}")
                return False
        
        # 检测第一个设备
        stream_url = first_source.get("stream_url", "")
        is_online = await check_rtsp_online(stream_url)
        
        result = {
            "deviceName": first_source.get("name", ""),
            "isOnline": is_online
        }
        return Response.success(result)
                
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", "50010")
    except Exception as e:
        logger.error(f"检测设备在线状态异常: {e}")
        return Response.error("系统错误", "50010")


# ==================== 摄像头管理接口 ====================

@sub_app.post("/api/camera/add")
async def add_camera(
    req_data: CameraAddRequest,
    request: Request
) -> Dict[str, Any]:
    """添加摄像头"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", "50010")
    
    stream_identifier = req_data.stream_identifier
    name = req_data.name  # 用户输入的名称
    
    # 调用内部函数添加摄像头
    success, source, error_msg = await _add_source_to_backend(did, stream_identifier, name, request)
    
    if not success:
        if error_msg == "already_exists":
            return Response.error("流标识已存在", "50011")
        elif error_msg == "创建存储目录失败":
            return Response.error(error_msg, "50010")
        else:
            return Response.error(error_msg or "创建摄像头失败", "50010")
    
    # 只返回 id、name、is_active
    return Response.success({
        "id": source.get("id"),
        "name": source.get("name"),
        "is_active": source.get("is_active")
    })


@sub_app.get("/api/camera/list")
async def list_cameras(
    request: Request
) -> Dict[str, Any]:
    """查询摄像头列表"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", "50010")
    
    # 调用 Backend API 查询源
    try:
        resp = await backend_client.get(
            path=f"/api/internal/sources/",
            request=request,
            description="Backend查询摄像头列表",
            params={"did": did},
            timeout=10
        )
        if resp.status == 200:
            cameras = await resp.json()
            # 只返回 id、name、is_active
            filtered_cameras = [
                {
                    "id": camera.get("id"),
                    "name": camera.get("name"),
                    "is_active": camera.get("is_active")
                }
                for camera in cameras
            ]
            return Response.success({
                "cameras": filtered_cameras,
                "total": len(filtered_cameras)
            })
        else:
            logger.error(f"Backend API 错误: {resp.status}")
            return Response.error("查询摄像头列表失败", "50010")
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", "50010")
    except Exception as e:
        logger.error(f"查询摄像头列表异常: {e}")
        return Response.error("系统错误", "50010")


@sub_app.post("/api/camera/update/{source_id}")
async def update_camera(
    source_id: int,
    req_data: CameraUpdateRequest,
    request: Request
) -> Dict[str, Any]:
    """更新摄像头"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", "50010")
    
    # 调用 Backend API 更新源（带权限校验）
    payload = req_data.model_dump(exclude_unset=True)
    
    try:
        resp = await backend_client.put(
            path=f"/api/internal/sources/{source_id}",
            request=request,
            description="Backend更新摄像头",
            params={"requesting_did": did},
            json=payload,
            timeout=10
        )
        if resp.status == 200:
            source = await resp.json()
            logger.info(f"更新摄像头成功: source_id={source_id}, did={did}")
            return Response.success({"source": source})
        elif resp.status == 403:
            return Response.error("无权操作此摄像头", "50012")
        elif resp.status == 404:
            return Response.error("摄像头不存在", "50011")
        else:
            logger.error(f"Backend API 错误: {resp.status}")
            return Response.error("更新摄像头失败", "50010")
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", "50010")
    except Exception as e:
        logger.error(f"更新摄像头异常: {e}")
        return Response.error("系统错误", "50010")


@sub_app.post("/api/camera/delete/{source_id}")
async def delete_camera(
    source_id: int,
    request: Request
) -> Dict[str, Any]:
    """删除摄像头"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", "50010")
    
    # 调用 Backend API 删除源（带权限校验）
    try:
        resp = await backend_client.delete(
            path=f"/api/internal/sources/{source_id}",
            request=request,
            description="Backend删除摄像头",
            params={"requesting_did": did},
            timeout=10
        )
        if resp.status == 200:
            result = await resp.json()
            logger.info(f"删除摄像头成功: source_id={source_id}, did={did}")
            return Response.success(result)
        elif resp.status == 403:
            return Response.error("无权删除此摄像头", "50012")
        elif resp.status == 404:
            return Response.error("摄像头不存在", "50011")
        elif resp.status == 400:
            error_detail = await resp.json()
            return Response.error(error_detail.get("detail", "删除失败"), "50011")
        else:
            logger.error(f"Backend API 错误: {resp.status}")
            return Response.error("删除摄像头失败", "50010")
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", "50010")
    except Exception as e:
        logger.error(f"删除摄像头异常: {e}")
        return Response.error("系统错误", "50010")


# ==================== 视频查询接口 ====================

@sub_app.api_route("/api/video/stream", methods=["GET", "HEAD"])
async def stream_video(
    token: str = Query(..., description="视频文件token"),
    request: Request = None
) -> StreamingResponse:
    """
    视频流播放接口（公开，不校验登录态）
    
    直接代理到 Backend 的 /video/stream 接口
    支持 Range 请求和 HEAD 请求
    
    安全性说明：
    1. 不需要登录态校验，因为 Backend 已通过 stream_token 的 HMAC 签名验证安全性
    2. stream_token 格式: base64(alias:filename).signature
    3. 只有合法的 token 才能访问视频资源
    """
    print(f"[路由 stream_video] 收到请求！method={request.method if request else 'unknown'}, token={token[:50]}...")
    logger.info(f"[路由 stream_video] 收到请求！method={request.method if request else 'unknown'}, token={token[:50]}...")
    try:
        # 构建 Backend URL
        backend_url = f"{settings.backend_api_url}/api/video/stream"
        
        # 准备请求头（转发 Range 和其他必要的头）
        headers = {}
        if request and hasattr(request, 'headers'):
            # 转发 Range 头（用于断点续传）
            if 'range' in request.headers:
                headers['Range'] = request.headers['range']
            # 转发 User-Agent（可选）
            if 'user-agent' in request.headers:
                headers['User-Agent'] = request.headers['user-agent']
        
        # HEAD 请求：只获取响应头
        if request.method == "HEAD":
            async with aiohttp.ClientSession() as session:
                async with session.head(
                    backend_url,
                    params={"token": token},
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as resp:
                    if resp.status in (200, 206):
                        # 转发响应头
                        response_headers = {}
                        for key in ['Content-Type', 'Content-Length', 'Accept-Ranges', 'Content-Range']:
                            if key.lower() in resp.headers:
                                response_headers[key] = resp.headers[key.lower()]
                        
                        return StreamingResponse(
                            iter([]),  # HEAD 请求不返回 body
                            status_code=resp.status,
                            headers=response_headers
                        )
                    elif resp.status == 403:
                        raise HTTPException(status_code=403, detail="Token 无效或已过期")
                    elif resp.status == 404:
                        raise HTTPException(status_code=404, detail="视频不存在")
                    else:
                        logger.error(f"Backend stream API 错误: {resp.status}")
                        raise HTTPException(status_code=500, detail="视频服务异常")
        
        # GET 请求：流式传输视频
        # 创建一个容器来在生成器和外部函数之间共享响应信息
        response_info = {}
        
        # 在生成器内部创建并管理 session 和 response 的生命周期
        async def iter_video_stream():
            session = aiohttp.ClientSession()
            try:
                resp = await session.get(
                    backend_url,
                    params={"token": token},
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=None)  # 视频流不设超时
                )
                try:
                    if resp.status not in (200, 206):
                        if resp.status == 403:
                            raise HTTPException(status_code=403, detail="Token 无效或已过期")
                        elif resp.status == 404:
                            raise HTTPException(status_code=404, detail="视频不存在")
                        else:
                            logger.error(f"Backend stream API 错误: {resp.status}")
                            raise HTTPException(status_code=500, detail="视频服务异常")
                    
                    # 保存响应信息（状态码和响应头）供外部使用
                    response_info['status_code'] = resp.status
                    response_info['headers'] = {}
                    for key in ['Content-Type', 'Content-Length', 'Accept-Ranges', 'Content-Range']:
                        if key.lower() in resp.headers:
                            response_info['headers'][key] = resp.headers[key.lower()]
                    
                    # 流式读取并转发视频内容
                    async for chunk in resp.content.iter_chunked(1024 * 64):  # 64KB chunks
                        yield chunk
                finally:
                    resp.close()
            finally:
                await session.close()
        
        # 创建异步生成器
        stream_generator = iter_video_stream()
        
        # 读取第一个 chunk 以触发响应信息的填充
        try:
            first_chunk = await stream_generator.__anext__()
        except StopAsyncIteration:
            # 空视频
            return StreamingResponse(
                iter([]),
                status_code=200,
                headers={'Content-Type': 'video/mp4'},
                media_type="video/mp4"
            )
        
        # 创建新的生成器，先返回第一个 chunk，然后继续
        async def final_stream():
            yield first_chunk
            async for chunk in stream_generator:
                yield chunk
        
        return StreamingResponse(
            final_stream(),
            status_code=response_info.get('status_code', 200),
            headers=response_info.get('headers', {}),
            media_type="video/mp4"
        )
    
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend stream API 失败: {e}")
        raise HTTPException(status_code=500, detail="视频服务连接失败")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"视频流传输异常: {e}")
        raise HTTPException(status_code=500, detail="视频服务异常")


@sub_app.get("/api/video/thumbnail")
async def get_video_thumbnail(
    token: str = Query(..., description="视频文件token"),
    request: Request = None
):
    """
    获取视频缩略图（公开，不校验登录态）
    
    直接代理到 Backend 的 /thumbnail 接口
    与视频流使用相同的 token 验证机制
    """
    print(f"[路由 get_video_thumbnail] 收到请求！token={token[:50]}...")
    logger.info(f"[路由 get_video_thumbnail] 收到请求！token={token[:50]}...")
    try:
        # 构建 Backend URL
        backend_url = f"{settings.backend_api_url}/api/thumbnail/"
        
        logger.info(f"代理缩略图请求到 Backend: token={token[:20]}...")
        
        # 调用 Backend 接口
        async with aiohttp.ClientSession() as session:
            async with session.get(
                backend_url,
                params={"token": token},
                timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:
                if resp.status == 200:
                    # 读取完整图片内容
                    content = await resp.read()
                    content_length = len(content)
                    
                    logger.info(f"缩略图读取成功，大小: {content_length} bytes")
                    
                    # 直接返回完整内容（图片很小，不需要流式传输）
                    from fastapi.responses import Response as FastAPIResponse
                    return FastAPIResponse(
                        content=content,
                        media_type="image/jpeg",
                        headers={
                            "Content-Length": str(content_length),  # 明确指定内容长度
                            "Cache-Control": "public, max-age=86400",
                            "Accept-Ranges": "bytes",
                            "Connection": "close"  # 确保连接正确关闭
                        }
                    )
                elif resp.status == 403:
                    raise HTTPException(status_code=403, detail="Token 无效或已过期")
                elif resp.status == 404:
                    raise HTTPException(status_code=404, detail="缩略图不存在")
                else:
                    response_text = await resp.text()
                    logger.error(f"Backend thumbnail API 错误: {resp.status}, {response_text}")
                    raise HTTPException(status_code=500, detail="缩略图服务异常")
                    
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend thumbnail API 失败: {e}")
        raise HTTPException(status_code=500, detail="缩略图服务连接失败")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"获取缩略图异常: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="缩略图服务异常")


@sub_app.get("/api/videos/by-date")
async def get_videos_by_date(
    request: Request,
    date: str = Query(..., pattern=r'^\d{4}-\d{2}-\d{2}$', description="日期 YYYY-MM-DD"),
    source_id: Optional[int] = Query(None, description="摄像头ID（可选，不传则查询所有摄像头）"),
    pet_name: Optional[str] = Query(None, max_length=100, description="宠物名称（可选，过滤包含该宠物的视频）"),
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(20, ge=0, le=1000, description="每页数量，0表示查询所有（最多1000条）")
) -> Dict[str, Any]:
    """按日期查询视频切片（支持按摄像头和宠物过滤）"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", "50010")
    
    try:
        # 构建查询参数
        video_query_params = {"date": date, "page": 1, "page_size": page_size if page_size > 0 else 1}
        
        # 如果指定了 source_id，需要先校验权限
        if source_id:
            resp = await backend_client.get(
                path=f"/api/internal/sources/{source_id}",
                request=request,
                description="Backend查询摄像头",
                timeout=10
            )
            if resp.status == 404:
                return Response.error("摄像头不存在", "50011")
            elif resp.status != 200:
                logger.error(f"查询摄像头失败: {resp.status}")
                return Response.error("查询摄像头信息失败", "50010")
            
            source = await resp.json()
            # 权限校验
            if source.get("did") != did:
                return Response.error("无权查看此摄像头的视频", "50012")
            
            # 使用 alias 查询
            video_query_params["alias"] = source["alias"]
        else:
            # 查询用户所有摄像头
            video_query_params["did"] = did
        
        # 添加宠物过滤参数
        if pet_name:
            video_query_params["pet_name"] = pet_name
        
        # 查询视频记录
        if page_size == 0:
            # 先查询总数
            count_resp = await backend_client.get(
                path="/api/videos/by_date",
                request=request,
                description="Backend视频总数查询",
                params=video_query_params,
                timeout=10
            )
            if count_resp.status == 200:
                count_result = await count_resp.json()
                total = count_result.get("total", 0)
                
                # 实际返回 min(total, 1000) 条
                actual_page_size = min(total, 1000)
                video_query_params["page_size"] = actual_page_size
                
                # 查询实际数据
                videos_resp = await backend_client.get(
                    path="/api/videos/by_date",
                    request=request,
                    description=f"Backend视频列表查询({actual_page_size}条)",
                    params=video_query_params,
                    timeout=30
                )
                if videos_resp.status == 200:
                    result = await videos_resp.json()
                    result["is_all"] = True
                    if total > 1000:
                        result["warning"] = f"当日共 {total} 条记录，已返回前 1000 条"
                    return Response.success(result)
                else:
                    return Response.error("查询视频失败", "50010")
            else:
                return Response.error("查询视频总数失败", "50010")
        else:
            # 普通分页查询
            video_query_params["page"] = page
            video_query_params["page_size"] = page_size
            videos_resp = await backend_client.get(
                path="/api/videos/by_date",
                request=request,
                description=f"Backend视频分页查询(p{page},ps{page_size})",
                params=video_query_params,
                timeout=30
            )
            if videos_resp.status == 200:
                result = await videos_resp.json()
                result["is_all"] = False
                return Response.success(result)
            else:
                return Response.error("查询视频失败", "50010")
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", "50010")
    except Exception as e:
        logger.error(f"查询视频异常: {e}")
        return Response.error("系统错误", "50010")


# ==================== 宠物管理接口 ====================

@sub_app.get("/api/pet/list")
async def list_pets(
    request: Request
) -> Dict[str, Any]:
    """获取宠物列表（简化版 - App端使用）"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", ErrorCode.PARAM_ERROR)
    
    # 调用 Backend API 查询宠物列表
    try:
        resp = await backend_client.get(
            path="/api/internal/pets/",
            request=request,
            description="Backend宠物列表接口",
            params={"did": did},
            timeout=10
        )
        if resp.status == 200:
            result = await resp.json()
            pets = result.get("pets", [])
            
            logger.info(f"[Service/Pet/List] Backend返回 {len(pets)} 条记录")
            # if pets:
            #     logger.info(f"[Service/Pet/List] 第一条pet对象: {pets[0]}")
            #     logger.info(f"[Service/Pet/List] 第一条pet的id字段: {pets[0].get('id')}")
            
            # 映射为App端简化格式（只包含petId, petName, avatarColor）
            app_pets = [map_pet_to_app_format(pet, simple=True) for pet in pets]
            
            # if app_pets:
            #     logger.info(f"[Service/Pet/List] 映射后第一条: {app_pets[0]}")
            
            return Response.success({"pets": app_pets})
        else:
            logger.error(f"Backend API 错误: {resp.status}")
            return Response.error("查询宠物列表失败", ErrorCode.SYSTEM_ERROR)
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", ErrorCode.NETWORK_ERROR)
    except Exception as e:
        logger.error(f"查询宠物列表异常: {e}")
        return Response.error("系统错误", ErrorCode.SYSTEM_ERROR)


@sub_app.get("/api/pet/list-detail")
async def list_pets_detail(
    request: Request
) -> Dict[str, Any]:
    """获取宠物列表（详细版 - 包含完整信息）"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", ErrorCode.PARAM_ERROR)
    
    # 调用 Backend API 查询宠物列表
    try:
        resp = await backend_client.get(
            path="/api/internal/pets/",
            request=request,
            description="Backend宠物详情列表接口",
            params={"did": did},
            timeout=10
        )
        if resp.status == 200:
            result = await resp.json()
            pets = result.get("pets", [])
            
            logger.info(f"[Service/Pet/ListDetail] Backend返回 {len(pets)} 条记录")
            # if pets:
            #     logger.info(f"[Service/Pet/ListDetail] 第一条pet对象: {pets[0]}")
            #     logger.info(f"[Service/Pet/ListDetail] 第一条pet的id字段: {pets[0].get('id')}")
            
            # 映射为App端详细格式（包含所有字段）
            app_pets = [map_pet_to_app_format(pet, simple=False) for pet in pets]
            
            # if app_pets:
            #     logger.info(f"[Service/Pet/ListDetail] 映射后第一条: {app_pets[0]}")
            
            return Response.success({"pets": app_pets})
        else:
            logger.error(f"Backend API 错误: {resp.status}")
            return Response.error("查询宠物列表失败", ErrorCode.SYSTEM_ERROR)
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", ErrorCode.NETWORK_ERROR)
    except Exception as e:
        logger.error(f"查询宠物列表异常: {e}")
        return Response.error("系统错误", ErrorCode.SYSTEM_ERROR)


@sub_app.post("/api/pet/add")
async def add_pet(
    req_data: PetCreateRequest,
    request: Request
) -> Dict[str, Any]:
    """添加宠物（支持App端字段）"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", ErrorCode.PARAM_ERROR)
    
    # 将请求数据转换为字典
    request_data = req_data.model_dump(exclude_unset=True)
    
    # 映射App端字段到数据库格式
    payload = map_app_to_db_format(request_data)
    
    # 确保有宠物名称
    if not payload.get("pet_name"):
        return Response.error("宠物名称不能为空", ErrorCode.PARAM_ERROR)
    
    # 调用 Backend API 创建宠物
    try:
        resp = await backend_client.post(
            path="/api/internal/pets/",
            request=request,
            description="Backend添加宠物",
            params={"did": did},
            json=payload,
            timeout=10
        )
        if resp.status == 200:
            pet = await resp.json()
            logger.info(f"添加宠物成功: did={did}, pet_name={payload.get('pet_name')}")
            # logger.info(f"[Service/Pet] Backend返回的pet对象: {pet}")
            # logger.info(f"[Service/Pet] pet中的id字段: {pet.get('id')}")
            # logger.info(f"[Service/Pet] pet中的did字段: {pet.get('did')}")
            
            # 返回App端格式
            app_pet = map_pet_to_app_format(pet, simple=False)
            # logger.info(f"[Service/Pet] 映射后的app_pet: {app_pet}")
            # logger.info(f"[Service/Pet] app_pet中的petId: {app_pet.get('petId')}")
            return Response.success({"pet": app_pet, "petId": app_pet.get("petId")})
        elif resp.status == 400:
            error_detail = await resp.json()
            detail_msg = error_detail.get("detail", "")
            if "already exists" in detail_msg:
                return Response.error("已存在同名宠物", ErrorCode.ALREADY_EXISTS)
            return Response.error("参数错误", ErrorCode.PARAM_ERROR)
        else:
            logger.error(f"Backend API 错误: {resp.status}")
            return Response.error("添加宠物失败", ErrorCode.SYSTEM_ERROR)
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", ErrorCode.NETWORK_ERROR)
    except Exception as e:
        logger.error(f"添加宠物异常: {e}")
        return Response.error("系统错误", ErrorCode.SYSTEM_ERROR)


@sub_app.post("/api/pet/update")
async def update_pet(
    req_data: PetUpdateRequest,
    request: Request
) -> Dict[str, Any]:
    """更新宠物（App端格式）"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", ErrorCode.PARAM_ERROR)
    
    # 将请求数据转换为字典
    request_data = req_data.model_dump(exclude_unset=True)
    
    # 获取petId（必填）并转换为整数
    try:
        pet_id = int(req_data.petId)
    except (ValueError, TypeError):
        return Response.error("宠物ID格式错误", ErrorCode.PARAM_ERROR)
    
    # 映射App端字段到数据库格式
    payload = map_app_to_db_format(request_data)
    
    # 调用 Backend API 更新宠物（使用by-id路由）
    try:
        resp = await backend_client.put(
            path=f"/api/internal/pets/by-id/{pet_id}",
            request=request,
            description="Backend更新宠物",
            params={"did": did},
            json=payload,
            timeout=10
        )
        if resp.status == 200:
            pet = await resp.json()
            logger.info(f"更新宠物成功: did={did}, pet_id={pet_id}")
            
            # 返回App端格式
            app_pet = map_pet_to_app_format(pet, simple=False)
            return Response.success({"pet": app_pet})
        elif resp.status == 404:
            return Response.error("宠物不存在", ErrorCode.NOT_FOUND)
        else:
            logger.error(f"Backend API 错误: {resp.status}")
            return Response.error("更新宠物失败", ErrorCode.SYSTEM_ERROR)
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", ErrorCode.NETWORK_ERROR)
    except Exception as e:
        logger.error(f"更新宠物异常: {e}")
        return Response.error("系统错误", ErrorCode.SYSTEM_ERROR)


@sub_app.get("/api/pet/calendar")
async def get_pet_calendar(
    request: Request,
    startDate: Optional[str] = Query(None, description="起始日期 yyyy-MM-dd"),
    endDate: Optional[str] = Query(None, description="结束日期 yyyy-MM-dd")
) -> Dict[str, Any]:
    """获取日历信息（有视频记录的日期列表）"""
    # logger.info(f"[DEBUG] ========== Calendar 接口请求 ==========")
    # logger.info(f"[DEBUG] 请求参数: startDate={startDate}, endDate={endDate}")
    
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", ErrorCode.PARAM_ERROR)
    
    # logger.info(f"[DEBUG] 用户did: {did}")
    
    # 调用 Backend API 查询视频记录日期（内部接口，无需JWT认证）
    # logger.info(f"[DEBUG] Backend API 基础URL: {settings.backend_api_url}")
    
    try:
        # logger.info(f"[DEBUG] 开始调用 Backend...")
        
        # 构建 params
        params = {"did": did}
        if startDate:
            params["start_date"] = startDate
        if endDate:
            params["end_date"] = endDate
        
        resp = await backend_client.get(
            path="/api/internal/video-records/dates",
            request=request,
            description="Backend日历查询",
            params=params,
            timeout=30
        )
        # logger.info(f"[DEBUG] Backend 响应状态码: {resp.status}")
        
        if resp.status == 200:
            result = await resp.json()
            # logger.info(f"[DEBUG] Backend 返回原始数据: {result}")
            
            dates = result.get("dates", [])
            # logger.info(f"[DEBUG] 解析到的日期数量: {len(dates)}")
            # logger.info(f"[DEBUG] 日期列表: {dates}")
            
            # 返回App端格式
            response_data = {"eventDates": dates}
            # logger.info(f"[DEBUG] 返回给App的数据: {response_data}")
            # logger.info(f"[DEBUG] ========== Calendar 接口请求完成 ==========")
            return Response.success(response_data)
        else:
            error_text = await resp.text()
            logger.error(f"Backend API 错误: status={resp.status}, 响应: {error_text[:200]}")
            return Response.error("查询日历失败", ErrorCode.SYSTEM_ERROR)
    except aiohttp.ClientError as e:
        logger.error(f"网络请求异常: {e}", exc_info=True)
        return Response.error("网络请求失败", ErrorCode.NETWORK_ERROR)
    except Exception as e:
        logger.error(f"未知异常: {e}", exc_info=True)
        return Response.error("系统错误", ErrorCode.SYSTEM_ERROR)


@sub_app.post("/api/pet/delete")
async def delete_pet(
    req_data: PetDeleteRequest,
    request: Request
) -> Dict[str, Any]:
    """删除宠物（App端格式）"""
    user_info = get_current_user(request)
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", ErrorCode.PARAM_ERROR)
    
    # 获取petId（必填）并转换为整数
    try:
        pet_id = int(req_data.petId)
    except (ValueError, TypeError):
        return Response.error("宠物ID格式错误", ErrorCode.PARAM_ERROR)
    
    # 调用 Backend API 删除宠物（使用by-id路由）
    try:
        resp = await backend_client.delete(
            path=f"/api/internal/pets/by-id/{pet_id}",
            request=request,
            description="Backend删除宠物",
            params={"did": did},
            timeout=10
        )
        if resp.status == 200:
            result = await resp.json()
            logger.info(f"删除宠物成功: did={did}, pet_id={pet_id}")
            return Response.success({"success": True})
        elif resp.status == 404:
            return Response.error("宠物不存在", ErrorCode.NOT_FOUND)
        else:
            logger.error(f"Backend API 错误: {resp.status}")
            return Response.error("删除宠物失败", ErrorCode.SYSTEM_ERROR)
    except aiohttp.ClientError as e:
        logger.error(f"调用 Backend API 失败: {e}")
        return Response.error("网络请求失败", ErrorCode.NETWORK_ERROR)
    except Exception as e:
        logger.error(f"删除宠物异常: {e}")
        return Response.error("系统错误", ErrorCode.SYSTEM_ERROR)


# ==================== 日报管理接口 ====================

@sub_app.get("/api/pet/daily-report")
async def get_daily_reports_app(
    request: Request,
    date: str = Query(..., description="日期 yyyy-MM-dd"),
    petId: Optional[str] = Query(None, description="宠物ID（可选）")
) -> Dict[str, Any]:
    """
    获取日报数据（App端格式）
    - date: 日期，格式 yyyy-MM-dd（必填）
    - petId: 宠物ID（可选，用于筛选）
    - 返回：petReports + events
    """
    import time
    req_start = time.time()
    
    # logger.info(f"[DEBUG] ========== 开始处理日报请求 ==========")
    # logger.info(f"[DEBUG] 请求参数 - date: {date}, petId: {petId}")
    
    user_info = get_current_user(request)
    # logger.info(f"[DEBUG] 用户信息: {user_info}")
    
    did = user_info.get("did")
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", ErrorCode.PARAM_ERROR)
    
    # petId 是 pets 表的 id，需要先查询得到 pet_name
    pet_name = None
    if petId:
        try:
            # 调用 Backend 的内部pets接口获取宠物信息（通过ID查询）
            # logger.info(f"[DEBUG] 查询宠物信息 - petId: {petId}, did: {did}")
            resp = await backend_client.get(
                path=f"/api/internal/pets/by-id/{petId}",
                request=request,
                description="Backend查询宠物by-id",
                params={"did": did},
                timeout=5
            )
            if resp.status == 200:
                pet_data = await resp.json()
                pet_name = pet_data.get("pet_name")
            else:
                response_text = await resp.text()
                logger.warning(f"查询宠物信息失败，status={resp.status}, 响应: {response_text[:200]}")
        except Exception as e:
            logger.error(f"查询宠物信息异常: {e}")
    
    # logger.info(f"[DEBUG] 解析后 - did: {did}, pet_name: {pet_name}")
    
    try:
        # 并行请求日报数据、视频事件数据和宠物列表
        
        # 1. 获取日报数据（调用 Backend 的内部接口，无需JWT认证）
        daily_report_params = {"did": did, "date": date}
        if pet_name:
            daily_report_params["pet_name"] = pet_name
        # logger.info(f"[DEBUG] 调用Backend日报接口，参数: {daily_report_params}")
        
        # 2. 获取视频事件数据（调用 Backend 的内部接口，无需JWT认证）
        video_params = {"did": did, "date": date}
        if pet_name:
            video_params["pet_name"] = pet_name
        # logger.info(f"[DEBUG] 调用Backend视频接口，参数: {video_params}")
        
        # 并行调用（BackendClient 会自动记录各自耗时）
        async def fetch_daily_reports():
            return await backend_client.get(
                path="/api/internal/daily-reports/",
                request=request,
                description="Backend日报接口",
                params=daily_report_params,
                timeout=10
            )
        
        async def fetch_video_records():
            return await backend_client.get(
                path="/api/internal/video-records/",
                request=request,
                description="Backend视频接口",
                params=video_params,
                timeout=10
            )
        
        async def fetch_pets():
            return await backend_client.get(
                path="/api/internal/pets/",
                request=request,
                description="Backend宠物列表",
                params={"did": did},
                timeout=5
            )
        
        responses = await asyncio.gather(
            fetch_daily_reports(),
            fetch_video_records(),
            fetch_pets(),
            return_exceptions=True
        )
        
        # logger.info(f"[DEBUG] Backend接口响应 - 日报状态: {responses[0].status if not isinstance(responses[0], Exception) else 'Exception'}, 视频状态: {responses[1].status if not isinstance(responses[1], Exception) else 'Exception'}, 宠物列表状态: {responses[2].status if not isinstance(responses[2], Exception) else 'Exception'}")
        
        # 先构建宠物映射表（从并发结果中获取）
        pets_map = {}
        if not isinstance(responses[2], Exception):
            pets_resp = responses[2]
            if pets_resp.status == 200:
                pets_data = await pets_resp.json()
                # 构建 pet_name -> pet_info 的映射
                for pet in pets_data.get("pets", []):
                    pets_map[pet.get("pet_name")] = pet
            else:
                response_text = await pets_resp.text()
                logger.warning(f"宠物列表接口返回非200状态: {pets_resp.status}, 响应: {response_text[:200]}")
        else:
            logger.error(f"宠物列表接口请求异常: {responses[2]}")
        
        # 处理日报数据
        pet_reports = []
        if not isinstance(responses[0], Exception):
            daily_resp = responses[0]
            # logger.info(f"[DEBUG] 日报接口响应状态: {daily_resp.status}")
            if daily_resp.status == 200:
                daily_data = await daily_resp.json()
                reports = daily_data.get("reports", [])
                # logger.info(f"[DEBUG] 日报数据 - 总数: {daily_data.get('total', 0)}, 返回记录数: {len(reports)}")
                
                # 映射为App端格式
                for report in reports:
                    report_pet_name = report.get("pet_name", "")
                    pet_info = pets_map.get(report_pet_name, {})
                    
                    # Backend返回的字段：did, date, pet_name, summary, daily_tag, insight_text等
                    pet_reports.append({
                        "petId": str(pet_info.get("id", "")),  # pets表的id
                        "petName": report_pet_name,
                        "petType": pet_info.get("pet_type", ""),
                        "weight": str(pet_info.get("weight", "") if pet_info.get("weight") else ""),
                        "features": pet_info.get("description", ""),
                        "avatarColor": pet_info.get("avatar_color") or "#E5E7EB",
                        "dailyTag": report.get("daily_tag", ""),
                        "dailyReport": report.get("summary", "")  # 使用summary字段
                    })
            else:
                logger.warning(f"日报接口返回非200状态: {daily_resp.status}")
                response_text = await daily_resp.text()
                logger.warning(f"日报接口响应内容: {response_text[:200]}")
        else:
            logger.error(f"日报接口请求异常: {responses[0]}")
        
        # 处理视频事件数据（Backend 返回的是 records 字段）
        events = []
        if not isinstance(responses[1], Exception):
            video_resp = responses[1]
            # logger.info(f"[DEBUG] 视频接口响应状态: {video_resp.status}")
            if video_resp.status == 200:
                video_data = await video_resp.json()
                records = video_data.get("records", [])
                # logger.info(f"[DEBUG] 视频数据 - 总数: {video_data.get('total', 0)}, 返回记录数: {len(records)}")
                
                # 映射为App端格式
                for idx, record in enumerate(records, 1):
                    # 提取时间部分 (HH:MM)
                    recorded_at = record.get("recorded_at", "")
                    event_time = ""
                    if recorded_at:
                        try:
                            dt = datetime.fromisoformat(recorded_at.replace('Z', '+00:00'))
                            event_time = dt.strftime("%H:%M")
                        except:
                            pass
                    
                    # 处理宠物信息：优先使用 pet_name，如果为空则从 pets 列表获取
                    pet_name_display = record.get("pet_name") or ""
                    pets_list = record.get("pets", [])
                    
                    # 如果 pet_name 为空但有 pets 列表，使用第一只宠物的名称
                    if not pet_name_display and pets_list:
                        pet_name_display = pets_list[0].get("pet_name", "")
                    
                    # 合并所有宠物的描述作为事件描述
                    event_descriptions = []
                    for pet_info in pets_list:
                        desc = pet_info.get("description", "")
                        if desc:
                            pet_display_name = pet_info.get("pet_name", "")
                            # 如果有多只宠物，前缀显示宠物名
                            if len(pets_list) > 1 and pet_display_name:
                                event_descriptions.append(f"{pet_display_name}: {desc}")
                            else:
                                event_descriptions.append(desc)
                    event_desc = " | ".join(event_descriptions)
                    
                    # 构建视频URL：使用外部访问地址生成完整URL
                    video_url_path = record.get("video_url", "")
                    full_video_url = ""
                    if video_url_path:
                        # Backend 可能返回以下格式：
                        # 1. 相对路径: /api/video/stream?token=xxx
                        # 2. 完整URL: http://localhost:8002/api/video/stream?token=xxx
                        # 需要统一转换为: https://pre.dxmbaoxian.com/pet/api/video/stream?token=xxx
                        
                        # 去除域名部分（如果存在），提取路径
                        if video_url_path.startswith("http://") or video_url_path.startswith("https://"):
                            # 提取路径部分（去掉 protocol://host:port）
                            try:
                                from urllib.parse import urlparse
                                parsed = urlparse(video_url_path)
                                # 路径+查询参数
                                video_url_path = parsed.path + ("?" + parsed.query if parsed.query else "")
                            except:
                                pass
                        
                        # 替换为 Service 层路径
                        service_path = ""
                        if "/api/video/stream" in video_url_path:
                            service_path = video_url_path.replace("/api/video/stream", "/pet/api/video/stream")
                        else:
                            # 兜底：直接使用原路径
                            service_path = video_url_path
                        
                        # 拼接完整的外部访问地址
                        full_video_url = f"{settings.external_base_url}{service_path}"
                    
                    # 从 pets_list 中找到 pet_name_display 对应的宠物信息
                    ai_status = ""
                    user_feedback = None
                    for pet_info in pets_list:
                        if pet_info.get("pet_name") == pet_name_display:
                            ai_status = pet_info.get("status", "")
                            user_feedback = pet_info.get("user_feedback")
                            break
                    
                    # 生成缩略图 URL：从 video_url 中提取 token 参数
                    thumbnail_url = ""
                    original_video_url = record.get("video_url", "")
                    if original_video_url:
                        try:
                            from urllib.parse import urlparse, parse_qs
                            # 提取 token 参数（无论是相对路径还是完整URL）
                            if "?" in original_video_url:
                                query_part = original_video_url.split("?", 1)[1]
                                params = parse_qs(query_part)
                                token = params.get("token", [None])[0]
                                if token:
                                    # 生成缩略图 URL
                                    thumbnail_url = f"{settings.external_base_url}/pet/api/video/thumbnail?token={token}"
                        except Exception as e:
                            logger.warning(f"解析缩略图 URL 失败: {e}")
                    
                    events.append({
                        "eventId": f"{date.replace('-', '')[-2:]}-{idx}",
                        "eventTime": event_time,
                        "petName": pet_name_display,
                        "videoId": record.get("id"),
                        "actions": record.get("actions", []) if isinstance(record.get("actions"), list) else [],
                        "eventDesc": event_desc,
                        "aiStatus": ai_status,
                        "userFeedback": user_feedback,
                        "videoUrl": full_video_url,
                        "videoTime": record.get("duration", 0),
                        "thumbnailColor": "#FEF3C7",
                        "thumbnailUrl": thumbnail_url
                    })
            else:
                logger.warning(f"视频接口返回非200状态: {video_resp.status}")
                response_text = await video_resp.text()
                logger.warning(f"视频接口响应内容: {response_text[:200]}")
        else:
            logger.error(f"视频接口请求异常: {responses[1]}")
        
        # logger.info(f"[DEBUG] 最终返回数据 - petReports数量: {len(pet_reports)}, events数量: {len(events)}")
        logger.info(f"获取日报数据成功: did={did}, date={date}, petId={petId}, petReports={len(pet_reports)}, events={len(events)}")
        
        result = {
            "date": date,
            "petReports": pet_reports,
            "events": events
        }
        # logger.info(f"[DEBUG] 返回结果: {result}")
        return Response.success(result)
            
    except Exception as e:
        logger.error(f"获取日报数据异常: {e}", exc_info=True)
        return Response.error("系统错误", ErrorCode.SYSTEM_ERROR)


# ==================== 行为反馈（点赞/点踩） ====================

@sub_app.post("/api/behavior/feedback")
async def submit_behavior_feedback(
    request: Request,
    video_id: int = Query(..., description="视频ID"),
    pet_name: str = Query(..., description="宠物名称"),
    action: str = Query(..., regex="^(like|dislike)$", description="反馈类型: like/dislike")
) -> Dict[str, Any]:
    """
    提交行为反馈（点赞/点踩）
    - 需要登录态
    - video_id: 视频ID
    - pet_name: 宠物名称
    - action: 'like' 或 'dislike'
    """
    user_info = get_current_user(request)
    did = user_info.get("did")
    
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", ErrorCode.PARAM_ERROR)
    
    try:
        logger.info(f"提交反馈: did={did}, video_id={video_id}, pet_name={pet_name}, action={action}")
        
        # 调用 Backend 内部 API
        params = {
            "video_id": video_id,
            "pet_name": pet_name,
            "did": did,
            "action": action
        }
        
        resp = await backend_client.post(
            path="/api/internal/behavior-feedback/",
            request=request,
            description="Backend提交反馈",
            params=params,
            timeout=5
        )
        if resp.status == 200:
            result = await resp.json()
            logger.info(f"反馈提交成功: {result}")
            return Response.success(result)
        elif resp.status == 404:
            logger.warning(f"行为记录不存在: video_id={video_id}, pet_name={pet_name}")
            return Response.error("该行为记录不存在", ErrorCode.NOT_FOUND)
        else:
            error_text = await resp.text()
            logger.error(f"Backend API 返回错误: {resp.status}, {error_text}")
            return Response.error("提交失败", ErrorCode.SYSTEM_ERROR)
    
    except Exception as e:
        logger.error(f"提交反馈异常: {e}", exc_info=True)
        return Response.error("系统错误", ErrorCode.SYSTEM_ERROR)


@sub_app.delete("/api/behavior/feedback")
async def cancel_behavior_feedback(
    request: Request,
    video_id: int = Query(..., description="视频ID"),
    pet_name: str = Query(..., description="宠物名称")
) -> Dict[str, Any]:
    """
    取消行为反馈（取消点赞/点踩）
    - 需要登录态
    - video_id: 视频ID
    - pet_name: 宠物名称
    """
    user_info = get_current_user(request)
    did = user_info.get("did")
    
    if not did:
        logger.error("用户信息中缺少 did 字段")
        return Response.error("用户信息异常", ErrorCode.PARAM_ERROR)
    
    try:
        logger.info(f"取消反馈: did={did}, video_id={video_id}, pet_name={pet_name}")
        
        # 调用 Backend 内部 API
        params = {
            "video_id": video_id,
            "pet_name": pet_name,
            "did": did
        }
        
        resp = await backend_client.delete(
            path="/api/internal/behavior-feedback/",
            request=request,
            description="Backend取消反馈",
            params=params,
            timeout=5
        )
        if resp.status == 200:
            result = await resp.json()
            logger.info(f"反馈取消成功: {result}")
            return Response.success(result)
        else:
            error_text = await resp.text()
            logger.error(f"Backend API 返回错误: {resp.status}, {error_text}")
            return Response.error("取消失败", ErrorCode.SYSTEM_ERROR)
    
    except Exception as e:
        logger.error(f"取消反馈异常: {e}", exc_info=True)
        return Response.error("系统错误", ErrorCode.SYSTEM_ERROR)


# ==================== 异常处理 ====================

@sub_app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """
    处理 HTTPException，直接返回 detail 内容
    避免 FastAPI 默认包装成 {"detail": {...}}
    """
    return JSONResponse(
        status_code=exc.status_code,
        content=exc.detail
    )


@sub_app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """全局异常处理"""
    logger.error(f"未处理的异常: {str(exc)}", exc_info=True)
    return JSONResponse(
        status_code=200,
        content=Response.error("服务内部错误", "50010")
    )


# ==================== 挂载子应用 ====================

# 将所有业务路由挂载到 /pet 路径下
app.mount("/pet", sub_app)

# ==================== 启动服务 ====================

def start_service():
    """启动 Service API 服务"""
    uvicorn.run(
        "service.app:app",
        host=settings.service_host,
        port=settings.service_port,
        reload=False,  # 生产环境关闭热重载
        log_level=settings.log_level.lower()
    )


if __name__ == "__main__":
    start_service()
