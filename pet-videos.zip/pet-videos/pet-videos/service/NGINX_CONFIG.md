# Service Nginx 转发配置说明

## 配置概述

Service API 所有接口路径统一以 `/pet` 开头，便于 Nginx 接入层统一转发。

## Nginx 配置示例

### 基础转发配置

```nginx
# Service API 转发
location /pet/ {
    # 转发到 Service 服务
    proxy_pass http://127.0.0.1:8006/pet/;
    
    # 保留原始请求头
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    
    # Cookie 透传（重要：用于登录态校验）
    proxy_set_header Cookie $http_cookie;
    
    # 超时设置
    proxy_connect_timeout 60s;
    proxy_send_timeout 60s;
    proxy_read_timeout 60s;
}
```

### 视频流优化配置

```nginx
# 视频流接口特殊优化
location /pet/api/video/stream {
    proxy_pass http://127.0.0.1:8006/pet/api/video/stream;
    
    # 基础请求头
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    
    # Range 请求支持（断点续传）
    proxy_set_header Range $http_range;
    proxy_set_header If-Range $http_if_range;
    
    # 禁用缓冲，实现流式传输
    proxy_buffering off;
    proxy_request_buffering off;
    
    # 增加超时时间（视频可能较大）
    proxy_connect_timeout 120s;
    proxy_send_timeout 300s;
    proxy_read_timeout 300s;
    
    # 增加 body 大小限制（如果支持上传）
    client_max_body_size 500M;
}
```

## 完整配置示例

```nginx
server {
    listen 80;
    server_name example.com;
    
    # Service API 统一转发
    location /pet/ {
        # 基础转发
        proxy_pass http://127.0.0.1:8006/pet/;
        
        # 请求头设置
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Cookie 透传（登录态校验必需）
        proxy_set_header Cookie $http_cookie;
        
        # 超时配置
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # 错误处理
        proxy_intercept_errors off;
    }
    
    # 视频流接口特殊处理（可选，如需优化）
    location /pet/api/video/stream {
        proxy_pass http://127.0.0.1:8006/pet/api/video/stream;
        
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Range $http_range;
        
        # 流式传输优化
        proxy_buffering off;
        proxy_request_buffering off;
        
        # 超时设置
        proxy_read_timeout 300s;
        
        # 大文件支持
        client_max_body_size 500M;
    }
}
```

## 路径映射说明

### 客户端请求 → Nginx → Service

| 客户端请求 | Nginx 转发 | Service 处理 |
|-----------|-----------|-------------|
| `GET /pet/health` | → `http://service:8006/pet/health` | `@sub_app.get("/health")` |
| `GET /pet/api/test` | → `http://service:8006/pet/api/test` | `@sub_app.get("/api/test")` |
| `POST /pet/api/camera/add` | → `http://service:8006/pet/api/camera/add` | `@sub_app.post("/api/camera/add")` |
| `GET /pet/api/video/stream` | → `http://service:8006/pet/api/video/stream` | `@sub_app.api_route("/api/video/stream")` |

### 关键说明

1. **路径前缀统一**: 所有 Service API 请求必须以 `/pet` 开头
2. **透传完整路径**: Nginx 转发时保留完整路径 `/pet/...`
3. **Cookie 透传**: 必须配置 `proxy_set_header Cookie $http_cookie`，否则登录态校验失败
4. **视频流优化**: 对 `/pet/api/video/stream` 可单独配置，禁用缓冲实现流式传输

## 接口分类

### 公开接口（无需登录）

- `GET /pet/health` - 健康检查
- `GET /pet/` - 根路径
- `GET /pet/api/video/stream` - 视频流播放

### 需要登录的接口（需要 Cookie）

- `GET /pet/api/test` - 测试接口
- `GET /pet/api/user/info` - 用户信息
- `POST /pet/api/camera/*` - 摄像头管理
- `GET /pet/api/videos/by-date` - 视频查询
- `GET /pet/api/pet/*` - 宠物管理
- `POST /pet/api/pet/*` - 宠物管理
- `GET /pet/api/daily-report` - 日报查询

## 测试验证

### 测试健康检查

```bash
curl http://example.com/pet/health
```

预期响应：
```json
{
  "ret": "0",
  "ret_msg": "ok",
  "service": "pet-videos-service",
  "status": "healthy",
  "version": "1.0.0"
}
```

### 测试登录态接口

```bash
curl http://example.com/pet/api/test \
  -H "Cookie: OPENBDUSS=xxx; STOKEN=xxx"
```

预期响应（已登录）：
```json
{
  "ret": "0",
  "ret_msg": "ok",
  "displayName": "张***三",
  "isLogin": true
}
```

预期响应（未登录）：
```json
{
  "ret": "50000",
  "ret_msg": "not_login"
}
```

### 测试视频流

```bash
curl -I "http://example.com/pet/api/video/stream?token=xxx"
```

预期响应头：
```
HTTP/1.1 200 OK
Content-Type: video/mp4
Content-Length: 10487592
Accept-Ranges: bytes
```

## 常见问题

### 1. 登录态校验失败

**现象**: 所有需要登录的接口都返回 `{"ret": "50000", "ret_msg": "not_login"}`

**原因**: Nginx 未透传 Cookie

**解决**: 添加配置 `proxy_set_header Cookie $http_cookie;`

### 2. 视频播放卡顿

**现象**: 视频流播放不流畅，进度条拖动失败

**原因**: Nginx 启用了缓冲，阻塞了流式传输

**解决**: 对视频流接口添加：
```nginx
proxy_buffering off;
proxy_request_buffering off;
```

### 3. 404 Not Found

**现象**: 所有 `/pet/*` 请求返回 404

**原因**: Nginx location 配置错误或 Service 未启动

**解决**:
1. 检查 Nginx 配置中 `location /pet/` 是否正确
2. 检查 `proxy_pass` 地址和端口
3. 验证 Service 是否在 8006 端口运行: `lsof -i :8006`

### 4. 超时错误

**现象**: 大文件上传或长视频播放时出现 504 Gateway Timeout

**原因**: Nginx 默认超时时间过短

**解决**: 增加超时配置：
```nginx
proxy_connect_timeout 120s;
proxy_send_timeout 300s;
proxy_read_timeout 300s;
```

## 安全建议

1. **生产环境使用 HTTPS**: 保护用户 Cookie 和登录态
2. **限制请求速率**: 使用 Nginx `limit_req` 模块防止滥用
3. **配置访问日志**: 便于问题排查和安全审计
4. **IP 白名单**: 对管理接口可考虑 IP 限制

## 配置检查清单

- [ ] Nginx 配置中添加 `location /pet/`
- [ ] `proxy_pass` 指向正确的 Service 地址 (127.0.0.1:8006)
- [ ] 配置 `proxy_set_header Cookie $http_cookie`
- [ ] 视频流接口禁用缓冲 (可选优化)
- [ ] 重载 Nginx 配置: `nginx -s reload`
- [ ] 测试健康检查接口: `curl http://domain/pet/health`
- [ ] 测试登录态接口（带 Cookie）
- [ ] 测试视频流播放
