# PetGuard App 后端接口设计文档

> 基于 petguard-demo 前端原型的后端接口设计

## 📋 目录

- [概述](#概述)
- [认证与授权](#认证与授权)
- [接口列表](#接口列表)
  - [1. 宠物管理](#1-宠物管理)
  - [2. 活动日志](#2-活动日志)
  - [3. 视频管理](#3-视频管理)
  - [4. 实时通知](#4-实时通知)
  - [5. 设备管理](#5-设备管理)
  - [6. 每日报告](#6-每日报告)
- [数据模型](#数据模型)
- [错误码定义](#错误码定义)

---

## 概述

### 技术栈
- **后端框架**: FastAPI
- **数据库**: SQLite / PostgreSQL
- **实时通知**: WebSocket / SSE (Server-Sent Events)
- **视频存储**: 本地存储 / OSS
- **AI 分析**: 集成现有的 video analysis 模块

### 基础信息
- **Base URL**: `https://api.petguard.com/api/v1`
- **认证方式**: JWT Bearer Token
- **请求格式**: JSON
- **响应格式**: JSON

---

## 认证与授权

### 认证流程
所有需要认证的接口在请求头中需要携带：
```
Authorization: Bearer <token>
```

### 获取 Token
复用现有的登录接口：
```
POST /api/auth/login
```

---

## 接口列表

## 1. 宠物管理

### 1.1 获取宠物列表

**接口**: `GET /pets`

**描述**: 获取当前用户的所有宠物信息

**请求参数**: 无

**响应示例**:
```json
{
  "code": 0,
  "message": "success",
  "data": [
    {
      "id": 1,
      "name": "栗子",
      "type": "狸花猫",
      "weight": "4.2kg",
      "features": "短毛，全身覆盖黑灰相间的经典斑纹，腹部毛色较浅，四肢有环状纹路。",
      "avatar_color": "bg-gray-200 text-gray-700",
      "created_at": "2025-01-15T10:00:00Z",
      "updated_at": "2025-11-20T15:30:00Z"
    },
    {
      "id": 2,
      "name": "奶油",
      "type": "金渐层长毛",
      "weight": "5.5kg",
      "features": "长毛，背部呈现金渐层色，面部圆润，耳尖有少量聪明毛，尾巴蓬松。",
      "avatar_color": "bg-yellow-100 text-yellow-700",
      "created_at": "2025-01-15T10:00:00Z",
      "updated_at": "2025-11-20T15:30:00Z"
    }
  ]
}
```

---

### 1.2 获取宠物详情

**接口**: `GET /pets/{pet_id}`

**描述**: 获取指定宠物的详细信息

**路径参数**:
- `pet_id` (integer, required): 宠物 ID

**响应示例**:
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": 1,
    "name": "栗子",
    "type": "狸花猫",
    "weight": "4.2kg",
    "features": "短毛，全身覆盖黑灰相间的经典斑纹",
    "avatar_color": "bg-gray-200 text-gray-700",
    "created_at": "2025-01-15T10:00:00Z",
    "updated_at": "2025-11-20T15:30:00Z"
  }
}
```

---

### 1.3 创建宠物

**接口**: `POST /pets`

**描述**: 添加新的宠物档案

**请求体**:
```json
{
  "name": "小花",
  "type": "橘猫",
  "weight": "5.0kg",
  "features": "短毛，全身橘色，性格活泼",
  "avatar_color": "bg-orange-100 text-orange-700"
}
```

**响应示例**:
```json
{
  "code": 0,
  "message": "创建成功",
  "data": {
    "id": 3,
    "name": "小花",
    "type": "橘猫",
    "weight": "5.0kg",
    "features": "短毛，全身橘色，性格活泼",
    "avatar_color": "bg-orange-100 text-orange-700",
    "created_at": "2025-11-24T10:00:00Z",
    "updated_at": "2025-11-24T10:00:00Z"
  }
}
```

---

### 1.4 更新宠物信息

**接口**: `PUT /pets/{pet_id}`

**描述**: 更新宠物档案信息

**路径参数**:
- `pet_id` (integer, required): 宠物 ID

**请求体**:
```json
{
  "name": "栗子",
  "type": "狸花猫",
  "weight": "4.5kg",
  "features": "短毛，全身覆盖黑灰相间的经典斑纹，腹部毛色较浅"
}
```

**响应示例**:
```json
{
  "code": 0,
  "message": "更新成功",
  "data": {
    "id": 1,
    "name": "栗子",
    "type": "狸花猫",
    "weight": "4.5kg",
    "features": "短毛，全身覆盖黑灰相间的经典斑纹，腹部毛色较浅",
    "avatar_color": "bg-gray-200 text-gray-700",
    "created_at": "2025-01-15T10:00:00Z",
    "updated_at": "2025-11-24T16:30:00Z"
  }
}
```

---

### 1.5 删除宠物

**接口**: `DELETE /pets/{pet_id}`

**描述**: 删除宠物档案

**路径参数**:
- `pet_id` (integer, required): 宠物 ID

**响应示例**:
```json
{
  "code": 0,
  "message": "删除成功"
}
```

---

## 2. 活动日志

### 2.1 获取活动日志列表

**接口**: `GET /activity-logs`

**描述**: 获取指定日期的宠物活动日志

**查询参数**:
- `date` (string, required): 日期，格式 `YYYY-MM-DD`
- `pet_id` (integer, optional): 宠物 ID，不传则返回所有宠物
- `page` (integer, optional): 页码，默认 1
- `page_size` (integer, optional): 每页数量，默认 20

**响应示例**:
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "total": 15,
    "page": 1,
    "page_size": 20,
    "logs": [
      {
        "id": "log-001",
        "time": "23:09",
        "pet_name": "双猫",
        "pet_id": null,
        "actions": ["多猫互动"],
        "description": "【实时】检测到深夜跑酷追逐，双方在客厅快速移动。",
        "status": "AI 判定：高能玩耍",
        "video_time": 14.5,
        "video_src": "/videos/event_20251124_230900.mp4",
        "thumbnail": "/thumbnails/event_20251124_230900.jpg",
        "thumbnail_color": "bg-gray-800 text-white",
        "alert_level": "warning",
        "created_at": "2025-11-24T23:09:15Z"
      },
      {
        "id": "log-002",
        "time": "09:40",
        "pet_name": "奶油",
        "pet_id": 2,
        "actions": ["饮食饮水"],
        "description": "在饮水区停留，喝水约 30 秒。",
        "status": "正常",
        "video_time": 320.0,
        "video_src": "/videos/event_20251124_094000.mp4",
        "thumbnail": "/thumbnails/event_20251124_094000.jpg",
        "thumbnail_color": "bg-blue-50 text-blue-600",
        "alert_level": "normal",
        "created_at": "2025-11-24T09:40:30Z"
      }
    ]
  }
}
```

---

### 2.2 获取单条活动日志详情

**接口**: `GET /activity-logs/{log_id}`

**描述**: 获取活动日志的详细信息

**路径参数**:
- `log_id` (string, required): 日志 ID

**响应示例**:
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": "log-001",
    "time": "23:09",
    "pet_name": "双猫",
    "pet_id": null,
    "actions": ["多猫互动"],
    "description": "【实时】检测到深夜跑酷追逐，双方在客厅快速移动。",
    "status": "AI 判定：高能玩耍",
    "video_time": 14.5,
    "video_src": "/videos/event_20251124_230900.mp4",
    "full_video_analysis": "通过运动检测算法，识别到两只猫同时在画面中高速移动...",
    "ai_confidence": 0.92,
    "alert_level": "warning",
    "created_at": "2025-11-24T23:09:15Z"
  }
}
```

---

### 2.3 获取日期列表（有日志的日期）

**接口**: `GET /activity-logs/dates`

**描述**: 获取有活动日志的日期列表（用于日历渲染）

**查询参数**:
- `start_date` (string, optional): 开始日期，格式 `YYYY-MM-DD`，默认 30 天前
- `end_date` (string, optional): 结束日期，格式 `YYYY-MM-DD`，默认今天

**响应示例**:
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "dates": [
      {
        "date": "2025-11-24",
        "day": "24",
        "week": "日",
        "is_today": true,
        "log_count": 15,
        "has_alert": true
      },
      {
        "date": "2025-11-23",
        "day": "23",
        "week": "六",
        "is_today": false,
        "log_count": 12,
        "has_alert": false
      }
    ]
  }
}
```

---

## 3. 视频管理

### 3.1 获取视频播放地址

**接口**: `GET /videos/stream`

**描述**: 获取视频流地址（复用现有接口）

**查询参数**:
- `video_path` (string, required): 视频文件路径
- `start_time` (float, optional): 起始时间（秒）

**响应**: 视频流（支持 Range 请求）

---

### 3.2 获取视频缩略图

**接口**: `GET /videos/thumbnail`

**描述**: 获取视频指定时间点的缩略图

**查询参数**:
- `video_path` (string, required): 视频文件路径
- `time` (float, optional): 时间点（秒），默认 0

**响应**: 图片文件（JPEG）

---

## 4. 实时通知

### 4.1 WebSocket 连接（推荐）

**接口**: `WS /ws/notifications`

**描述**: 建立 WebSocket 连接，接收实时通知

**连接参数**:
- `token` (string, required): JWT Token

**消息格式**:
```json
{
  "type": "alert",
  "data": {
    "id": "alert-001",
    "title": "检测到多猫互动",
    "text": "【实时】检测到深夜跑酷追逐，双方在客厅快速移动。",
    "video_time": 14.5,
    "video_src": "/videos/event_20251124_230900.mp4",
    "pet_names": ["栗子", "奶油"],
    "actions": ["多猫互动"],
    "alert_level": "warning",
    "timestamp": "2025-11-24T23:09:15Z"
  }
}
```

**心跳消息**:
```json
{
  "type": "ping",
  "timestamp": "2025-11-24T23:10:00Z"
}
```

客户端应回复：
```json
{
  "type": "pong",
  "timestamp": "2025-11-24T23:10:00Z"
}
```

---

### 4.2 SSE 推送（备选方案）

**接口**: `GET /sse/notifications`

**描述**: 建立 SSE 连接，接收实时通知

**查询参数**:
- `token` (string, required): JWT Token

**事件格式**:
```
event: alert
data: {"id":"alert-001","title":"检测到多猫互动","text":"【实时】检测到深夜跑酷追逐","video_time":14.5,"timestamp":"2025-11-24T23:09:15Z"}

event: heartbeat
data: {"timestamp":"2025-11-24T23:10:00Z"}
```

---

### 4.3 获取未读通知列表

**接口**: `GET /notifications`

**描述**: 获取未读通知列表

**查询参数**:
- `page` (integer, optional): 页码，默认 1
- `page_size` (integer, optional): 每页数量，默认 20

**响应示例**:
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "total": 5,
    "unread_count": 3,
    "notifications": [
      {
        "id": "notif-001",
        "title": "检测到多猫互动",
        "text": "【实时】检测到深夜跑酷追逐",
        "video_time": 14.5,
        "video_src": "/videos/event_20251124_230900.mp4",
        "alert_level": "warning",
        "is_read": false,
        "created_at": "2025-11-24T23:09:15Z"
      }
    ]
  }
}
```

---

### 4.4 标记通知为已读

**接口**: `PUT /notifications/{notification_id}/read`

**描述**: 标记通知为已读

**路径参数**:
- `notification_id` (string, required): 通知 ID

**响应示例**:
```json
{
  "code": 0,
  "message": "已标记为已读"
}
```

---

## 5. 设备管理

### 5.1 获取设备状态

**接口**: `GET /devices/status`

**描述**: 获取监控设备的连接状态

**响应示例**:
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "online": true,
    "last_seen": "2025-11-24T23:10:00Z",
    "camera_status": "recording",
    "storage_used": "45.2GB",
    "storage_total": "128GB",
    "ai_enabled": true
  }
}
```

---

### 5.2 获取通知设置

**接口**: `GET /settings/notifications`

**描述**: 获取智能通知设置

**响应示例**:
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "enabled": true,
    "alert_types": ["多猫互动", "呕吐", "异常活动"],
    "quiet_hours": {
      "enabled": false,
      "start": "22:00",
      "end": "08:00"
    }
  }
}
```

---

### 5.3 更新通知设置

**接口**: `PUT /settings/notifications`

**描述**: 更新智能通知设置

**请求体**:
```json
{
  "enabled": true,
  "alert_types": ["多猫互动", "呕吐", "异常活动"],
  "quiet_hours": {
    "enabled": true,
    "start": "23:00",
    "end": "07:00"
  }
}
```

**响应示例**:
```json
{
  "code": 0,
  "message": "设置已更新",
  "data": {
    "enabled": true,
    "alert_types": ["多猫互动", "呕吐", "异常活动"],
    "quiet_hours": {
      "enabled": true,
      "start": "23:00",
      "end": "07:00"
    }
  }
}
```

---

## 6. 每日报告

### 6.1 获取宠物每日报告

**接口**: `GET /pets/{pet_id}/daily-report`

**描述**: 获取指定宠物的每日报告

**路径参数**:
- `pet_id` (integer, required): 宠物 ID

**查询参数**:
- `date` (string, required): 日期，格式 `YYYY-MM-DD`

**响应示例**:
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "pet_id": 1,
    "pet_name": "栗子",
    "date": "2025-11-24",
    "summary": "**【栗子日报】**\n今日标签：**精力过剩**。\n06:30 进行了高强度的**活动**（跑酷）。全天**饮食饮水**正常。注意：23:09 检测到**多猫互动**（追逐）。",
    "tags": ["精力过剩"],
    "activities": {
      "rest": 8.5,
      "activity": 2.3,
      "eating": 0.5,
      "interaction": 0.2
    },
    "alerts_count": 1,
    "total_time_tracked": 11.5
  }
}
```

---

### 6.2 获取所有宠物每日报告

**接口**: `GET /daily-reports`

**描述**: 获取所有宠物的每日报告

**查询参数**:
- `date` (string, required): 日期，格式 `YYYY-MM-DD`

**响应示例**:
```json
{
  "code": 0,
  "message": "success",
  "data": [
    {
      "pet_id": 1,
      "pet_name": "栗子",
      "date": "2025-11-24",
      "summary": "**【栗子日报】**\n今日标签：**精力过剩**。",
      "tags": ["精力过剩"],
      "activities": {
        "rest": 8.5,
        "activity": 2.3,
        "eating": 0.5,
        "interaction": 0.2
      },
      "alerts_count": 1
    },
    {
      "pet_id": 2,
      "pet_name": "奶油",
      "date": "2025-11-24",
      "summary": "**【奶油日报】**\n今日标签：**岁月静好**。",
      "tags": ["岁月静好"],
      "activities": {
        "rest": 10.2,
        "activity": 0.5,
        "eating": 0.4,
        "interaction": 0.1
      },
      "alerts_count": 0
    }
  ]
}
```

---

## 数据模型

### Pet（宠物）
```python
class Pet(Base):
    __tablename__ = "pets"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(50), nullable=False)
    type = Column(String(50), nullable=False)  # 品种
    weight = Column(String(20), nullable=True)
    features = Column(Text, nullable=True)  # 外观特征描述
    avatar_color = Column(String(100), default="bg-gray-200 text-gray-700")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

### ActivityLog（活动日志）
```python
class ActivityLog(Base):
    __tablename__ = "activity_logs"
    
    id = Column(String(50), primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    pet_id = Column(Integer, ForeignKey("pets.id"), nullable=True)  # null 表示多猫
    pet_name = Column(String(50), nullable=False)  # 用于显示，如"双猫"
    date = Column(Date, nullable=False, index=True)
    time = Column(String(10), nullable=False)  # HH:MM 格式
    actions = Column(JSON, nullable=False)  # ["多猫互动", "活动"]
    description = Column(Text, nullable=False)
    status = Column(String(200), nullable=False)
    video_time = Column(Float, nullable=False)
    video_src = Column(String(500), nullable=True)
    thumbnail = Column(String(500), nullable=True)
    thumbnail_color = Column(String(100), default="bg-gray-800 text-white")
    alert_level = Column(String(20), default="normal")  # normal, warning, critical
    ai_confidence = Column(Float, nullable=True)
    full_analysis = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
```

### Notification（通知）
```python
class Notification(Base):
    __tablename__ = "notifications"
    
    id = Column(String(50), primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    log_id = Column(String(50), ForeignKey("activity_logs.id"), nullable=True)
    title = Column(String(200), nullable=False)
    text = Column(Text, nullable=False)
    video_time = Column(Float, nullable=True)
    video_src = Column(String(500), nullable=True)
    alert_level = Column(String(20), default="normal")
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
```

### DeviceStatus（设备状态）
```python
class DeviceStatus(Base):
    __tablename__ = "device_status"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    online = Column(Boolean, default=False)
    last_seen = Column(DateTime, nullable=True)
    camera_status = Column(String(50), default="idle")  # idle, recording, error
    storage_used_bytes = Column(BigInteger, default=0)
    storage_total_bytes = Column(BigInteger, default=0)
    ai_enabled = Column(Boolean, default=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

### NotificationSettings（通知设置）
```python
class NotificationSettings(Base):
    __tablename__ = "notification_settings"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    enabled = Column(Boolean, default=True)
    alert_types = Column(JSON, default=list)  # ["多猫互动", "呕吐"]
    quiet_hours_enabled = Column(Boolean, default=False)
    quiet_hours_start = Column(String(5), nullable=True)  # "22:00"
    quiet_hours_end = Column(String(5), nullable=True)  # "08:00"
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

### DailyReport（每日报告）
```python
class DailyReport(Base):
    __tablename__ = "daily_reports"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    pet_id = Column(Integer, ForeignKey("pets.id"), nullable=False)
    date = Column(Date, nullable=False, index=True)
    summary = Column(Text, nullable=False)
    tags = Column(JSON, default=list)  # ["精力过剩", "岁月静好"]
    activity_rest_hours = Column(Float, default=0)
    activity_activity_hours = Column(Float, default=0)
    activity_eating_hours = Column(Float, default=0)
    activity_interaction_hours = Column(Float, default=0)
    alerts_count = Column(Integer, default=0)
    total_time_tracked = Column(Float, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        UniqueConstraint('user_id', 'pet_id', 'date', name='uix_user_pet_date'),
    )
```

---

## 错误码定义

| 错误码 | 说明 |
|--------|------|
| 0 | 成功 |
| 1000 | 未知错误 |
| 1001 | 参数错误 |
| 1002 | 未授权 |
| 1003 | 禁止访问 |
| 1004 | 资源不存在 |
| 2001 | 宠物不存在 |
| 2002 | 宠物名称重复 |
| 3001 | 日志不存在 |
| 4001 | 视频文件不存在 |
| 4002 | 视频处理失败 |
| 5001 | 设备离线 |
| 5002 | 设备连接失败 |

---

## 实现优先级

### Phase 1 - MVP（最小可行产品）
1. ✅ 宠物管理（1.1, 1.2, 1.4）
2. ✅ 活动日志（2.1, 2.3）
3. ✅ 视频播放（3.1）
4. ✅ 每日报告（6.2）

### Phase 2 - 实时功能
1. ⏳ WebSocket 通知（4.1）
2. ⏳ 通知列表（4.3, 4.4）
3. ⏳ 设备状态（5.1）

### Phase 3 - 完善功能
1. ⏳ 视频缩略图（3.2）
2. ⏳ 通知设置（5.2, 5.3）
3. ⏳ 宠物创建删除（1.3, 1.5）
4. ⏳ 日志详情（2.2）
5. ⏳ 单个宠物日报（6.1）

---

## 与现有系统集成

### 复用现有模块
1. **认证模块**: 复用 `backend/utils/security.py`
2. **视频服务**: 复用 `backend/services/video_service.py`
3. **数据库**: 扩展 `backend/models/database.py`
4. **API 路由**: 在 `backend/api/` 下新增 `pets.py`, `activity_logs.py`, `notifications.py`

### 需要新增的模块
1. **WebSocket 管理器**: `backend/services/websocket_manager.py`
2. **通知服务**: `backend/services/notification_service.py`
3. **日报生成器**: `backend/services/daily_report_generator.py`
4. **宠物识别服务**: `backend/services/pet_recognition_service.py`（基于 YOLO）

### AI 分析集成
利用现有的监控脚本 (`scripts/pet_monitor_pyav.py`)，扩展功能：
- 识别宠物个体（基于外观特征）
- 行为分类（休息、活动、饮食、互动、异常）
- 生成活动日志和通知
- 自动生成每日报告

---

## 附录

### 相关文件
- 前端原型: `/Users/dxm/code/ai/petguard-demo/`
- 后端项目: `/Users/dxm/code/dxm/fsg-fbfe/pet-videos/`
- 监控脚本: `/Users/dxm/code/dxm/fsg-fbfe/pet-videos/scripts/pet_monitor_pyav.py`

### 参考文档
- 现有 API 文档: http://localhost:8002/docs
- 视频分析服务: `backend/services/video_service.py`
- 任务管理: `backend/api/tasks.py`

---

**文档版本**: v1.0  
**创建日期**: 2026-01-29  
**最后更新**: 2026-01-29  
**维护者**: Backend Team
