"""
统一的 API 响应格式
定义标准的错误码和响应结构
"""

from typing import Dict, Any, Union


class Response:
    """统一的 API 响应格式"""
    
    @staticmethod
    def success(data: Any = None, ret_msg: str = "success") -> Dict[str, Any]:
        """
        成功响应
        
        Args:
            data: 响应数据（会被包裹在 data 字段中）
            ret_msg: 响应消息，默认 "success"
        
        Returns:
            {"ret": 0, "ret_msg": "success", "data": {...}}
        """
        return {
            "ret": 0,
            "ret_msg": ret_msg,
            "data": data if data is not None else {}
        }
    
    @staticmethod
    def not_login() -> Dict[str, Any]:
        """
        未登录响应
        
        Returns:
            {"ret": "50000", "ret_msg": "not_login", "data": null}
        """
        return {
            "ret": ErrorCode.NOT_LOGIN,
            "ret_msg": "not_login",
            "data": None
        }
    
    @staticmethod
    def error(message: str, code: Union[str, int] = None) -> Dict[str, Any]:
        """
        错误响应
        
        Args:
            message: 错误描述
            code: 错误码（字符串或数字），默认 "50010"
        
        Returns:
            {"ret": "50010", "ret_msg": "错误描述", "data": null}
        """
        return {
            "ret": code if code is not None else ErrorCode.SYSTEM_ERROR,
            "ret_msg": message,
            "data": None
        }


# 统一错误码定义（字符串类型，恢复为 App 改造前的格式）
class ErrorCode:
    """API 错误码（字符串类型）"""
    SUCCESS = 0             # 成功
    NOT_LOGIN = "50000"     # 未登录
    SYSTEM_ERROR = "50010"  # 系统错误
    PARAM_ERROR = "50011"   # 参数错误
    NO_PERMISSION = "50012" # 权限错误
    NOT_FOUND = "50013"     # 资源不存在
    ALREADY_EXISTS = "50011"  # 资源已存在（归类为参数错误）
    NETWORK_ERROR = "50010"   # 网络错误（归类为系统错误）
