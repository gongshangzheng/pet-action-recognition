# Pet-Videos Service API

独立的服务接口模块，支持登录态校验。

## 功能特性

- ✅ 基于 FastAPI 的异步 API 服务
- ✅ 通过 BNS 服务进行登录态校验
- ✅ 从 Cookie 中获取 `OPENBDUSS` 和 `STOKEN`
- ✅ 支持配置哪些接口需要校验登录态
- ✅ 统一的响应格式

## 目录结构

```
service/
├── __init__.py           # 模块初始化
├── app.py                # FastAPI 应用主文件
├── auth.py               # 登录态校验模块
├── config.py             # 配置文件
├── bns_client.py         # BNS 同步客户端
├── bns_client_async.py   # BNS 异步客户端
└── README.md             # 本文档
```

## 快速开始

### 1. 安装依赖

```bash
pip install fastapi uvicorn aiohttp noah_python_sdk
```

### 2. 启动服务

#### Linux/macOS

```bash
# 使用启动脚本（推荐）
./start_service.sh

# 或直接运行
python -m service.app

# 或使用 uvicorn
uvicorn service.app:app --host 0.0.0.0 --port 8006 --reload
```

#### Windows

**方法 1: 使用批处理脚本（推荐）**
```cmd
start_service.bat
```

**方法 2: 使用 PowerShell 脚本**
```powershell
.\start_service.ps1
```

**方法 3: 手动启动**
```cmd
# 设置环境变量（必需，否则日志会有错误）
set _NOAHEE_INSTANCEID=5.android-container.licai-licai

# 启动服务
python -m service.app
```

> ⚠️ **Windows 服务器注意事项**  
> 必须设置环境变量 `_NOAHEE_INSTANCEID=5.android-container.licai-licai`，否则日志中会出现错误。  
> 启动脚本已自动设置该变量，手动启动时请务必设置。

### 3. 访问接口

- **健康检查**: http://localhost:8006/pet/health
- **测试接口**: http://localhost:8006/pet/api/test
- **视频流**: http://localhost:8006/pet/api/video/stream

> 📌 **注意**: 所有接口路径已添加 `/pet` 前缀

## 接口说明

### 公开接口（不需要登录）

#### GET /health
健康检查接口

**响应示例**:
```json
{
  "ret": "0",
  "ret_msg": "ok",
  "service": "pet-videos-service",
  "status": "healthy",
  "version": "1.0.0"
}
```

### 需要登录的接口

#### GET /api/test
测试接口，需要登录态校验

**请求头**:
- Cookie: `OPENBDUSS=xxx; STOKEN=xxx`

**成功响应** (HTTP 200):
```json
{
  "ret": "0",
  "ret_msg": "ok",
  "displayName": "张*",
  "isLogin": true
}
```

**未登录响应** (HTTP 200):
```json
{
  "ret": "50000",
  "ret_msg": "not_login"
}
```

> 📝 **注意**: 所有响应都返回 HTTP 200，通过 `ret` 字段区分状态。  
> `displayName` 会进行打码处理（如：张三 -> 张*）

#### GET /api/user/info
获取当前登录用户信息

**请求头**:
- Cookie: `OPENBDUSS=xxx; STOKEN=xxx`

**响应格式**: 同上

---

### 摄像头管理接口

#### POST /api/camera/add
添加摄像头（需要登录）

**请求体**:
```json
{
  "stream_identifier": "chc4ng9",
  "name": "我的客厅摄像头"
}
```

**说明**:
- `stream_identifier`: 流标识，只能包含字母、数字、下划线、连字符，长度 1-50
- `name`: 摄像头名称，用户自定义，长度 1-100
- 自动生成完整 RTSP URL: `{RTSP_BASE_URL}/{stream_identifier}`
- 自动生成存储路径: `{STORAGE_BASE_PATH}/{stream_identifier}`
- 自动生成别名: `{did}_{stream_identifier}`

**响应示例**:
```json
{
  "ret": "0",
  "ret_msg": "ok",
  "id": 123,
  "name": "我的客厅摄像头",
  "is_active": true
}
```

#### GET /api/camera/list
查询摄像头列表（需要登录，只返回当前用户的摄像头）

**响应示例**:
```json
{
  "ret": "0",
  "ret_msg": "ok",
  "cameras": [
    {
      "id": 123,
      "name": "我的客厅摄像头",
      "is_active": true
    },
    {
      "id": 124,
      "name": "后院摄像头",
      "is_active": false
    }
  ],
  "total": 2
}
```

#### POST /api/camera/update/{source_id}
更新摄像头（需要登录，只能操作自己的摄像头）

**请求体**:
```json
{
  "name": "我的客厅摄像头",
  "is_active": true
}
```

**说明**: 只能更新 `name` 和 `is_active` 字段

#### POST /api/camera/delete/{source_id}
删除摄像头（需要登录，只能删除自己的摄像头）

**约束**: 如果摄像头有关联任务，不允许删除

---

### 视频查询接口

#### GET/HEAD /api/video/stream
视频流播放接口（**公开接口，暂不校验登录态**）

直接代理到 Backend 的 `/video/stream` 接口，支持 Range 请求和 HEAD 请求。

**查询参数**:
- `token` (必填): 视频文件 token（从 `/api/videos/by-date` 接口获取）

**特性**:
- ⚠️ **暂不校验登录态**（公开接口）
- ✅ 支持 HTTP Range 请求（断点续传）
- ✅ 支持 HEAD 请求（获取视频大小）
- ✅ 流式传输，不占用内存

**使用场景**:
```bash
# 播放视频（从 /api/videos/by-date 响应中获取 stream_token）
GET /api/video/stream?token=xxx

# 获取视频信息（HEAD 请求）
HEAD /api/video/stream?token=xxx

# Range 请求示例（浏览器自动处理）
GET /api/video/stream?token=xxx
Range: bytes=0-1023
```

**HTML 使用示例**:
```html
<video controls>
  <source src="/api/video/stream?token=xxx" type="video/mp4">
</video>
```

**错误响应**:
- `403`: Token 无效或已过期
- `404`: 视频不存在
- `500`: 视频服务异常

---

#### GET /api/videos/by-date
按日期查询视频切片（需要登录，支持按摄像头和宠物过滤）

**查询参数**:
- `date` (必填): 日期，格式 YYYY-MM-DD
- `source_id` (可选): 摄像头ID，不传则查询所有摄像头
- `pet_name` (可选): 宠物名称，过滤包含该宠物的视频
- `page` (可选): 页码，默认 1
- `page_size` (可选): 每页数量，0-1000，默认 20
  - `0`: 查询当日所有切片（最多返回 1000 条）
  - `1-1000`: 正常分页

**使用场景**:
```bash
# 查询某日所有摄像头的视频
GET /api/videos/by-date?date=2026-01-23

# 查询某日某摄像头的视频
GET /api/videos/by-date?date=2026-01-23&source_id=123

# 查询某日包含"毛毛"的所有视频
GET /api/videos/by-date?date=2026-01-23&pet_name=毛毛

# 查询某日某摄像头中包含"毛毛"的视频
GET /api/videos/by-date?date=2026-01-23&source_id=123&pet_name=毛毛
```

**响应示例（分页）**:
```json
{
  "ret": "0",
  "ret_msg": "ok",
  "videos": [
    {
      "id": 1001,
      "filename": "20260130_120530_pet.mp4",
      "source_id": 123,
      "file_size": 5242880,
      "size_mb": 5.0,
      "duration": 10.5,
      "detection_type": "pet",
      "llm_status": "completed",
      "recorded_at": "2026-01-30T12:05:30",
      "pets": [
        {
          "name": "毛毛",
          "actions": ["玩耍", "跳跃"],
          "description": "在客厅里追逐玩具球，活跃度高",
          "status": "活跃",
          "location": "客厅",
          "score": 8
        },
        {
          "name": "球球",
          "actions": ["休息"],
          "description": "趴在沙发上休息",
          "status": "正常",
          "location": "沙发",
          "score": 3
        }
      ]
    }
  ],
  "total": 156,
  "page": 1,
  "page_size": 20,
  "is_all": false
}
```

**注意**: 
- `pets` 字段包含该视频中所有识别到的宠物及其 LLM 分析结果
- 如果指定了 `pet_name` 参数，只返回包含该宠物的视频

**响应示例（page_size=0）**:
```json
{
  "ret": "0",
  "ret_msg": "ok",
  "videos": [ ...1000条记录... ],
  "total": 1523,
  "page": 1,
  "page_size": 1000,
  "is_all": true,
  "warning": "当日共 1523 条记录，已返回前 1000 条",
  "source_info": { ... }
}
```

---

### 宠物管理接口

#### GET /api/pet/list
获取宠物列表（需要登录，只返回当前用户的宠物）

**响应示例**:
```json
{
  "ret": "0",
  "ret_msg": "ok",
  "pets": [
    {
      "did": "12345",
      "pet_name": "大黄",
      "pet_type": "狗",
      "breed": "金毛",
      "gender": "公",
      "birth_date": "2020-05-15",
      "color": "金黄色",
      "avatar_url": "https://...",
      "description": "活泼好动",
      "created_at": "2026-01-30T10:00:00",
      "updated_at": "2026-01-30T10:00:00"
    }
  ],
  "total": 1
}
```

#### GET /api/pet/{pet_name}
获取宠物详情（需要登录，只能查看自己的宠物）

**响应格式**: 同上，返回单个宠物对象

#### POST /api/pet/add
添加宠物（需要登录）

**请求体**:
```json
{
  "pet_name": "小白",
  "pet_type": "猫",
  "breed": "英短",
  "gender": "母",
  "birth_date": "2021-03-10",
  "color": "白色",
  "avatar_url": "https://...",
  "description": "安静乖巧"
}
```

**说明**:
- `pet_name` 必填，其他字段可选
- `birth_date` 格式: YYYY-MM-DD
- 同一用户不能添加同名宠物

#### POST /api/pet/update/{pet_name}
更新宠物（需要登录，只能更新自己的宠物）

**请求体**: 同添加，所有字段可选

**说明**: 宠物名称不可修改

#### POST /api/pet/delete/{pet_name}
删除宠物（需要登录，只能删除自己的宠物）

**响应示例**:
```json
{
  "ret": "0",
  "ret_msg": "ok",
  "message": "Pet deleted successfully"
}
```

---

### 日报管理接口

> **📌 说明**：日报由后端系统按策略自动生成（例如定时任务、视频分析完成后触发等），用户**只能查看**，不能手动触发生成、编辑或删除。

#### GET /api/daily-report
获取日报列表（需要登录，只能查询自己的日报）

**查询参数**：
- `date`（可选）：日期，格式 `YYYY-MM-DD`
- `pet_name`（可选）：宠物名称

**响应示例**：
```json
{
  "errno": 0,
  "errmsg": "success",
  "data": {
    "reports": [
      {
        "did": "user123",
        "date": "2026-01-23",
        "pet_name": "毛毛",
        "summary": "今天毛毛表现活跃，大部分时间在客厅玩耍...",
        "analysis_data": "{...}",
        "video_count": 15,
        "total_duration": 3600.0,
        "created_at": "2026-01-23T10:00:00",
        "updated_at": "2026-01-23T20:30:00"
      }
    ],
    "total": 1
  }
}
```

#### GET /api/daily-report/{date}/{pet_name}
获取指定日报（需要登录）

**路径参数**：
- `date`：日期，格式 `YYYY-MM-DD`
- `pet_name`：宠物名称

**响应示例**：
```json
{
  "errno": 0,
  "errmsg": "success",
  "data": {
    "did": "user123",
    "date": "2026-01-23",
    "pet_name": "毛毛",
    "summary": "今天毛毛表现活跃...",
    "analysis_data": "{...}",
    "video_count": 15,
    "total_duration": 3600.0,
    "created_at": "2026-01-23T10:00:00",
    "updated_at": "2026-01-23T20:30:00"
  }
}
```

**日报生成策略**：
- 后端定时任务每天自动生成前一天的日报
- 视频分析完成后自动触发更新当日日报
- 系统内部调用 Backend API 生成日报，用户无需手动触发

---

## 配置说明

### 配置文件

直接修改 `service/config.py` 文件即可：

```python
# service/config.py
class ServiceConfig:
    # 服务监听地址
    SERVICE_HOST = "0.0.0.0"
    
    # 服务端口
    SERVICE_PORT = 8006
    
    # 日志级别
    LOG_LEVEL = "INFO"
    
    # 公开路径（不需要登录）
    PUBLIC_PATHS = "/health"
```

**简单直接，无需额外的配置文件！**

### 添加/移除公开路径

在代码中动态配置：

```python
from service.auth import get_auth

auth = get_auth()

# 添加公开路径
auth.add_public_path("/api/public")

# 移除公开路径
auth.remove_public_path("/api/public")
```

## 开发新接口

### 方式 1: 使用依赖注入（推荐）

```python
from fastapi import Depends
from service.auth import require_login, AuthResponse

@app.get("/api/your-endpoint")
async def your_endpoint(user_info: Dict = Depends(require_login)):
    """需要登录的接口"""
    # user_info 已经包含了用户信息
    return AuthResponse.success({
        "message": "处理成功",
        "user": user_info
    })
```

### 方式 2: 手动校验

```python
from service.auth import get_auth

@app.get("/api/your-endpoint")
async def your_endpoint(request: Request):
    """手动校验登录态"""
    auth = get_auth()
    user_info = await auth.verify_session(request, raise_exception=True)
    
    # 处理业务逻辑
    return AuthResponse.success({"user": user_info})
```

### 方式 3: 可选登录

```python
from service.auth import optional_login

@app.get("/api/optional")
async def optional_endpoint(user_info: Optional[Dict] = Depends(optional_login)):
    """可选登录的接口"""
    if user_info:
        return {"message": "已登录", "user": user_info}
    else:
        return {"message": "访客模式"}
```

## 响应格式规范

**所有响应统一返回 HTTP 200，通过 `ret` 字段区分状态**

### 成功响应 (HTTP 200)
```json
{
  "ret": "0",
  "ret_msg": "ok",
  // 其他业务字段...
}
```

### 未登录响应 (HTTP 200)
```json
{
  "ret": "50000",
  "ret_msg": "not_login"
}
```

### 业务错误响应 (HTTP 200)
```json
{
  "ret": "50010",  // 或其他业务错误码
  "ret_msg": "系统错误"
}
```

### 错误码说明

| ret 码 | 说明 | 场景 |
|--------|------|------|
| 0 | 成功 | 正常响应 |
| 50000 | 未登录 | Cookie 缺失或登录态校验失败 |
| 50010 | 系统错误 | 网络请求失败、创建目录失败、Backend API 错误 |
| 50011 | 参数错误 | 格式无效、资源不存在、资源已存在 |
| 50012 | 权限错误 | 无权操作其他用户的资源 |

## 测试

### 使用 curl 测试

```bash
# 测试健康检查（不需要登录）
curl http://localhost:8001/health

# 测试需要登录的接口（会返回未登录）
curl http://localhost:8001/api/test

# 带 Cookie 测试
curl -b "OPENBDUSS=xxx;STOKEN=xxx" http://localhost:8001/api/test
```

### 使用 Python 测试

```python
import requests

# 不需要登录的接口
response = requests.get("http://localhost:8001/health")
print(response.json())

# 需要登录的接口
cookies = {
    "OPENBDUSS": "your_openbduss_here",
    "STOKEN": "your_stoken_here"
}
response = requests.get("http://localhost:8001/api/test", cookies=cookies)
print(response.json())
```

## 日志

日志示例：
```
2026-01-23 10:00:00 - service.auth - INFO - [登录态校验] 路径: /api/test, openbduss: True, stoken: True
2026-01-23 10:00:00 - service.auth - INFO - [登录态校验] 成功: did=123456, uname=username
```

## 环境变量配置

在 `.env` 文件中配置以下环境变量：

```bash
# Service API 配置
SERVICE_STORAGE_BASE_PATH=D:\pet-videos\videos  # 视频存储基础路径
SERVICE_RTSP_BASE_URL=rtsp://59.110.63.88:8554/rtp  # RTSP 服务器基础地址
SERVICE_BACKEND_API_URL=http://localhost:8002  # Backend API 地址
```

## 注意事项

1. **Cookie 名称**: 默认从 `OPENBDUSS` 和 `STOKEN` 这两个 Cookie 中获取认证信息
2. **超时设置**: BNS 请求超时时间为 5 秒，Backend API 请求超时 10 秒
3. **日志级别**: 生产环境建议设置为 `INFO` 或 `WARNING`
4. **数据隔离**: 用户只能访问自己的摄像头、视频和宠物数据（通过 `did` 区分）
5. **权限校验**: Service 层和 Backend 层双重校验
6. **响应格式**: 所有接口返回 HTTP 200，通过 `ret` 字段区分状态

## 扩展

### 添加新的认证方式

在 `auth.py` 中扩展 `SessionAuth` 类：

```python
async def verify_token(self, token: str) -> Optional[Dict]:
    """基于 Token 的认证"""
    # 实现 Token 认证逻辑
    pass
```

### 集成到现有项目

```python
from fastapi import FastAPI
from service.auth import require_login

existing_app = FastAPI()

@existing_app.get("/protected")
async def protected(user_info: Dict = Depends(require_login)):
    return {"user": user_info}
```
