"""
登录态校验模块
支持从 Cookie 中获取 openbduss 和 stoken，调用 BNS 服务校验登录态
"""

from fastapi import Request, HTTPException
from typing import Optional, Dict, Any, Set
import logging

from service.bns_client_async import get_async_bns_client
from service.response import Response

logger = logging.getLogger(__name__)


class SessionAuth:
    """会话认证类"""
    
    def __init__(self):
        self.bns_client = get_async_bns_client()
        # 不需要登录校验的路径集合
        self.public_paths: Set[str] = set()
    
    def add_public_path(self, path: str):
        """添加不需要登录校验的路径"""
        self.public_paths.add(path)
    
    def remove_public_path(self, path: str):
        """移除不需要登录校验的路径"""
        self.public_paths.discard(path)
    
    def is_public_path(self, path: str) -> bool:
        """判断路径是否需要登录校验"""
        return path in self.public_paths
    
    async def verify_session(
        self,
        request: Request,
        raise_exception: bool = True
    ) -> Optional[Dict[str, Any]]:
        """
        校验会话登录态
        
        Args:
            request: FastAPI 请求对象
            raise_exception: 如果为 True，校验失败抛出异常；如果为 False，返回 None
            
        Returns:
            校验成功返回用户信息字典，失败返回 None 或抛出异常
        """
        # 1. 从 Cookie 中获取 openbduss 和 stoken
        open_bduss = request.cookies.get("OPENBDUSS", "")
        stoken = request.cookies.get("STOKEN", "")
        
        logger.info(f"[登录态校验] 路径: {request.url.path}, openbduss: {bool(open_bduss)}, stoken: {bool(stoken)}")
        
        # 2. 检查必需的认证信息
        if not open_bduss:
            logger.warning(f"[登录态校验] Cookie 中未找到 OPENBDUSS")
            if raise_exception:
                raise HTTPException(
                    status_code=200,
                    detail=Response.not_login()
                )
            return None
        
        # 3. 调用 BNS 服务校验登录态
        try:
            # 获取 User-Agent
            ua = request.headers.get("User-Agent", "Mozilla/5.0")
            
            # 构造请求参数
            # 注意：nginx 转发时会去掉 /pet/ 前缀，这里需要加回去
            uri = f"/pet{request.url.path}"
            
            params = {
                "openBduss": open_bduss,
                "bduss": "",
                "stoken": stoken if stoken else None,
                "from": "pc",
                "version": "0.0.0",
                "os": "windows",
                "ua": ua,
                "uri": uri,  # 传递带 /pet/ 前缀的完整 URI
                "host": request.url.hostname or "localhost"
            }
            
            logger.debug(f"[登录态校验] 调用 getSessionInfo, uri: {request.url.path}")
            
            # 调用异步 BNS 客户端
            result = await self.bns_client.request(
                service_name="smart.group.user-service.licai-licai",
                api_path="/user/getSessionInfo",
                uri=uri,  # 使用带 /pet/ 前缀的 URI
                params=params,
                method="POST",
                timeout=5,
                verbose=False  # 生产环境关闭详细日志
            )
            
            # 4. 处理响应
            if not result["success"]:
                logger.error(f"[登录态校验] BNS 请求失败: {result['error']}")
                if raise_exception:
                    raise HTTPException(
                        status_code=200,
                        detail=Response.error("登录态校验服务异常")
                    )
                return None
            
            # 5. 解析业务响应
            data = result["data"]
            result_code = data.get("resultCode", "")
            
            if result_code != "0":
                logger.warning(f"[登录态校验] 校验失败: {data.get('resultMsg', '')}")
                if raise_exception:
                    raise HTTPException(
                        status_code=200,
                        detail=Response.not_login()
                    )
                return None
            
            # 6. 获取用户信息
            session_data = data.get("data", {})
            is_login = session_data.get("isLogin", False)
            
            if not is_login:
                logger.warning(f"[登录态校验] 用户未登录")
                if raise_exception:
                    raise HTTPException(
                        status_code=200,
                        detail=Response.not_login()
                    )
                return None
            
            # 7. 返回用户信息
            user_info = {
                "did": session_data.get("did"),
                "uname": session_data.get("uname"),
                "mobile": session_data.get("mobile"),
                "displayName": session_data.get("displayName"),
                "headUrl": session_data.get("headUrl"),
                "isLogin": is_login,
                "loginName": session_data.get("loginName"),
            }
            
            logger.info(f"[登录态校验] 成功: did={user_info['did']}, uname={user_info['uname']}")
            return user_info
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"[登录态校验] 异常: {str(e)}", exc_info=True)
            if raise_exception:
                raise HTTPException(
                    status_code=200,
                    detail=Response.error("登录态校验服务异常")
                )
            return None


# 全局单例
_auth_instance: Optional[SessionAuth] = None


def get_auth() -> SessionAuth:
    """获取认证实例（单例模式）"""
    global _auth_instance
    if _auth_instance is None:
        _auth_instance = SessionAuth()
    return _auth_instance


async def require_login(request: Request) -> Dict[str, Any]:
    """
    FastAPI 依赖注入：要求登录
    
    用法:
        @app.get("/api/test")
        async def test(user_info: Dict = Depends(require_login)):
            return {"user": user_info}
    """
    auth = get_auth()
    return await auth.verify_session(request, raise_exception=True)


async def optional_login(request: Request) -> Optional[Dict[str, Any]]:
    """
    FastAPI 依赖注入：可选登录
    
    用法:
        @app.get("/api/profile")
        async def profile(user_info: Optional[Dict] = Depends(optional_login)):
            if user_info:
                return {"user": user_info}
            else:
                return {"message": "guest"}
    """
    auth = get_auth()
    return await auth.verify_session(request, raise_exception=False)
