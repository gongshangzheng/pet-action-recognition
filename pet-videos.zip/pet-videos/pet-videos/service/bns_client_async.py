"""
BNS服务请求客户端 - 异步版本
支持通过BNS服务发现机制进行负载均衡请求（高并发场景）

直连模式：若 service_name 包含端口号（如 "10.33.77.183:8331"），
则跳过BNS解析，直接使用该地址发起请求，便于测试环境联调。
"""

from noah_python_sdk.clients import BNSClient, BNSGroupHttpClient
import aiohttp
import asyncio
import random
import re
from typing import Dict, Any


def _is_direct_address(service_name: str) -> bool:
    """判断是否为直连地址（host:port 格式，含端口号则跳过BNS解析）"""
    return bool(re.search(r':\d+$', service_name))


class AsyncBNSServiceClient:
    """BNS服务请求客户端（异步版本）"""
    
    def __init__(self):
        self.bns_client = BNSClient()
        self.bns_client.bns_group_clients = [BNSGroupHttpClient()]
    
    async def request(
        self,
        service_name: str,
        api_path: str,
        uri: str,
        params: dict,
        method: str = "POST",
        timeout: int = 5,
        verbose: bool = True
    ) -> Dict[str, Any]:
        """
        通过BNS服务发送请求（异步方式）
        
        Args:
            service_name: BNS服务名（如 "message-service.licai-licai"）
                          或直连地址（如 "10.33.77.183:8331"，含端口则跳过BNS解析）
            api_path: API路径
            uri: 当前接口URI（业务上下文路径），传空字符串则不注入到请求参数
            params: 请求参数字典
            method: 请求方法（GET/POST），默认POST
            timeout: 超时时间（秒），默认5秒
            verbose: 是否打印详细日志
            
        Returns:
            {
                "success": True/False,
                "data": 响应数据,
                "error": 错误信息,
                "status_code": HTTP状态码,
                "instance": "ip:port"
            }
        """
        instance_info = None
        try:
            # 1. 解析服务实例地址
            if _is_direct_address(service_name):
                # 直连模式：跳过BNS解析
                url = f"http://{service_name}{api_path}"
                instance_info = service_name
                if verbose:
                    print(f"[异步直连请求] 直连: {service_name}（跳过BNS解析）")
                    print(f"[异步直连请求] URL: {url}")
                    print(f"[异步直连请求] 方法: {method}")
            else:
                # BNS模式：通过服务发现获取实例
                instances = await asyncio.to_thread(
                    self.bns_client.get_instances_by_service,
                    service_name,
                    True
                )
                
                if not instances:
                    return {
                        "success": False,
                        "error": f"未找到可用的服务实例: {service_name}",
                        "data": None,
                        "status_code": None,
                        "instance": None
                    }
                
                instance = random.choice(instances)
                url = f"http://{instance.ip}:{instance.port}{api_path}"
                instance_info = f"{instance.ip}:{instance.port}"
                
                if verbose:
                    print(f"[异步BNS请求] 服务: {service_name}")
                    print(f"[异步BNS请求] 实例: {instance_info}")
                    print(f"[异步BNS请求] URL: {url}")
                    print(f"[异步BNS请求] URI: {uri}")
                    print(f"[异步BNS请求] 方法: {method}")
            
            # 2. 构建请求参数（uri 非空时才注入）
            request_params = params.copy()
            if uri and 'uri' not in request_params:
                request_params['uri'] = uri
            
            # 3. 发送异步请求
            timeout_obj = aiohttp.ClientTimeout(total=timeout)
            
            async with aiohttp.ClientSession(timeout=timeout_obj) as session:
                if method.upper() == "POST":
                    async with session.post(url, json=request_params) as response:
                        status_code = response.status
                        text = await response.text()
                        
                        if verbose:
                            print(f"[异步BNS响应] 状态码: {status_code}")
                        
                        if status_code == 200:
                            try:
                                data = await response.json()
                                return {
                                    "success": True,
                                    "data": data,
                                    "error": None,
                                    "status_code": status_code,
                                    "instance": instance_info
                                }
                            except Exception as e:
                                return {
                                    "success": False,
                                    "data": None,
                                    "error": f"JSON解析失败: {str(e)}",
                                    "status_code": status_code,
                                    "instance": instance_info
                                }
                        else:
                            return {
                                "success": False,
                                "data": None,
                                "error": f"HTTP {status_code}: {text[:200]}",
                                "status_code": status_code,
                                "instance": instance_info
                            }
                            
                elif method.upper() == "GET":
                    async with session.get(url, params=request_params) as response:
                        status_code = response.status
                        text = await response.text()
                        
                        if verbose:
                            print(f"[异步BNS响应] 状态码: {status_code}")
                        
                        if status_code == 200:
                            try:
                                data = await response.json()
                                return {
                                    "success": True,
                                    "data": data,
                                    "error": None,
                                    "status_code": status_code,
                                    "instance": instance_info
                                }
                            except Exception as e:
                                return {
                                    "success": False,
                                    "data": None,
                                    "error": f"JSON解析失败: {str(e)}",
                                    "status_code": status_code,
                                    "instance": instance_info
                                }
                        else:
                            return {
                                "success": False,
                                "data": None,
                                "error": f"HTTP {status_code}: {text[:200]}",
                                "status_code": status_code,
                                "instance": instance_info
                            }
                else:
                    return {
                        "success": False,
                        "error": f"不支持的请求方法: {method}",
                        "data": None,
                        "status_code": None,
                        "instance": instance_info
                    }
                    
        except asyncio.TimeoutError:
            return {
                "success": False,
                "error": f"请求超时（{timeout}秒）",
                "data": None,
                "status_code": None,
                "instance": instance_info
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"请求失败: {str(e)}",
                "data": None,
                "status_code": None,
                "instance": instance_info
            }
    
    async def get_session_info(
        self,
        open_bduss: str,
        uri: str = "/index.html",
        verbose: bool = True,
        **kwargs
    ) -> Dict[str, Any]:
        """
        便捷方法：获取会话信息（异步）
        
        Args:
            open_bduss: OpenBDUSS令牌
            uri: 当前接口URI
            verbose: 是否打印详细日志
            **kwargs: 其他参数
        """
        params = {
            'openBduss': open_bduss,
            'bduss': kwargs.get('bduss', ''),
            'stoken': kwargs.get('stoken', None),
            'from': kwargs.get('from', 'pc'),
            'version': kwargs.get('version', '0.0.0'),
            'os': kwargs.get('os', 'windows'),
            'ua': kwargs.get('ua', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36')
        }
        
        return await self.request(
            service_name="smart.group.user-service.licai-licai",
            api_path="/user/getSessionInfo",
            uri=uri,
            params=params,
            method="POST",
            timeout=5,
            verbose=verbose
        )


# 全局单例
_async_client = None


def get_async_bns_client() -> AsyncBNSServiceClient:
    """获取异步BNS客户端单例"""
    global _async_client
    if _async_client is None:
        _async_client = AsyncBNSServiceClient()
    return _async_client


async def request_bns_service_async(
    service_name: str,
    api_path: str,
    uri: str,
    params: dict,
    method: str = "POST",
    timeout: int = 5,
    verbose: bool = True
) -> Dict[str, Any]:
    """
    便捷函数：通过BNS服务发送请求（异步方式）
    
    使用示例：
        async def main():
            result = await request_bns_service_async(
                service_name="smart.group.user-service.licai-licai",
                api_path="/user/getSessionInfo",
                uri="/index.html",
                params={'openBduss': 'xxx'}
            )
            if result['success']:
                print(result['data'])
        
        asyncio.run(main())
    """
    client = get_async_bns_client()
    return await client.request(service_name, api_path, uri, params, method, timeout, verbose)


async def batch_request(requests_list: list) -> list:
    """
    批量异步请求（高并发场景）
    
    Args:
        requests_list: 请求列表，每个元素是一个字典，包含 request_bns_service_async 的参数
        
    使用示例：
        async def main():
            requests = [
                {
                    'service_name': 'xxx',
                    'api_path': '/api1',
                    'uri': '/page1',
                    'params': {...}
                },
                {
                    'service_name': 'xxx',
                    'api_path': '/api2',
                    'uri': '/page2',
                    'params': {...}
                }
            ]
            results = await batch_request(requests)
            for i, result in enumerate(results):
                print(f"请求{i}: {result['success']}")
    """
    tasks = []
    for req in requests_list:
        task = request_bns_service_async(**req)
        tasks.append(task)
    
    return await asyncio.gather(*tasks)
