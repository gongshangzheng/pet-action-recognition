#!/usr/bin/env python3
"""
测试错误码定义是否完整
"""

from response import Response, ErrorCode

print("=" * 60)
print("错误码定义测试")
print("=" * 60)
print()

# 测试所有错误码
print("1. 成功响应:")
print(Response.success({"test": "data"}))
print()

print("2. 未登录响应:")
print(Response.not_login())
print()

print("3. 系统错误:")
print(Response.error("系统错误", ErrorCode.SYSTEM_ERROR))
print()

print("4. 参数错误:")
print(Response.error("参数错误", ErrorCode.PARAM_ERROR))
print()

print("5. 权限错误:")
print(Response.error("权限错误", ErrorCode.NO_PERMISSION))
print()

print("6. 资源已存在:")
print(Response.error("资源已存在", ErrorCode.ALREADY_EXISTS))
print()

print("7. 网络错误:")
print(Response.error("网络错误", ErrorCode.NETWORK_ERROR))
print()

print("=" * 60)
print("所有错误码定义:")
print("=" * 60)
print(f"SUCCESS: {ErrorCode.SUCCESS}")
print(f"NOT_LOGIN: {ErrorCode.NOT_LOGIN}")
print(f"SYSTEM_ERROR: {ErrorCode.SYSTEM_ERROR}")
print(f"PARAM_ERROR: {ErrorCode.PARAM_ERROR}")
print(f"NO_PERMISSION: {ErrorCode.NO_PERMISSION}")
print(f"ALREADY_EXISTS: {ErrorCode.ALREADY_EXISTS}")
print(f"NETWORK_ERROR: {ErrorCode.NETWORK_ERROR}")
print()

print("✅ 所有错误码测试通过！")
