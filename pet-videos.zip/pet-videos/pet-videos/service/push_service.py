"""
消息Push服务封装

通过中台消息网关（message-service）发送App Push通知。
业务侧指定模板Code和模板变量即可，无需关心底层请求细节。

生产环境通过BNS解析服务地址；测试时可直接传入 host:port 跳过BNS。

对外暴露两个主方法：
  - send_push(user_id, ...)       已知 userId 时直接发送
  - send_push_by_did(did, ...)    只有 did 时自动查询 userId 再发送
"""

import time
import random
import string
import logging
import json
from typing import Dict, Any, Optional

from bns_client_async import request_bns_service_async

logger = logging.getLogger(__name__)
push_detail_logger = logging.getLogger("push_detail")  # 独立 Push 详细日志

# 消息服务配置（生产环境 BNS）
MESSAGE_SERVICE_NAME = "smart.group.message-service.licai-licai"
MESSAGE_SEND_API     = "/licai/msgcenter/sendMessage"

# 用户服务配置（生产环境BNS）
USER_SERVICE_NAME  = "smart.group.user-service.licai-licai"
USER_QUERY_DID_API = "/user/queryUserIdByDid"


def _gen_batch_no() -> str:
    ts     = str(int(time.time() * 1000))
    suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    return f"pet_{ts}_{suffix}"


def _gen_message_id() -> str:
    ts     = str(int(time.time() * 1000))
    suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
    return f"petmsg_{ts}_{suffix}"


async def send_push(
    template_code: str,
    user_id: str,
    template_params: Optional[Dict[str, str]] = None,
    service_name: str = MESSAGE_SERVICE_NAME,
    timeout: int = 10,
    verbose: bool = False,
) -> Dict[str, Any]:
    """
    发送 App Push 消息。

    Args:
        template_code:   触达后台配置的模板 Code，如 "PET_ACTION_NOTICE"
        user_id:         目标用户的 userId（字符串）
        template_params: 模板变量字典，无占位符时传 None 或 {}
                         示例: {"PET_NAME": "小黄", "PET_ACTION": "吃饭"}
        service_name:    消息服务名（BNS）或直连地址（测试用）
                         - 生产: "message-service.licai-licai"（默认）
                         - 测试: "10.33.77.183:8331"（含端口则跳过BNS解析）
        timeout:         请求超时秒数，默认 10 秒
        verbose:         是否输出详细日志，默认 False

    Returns:
        {
            "success":     True / False,
            "result_code": 接口返回码，"0" 表示成功,
            "result_msg":  接口返回信息,
            "data":        完整响应体,
            "error":       异常描述（失败时非 None）,
        }

    使用示例:
        # 生产环境（通过BNS）
        result = await send_push(
            template_code="PET_ACTION_NOTICE",
            user_id="29189742",
            template_params={
                "PET_NAME":               "小黄",
                "PET_ACTION":             "吃饭",
                "PET_ACTION_DESCRIPTION": "小黄正在津津有味地享用午餐",
            },
        )

        # 测试环境（直连，跳过BNS）
        result = await send_push(
            template_code="PET_ACTION_NOTICE",
            user_id="29189742",
            template_params={...},
            service_name="10.33.77.183:8331",
        )

        if result["success"]:
            print("Push 发送成功")
        else:
            print("Push 发送失败:", result["error"])
    """
    user_param: Dict[str, Any] = {
        "messageId": _gen_message_id(),
        "userId":    user_id,
    }
    if template_params:
        user_param["templateParams"] = template_params

    payload = {
        "batchNo":      _gen_batch_no(),
        "templateCode": template_code,
        "confirmType":  0,
        "synSend":      True,
        "userParams":   [user_param],
    }

    if verbose:
        logger.info(
            f"[PushService] 发送Push: template={template_code}, "
            f"userId={user_id}, service={service_name}"
        )
    
    # 记录请求详情到独立日志
    push_detail_logger.info(
        f"[请求] service={service_name}, api={MESSAGE_SEND_API}\n"
        f"  Payload: {json.dumps(payload, ensure_ascii=False, indent=2)}"
    )

    result = await request_bns_service_async(
        service_name=service_name,
        api_path=MESSAGE_SEND_API,
        uri="",          # 消息服务无需 uri 参数，传空字符串不会注入到 payload
        params=payload,
        method="POST",
        timeout=timeout,
        verbose=verbose,
    )
    
    # 记录响应详情到独立日志
    push_detail_logger.info(
        f"[响应] success={result['success']}\n"
        f"  Response: {json.dumps(result, ensure_ascii=False, indent=2)}"
    )

    if not result["success"]:
        logger.error(f"[PushService] 请求失败: {result['error']}")
        push_detail_logger.error(f"[失败] 网络请求失败: {result['error']}")
        return {
            "success":     False,
            "result_code": None,
            "result_msg":  result["error"],
            "data":        None,
            "error":       result["error"],
        }

    data            = result["data"]
    gw_result_code  = str(data.get("resultCode", ""))
    gw_result_msg   = data.get("resultMsg", "")

    # 网关层失败（请求未被接受）
    if gw_result_code != "0":
        logger.error(
            f"[PushService] 网关拒绝: code={gw_result_code}, msg={gw_result_msg}"
        )
        push_detail_logger.error(
            f"[失败-网关] code={gw_result_code}, msg={gw_result_msg}\n"
            f"  userId={user_id}, template={template_code}"
        )
        return {
            "success":     False,
            "result_code": gw_result_code,
            "result_msg":  gw_result_msg,
            "data":        data,
            "error":       f"网关拒绝: [{gw_result_code}] {gw_result_msg}",
        }

    # 检查每个用户的实际推送结果（在 data.responseMap 中）
    # responseMap 的 key 是动态的复合字符串，取第一个 value 即当前用户的结果
    response_map: dict = (data.get("data") or {}).get("responseMap") or {}
    if response_map:
        # 单次调用只传一个用户，取第一个结果即可
        user_result    = next(iter(response_map.values()), {})
        push_code      = str(user_result.get("resultCode") or user_result.get("errCode") or "")
        push_msg       = user_result.get("resultMsg") or user_result.get("errMsg") or ""
        push_succeeded = (push_code == "0" or push_code == "")

        if push_succeeded:
            logger.info(
                f"[PushService] Push发送成功: template={template_code}, userId={user_id}"
            )
            push_detail_logger.info(
                f"[成功] userId={user_id}, template={template_code}\n"
                f"  code={push_code}, msg={push_msg}"
            )
            return {
                "success":     True,
                "result_code": push_code,
                "result_msg":  push_msg,
                "data":        data,
                "error":       None,
            }
        else:
            logger.error(
                f"[PushService] Push推送失败: code={push_code}, msg={push_msg}"
            )
            push_detail_logger.error(
                f"[失败-推送] code={push_code}, msg={push_msg}\n"
                f"  userId={user_id}, template={template_code}\n"
                f"  template_params={json.dumps(template_params, ensure_ascii=False)}\n"
                f"  responseMap={json.dumps(response_map, ensure_ascii=False, indent=2)}"
            )
            return {
                "success":     False,
                "result_code": push_code,
                "result_msg":  push_msg,
                "data":        data,
                "error":       f"推送失败: [{push_code}] {push_msg}",
            }

    # responseMap 为空：仅凭网关成功视为发送成功
    logger.info(
        f"[PushService] Push发送成功(无responseMap): template={template_code}, userId={user_id}"
    )
    return {
        "success":     True,
        "result_code": gw_result_code,
        "result_msg":  gw_result_msg,
        "data":        data,
        "error":       None,
    }


async def get_user_id_by_did(
    did: str,
    service_name: str = USER_SERVICE_NAME,
    timeout: int = 5,
    verbose: bool = False,
) -> Optional[str]:
    """
    通过 did 查询 userId（异步，走 BNS）。

    Args:
        did:          设备/用户 did（字符串形式的 Long）
        service_name: user-service 的 BNS 服务名或直连地址（含端口则跳过BNS）
                      默认: "smart.group.user-service.licai-licai"
        timeout:      超时秒数，默认 5 秒
        verbose:      是否输出详细日志

    Returns:
        userId 字符串，查询失败返回 None

    接口: GET /user/queryUserIdByDid?did={did}
    响应: { "result": 0, "resultString": "ok", "userId": 29189742 }
    """
    push_detail_logger.info(
        f"[查询userId] did={did}, service={service_name}"
    )
    
    result = await request_bns_service_async(
        service_name=service_name,
        api_path=USER_QUERY_DID_API,
        uri="",
        params={"did": did},
        method="GET",
        timeout=timeout,
        verbose=verbose,
    )
    
    push_detail_logger.info(
        f"[查询userId响应] {json.dumps(result, ensure_ascii=False)}"
    )

    if not result["success"]:
        logger.error(f"[PushService] queryUserIdByDid 请求失败: did={did}, error={result['error']}")
        push_detail_logger.error(f"[失败-查询userId] did={did}, error={result['error']}")
        return None

    data = result["data"]
    if data.get("result") != 0:
        logger.error(
            f"[PushService] queryUserIdByDid 业务失败: did={did}, "
            f"result={data.get('result')}, msg={data.get('resultString')}"
        )
        push_detail_logger.error(
            f"[失败-查询userId] did={did}, result={data.get('result')}, msg={data.get('resultString')}"
        )
        return None

    user_id = data.get("userId")
    if not user_id:
        logger.error(f"[PushService] queryUserIdByDid 返回 userId 为空: did={did}")
        push_detail_logger.error(f"[失败-查询userId] did={did}, userId 为空")
        return None

    push_detail_logger.info(f"[查询userId成功] did={did} -> userId={user_id}")
    return str(user_id)


async def send_push_by_did(
    did: str,
    template_code: str,
    template_params: Optional[Dict[str, str]] = None,
    message_service_name: str = MESSAGE_SERVICE_NAME,
    user_service_name: str = USER_SERVICE_NAME,
    timeout: int = 10,
    verbose: bool = False,
) -> Dict[str, Any]:
    """
    通过 did 发送 App Push（自动查询 userId 再发送）。

    Args:
        did:                  设备/用户 did
        template_code:        模板 Code，如 "PET_ACTION_NOTICE"
        template_params:      模板变量字典
        message_service_name: 消息服务 BNS 名或直连地址
        user_service_name:    用户服务 BNS 名或直连地址
        timeout:              超时秒数
        verbose:              是否输出详细日志

    Returns:
        同 send_push() 的返回结构，查不到 userId 时直接返回失败

    使用示例:
        # 生产环境（全走BNS）
        result = await send_push_by_did(
            did="20000000060148",
            template_code="PET_ACTION_NOTICE",
            template_params={
                "PET_NAME":               "小黄",
                "PET_ACTION":             "吃饭",
                "PET_ACTION_DESCRIPTION": "小黄正在津津有味地享用午餐",
            },
        )

        # 测试环境（直连，跳过BNS）
        result = await send_push_by_did(
            did="20000000060148",
            template_code="PET_ACTION_NOTICE",
            template_params={...},
            message_service_name="10.33.77.183:8331",
            user_service_name="10.x.x.x:8080",
        )
    """
    push_detail_logger.info(
        f"[发送流程开始] did={did}, template={template_code}\n"
        f"  params={json.dumps(template_params, ensure_ascii=False)}"
    )
    
    user_id = await get_user_id_by_did(
        did=did,
        service_name=user_service_name,
        timeout=timeout,
        verbose=verbose,
    )

    if not user_id:
        error_msg = f"did={did} 查询 userId 失败，无法发送 Push"
        logger.error(f"[PushService] {error_msg}")
        push_detail_logger.error(
            f"[发送流程失败] {error_msg}\n"
            f"  template={template_code}, params={json.dumps(template_params, ensure_ascii=False)}"
        )
        return {
            "success":     False,
            "result_code": None,
            "result_msg":  error_msg,
            "data":        None,
            "error":       error_msg,
        }

    logger.info(f"[PushService] did={did} 查询到 userId={user_id}")

    result = await send_push(
        template_code=template_code,
        user_id=user_id,
        template_params=template_params,
        service_name=message_service_name,
        timeout=timeout,
        verbose=verbose,
    )
    
    push_detail_logger.info(
        f"[发送流程完成] did={did} -> userId={user_id}, success={result['success']}, "
        f"code={result['result_code']}, msg={result['result_msg']}"
    )
    
    return result
