# Service API 快速参考

> 所有接口路径统一以 `/pet` 开头
> 
> 基础URL: `http://your-domain/pet`

## 🔓 公开接口 (无需登录)

### 健康检查
```http
GET /pet/health
```
**响应**: `{"ret":"0","ret_msg":"ok","service":"pet-videos-service","status":"healthy","version":"1.0.0"}`

### 视频流播放
```http
GET /pet/api/video/stream?token=xxx
HEAD /pet/api/video/stream?token=xxx
```
**功能**: 支持 Range 请求、断点续传、流式传输

---

## 🔐 需要登录的接口

> 所有需要登录的接口必须在请求头中包含 Cookie: `OPENBDUSS=xxx; STOKEN=xxx`

### 1. 用户认证

#### 测试登录态
```http
GET /pet/api/test
```

#### 获取用户信息
```http
GET /pet/api/user/info
```

---

### 2. 摄像头管理

#### 添加摄像头
```http
POST /pet/api/camera/add
Content-Type: application/json

{
  "stream_identifier": "living_room_01",
  "name": "客厅摄像头"
}
```
**说明**:
- `stream_identifier`: 只能包含字母、数字、下划线、连字符，长度1-50
- 自动生成 RTSP URL、存储路径、别名

#### 查询摄像头列表
```http
GET /pet/api/camera/list
```
**响应**: `{"ret":"0","ret_msg":"ok","cameras":[...],"total":2}`

#### 更新摄像头
```http
POST /pet/api/camera/update/123
Content-Type: application/json

{
  "name": "新名称",
  "is_active": true
}
```

#### 删除摄像头
```http
POST /pet/api/camera/delete/123
```
**约束**: 有关联任务的摄像头不能删除

---

### 3. 视频查询

#### 按日期查询视频
```http
GET /pet/api/videos/by-date?date=2026-01-23
GET /pet/api/videos/by-date?date=2026-01-23&source_id=123
GET /pet/api/videos/by-date?date=2026-01-23&pet_name=毛毛
GET /pet/api/videos/by-date?date=2026-01-23&page=1&page_size=20
GET /pet/api/videos/by-date?date=2026-01-23&page_size=0  # 返回全部(最多1000条)
```

**查询参数**:
- `date` (必填): YYYY-MM-DD 格式
- `source_id` (可选): 摄像头ID
- `pet_name` (可选): 宠物名称
- `page` (可选): 页码，默认1
- `page_size` (可选): 每页数量，0-1000，默认20
  - `0`: 返回所有(最多1000条)
  - `1-1000`: 正常分页

**响应示例**:
```json
{
  "ret": "0",
  "ret_msg": "ok",
  "videos": [
    {
      "id": 1001,
      "filename": "20260130_120530_pet.mp4",
      "source_id": 123,
      "size_mb": 5.0,
      "duration": 10.5,
      "llm_status": "completed",
      "recorded_at": "2026-01-30T12:05:30",
      "pets": [
        {
          "name": "毛毛",
          "actions": ["玩耍", "跳跃"],
          "description": "在客厅里追逐玩具球",
          "status": "活跃",
          "location": "客厅",
          "score": 8
        }
      ]
    }
  ],
  "total": 156,
  "page": 1,
  "page_size": 20,
  "is_all": false
}
```

---

### 4. 宠物管理

#### 获取宠物列表
```http
GET /pet/api/pet/list
```

#### 获取宠物详情
```http
GET /pet/api/pet/{pet_name}
```

#### 添加宠物
```http
POST /pet/api/pet/add
Content-Type: application/json

{
  "pet_name": "小白",
  "pet_type": "猫",
  "breed": "英短",
  "gender": "母",
  "birth_date": "2021-03-10",
  "color": "白色",
  "avatar_url": "https://...",
  "description": "安静乖巧"
}
```
**说明**:
- `pet_name` 必填
- `birth_date` 格式: YYYY-MM-DD
- 同一用户不能添加同名宠物

#### 更新宠物
```http
POST /pet/api/pet/update/{pet_name}
Content-Type: application/json

{
  "pet_type": "猫",
  "description": "更新描述"
}
```
**注意**: 宠物名称不可修改

#### 删除宠物
```http
POST /pet/api/pet/delete/{pet_name}
```

---

### 5. 日报管理

> 日报由后端自动生成，用户只能查看

#### 获取日报列表
```http
GET /pet/api/daily-report
GET /pet/api/daily-report?date=2026-01-23
GET /pet/api/daily-report?pet_name=毛毛
GET /pet/api/daily-report?date=2026-01-23&pet_name=毛毛
```

**查询参数**:
- `date` (可选): YYYY-MM-DD 格式
- `pet_name` (可选): 宠物名称

#### 获取指定日报
```http
GET /pet/api/daily-report/2026-01-23/毛毛
```

**响应格式**:
```json
{
  "errno": 0,
  "errmsg": "success",
  "data": {
    "did": "user123",
    "date": "2026-01-23",
    "pet_name": "毛毛",
    "summary": "今天毛毛表现活跃...",
    "analysis_data": "{...}",
    "video_count": 15,
    "total_duration": 3600.0,
    "created_at": "2026-01-23T10:00:00",
    "updated_at": "2026-01-23T20:30:00"
  }
}
```

---

## 📝 响应格式规范

所有响应统一返回 **HTTP 200**，通过 `ret` 字段区分状态

### 成功响应
```json
{
  "ret": "0",
  "ret_msg": "ok",
  ...业务字段
}
```

### 未登录响应
```json
{
  "ret": "50000",
  "ret_msg": "not_login"
}
```

### 错误响应
```json
{
  "ret": "50010",
  "ret_msg": "系统错误"
}
```

## 🔢 错误码说明

| ret 码 | 说明 | 场景 |
|--------|------|------|
| 0 | 成功 | 正常响应 |
| 50000 | 未登录 | Cookie缺失或登录态校验失败 |
| 50010 | 系统错误 | 网络请求失败、创建目录失败 |
| 50011 | 参数错误 | 格式无效、资源不存在/已存在 |
| 50012 | 权限错误 | 无权操作其他用户的资源 |

---

## 🧪 测试示例

### cURL 测试

```bash
# 健康检查
curl http://localhost:8006/pet/health

# 测试登录态（未登录）
curl http://localhost:8006/pet/api/test

# 带 Cookie 测试
curl -b "OPENBDUSS=xxx;STOKEN=xxx" http://localhost:8006/pet/api/test

# 查询摄像头列表
curl -b "OPENBDUSS=xxx;STOKEN=xxx" http://localhost:8006/pet/api/camera/list

# 添加摄像头
curl -X POST http://localhost:8006/pet/api/camera/add \
  -H "Content-Type: application/json" \
  -b "OPENBDUSS=xxx;STOKEN=xxx" \
  -d '{"stream_identifier":"test01","name":"测试摄像头"}'

# 查询视频
curl -b "OPENBDUSS=xxx;STOKEN=xxx" \
  "http://localhost:8006/pet/api/videos/by-date?date=2026-01-23"

# 获取宠物列表
curl -b "OPENBDUSS=xxx;STOKEN=xxx" http://localhost:8006/pet/api/pet/list
```

### JavaScript/Fetch 测试

```javascript
// 查询摄像头列表
fetch('http://localhost:8006/pet/api/camera/list', {
  credentials: 'include'  // 自动携带 Cookie
})
  .then(res => res.json())
  .then(data => console.log(data));

// 添加摄像头
fetch('http://localhost:8006/pet/api/camera/add', {
  method: 'POST',
  credentials: 'include',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    stream_identifier: 'living_room_01',
    name: '客厅摄像头'
  })
})
  .then(res => res.json())
  .then(data => console.log(data));

// 查询视频
fetch('http://localhost:8006/pet/api/videos/by-date?date=2026-01-23&page_size=20', {
  credentials: 'include'
})
  .then(res => res.json())
  .then(data => console.log(data));
```

### Python/Requests 测试

```python
import requests

base_url = "http://localhost:8006/pet"
cookies = {
    "OPENBDUSS": "your_openbduss",
    "STOKEN": "your_stoken"
}

# 健康检查
response = requests.get(f"{base_url}/health")
print(response.json())

# 查询摄像头
response = requests.get(f"{base_url}/api/camera/list", cookies=cookies)
print(response.json())

# 添加摄像头
response = requests.post(
    f"{base_url}/api/camera/add",
    json={
        "stream_identifier": "test01",
        "name": "测试摄像头"
    },
    cookies=cookies
)
print(response.json())

# 查询视频
response = requests.get(
    f"{base_url}/api/videos/by-date",
    params={"date": "2026-01-23", "page_size": 20},
    cookies=cookies
)
print(response.json())
```

---

## 📚 相关文档

- [完整 API 文档](./README.md)
- [Nginx 配置指南](./NGINX_CONFIG.md)
- [开发指南](./README.md#开发新接口)

---

## 💡 注意事项

1. **所有路径必须以 `/pet` 开头**
2. **需要登录的接口必须携带 Cookie** (OPENBDUSS + STOKEN)
3. **所有响应返回 HTTP 200**，通过 `ret` 字段区分状态
4. **用户只能访问自己的数据**，通过 `did` 进行数据隔离
5. **视频流接口支持 Range 请求**，可实现断点续传
6. **日报只能查看，不能手动创建或修改**
