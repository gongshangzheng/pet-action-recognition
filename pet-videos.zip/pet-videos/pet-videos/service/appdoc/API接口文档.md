# DXMPetGuard 后端接口文档

> **版本：** v1.0  
> **更新时间：** 2026-02-04  
> **状态：** 🚧 设计阶段（前端已使用 Mock 数据完成开发）

---

## 📋 目录

- [1. 接口概览](#1-接口概览)
- [2. 通用说明](#2-通用说明)
- [3. Home 页面接口](#3-home-页面接口)
  - [3.1 获取日报数据](#31-获取日报数据)
  - [3.2 获取宠物列表](#32-获取宠物列表)
  - [3.3 获取日历信息](#33-获取日历信息)
- [4. 设置页面接口](#4-设置页面接口)
  - [4.1 获取宠物列表（详细信息）](#41-获取宠物列表详细信息)
  - [4.2 更新宠物信息](#42-更新宠物信息)
  - [4.3 添加宠物](#43-添加宠物)
  - [4.4 绑定设备](#44-绑定设备)
- [5. 数据模型](#5-数据模型)
- [6. 错误码规范](#6-错误码规范)
- [7. Mock 数据示例](#7-mock-数据示例)

---

## 1. 接口概览

| 序号 | 接口名称 | 请求方式 | 接口路径 | 说明 | 状态 |
|-----|---------|---------|---------|------|------|
| 1 | 获取日报数据 | GET | `/api/pet/daily-report` | 获取指定日期的宠物日报 | ⏳ 待开发 |
| 2 | 获取宠物列表（简化） | GET | `/api/pet/list` | 获取宠物列表（用于筛选器） | ⏳ 待开发 |
| 3 | 获取日历信息 | GET | `/api/pet/calendar` | 获取有事件的日期列表 | ⏳ 待开发 |
| 4 | 获取宠物列表（详细） | GET | `/api/pet/list-detail` | 获取宠物详细信息 | ⏳ 待开发 |
| 5 | 更新宠物信息 | POST | `/api/pet/update` | 更新宠物信息 | ⏳ 待开发 |
| 6 | 添加宠物 | POST | `/api/pet/add` | 添加新宠物 | ⏳ 待开发 |
| 7 | 绑定设备 | POST | `/api/device/bind` | 通过二维码绑定设备 | ⏳ 待开发 |

---

## 2. 通用说明

### 2.1 基础URL

```
开发环境: https://dev.dxmpetguard.com
生产环境: https://api.dxmpetguard.com
```

### 2.2 请求头

```http
Content-Type: application/json
```

### 2.3 通用响应格式

**成功响应：**

```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    // 具体业务数据
  }
}
```

**失败响应：**

```json
{
  "ret": -1,
  "ret_msg": "具体错误信息",
  "data": null
}
```

### 2.4 HTTP 状态码

| 状态码 | 说明 |
|-------|------|
| 200 | 请求成功 |
| 400 | 请求参数错误 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |

---

## 3. Home 页面接口

### 3.1 获取日报数据

**接口描述：** 获取指定日期的宠物日报，包括宠物信息和事件列表。

**请求方式：** `GET`

**接口路径：** `/api/pet/daily-report`

**请求参数：**

| 参数名 | 类型 | 必填 | 说明 | 示例 |
|-------|------|------|------|------|
| date | String | ✅ | 日期（格式：yyyy-MM-dd） | `2025-11-24` |
| petId | String | ❌ | 宠物ID（不传则返回所有宠物） | `001` |

**请求示例：**

```http
GET /api/pet/daily-report?date=2025-11-24&petId=001
```

**响应示例：**

```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "date": "2025-11-24",
    "petReports": [
      {
        "petId": "001",
        "petName": "栗子",
        "petType": "狸花猫",
        "weight": "4.2kg",
        "features": "短毛，全身覆盖黑灰相间的经典斑纹，腹部毛色较浅，四肢有环状纹路。",
        "avatarColor": "#E5E7EB",
        "dailyTag": "精力过剩",
        "dailyReport": "06:30 进行了高强度的活动（跑酷）。全天饮食饮水正常。注意：23:09 检测到多猫互动（追逐）。"
      },
      {
        "petId": "002",
        "petName": "奶油",
        "petType": "金渐层长毛",
        "weight": "5.5kg",
        "features": "长毛，背部呈现金渐层色，面部圆润，耳尖有少量聪明毛，尾巴蓬松。",
        "avatarColor": "#FEF3C7",
        "dailyTag": "岁月静好",
        "dailyReport": "大部分时间处于休息状态。09:40 进行了饮食饮水。晚间被动参与了一次多猫互动。"
      }
    ],
    "events": [
      {
        "eventId": "24-1",
        "eventTime": "14:30",
        "petName": "奶油",
        "actions": ["活动", "多猫互动"],
        "eventDesc": "奶油在客厅地面悠闲地巡视了一圈，随后轻快地跳上猫爬架，并抬头看向高处的同伴。",
        "aiStatus": "状态非常活泼，探索欲满满，是个充满好奇心的小可爱。",
        "videoUrl": "https://cdn.example.com/video/event_24_1.mp4",
        "videoTime": 0,
        "thumbnailColor": "#FEF3C7",
        "thumbnailUrl": "https://cdn.example.com/thumb/event_24_1.jpg"
      },
      {
        "eventId": "24-2",
        "eventTime": "14:28",
        "petName": "栗子",
        "actions": ["休息", "多猫互动"],
        "eventDesc": "栗子一直稳稳地趴在猫爬架的高层窝里，俯瞰着下方活动的同伴，神情淡定自若。",
        "aiStatus": "情绪稳定且放松，像是在享受它的午后静谧时光，状态很好。",
        "videoUrl": "https://cdn.example.com/video/event_24_2.mp4",
        "videoTime": 0,
        "thumbnailColor": "#E5E7EB",
        "thumbnailUrl": "https://cdn.example.com/thumb/event_24_2.jpg"
      }
    ]
  }
}
```

**字段说明：**

| 字段 | 类型 | 说明 |
|-----|------|------|
| date | String | 日期 |
| petReports | Array | 宠物日报列表 |
| petReports[].petId | String | 宠物ID |
| petReports[].petName | String | 宠物名字 |
| petReports[].petType | String | 品种 |
| petReports[].weight | String | 体重（如：4.2kg） |
| petReports[].features | String | 外观特征 |
| petReports[].avatarColor | String | 头像背景色（Hex格式） |
| petReports[].dailyTag | String | 今日标签（如：精力过剩） |
| petReports[].dailyReport | String | 日报内容（纯文本） |
| events | Array | 事件列表（按时间倒序） |
| events[].eventId | String | 事件ID |
| events[].eventTime | String | 事件时间（格式：HH:mm） |
| events[].petName | String | 宠物名（可以是"双猫"） |
| events[].actions | Array | 行为标签数组 |
| events[].eventDesc | String | 详细描述 |
| events[].aiStatus | String | AI判断 |
| events[].videoUrl | String | 视频URL（**必须支持HTTP Range请求**） |
| events[].videoTime | Integer | 视频起始时间点（秒） |
| events[].thumbnailColor | String | 缩略图背景色（Hex格式） |
| events[].thumbnailUrl | String | 缩略图URL（可选） |

**重要提示：**

1. ⚠️ **视频服务器必须支持 HTTP Range 请求（返回 `206 Partial Content`）**，否则 iOS 端播放会失败（黑屏）。
2. ⚠️ **视频编码必须使用 H.264 或 HEVC (hvc1 tag)**，不支持 hev1 tag 的 HEVC。
3. ⚠️ **建议视频使用 faststart 优化**（moov box 放在文件开头），加快播放启动速度。
4. 推荐使用 FFmpeg 转码：
   ```bash
   ffmpeg -i input.mp4 -c:v libx264 -c:a aac -movflags +faststart output.mp4
   ```

**错误码：**

| ret | 说明 |
|-----|------|
| 0 | 成功 |
| -1 | 日期格式错误 |
| -2 | 宠物ID不存在 |
| -3 | 该日期无数据 |

---

### 3.2 获取宠物列表

**接口描述：** 获取宠物列表（简化版本，用于 Home 页面筛选器）。

**请求方式：** `GET`

**接口路径：** `/api/pet/list`

**请求参数：** 无

**请求示例：**

```http
GET /api/pet/list
```

**响应示例：**

```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "pets": [
      {
        "petId": "001",
        "petName": "栗子",
        "avatarColor": "#E5E7EB"
      },
      {
        "petId": "002",
        "petName": "奶油",
        "avatarColor": "#FEF3C7"
      }
    ]
  }
}
```

**字段说明：**

| 字段 | 类型 | 说明 |
|-----|------|------|
| pets | Array | 宠物列表 |
| pets[].petId | String | 宠物ID |
| pets[].petName | String | 宠物名字 |
| pets[].avatarColor | String | 头像背景色（Hex格式） |

**错误码：**

| ret | 说明 |
|-----|------|
| 0 | 成功 |
| -1 | 获取失败 |

---

### 3.3 获取日历信息

**接口描述：** 获取有事件的日期列表（用于日历标记）。

**请求方式：** `GET`

**接口路径：** `/api/pet/calendar`

**请求参数：**

| 参数名 | 类型 | 必填 | 说明 | 示例 |
|-------|------|------|------|------|
| startDate | String | ❌ | 起始日期（默认：最近30天） | `2025-11-01` |
| endDate | String | ❌ | 结束日期（默认：今天） | `2025-11-30` |

**请求示例：**

```http
GET /api/pet/calendar?startDate=2025-11-01&endDate=2025-11-30
```

**响应示例：**

```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "eventDates": [
      "2025-11-01",
      "2025-11-03",
      "2025-11-05",
      "2025-11-20",
      "2025-11-21",
      "2025-11-22",
      "2025-11-23",
      "2025-11-24"
    ]
  }
}
```

**字段说明：**

| 字段 | 类型 | 说明 |
|-----|------|------|
| eventDates | Array | 有事件的日期列表（格式：yyyy-MM-dd） |

**错误码：**

| ret | 说明 |
|-----|------|
| 0 | 成功 |
| -1 | 日期格式错误 |

---

## 4. 设置页面接口

### 4.1 获取宠物列表（详细信息）

**接口描述：** 获取宠物详细信息（用于设置页面展示）。

**请求方式：** `GET`

**接口路径：** `/api/pet/list-detail`

**请求参数：** 无

**请求示例：**

```http
GET /api/pet/list-detail
```

**响应示例：**

```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "pets": [
      {
        "petId": "001",
        "petName": "栗子",
        "petType": "狸花猫",
        "weight": "4.2kg",
        "features": "短毛，全身覆盖黑灰相间的经典斑纹，腹部毛色较浅，四肢有环状纹路。",
        "avatarColor": "#E5E7EB"
      },
      {
        "petId": "002",
        "petName": "奶油",
        "petType": "金渐层长毛",
        "weight": "5.5kg",
        "features": "长毛，背部呈现金渐层色，面部圆润，耳尖有少量聪明毛，尾巴蓬松。",
        "avatarColor": "#FEF3C7"
      }
    ]
  }
}
```

**字段说明：**

| 字段 | 类型 | 说明 |
|-----|------|------|
| pets | Array | 宠物列表 |
| pets[].petId | String | 宠物ID |
| pets[].petName | String | 宠物名字 |
| pets[].petType | String | 品种（可为空） |
| pets[].weight | String | 体重（可为空，如：4.2kg） |
| pets[].features | String | 外观特征（可为空） |
| pets[].avatarColor | String | 头像背景色（Hex格式） |

**错误码：**

| ret | 说明 |
|-----|------|
| 0 | 成功 |
| -1 | 获取失败 |

---

### 4.2 更新宠物信息

**接口描述：** 更新已存在的宠物信息。

**请求方式：** `POST`

**接口路径：** `/api/pet/update`

**请求参数：**

| 参数名 | 类型 | 必填 | 说明 | 示例 |
|-------|------|------|------|------|
| petId | String | ✅ | 宠物ID | `001` |
| petName | String | ❌ | 宠物名字 | `栗子` |
| petType | String | ❌ | 品种 | `狸花猫` |
| weight | String | ❌ | 体重 | `4.5kg` |
| features | String | ❌ | 外观特征 | `短毛，黑灰斑纹...` |

**请求示例：**

```http
POST /api/pet/update
Content-Type: application/json

{
  "petId": "001",
  "petName": "栗子",
  "petType": "狸花猫",
  "weight": "4.5kg",
  "features": "短毛，黑灰斑纹，活泼好动"
}
```

**响应示例：**

```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "petId": "001",
    "petName": "栗子",
    "petType": "狸花猫",
    "weight": "4.5kg",
    "features": "短毛，黑灰斑纹，活泼好动",
    "avatarColor": "#E5E7EB",
    "updateTime": 1707028800
  }
}
```

**字段说明：**

| 字段 | 类型 | 说明 |
|-----|------|------|
| petId | String | 宠物ID |
| petName | String | 宠物名字 |
| petType | String | 品种 |
| weight | String | 体重 |
| features | String | 外观特征 |
| avatarColor | String | 头像背景色（Hex格式） |
| updateTime | Integer | 更新时间（Unix时间戳） |

**错误码：**

| ret | 说明 |
|-----|------|
| 0 | 成功 |
| -1 | 宠物ID不存在 |
| -2 | 参数错误 |

---

### 4.3 添加宠物

**接口描述：** 添加新宠物。

**请求方式：** `POST`

**接口路径：** `/api/pet/add`

**请求参数：**

| 参数名 | 类型 | 必填 | 说明 | 示例 |
|-------|------|------|------|------|
| petName | String | ✅ | 宠物名字 | `小白` |
| petType | String | ❌ | 品种 | `英短` |
| weight | String | ❌ | 体重 | `5.5kg` |
| features | String | ❌ | 外观特征 | `长毛，白色，蓝眼睛` |
| avatarColor | String | ❌ | 头像背景色（前端随机生成） | `#E5E7EB` |

**请求示例：**

```http
POST /api/pet/add
Content-Type: application/json

{
  "petName": "小白",
  "petType": "英短",
  "weight": "5.5kg",
  "features": "长毛，白色，蓝眼睛",
  "avatarColor": "#DBEAFE"
}
```

**响应示例：**

```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "petId": "003",
    "petName": "小白",
    "petType": "英短",
    "weight": "5.5kg",
    "features": "长毛，白色，蓝眼睛",
    "avatarColor": "#DBEAFE",
    "createTime": 1707028800
  }
}
```

**字段说明：**

| 字段 | 类型 | 说明 |
|-----|------|------|
| petId | String | 宠物ID（服务端生成） |
| petName | String | 宠物名字 |
| petType | String | 品种 |
| weight | String | 体重 |
| features | String | 外观特征 |
| avatarColor | String | 头像背景色（Hex格式） |
| createTime | Integer | 创建时间（Unix时间戳） |

**错误码：**

| ret | 说明 |
|-----|------|
| 0 | 成功 |
| -1 | 宠物名称不能为空 |
| -2 | 已达到宠物数量上限 |
| -3 | 宠物名称已存在 |

---

### 4.4 绑定设备

**接口描述：** 通过二维码绑定智能摄像头等设备。

**请求方式：** `POST`

**接口路径：** `/api/device/bind`

**请求参数：**

| 参数名 | 类型 | 必填 | 说明 | 示例 |
|-------|------|------|------|------|
| qrCode | String | ✅ | 二维码内容 | `DEVICE_12345_ABCDEF` |

**请求示例：**

```http
POST /api/device/bind
Content-Type: application/json

{
  "qrCode": "DEVICE_12345_ABCDEF"
}
```

**响应示例：**

```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "deviceId": "DEVICE_12345",
    "deviceName": "智能摄像头-客厅",
    "deviceType": "camera",
    "bindTime": 1707028800
  }
}
```

**字段说明：**

| 字段 | 类型 | 说明 |
|-----|------|------|
| deviceId | String | 设备ID |
| deviceName | String | 设备名称 |
| deviceType | String | 设备类型（camera/feeder等） |
| bindTime | Integer | 绑定时间（Unix时间戳） |

**错误码：**

| ret | 说明 |
|-----|------|
| 0 | 成功 |
| -1 | 二维码无效 |
| -2 | 设备已被绑定 |
| -3 | 设备不存在 |

---

## 5. 数据模型

### 5.1 宠物信息模型（PetInfo）

```typescript
interface PetInfo {
  petId: string;           // 宠物ID
  petName: string;         // 宠物名字
  petType?: string;        // 品种（可选）
  weight?: string;         // 体重（可选，如：4.2kg）
  features?: string;       // 外观特征（可选）
  avatarColor: string;     // 头像背景色（Hex格式）
  dailyTag?: string;       // 今日标签（仅在日报中返回）
  dailyReport?: string;    // 日报内容（仅在日报中返回）
}
```

### 5.2 事件模型（Event）

```typescript
interface Event {
  eventId: string;         // 事件ID
  eventTime: string;       // 事件时间（格式：HH:mm）
  petName: string;         // 宠物名（可以是"双猫"）
  actions: string[];       // 行为标签数组
  eventDesc: string;       // 详细描述
  aiStatus: string;        // AI判断
  videoUrl: string;        // 视频URL
  videoTime: number;       // 视频起始时间点（秒）
  thumbnailColor: string;  // 缩略图背景色（Hex格式）
  thumbnailUrl?: string;   // 缩略图URL（可选）
}
```

### 5.3 日报响应模型（DailyReportResponse）

```typescript
interface DailyReportResponse {
  date: string;            // 日期（格式：yyyy-MM-dd）
  petReports: PetInfo[];   // 宠物日报列表
  events: Event[];         // 事件列表（按时间倒序）
}
```

### 5.4 设备信息模型（DeviceInfo）

```typescript
interface DeviceInfo {
  deviceId: string;        // 设备ID
  deviceName: string;      // 设备名称
  deviceType: string;      // 设备类型（camera/feeder等）
  bindTime: number;        // 绑定时间（Unix时间戳）
}
```

---

## 6. 错误码规范

### 6.1 通用错误码

| ret | 说明 |
|-----|------|
| 0 | 成功 |
| -999 | 系统错误 |
| -998 | 网络错误 |
| -997 | 参数错误 |
| -996 | 数据解析失败 |

### 6.3 业务错误码

| ret | 说明 |
|-----|------|
| -1 | 通用业务错误 |
| -2 | 资源不存在 |
| -3 | 资源已存在 |
| -4 | 权限不足 |
| -5 | 数量超限 |

---

## 7. Mock 数据示例

### 7.1 日报数据 Mock

**文件：** `daily-report.json`

```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "date": "2025-11-24",
    "petReports": [
      {
        "petId": "001",
        "petName": "栗子",
        "petType": "狸花猫",
        "weight": "4.2kg",
        "features": "短毛，全身覆盖黑灰相间的经典斑纹，腹部毛色较浅，四肢有环状纹路。",
        "avatarColor": "#E5E7EB",
        "dailyTag": "精力过剩",
        "dailyReport": "06:30 进行了高强度的活动（跑酷）。全天饮食饮水正常。注意：23:09 检测到多猫互动（追逐）。"
      }
    ],
    "events": [
      {
        "eventId": "24-1",
        "eventTime": "14:30",
        "petName": "奶油",
        "actions": ["活动", "多猫互动"],
        "eventDesc": "奶油在客厅地面悠闲地巡视了一圈，随后轻快地跳上猫爬架。",
        "aiStatus": "状态非常活泼，探索欲满满。",
        "videoUrl": "https://cdn.example.com/video/event_24_1.mp4",
        "videoTime": 0,
        "thumbnailColor": "#FEF3C7",
        "thumbnailUrl": "https://cdn.example.com/thumb/event_24_1.jpg"
      }
    ]
  }
}
```

### 7.2 宠物列表 Mock

**文件：** `pet-list.json`

```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "pets": [
      {
        "petId": "001",
        "petName": "栗子",
        "avatarColor": "#E5E7EB"
      },
      {
        "petId": "002",
        "petName": "奶油",
        "avatarColor": "#FEF3C7"
      }
    ]
  }
}
```

### 7.3 日历信息 Mock

**文件：** `calendar-info.json`

```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "eventDates": [
      "2025-11-20",
      "2025-11-21",
      "2025-11-22",
      "2025-11-23",
      "2025-11-24"
    ]
  }
}
```

---

## 8. 视频流服务器配置要求

### 8.1 HTTP Range 支持（⚠️ 重要）

iOS 播放器 **必须** 要求服务器支持 HTTP Range 请求，否则会出现黑屏问题。

**正确的服务器响应：**

```http
HTTP/1.1 206 Partial Content
Content-Type: video/mp4
Content-Length: 1048576
Accept-Ranges: bytes
Content-Range: bytes 0-1048575/10485760
```

**错误的服务器响应：**

```http
HTTP/1.1 200 OK
Content-Type: video/mp4
Content-Length: 10485760
```

### 8.2 视频编码要求

| 编码格式 | iOS 支持 | 说明 |
|---------|---------|------|
| H.264 (avc1) | ✅ | 完全支持，推荐使用 |
| HEVC (hvc1) | ✅ | iOS 11+ 支持 |
| HEVC (hev1) | ❌ | **不支持**，iOS 无法播放 |

**推荐转码命令：**

```bash
# H.264 编码 (最佳兼容性)
ffmpeg -i input.mp4 \
  -c:v libx264 -preset medium -crf 23 \
  -c:a aac -b:a 128k \
  -movflags +faststart \
  output.mp4

# HEVC 编码 (hvc1 tag, 更高压缩率)
ffmpeg -i input.mp4 \
  -c:v libx265 -preset medium -crf 28 \
  -c:a aac -b:a 128k \
  -tag:v hvc1 \
  -movflags +faststart \
  output.mp4
```

### 8.3 服务器端实现示例（Node.js + Express）

```javascript
const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();

app.get('/api/video/stream', (req, res) => {
  const videoPath = path.join(__dirname, 'videos', 'event_24_1.mp4');
  const stat = fs.statSync(videoPath);
  const fileSize = stat.size;
  const range = req.headers.range;

  if (range) {
    // 支持 Range 请求
    const parts = range.replace(/bytes=/, "").split("-");
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
    const chunksize = (end - start) + 1;
    const file = fs.createReadStream(videoPath, { start, end });
    const head = {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': 'video/mp4',
    };
    res.writeHead(206, head);
    file.pipe(res);
  } else {
    // 不支持 Range 请求
    const head = {
      'Content-Length': fileSize,
      'Content-Type': 'video/mp4',
    };
    res.writeHead(200, head);
    fs.createReadStream(videoPath).pipe(res);
  }
});

app.listen(8006, () => {
  console.log('视频服务器运行在 http://localhost:8006');
});
```

---

## 9. 前端调用示例

### 9.1 Objective-C 调用示例

```objective-c
#import "DFHomeRequest.h"

// 获取日报数据
DFHomeRequest *request = [[DFHomeRequest alloc] init];
[request fetchDailyReportWithDate:@"2025-11-24"
                           petId:@"001"
                      completion:^(DFDailyReportResponseModel * _Nullable model, NSError * _Nullable error) {
    if (error) {
        NSLog(@"❌ 获取日报失败: %@", error);
        return;
    }
    
    NSLog(@"✅ 获取日报成功，宠物数: %lu", model.petReports.count);
    // 更新UI
}];

// 添加宠物
DFMyHomeRequest *myHomeRequest = [[DFMyHomeRequest alloc] init];
DFPetInfoModel *pet = [[DFPetInfoModel alloc] init];
pet.petName = @"小白";
pet.petType = @"英短";
pet.weight = @"5.5kg";

[myHomeRequest savePetInfo:pet completion:^(BOOL success, NSError * _Nullable error) {
    if (success) {
        NSLog(@"✅ 添加宠物成功");
    } else {
        NSLog(@"❌ 添加宠物失败: %@", error);
    }
}];
```

---

## 10. 附录

### 10.1 Mock 数据文件路径

```
DXMPetGuard/Resources/MockData/
├── daily-report.json      # 日报数据
├── pet-list.json          # 宠物列表
└── calendar-info.json     # 日历信息
```

### 10.2 前端请求类文件路径

```
DXMPetGuard/Module/
├── Home/Request/
│   ├── DFHomeRequest.h
│   └── DFHomeRequest.m
└── MyHome/Request/
    ├── DFMyHomeRequest.h
    └── DFMyHomeRequest.m
```

### 10.3 数据模型文件路径

```
DXMPetGuard/Module/Home/Model/
├── DFPetInfoModel.h
├── DFPetEventModel.h
└── DFDailyReportResponseModel.h
```

---

## 11. 联系方式

如有接口问题，请联系：

- **前端负责人：** TJL
- **后端负责人：** （待定）

---

**文档版本：** v1.0  
**最后更新：** 2026-02-04  
**文档状态：** ✅ 已完成

