# Service API 适配 App 端需求 - 实施方案

> 更新时间：2026-02-04  
> 状态：Phase 1 已完成，Phase 2-5 待实施

---

## ✅ Phase 1: 响应格式工具类（已完成）

### 完成内容

1. **创建 AppResponse 类** (`service/response.py`)
   ```python
   class AppResponse:
       @staticmethod
       def success(data=None, ret_msg="success"):
           return {"ret": 0, "ret_msg": ret_msg, "data": data}
       
       @staticmethod
       def error(ret_msg, ret=-1):
           return {"ret": ret, "ret_msg": ret_msg, "data": None}
   ```

2. **定义 App 端错误码**
   ```python
   class AppErrorCode:
       SUCCESS = 0
       GENERAL_ERROR = -1
       NOT_FOUND = -2
       ALREADY_EXISTS = -3
       NO_PERMISSION = -4
       LIMIT_EXCEEDED = -5
       SYSTEM_ERROR = -999
   ```

---

## 🔄 Phase 2: 宠物接口调整（待实施）

### 2.1 调整宠物列表（简化版）

**接口:** `GET /pet/api/pet/list`

**需要修改:**
```python
# 当前返回
{
  "ret": "0",
  "ret_msg": "ok",
  "pets": [{
    "did": "12345",
    "pet_name": "大黄",
    "pet_type": "狗",
    ...全部字段
  }],
  "total": 1
}

# App期望返回
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "pets": [{
      "petId": "001",
      "petName": "栗子",
      "avatarColor": "#E5E7EB"
    }]
  }
}
```

**实施步骤:**
1. 修改响应格式使用 `AppResponse.success()`
2. 添加字段映射函数 `_map_pet_to_app_format()`
3. 添加 `avatarColor` 字段（从 pet 数据生成或存储）
4. 只返回简化字段（petId, petName, avatarColor）

---

### 2.2 新增宠物列表（详细版）

**接口:** `GET /pet/api/pet/list-detail`（新增）

**返回格式:**
```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "pets": [{
      "petId": "001",
      "petName": "栗子",
      "petType": "狸花猫",
      "weight": "4.2kg",
      "features": "短毛，黑灰斑纹...",
      "avatarColor": "#E5E7EB"
    }]
  }
}
```

**实施步骤:**
1. 新增路由 `@sub_app.get("/api/pet/list-detail")`
2. 复用 `get_pet_list()` 的查询逻辑
3. 返回完整宠物信息
4. 字段映射：
   - `petId` ← `did`
   - `petName` ← `pet_name`
   - `petType` ← `breed`
   - `weight` ← 需要数据库新增字段
   - `features` ← `description`
   - `avatarColor` ← 需要新增

---

### 2.3 调整添加宠物接口

**接口:** `POST /pet/api/pet/add`

**请求参数调整:**
```json
// App 发送
{
  "petName": "小白",
  "petType": "英短",
  "weight": "5.5kg",
  "features": "长毛，白色",
  "avatarColor": "#DBEAFE"
}

// 需要映射到
{
  "pet_name": "小白",
  "breed": "英短",
  "weight": "5.5kg",  // 新字段
  "description": "长毛，白色",
  "avatar_color": "#DBEAFE"  // 新字段
}
```

**实施步骤:**
1. 修改请求模型支持 App 字段
2. 添加字段映射逻辑
3. 存储 `weight` 和 `avatar_color`
4. 响应格式改为 `AppResponse.success()`
5. 返回生成的 `petId`

---

### 2.4 调整更新宠物接口

**接口:** `POST /pet/api/pet/update`（路径参数改为body参数）

**请求参数调整:**
```json
// App 发送
{
  "petId": "001",
  "petName": "栗子",
  "petType": "狸花猫",
  "weight": "4.5kg",
  "features": "短毛，黑灰斑纹"
}
```

**实施步骤:**
1. 修改路由从 `/update/{pet_name}` 改为 `/update`
2. 支持 `petId` 参数（映射到数据库查询）
3. 添加字段映射
4. 响应格式改为 `AppResponse.success()`

---

## 🆕 Phase 3: 新增接口（待实施）

### 3.1 日历信息接口

**接口:** `GET /pet/api/pet/calendar`（全新）

**请求参数:**
- `startDate` (可选): 起始日期，格式 yyyy-MM-dd
- `endDate` (可选): 结束日期，格式 yyyy-MM-dd

**返回格式:**
```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "eventDates": [
      "2025-11-01",
      "2025-11-03",
      "2025-11-05"
    ]
  }
}
```

**实施步骤:**
1. 新增路由 `@sub_app.get("/api/pet/calendar")`
2. 查询 `video_records` 表的 `recorded_at` 字段
3. 按日期去重分组
4. 返回日期字符串数组
5. SQL示例：
   ```sql
   SELECT DISTINCT DATE(recorded_at) as event_date
   FROM video_records
   WHERE did = ?
     AND recorded_at BETWEEN ? AND ?
   ORDER BY event_date DESC
   ```

---

### 3.2 设备绑定接口

**接口:** `POST /pet/api/device/bind`（全新）

**请求参数:**
```json
{
  "qrCode": "DEVICE_12345_ABCDEF"
}
```

**返回格式:**
```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "deviceId": "DEVICE_12345",
    "deviceName": "智能摄像头-客厅",
    "deviceType": "camera",
    "bindTime": 1707028800
  }
}
```

**实施步骤:**
1. 新增路由 `@sub_app.post("/api/device/bind")`
2. 解析二维码内容（提取 deviceId）
3. 调用现有的 `camera/add` 接口逻辑
4. 返回设备信息
5. 二维码格式示例：`DEVICE_{deviceId}_{token}`

---

## 🔧 Phase 4: 日报接口增强（待实施）

### 4.1 调整日报接口

**接口:** `GET /pet/api/daily-report`

**请求参数调整:**
- `date` (必填): yyyy-MM-dd
- `petId` (可选): 宠物ID

**返回格式调整:**
```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "date": "2025-11-24",
    "petReports": [{
      "petId": "001",
      "petName": "栗子",
      "petType": "狸花猫",
      "weight": "4.2kg",
      "features": "短毛，黑灰斑纹",
      "avatarColor": "#E5E7EB",
      "dailyTag": "精力过剩",
      "dailyReport": "06:30 进行了高强度的活动..."
    }],
    "events": [{
      "eventId": "24-1",
      "eventTime": "14:30",
      "petName": "奶油",
      "actions": ["活动", "多猫互动"],
      "eventDesc": "奶油在客厅...",
      "aiStatus": "状态非常活泼...",
      "videoUrl": "https://...",
      "videoTime": 0,
      "thumbnailColor": "#FEF3C7",
      "thumbnailUrl": "https://..."
    }]
  }
}
```

**实施步骤:**
1. 修改响应格式使用 `AppResponse.success()`
2. 整合 `petReports` 部分（从 daily_reports 表）
3. 整合 `events` 部分（从 video_records 表）
4. 添加字段映射
5. 支持 `petId` 参数筛选
6. 查询逻辑：
   ```python
   # 查询日报
   daily_reports = db.query(DailyReport).filter(
       DailyReport.date == date,
       DailyReport.did == user_did
   ).all()
   
   # 查询视频事件
   video_events = db.query(VideoRecord).filter(
       VideoRecord.recorded_at.startswith(date),
       VideoRecord.did == user_did,
       VideoRecord.llm_status == 'completed'
   ).all()
   ```

---

## 🔍 Phase 5: 测试验证（待实施）

### 5.1 接口测试清单

| 接口 | 方法 | 路径 | 测试点 |
|------|------|------|--------|
| 宠物列表（简化） | GET | `/pet/api/pet/list` | 响应格式、字段映射、avatarColor |
| 宠物列表（详细） | GET | `/pet/api/pet/list-detail` | 完整字段、weight、features |
| 日历信息 | GET | `/pet/api/pet/calendar` | 日期数组、范围筛选 |
| 添加宠物 | POST | `/pet/api/pet/add` | 字段映射、petId生成 |
| 更新宠物 | POST | `/pet/api/pet/update` | petId参数、字段更新 |
| 设备绑定 | POST | `/pet/api/device/bind` | 二维码解析、设备信息返回 |
| 日报数据 | GET | `/pet/api/daily-report` | petReports、events整合 |

### 5.2 测试脚本示例

```bash
# 测试宠物列表（简化）
curl "http://localhost:8006/pet/api/pet/list" \
  -H "Cookie: OPENBDUSS=xxx; STOKEN=xxx"

# 期望响应
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "pets": [{"petId": "001", "petName": "栗子", "avatarColor": "#E5E7EB"}]
  }
}

# 测试日历信息
curl "http://localhost:8006/pet/api/pet/calendar?startDate=2025-11-01&endDate=2025-11-30" \
  -H "Cookie: OPENBDUSS=xxx; STOKEN=xxx"

# 期望响应
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "eventDates": ["2025-11-01", "2025-11-03", "2025-11-05"]
  }
}
```

---

## 📊 数据库字段调整需求

### 需要新增的字段

#### pets 表
```sql
ALTER TABLE pets ADD COLUMN weight VARCHAR(20);  -- 体重，如 "4.2kg"
ALTER TABLE pets ADD COLUMN avatar_color VARCHAR(10);  -- 头像背景色，如 "#E5E7EB"
```

### 字段映射表

| App字段 | 数据库字段 | 说明 |
|---------|-----------|------|
| petId | did | 宠物ID（当前用did） |
| petName | pet_name | 宠物名称 |
| petType | breed | 品种 |
| weight | weight | 体重（新增） |
| features | description | 外观特征 |
| avatarColor | avatar_color | 头像背景色（新增） |

---

## 🎯 实施进度

| Phase | 任务 | 状态 | 预计时间 |
|-------|------|------|---------|
| Phase 1 | 响应格式工具类 | ✅ 已完成 | - |
| Phase 2 | 宠物接口调整 | ⏳ 待实施 | 1小时 |
| Phase 3 | 新增接口 | ⏳ 待实施 | 1.5小时 |
| Phase 4 | 日报接口增强 | ⏳ 待实施 | 1小时 |
| Phase 5 | 测试验证 | ⏳ 待实施 | 30分钟 |

**总计:** 约 4 小时

---

## 🚨 注意事项

1. **数据库迁移**: 需要先执行 SQL 添加 `weight` 和 `avatar_color` 字段
2. **向后兼容**: 如果有其他调用方，需要考虑向后兼容性
3. **petId 映射**: 当前用 `did` 作为 petId，需确认是否合适
4. **avatarColor 生成**: 如果数据库中没有，需要有默认生成逻辑
5. **视频 events**: 需要从 video_records 表查询并映射字段

---

## 📚 相关文档

- App端接口文档: `service/appdoc/API接口文档.md`
- App端快速参考: `service/appdoc/接口快速参考.md`
- 开发检查清单: `service/appdoc/后端开发检查清单.md`
