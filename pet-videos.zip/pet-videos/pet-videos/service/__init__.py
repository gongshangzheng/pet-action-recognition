"""
Pet-Videos Service 模块
提供独立的 API 服务，支持登录态校验
"""

__version__ = "1.0.0"
