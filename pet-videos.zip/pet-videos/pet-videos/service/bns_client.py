"""
BNS服务请求客户端 - 同步版本
支持通过BNS服务发现机制进行负载均衡请求

直连模式：若 service_name 包含端口号（如 "10.33.77.183:8331"），
则跳过BNS解析，直接使用该地址发起请求，便于测试环境联调。
"""

from noah_python_sdk.clients import BNSClient, BNSGroupHttpClient
import requests
import random
import re
from typing import Dict, Any


def _is_direct_address(service_name: str) -> bool:
    """判断是否为直连地址（host:port 格式，含端口号则跳过BNS解析）"""
    return bool(re.search(r':\d+$', service_name))


class BNSServiceClient:
    """BNS服务请求客户端（同步版本）"""
    
    def __init__(self):
        self.bns_client = BNSClient()
        self.bns_client.bns_group_clients = [BNSGroupHttpClient()]
    
    def request(
        self,
        service_name: str,
        api_path: str,
        uri: str,
        params: dict,
        method: str = "POST",
        timeout: int = 5,
        verbose: bool = True
    ) -> Dict[str, Any]:
        """
        通过BNS服务发送请求（同步方式）
        
        Args:
            service_name: BNS服务名（如 "smart.group.user-service.licai-licai"）
                          或直连地址（如 "10.33.77.183:8331"，含端口则跳过BNS解析）
            api_path: API路径，如 "/user/getSessionInfo"
            uri: 当前接口URI（业务上下文路径），传空字符串则不注入到请求参数
            params: 请求参数字典
            method: 请求方法（GET/POST），默认POST
            timeout: 超时时间（秒），默认5秒
            verbose: 是否打印详细日志，默认True
            
        Returns:
            {
                "success": True/False,
                "data": 响应数据,
                "error": 错误信息,
                "status_code": HTTP状态码,
                "instance": "ip:port"  # 实际请求的实例
            }
        """
        instance_info = None
        try:
            # 1. 解析服务实例地址
            if _is_direct_address(service_name):
                # 直连模式：跳过BNS解析
                url = f"http://{service_name}{api_path}"
                instance_info = service_name
                if verbose:
                    print(f"[BNS直连请求] 直连: {service_name}（跳过BNS解析）")
                    print(f"[BNS直连请求] URL: {url}")
                    print(f"[BNS直连请求] 方法: {method}")
            else:
                # BNS模式：通过服务发现获取实例
                instances = self.bns_client.get_instances_by_service(
                    service_name,
                    True
                )
                
                if not instances:
                    return {
                        "success": False,
                        "error": f"未找到可用的服务实例: {service_name}",
                        "data": None,
                        "status_code": None,
                        "instance": None
                    }
                
                instance = random.choice(instances)
                url = f"http://{instance.ip}:{instance.port}{api_path}"
                instance_info = f"{instance.ip}:{instance.port}"
                
                if verbose:
                    print(f"[BNS请求] 服务: {service_name}")
                    print(f"[BNS请求] 实例: {instance_info}")
                    print(f"[BNS请求] URL: {url}")
                    print(f"[BNS请求] URI: {uri}")
                    print(f"[BNS请求] 方法: {method}")
            
            # 2. 构建请求参数（uri 非空时才注入）
            request_params = params.copy()
            if uri and 'uri' not in request_params:
                request_params['uri'] = uri
            
            # 3. 发送请求（同步）
            if method.upper() == "POST":
                response = requests.post(
                    url, 
                    json=request_params, 
                    timeout=timeout
                )
            elif method.upper() == "GET":
                response = requests.get(
                    url, 
                    params=request_params, 
                    timeout=timeout
                )
            else:
                return {
                    "success": False,
                    "error": f"不支持的请求方法: {method}",
                    "data": None,
                    "status_code": None,
                    "instance": instance_info
                }
            
            # 4. 处理响应
            if verbose:
                print(f"[BNS响应] 状态码: {response.status_code}")
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    return {
                        "success": True,
                        "data": data,
                        "error": None,
                        "status_code": response.status_code,
                        "instance": instance_info
                    }
                except Exception as e:
                    return {
                        "success": False,
                        "data": None,
                        "error": f"JSON解析失败: {str(e)}",
                        "status_code": response.status_code,
                        "instance": instance_info
                    }
            else:
                return {
                    "success": False,
                    "data": None,
                    "error": f"HTTP {response.status_code}: {response.text[:200]}",
                    "status_code": response.status_code,
                    "instance": instance_info
                }
                
        except requests.exceptions.Timeout:
            return {
                "success": False,
                "error": f"请求超时（{timeout}秒）",
                "data": None,
                "status_code": None,
                "instance": instance_info
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"请求失败: {str(e)}",
                "data": None,
                "status_code": None,
                "instance": instance_info
            }
    
    def get_session_info(
        self,
        open_bduss: str,
        uri: str = "/index.html",
        verbose: bool = True,
        **kwargs
    ) -> Dict[str, Any]:
        """
        便捷方法：获取会话信息
        
        Args:
            open_bduss: OpenBDUSS令牌
            uri: 当前接口URI，默认 "/index.html"
            verbose: 是否打印详细日志
            **kwargs: 其他参数（bduss, stoken, from, version, os, ua等）
        """
        params = {
            'openBduss': open_bduss,
            'bduss': kwargs.get('bduss', ''),
            'stoken': kwargs.get('stoken', None),
            'from': kwargs.get('from', 'pc'),
            'version': kwargs.get('version', '0.0.0'),
            'os': kwargs.get('os', 'windows'),
            'ua': kwargs.get('ua', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36')
        }
        
        return self.request(
            service_name="smart.group.user-service.licai-licai",
            api_path="/user/getSessionInfo",
            uri=uri,
            params=params,
            method="POST",
            timeout=5,
            verbose=verbose
        )


# 全局单例
_client = None


def get_bns_client() -> BNSServiceClient:
    """获取BNS客户端单例"""
    global _client
    if _client is None:
        _client = BNSServiceClient()
    return _client


def request_bns_service(
    service_name: str,
    api_path: str,
    uri: str,
    params: dict,
    method: str = "POST",
    timeout: int = 5,
    verbose: bool = True
) -> Dict[str, Any]:
    """
    便捷函数：通过BNS服务发送请求（同步方式）
    
    使用示例：
        result = request_bns_service(
            service_name="smart.group.user-service.licai-licai",
            api_path="/user/getSessionInfo",
            uri="/index.html",
            params={
                'openBduss': 'xxx',
                'bduss': '',
                'from': 'pc'
            }
        )
        
        if result['success']:
            print("成功:", result['data'])
        else:
            print("失败:", result['error'])
    """
    client = get_bns_client()
    return client.request(service_name, api_path, uri, params, method, timeout, verbose)
