#!/bin/bash
# 启动前端脚本

echo "启动 Pet Videos Analysis 前端..."

# 检查是否在项目根目录
if [ ! -d "frontend" ]; then
    echo "错误: 请在项目根目录运行此脚本"
    exit 1
fi

# 进入前端目录
cd frontend

# 检查依赖
if [ ! -d "node_modules" ]; then
    echo "依赖未安装，安装中..."
    npm install
fi

# 启动前端
echo "启动前端服务..."
echo "前端地址: http://localhost:5173"
npm run dev
