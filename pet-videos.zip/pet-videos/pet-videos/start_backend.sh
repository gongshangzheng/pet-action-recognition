#!/bin/bash
# 启动后端脚本

echo "启动 Pet Videos Analysis 后端..."

# 检查是否在项目根目录
if [ ! -d "backend" ]; then
    echo "错误: 请在项目根目录运行此脚本"
    exit 1
fi

# 检查 .env 文件
if [ ! -f ".env" ]; then
    echo "错误: .env 文件不存在，请先配置环境变量"
    echo "提示: cp env.example .env 然后编辑 .env 文件"
    exit 1
fi

# 进入后端目录
cd backend

# 检查虚拟环境
if [ ! -d "venv" ]; then
    echo "虚拟环境不存在，创建中..."
    python3 -m venv venv
    echo "虚拟环境创建完成"
fi

# 激活虚拟环境
echo "激活虚拟环境..."
source venv/bin/activate

# 检查依赖
if [ ! -f "venv/bin/uvicorn" ]; then
    echo "安装依赖..."
    pip install -r requirements.txt
fi

# 启动后端
echo "启动后端服务..."
echo "API 文档: http://localhost:8000/docs"
python main.py
