# 更新日志

## [v1.1.0] - 2026-01-15 - 安全加固版

### 🔒 安全改进

#### 视频流API安全加固
- **问题**：原实现存在严重安全隐患，前端可传递任意文件路径
- **修复**：
  - ✅ 使用加密Token代替明文路径
  - ✅ Token包含HMAC签名，防止篡改
  - ✅ 多层路径验证（存在性、类型、目录白名单）
  - ✅ 防止路径穿越攻击（`../`等）
  - ✅ 文件类型白名单（只允许视频格式）
  - ✅ 目录白名单（只允许配置目录内的文件）

#### 受影响的文件
**后端**：
- 新增：`backend/utils/security.py` - 安全工具模块
- 修改：`backend/api/videos.py` - 视频流API改用token验证
- 修改：`backend/services/video_service.py` - 生成stream_token
- 修改：`backend/models/schemas.py` - VideoInfo添加stream_token字段

**前端**：
- 修改：`frontend/src/types/index.ts` - VideoInfo类型添加stream_token
- 修改：`frontend/src/components/VideoList/index.tsx` - 使用stream_token播放
- 修改：`frontend/src/components/SliceStats/index.tsx` - 使用stream_token播放

**文档**：
- 新增：`SECURITY.md` - 安全特性说明文档

### 🔧 技术细节

#### Token格式
```
base64(path).signature
```
- 使用base64编码路径
- 使用SHA256生成16字符签名
- 签名密钥：`JWT_SECRET`环境变量

#### API变更
```
旧: GET /api/video/stream?path=/path/to/video.mp4
新: GET /api/video/stream?token=<encrypted_token>
```

#### 安全验证流程
1. Token解码和签名验证
2. 文件存在性验证
3. 文件类型验证（.mp4, .avi, .mkv等）
4. 目录白名单验证
5. 路径穿越检测

### 📝 升级说明

**对现有部署的影响**：
- ✅ 无需数据库迁移
- ✅ 无需修改历史数据
- ✅ 向后兼容（历史记录仍使用path）

**升级步骤**：
1. 备份现有数据
2. 更新代码
3. 确保 `.env` 包含 `JWT_SECRET`
4. 重启服务
5. 测试视频播放功能

### 🛠️ 部署工具改进

#### Windows部署脚本优化
- 修复：`start_backend.bat` - 改用127.0.0.1解决IPv6冲突
- 修复：`install.bat`、`package.bat`、`quick_deploy.bat` - GBK编码和CRLF换行
- 新增：`package.bat` - 源码打包脚本（仅打包源码，排除依赖）
- 新增：`quick_deploy.bat` - 快速部署脚本（用于更新代码）
- 新增：`DEPLOY.md` - 完整部署文档

#### 前端配置优化
- 修复：`vite.config.ts` - 使用127.0.0.1解决Windows IPv6连接问题
- 改进：增加详细的代理调试日志

### 🐛 Bug修复

#### 登录功能问题
- 修复：`.env` 文件编码问题导致密码验证失败
- 修复：前端401响应无限循环问题（改用自定义事件）
- 修复：Vite代理IPv6连接失败（强制使用IPv4）
- 新增：`backend/debug_login.py` - 登录调试工具
- 新增：`backend/fix_env_encoding.py` - 编码修复工具

#### 环境安装问题
- 修复：Windows上`uvloop`安装失败（移除不兼容依赖）
- 修复：Node.js版本兼容性（自动安装本地v18）
- 修复：FFmpeg自动安装脚本的路径处理
- 改进：虚拟环境损坏时自动重建

### 📦 打包和部署

#### 新增打包功能
- **源码打包**：只打包源码（约3MB），大幅减少上传时间
- **完整部署**：首次部署用`install.bat`自动安装所有依赖
- **快速更新**：已有环境用`quick_deploy.bat`快速更新代码

#### 文件大小对比
| 类型 | 大小 | 上传时间 | 适用场景 |
|------|------|---------|---------|
| 完整打包 | ~500MB | 10-30分钟 | ❌ 不推荐 |
| 源码打包 | ~3MB | <1分钟 | ✅ 推荐 |

---

## [v1.0.0] - 2026-01-13 - 初始版本

### ✨ 核心功能

#### 视频分析
- 支持多目录配置
- 视频列表浏览（分页）
- 视频预览播放
- 参数可调（FPS、Max/Min Pixels、高分辨率模式）
- 费用预估（显示详细Token计算）
- 实时分析（调用qwen3-vl-plus模型）
- 梯度定价（支持阿里云多档定价）

#### 历史记录
- 调用历史列表
- 详情查看
- 记录删除
- SQLite存储

#### 切片统计
- 按目录统计
- 按日期统计
- 点击日期查看当日视频列表
- 支持播放

#### 用户认证
- JWT Token认证
- 用户名密码登录
- 受保护的API路由
- Token过期处理

### 🏗️ 技术架构

**后端**：
- FastAPI框架
- SQLAlchemy ORM
- DashScope API集成
- FFmpeg视频信息提取
- JWT认证
- CORS支持

**前端**：
- React 18 + TypeScript
- Ant Design UI
- Vite构建工具
- Axios HTTP客户端
- 响应式设计

**数据库**：
- SQLite（历史记录）

**部署**：
- Windows Server支持
- 自动环境安装
- 服务管理脚本

### 📚 文档

- `README.md` - 项目介绍
- `QUICKSTART.md` - 快速开始
- `env.example` - 配置示例

---

**版本说明**：
- 主版本号：重大架构变更或不兼容更新
- 次版本号：新功能或重要改进
- 修订号：Bug修复和小改进
