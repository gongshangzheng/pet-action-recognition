@echo off
REM 数据库位置统一脚本 - Windows版本
REM 将backend/database/history.db迁移到根目录database/history.db

setlocal
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

echo ========================================
echo 数据库位置统一迁移
echo ========================================
echo.

REM 检查根目录数据库是否存在
if not exist "database\history.db" (
    echo [ERROR] 根目录数据库不存在: database\history.db
    echo 请先创建database目录并初始化数据库
    pause
    exit /b 1
)

REM 检查backend数据库是否存在
if not exist "backend\database\history.db" (
    echo [INFO] backend\database\history.db 不存在，无需迁移
    echo [INFO] 当前已使用根目录数据库
    goto verify
)

echo [1/4] 备份根目录数据库...
for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate=%%c%%a%%b)
for /f "tokens=1-2 delims=/: " %%a in ("%TIME: =0%") do (set mytime=%%a%%b)
set "BACKUP_FILE=database\history.db.backup_%mydate%_%mytime%"

copy "database\history.db" "%BACKUP_FILE%" >nul
if %errorlevel% neq 0 (
    echo [ERROR] 备份失败
    pause
    exit /b 1
)
echo       备份成功: %BACKUP_FILE%
echo.

echo [2/4] 比较两个数据库大小...
for %%A in ("database\history.db") do set size1=%%~zA
for %%A in ("backend\database\history.db") do set size2=%%~zA
echo       根目录数据库: %size1% bytes
echo       backend数据库: %size2% bytes
echo.

REM 比较大小，使用较大的数据库
if %size2% GTR %size1% (
    echo [INFO] backend数据库更大，将覆盖根目录数据库
    copy "backend\database\history.db" "database\history.db" >nul
    if %errorlevel% neq 0 (
        echo [ERROR] 复制失败
        pause
        exit /b 1
    )
    echo       复制成功
) else (
    echo [INFO] 根目录数据库已是最新，无需覆盖
)
echo.

echo [3/4] 重命名backend数据库目录...
for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate2=%%c%%a%%b)
for /f "tokens=1-2 delims=/: " %%a in ("%TIME: =0%") do (set mytime2=%%a%%b)
set "BACKUP_DIR=backend\database.backup_%mydate2%_%mytime2%"

move "backend\database" "%BACKUP_DIR%" >nul
if %errorlevel% neq 0 (
    echo [ERROR] 重命名失败
    pause
    exit /b 1
)
echo       重命名成功: %BACKUP_DIR%
echo.

:verify
echo [4/4] 验证数据库...
if not exist "database\history.db" (
    echo [ERROR] 根目录数据库不存在
    pause
    exit /b 1
)

REM 检查数据库是否可访问
sqlite3 "database\history.db" "SELECT COUNT(*) FROM sqlite_master WHERE type='table';" >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] 数据库损坏或无法访问
    echo 请从备份恢复: %BACKUP_FILE%
    pause
    exit /b 1
)

echo       数据库验证成功
echo.
echo ========================================
echo 迁移完成!
echo ========================================
echo.
echo 数据库位置: database\history.db
echo 备份位置: %BACKUP_FILE%
if exist "%BACKUP_DIR%" (
    echo 旧数据库: %BACKUP_DIR%
)
echo.
echo 下一步:
echo 1. 执行pets表ID迁移: backend\migrations\run_migration_002.bat
echo 2. 重启Backend服务: python backend\main.py
echo 3. 重启Service服务: python -m service.app
echo.

endlocal
pause
