# 数据库迁移快速开始

## 概述

本项目使用 **Python 脚本** 进行数据库迁移，统一跨平台操作方式。

## 前置要求

- Python 3.7+
- SQLite3

## 迁移列表

### 1. 统一数据库位置

将 `backend/database/history.db` 迁移到 `database/history.db`

### 2. Pets表添加自增ID

将pets表从联合主键改为自增ID主键

## 快速执行

### 完整迁移（推荐新环境）

在项目根目录执行：

```bash
# 步骤1：统一数据库位置
python3 backend/migrations/migrate_unify_database_location.py

# 步骤2：添加pets表ID
python3 backend/migrations/migrate_add_pets_id.py

# 步骤3：重启服务
# Backend
python3 backend/main.py

# Service（新终端）
python3 -m service.app
```

### Windows环境

```cmd
REM 步骤1：统一数据库位置
python backend\migrations\migrate_unify_database_location.py

REM 步骤2：添加pets表ID
python backend\migrations\migrate_add_pets_id.py

REM 步骤3：重启服务
python backend\main.py
python -m service.app
```

## 迁移脚本特性

### ✅ 自动检测

脚本会自动检测是否已经迁移，已迁移会跳过：

```bash
$ python3 backend/migrations/migrate_add_pets_id.py
==================================================
Pets 表自增ID迁移
==================================================

数据库路径: database/history.db
✓ 数据库已备份: database/history.db.backup_20260206_170640
✓ pets 表已经有 id 字段，无需迁移
```

### ✅ 自动备份

所有迁移执行前会自动创建备份：

```
database/history.db.backup_20260206_170640
backend/database.backup_20260206_170640
```

### ✅ 详细输出

清晰的步骤和进度提示：

```
[1/4] 备份根目录数据库...
     备份成功: database/history.db.backup_20260206_170640

[2/4] 比较数据库大小...
     根目录数据库: 393,216 bytes
     Backend数据库: 393,216 bytes

[3/4] 重命名 backend/database 目录...
     重命名成功: backend/database.backup_20260206_170640

[4/4] 验证迁移结果...
     ✓ 数据库表数量: 15
     ✓ 数据库大小: 393,216 bytes
```

### ✅ 错误恢复

失败时提供恢复指引：

```
❌ 迁移失败: [错误信息]

可以从备份恢复: database/history.db.backup_20260206_170640
```

## 验证迁移

### 验证数据库位置

```bash
# 检查文件是否存在
ls -l database/history.db

# 检查backend目录是否已重命名
ls backend/database  # 应该提示不存在
ls backend/database.backup_*  # 应该存在
```

### 验证pets表结构

```bash
sqlite3 database/history.db "PRAGMA table_info(pets);"
```

预期输出（第一个字段应该是id）：

```
0|id|INTEGER|0||1
1|did|VARCHAR(50)|1||0
2|pet_name|VARCHAR(100)|1||0
...
```

### 验证Backend API

```bash
# 查询宠物列表
curl "http://localhost:8002/api/internal/pets/?did=YOUR_DID"

# 通过ID查询
curl "http://localhost:8002/api/internal/pets/by-id/1?did=YOUR_DID"
```

预期返回包含 `"id": 1` 字段。

## 常见问题

### Q1: 如何指定数据库路径？

使用环境变量：

```bash
DATABASE_PATH=database/history.db python3 backend/migrations/migrate_xxx.py
```

或在 `.env` 文件中配置：

```bash
DATABASE_PATH=database/history.db
```

### Q2: 迁移失败了怎么办？

从自动创建的备份恢复：

```bash
# 查看备份文件
ls -lt database/history.db.backup_*

# 恢复最新备份
cp database/history.db.backup_YYYYMMDD_HHMMSS database/history.db
```

### Q3: 可以重复执行迁移吗？

可以。脚本具有幂等性，会自动检测是否已迁移：

```bash
# 重复执行是安全的
python3 backend/migrations/migrate_add_pets_id.py
# 输出: ✓ pets 表已经有 id 字段，无需迁移
```

### Q4: Windows环境路径问题

Python的pathlib会自动处理路径分隔符，无需担心 `/` 和 `\` 的区别。

### Q5: 迁移需要多久？

通常几秒钟内完成：
- 小数据库（<1MB）：< 1秒
- 中等数据库（1-10MB）：1-3秒
- 大数据库（10-100MB）：3-10秒

## 回滚方案

### 回滚pets表ID

```bash
# 从备份恢复
cp database/history.db.backup_YYYYMMDD_HHMMSS database/history.db
```

### 回滚数据库位置

```bash
# 恢复backend数据库目录
mv backend/database.backup_YYYYMMDD_HHMMSS backend/database
```

## 生产环境建议

1. **提前测试**：在开发/测试环境先执行验证
2. **停服维护**：迁移期间停止Backend和Service服务
3. **手动备份**：除自动备份外，手动备份一份数据库
4. **验证完整**：迁移后全面测试API接口
5. **保留备份**：至少保留最近3个备份文件

## 技术支持

如遇问题，提供以下信息：

1. 操作系统和Python版本
2. 执行的完整命令
3. 完整的错误输出
4. 数据库文件大小和位置
5. 备份文件列表

## 相关文档

- `backend/migrations/README.md` - 迁移脚本详细说明
- `MIGRATION_SUMMARY.md` - 迁移操作总结
- `DATABASE_MIGRATION_GUIDE.md` - 数据库位置统一指南
- `CHANGELOG_pets_id.md` - Pets表ID迁移变更日志
