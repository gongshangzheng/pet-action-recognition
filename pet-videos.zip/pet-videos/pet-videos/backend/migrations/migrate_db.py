"""数据库迁移脚本 - 添加 dir_alias 字段

用途：
将旧版本数据库（v1.1.x）迁移到新版本（v1.2.0）
添加 dir_alias 字段用于存储目录别名

使用：
python migrate_db.py
"""
import sqlite3
from pathlib import Path

def migrate_database():
    """执行数据库迁移"""
    db_path = Path("database/history.db")
    
    if not db_path.exists():
        print("✓ 数据库文件不存在，将在首次使用时自动创建新结构")
        return
    
    print(f"检查数据库: {db_path}")
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()
    
    try:
        # 检查表结构
        cursor.execute("PRAGMA table_info(analysis_history)")
        columns = [col[1] for col in cursor.fetchall()]
        
        # 检查是否已有 dir_alias 列
        if 'dir_alias' in columns:
            print("✓ dir_alias 列已存在，无需迁移")
            return
        
        # 检查记录数量
        cursor.execute("SELECT COUNT(*) FROM analysis_history")
        record_count = cursor.fetchone()[0]
        print(f"  当前历史记录: {record_count} 条")
        
        # 添加新列
        print("  添加 dir_alias 列...")
        cursor.execute("ALTER TABLE analysis_history ADD COLUMN dir_alias VARCHAR(100)")
        conn.commit()
        
        print("✓ 数据库迁移完成！")
        print(f"  • 保留了 {record_count} 条历史记录")
        print("  • 旧记录的 dir_alias 为 NULL")
        print("  • 新记录将自动保存别名")
        
    except sqlite3.OperationalError as e:
        if "duplicate column" in str(e):
            print("✓ dir_alias 列已存在")
        else:
            print(f"✗ 迁移失败: {e}")
            raise
    finally:
        conn.close()


if __name__ == "__main__":
    print("=" * 70)
    print("Pet-Videos 数据库迁移工具 (v1.1.x → v1.2.0)")
    print("=" * 70)
    print()
    
    migrate_database()
    
    print()
    print("=" * 70)
