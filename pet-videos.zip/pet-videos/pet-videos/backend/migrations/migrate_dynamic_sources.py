import sys
import os
from pathlib import Path

# 添加项目根目录到路径
base_dir = Path(__file__).resolve().parent.parent
sys.path.append(str(base_dir))
sys.path.append(str(base_dir / "backend"))

from backend.database.db import engine, SessionLocal, init_db
from backend.models.database import Base, StreamSource, SlicingTask
from backend.config import settings
from sqlalchemy import inspect

def migrate():
    # 1. 确保表存在
    print("Initializing database tables...")
    # init_db 会创建所有在 models.database 中定义的表
    init_db()
    
    # 2. 检查并迁移数据
    db = SessionLocal()
    try:
        # 检查表是否存在（有些 SQLAlchemy 版本 init_db 可能没自动创建新表，如果元数据没更新的话）
        inspector = inspect(engine)
        tables = inspector.get_table_names()
        print(f"Existing tables: {tables}")
        
        if 'stream_sources' not in tables:
            print("Table 'stream_sources' was not created. This shouldn't happen.")
            return

        source_count = db.query(StreamSource).count()
        if source_count == 0:
            print("Migrating static video directories to dynamic stream sources...")
            dirs_map = settings.get_video_dirs_map()
            for alias, path in dirs_map.items():
                # 检查是否已经存在该别名（防止重复）
                existing = db.query(StreamSource).filter(StreamSource.alias == alias).first()
                if not existing:
                    source = StreamSource(
                        name=f"摄像头_{alias}",
                        alias=alias,
                        stream_url="rtsp://placeholder_url",  # 静态配置中没有流地址，先用占位符
                        storage_path=path,
                        is_active=True
                    )
                    db.add(source)
                    print(f"Added source: {alias} -> {path}")
            db.commit()
            print(f"Successfully migrated {len(dirs_map)} sources.")
        else:
            print(f"Table 'stream_sources' already has {source_count} records. Skipping data migration.")
            
        # 3. 确保 slicing_tasks 表对应的初始任务记录（如果需要的话，目前可以先不加）
        
    except Exception as e:
        print(f"Migration failed: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    migrate()
