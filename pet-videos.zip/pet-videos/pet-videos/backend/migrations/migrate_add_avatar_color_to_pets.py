#!/usr/bin/env python3
"""
数据库迁移脚本：在 pets 表中添加 avatar_color 字段

执行方式：
python3 backend/migrations/migrate_add_avatar_color_to_pets.py
"""
import sqlite3
import sys
import os
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def get_db_path():
    """动态获取数据库路径"""
    # 优先使用环境变量
    db_path = os.environ.get('DATABASE_PATH')
    if db_path:
        return db_path
    
    # 尝试从配置文件读取
    try:
        from config import settings
        return settings.database_path
    except:
        # 默认路径
        return str(Path(__file__).parent.parent / 'database' / 'history.db')

def migrate():
    db_path = get_db_path()
    print(f"连接到数据库: {db_path}")
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 1. 检查 avatar_color 字段是否已存在
        cursor.execute("PRAGMA table_info(pets)")
        columns = [row[1] for row in cursor.fetchall()]
        
        if 'avatar_color' in columns:
            print("✅ avatar_color 字段已存在，无需迁移")
            return
        
        print("\n开始迁移...")
        
        # 2. 添加 avatar_color 字段（头像背景色）
        print("  - 添加 avatar_color 字段...")
        cursor.execute("""
            ALTER TABLE pets ADD COLUMN avatar_color VARCHAR(10)
        """)
        
        # 3. 设置默认值
        print("  - 设置默认值为 #E5E7EB...")
        cursor.execute("""
            UPDATE pets SET avatar_color = '#E5E7EB' WHERE avatar_color IS NULL
        """)
        
        conn.commit()
        print("\n✅ 迁移成功！")
        print("\n变更内容：")
        print("  - pets 表新增 avatar_color 字段（VARCHAR(10) 类型，可为空）")
        print("  - 默认值：#E5E7EB（灰色）")
        
    except Exception as e:
        conn.rollback()
        print(f"\n❌ 迁移失败: {e}")
        raise
    finally:
        conn.close()

if __name__ == '__main__':
    migrate()
