#!/usr/bin/env python3
"""
修复 migrate_unify_video_records.py 中缺失的 llm_retry_count 字段

这是一个临时补丁脚本，用于在服务器上快速修复迁移脚本
"""

import os
import sys
from pathlib import Path

def fix_migration_script():
    """修复迁移脚本"""
    script_path = Path(__file__).parent / "migrate_unify_video_records.py"
    
    if not script_path.exists():
        print(f"❌ 文件不存在: {script_path}")
        return False
    
    print(f"📂 修复文件: {script_path}")
    
    # 读取文件内容
    with open(script_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 检查是否已经修复
    if 'llm_retry_count' in content and 'llm_retry_count, llm_completed_at' in content:
        print("✅ 文件已经修复过了")
        return True
    
    # 旧的 INSERT 语句
    old_insert = """                    # 插入到 video_records
                    cursor.execute(\"\"\"
                        INSERT INTO video_records (
                            source_id, did, call_type,
                            file_name, file_path, duration,
                            prompt, model_name, analysis_fps,
                            max_pixels, min_pixels, vl_high_resolution_images,
                            input_tokens, output_tokens, total_tokens,
                            analysis_cost, analysis_duration_sec,
                            llm_raw_response, llm_result,
                            llm_status, llm_prompt_id, llm_analysis_id,
                            llm_completed_at, recorded_at, created_at, updated_at
                        ) VALUES (
                            0, '0', ?,
                            ?, ?, ?,
                            ?, ?, ?,
                            ?, ?, ?,
                            ?, ?, ?,
                            ?, ?,
                            ?, ?,
                            'completed', ?, ?,
                            ?, ?, ?, ?
                        )
                    \"\"\", (
                        call_type or 'manual',
                        video_name, video_path, duration_sec,
                        prompt, model_name, fps,
                        max_pixels, min_pixels, vl_high_resolution,
                        input_tokens, output_tokens, total_tokens,
                        cost, analysis_duration,
                        model_response, model_response,  # llm_raw_response 和 llm_result 都存
                        prompt_id, hist_id,
                        created_at, created_at, created_at, created_at
                    ))"""
    
    # 新的 INSERT 语句
    new_insert = """                    # 插入到 video_records
                    cursor.execute(\"\"\"
                        INSERT INTO video_records (
                            source_id, did, call_type,
                            file_name, file_path, duration,
                            prompt, model_name, analysis_fps,
                            max_pixels, min_pixels, vl_high_resolution_images,
                            input_tokens, output_tokens, total_tokens,
                            analysis_cost, analysis_duration_sec,
                            llm_raw_response, llm_result,
                            llm_status, llm_prompt_id, llm_analysis_id,
                            llm_retry_count, llm_completed_at, 
                            recorded_at, created_at, updated_at
                        ) VALUES (
                            0, '0', ?,
                            ?, ?, ?,
                            ?, ?, ?,
                            ?, ?, ?,
                            ?, ?, ?,
                            ?, ?,
                            ?, ?,
                            'completed', ?, ?,
                            0, ?,
                            ?, ?, ?
                        )
                    \"\"\", (
                        call_type or 'manual',
                        video_name, video_path, duration_sec,
                        prompt, model_name, fps,
                        max_pixels, min_pixels, vl_high_resolution,
                        input_tokens, output_tokens, total_tokens,
                        cost, analysis_duration,
                        model_response, model_response,  # llm_raw_response 和 llm_result 都存
                        prompt_id, hist_id,
                        created_at,
                        created_at, created_at, created_at
                    ))"""
    
    # 替换内容
    if old_insert in content:
        content = content.replace(old_insert, new_insert)
        
        # 备份原文件
        backup_path = script_path.with_suffix('.py.bak')
        with open(backup_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ 已备份原文件: {backup_path}")
        
        # 写入修复后的内容
        with open(script_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        print("✅ 修复完成！")
        print("\n修改内容:")
        print("  - 添加了 llm_retry_count 字段（默认值 0）")
        print("  - 调整了 VALUES 参数顺序")
        print("\n现在可以重新运行迁移:")
        print("  python migrations\\migrate_unify_video_records.py")
        return True
    else:
        print("⚠️  未找到需要修复的代码段")
        print("文件可能已经是新版本，或者格式不匹配")
        return False

if __name__ == '__main__':
    success = fix_migration_script()
    sys.exit(0 if success else 1)
