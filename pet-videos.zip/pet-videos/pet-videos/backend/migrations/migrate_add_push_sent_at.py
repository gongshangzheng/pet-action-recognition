"""
为 pet_behaviors 表添加 push_sent_at 字段的迁移脚本
用于记录 Push 推送时间，实现推送冷却机制
"""
import sqlite3
import os
from pathlib import Path

def get_db_path():
    """获取数据库路径"""
    # 支持环境变量配置
    db_path = os.getenv('DATABASE_PATH')
    if db_path:
        return db_path
    
    # 尝试从配置文件读取
    try:
        import sys
        current_dir = Path(__file__).parent.parent
        sys.path.insert(0, str(current_dir))
        from config import settings
        return settings.database_path
    except:
        # 默认路径
        current_dir = Path(__file__).parent.parent
        return str(current_dir / 'database' / 'history.db')

def migrate():
    """执行迁移"""
    db_path = get_db_path()
    print(f"数据库路径: {db_path}")
    
    if not os.path.exists(db_path):
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 检查表是否存在
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='pet_behaviors'
        """)
        
        if not cursor.fetchone():
            print("❌ pet_behaviors 表不存在，请先运行基础迁移")
            return False
        
        # 检查字段是否已存在
        cursor.execute("PRAGMA table_info(pet_behaviors)")
        columns = [row[1] for row in cursor.fetchall()]
        
        if 'push_sent_at' in columns:
            print("ℹ️  push_sent_at 字段已存在，跳过添加")
            return True
        
        # 添加 push_sent_at 字段
        print("为 pet_behaviors 表添加 push_sent_at 字段...")
        cursor.execute("""
            ALTER TABLE pet_behaviors 
            ADD COLUMN push_sent_at DATETIME
        """)
        
        # 创建索引（加速冷却查询）
        print("创建索引...")
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_pet_behaviors_push_sent 
            ON pet_behaviors(did, pet_name, push_sent_at)
        """)
        
        conn.commit()
        print("✅ push_sent_at 字段添加成功！")
        return True
        
    except Exception as e:
        conn.rollback()
        print(f"❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        conn.close()

if __name__ == '__main__':
    success = migrate()
    exit(0 if success else 1)
