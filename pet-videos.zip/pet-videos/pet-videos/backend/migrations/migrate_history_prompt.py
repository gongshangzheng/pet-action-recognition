"""
数据库迁移脚本：添加 analysis_history.prompt_id 和 prompt_name 字段
用于关联提示词信息到调用历史
"""
import sqlite3
import sys
from pathlib import Path

def migrate():
    """执行迁移"""
    db_path = Path(__file__).parent / 'database' / 'history.db'
    
    if not db_path.exists():
        print(f"⚠️  数据库文件不存在: {db_path}")
        print("   如果是新安装，数据库会在首次启动时自动创建")
        return
    
    print(f"连接数据库: {db_path}")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 检查字段是否存在
        cursor.execute("PRAGMA table_info(analysis_history)")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]
        
        changes = []
        
        if 'prompt_id' not in column_names:
            print("正在添加 prompt_id 字段...")
            cursor.execute("ALTER TABLE analysis_history ADD COLUMN prompt_id INTEGER")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_analysis_prompt_id ON analysis_history(prompt_id)")
            changes.append("prompt_id")
        
        if 'prompt_name' not in column_names:
            print("正在添加 prompt_name 字段...")
            cursor.execute("ALTER TABLE analysis_history ADD COLUMN prompt_name VARCHAR(100)")
            changes.append("prompt_name")
        
        if changes:
            conn.commit()
            cursor.execute("SELECT COUNT(*) FROM analysis_history")
            total = cursor.fetchone()[0]
            
            print(f"✅ 迁移完成")
            print(f"   • 添加了 {len(changes)} 个字段: {', '.join(changes)}")
            print(f"   • 现有 {total} 条历史记录未受影响")
            print(f"   • 旧记录的 prompt_id 和 prompt_name 为 NULL")
            print(f"   • 新记录会自动保存提示词信息")
        else:
            print("✓ 字段已存在，无需迁移")
        
    except Exception as e:
        print(f"❌ 迁移失败: {e}")
        conn.rollback()
        sys.exit(1)
    finally:
        conn.close()

if __name__ == '__main__':
    print("="*60)
    print("数据库迁移: 添加调用历史提示词关联")
    print("="*60)
    print()
    migrate()
    print()
    print("="*60)
