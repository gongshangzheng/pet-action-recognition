# 服务器数据库迁移指南

## 📋 迁移概述

本次迁移主要升级 `daily_reports` 表结构，以支持日报功能的 V2.0 和 V3.0 版本。

### 变更内容

#### V2.0 新增字段
- `daily_tag` VARCHAR(50) - 日报标签（如"精力过剩"、"岁月静好"）
- `insight_text` TEXT - 洞察建议（15字以内）

#### V3.0 新增字段
- `id` INTEGER PRIMARY KEY AUTOINCREMENT - 自增主键（替代原复合主键）
- `llm_request` TEXT - LLM原始请求内容
- `llm_response` TEXT - LLM原始响应内容
- `generation_status` VARCHAR(20) - 生成状态（completed/processing/failed）
- `error_message` TEXT - 错误信息
- `retry_count` INTEGER - 重试次数

### 主键变更
- **旧结构**：PRIMARY KEY (did, date, pet_name) - 复合主键，每天每宠物只能有一条记录
- **新结构**：PRIMARY KEY (id) - 自增主键，支持每天每宠物多条记录用于追踪

---

## 🚀 迁移步骤

### 方案选择

根据你的情况选择合适的部署方案：

| 方案 | 适用场景 | 优点 | 缺点 |
|------|---------|------|------|
| **方案A：直接部署已迁移文件** ⭐ | 本地已有从服务器下载的数据库 | 最简单、最快速、最安全 | 需要下载和上传数据库文件 |
| **方案B：服务器上执行迁移** | 无法下载服务器数据库 | 不需要传输文件 | 需要在服务器上执行脚本 |

---

## 方案A：直接部署已迁移文件（推荐）⭐

如果你已经下载了服务器数据库到本地并完成迁移，**这是最简单安全的方案**。

### 前置条件

1. ✅ 本地有 `backend/database/server/history.db`（从服务器下载）
2. ✅ 本地已执行迁移脚本完成升级
3. ✅ 数据完整性已验证

### 一键部署

```bash
# 在本地执行
cd backend/migrations
./deploy_database_file.sh user@your-server.com /path/to/pet-videos
```

脚本会自动：
1. ✅ 验证本地数据库结构（16个字段）
2. ✅ 在服务器上备份现有数据库
3. ✅ 停止服务器服务
4. ✅ 上传已迁移的数据库文件
5. ✅ 重启服务器服务
6. ✅ 验证服务状态

### 手动部署

如果不想用脚本，可以手动执行：

```bash
# 1. 上传数据库文件
scp backend/database/server/history.db user@server:/path/to/pet-videos/backend/database/history.db.new

# 2. 在服务器上操作
ssh user@server
cd /path/to/pet-videos/backend

# 备份
cp database/history.db database/history.db.backup_$(date +%Y%m%d_%H%M%S)

# 停止服务
pkill -f "python.*main.py"

# 替换数据库
mv database/history.db.new database/history.db

# 重启服务
nohup python3 main.py > logs/backend.log 2>&1 &
```

---

## 方案B：服务器上执行迁移

### 前置条件

1. **备份数据库**（重要！）
   ```bash
   # 在服务器上执行
   cp backend/database/history.db backend/database/history.db.backup_$(date +%Y%m%d_%H%M%S)
   ```

2. **检查数据库中 daily_reports 是否有重要数据**
   ```bash
   cd backend
   sqlite3 database/history.db "SELECT COUNT(*) FROM daily_reports;"
   ```
   
   - 如果返回 `0`，可以直接执行迁移
   - 如果有数据，请使用 `migrate_rebuild_daily_reports.py` 进行带数据迁移

### 步骤 1: 上传代码

将新代码（包含迁移脚本）上传到服务器：

```bash
# 本地执行
git push origin dev

# 服务器执行
cd /path/to/pet-videos
git pull origin dev
```

### 步骤 2: 停止服务

```bash
# 停止后端服务
pkill -f "python.*main.py" || true

# 或使用 systemd（如果配置了）
# sudo systemctl stop pet-videos-backend
```

### 步骤 3: 执行迁移

```bash
cd backend

# 执行迁移脚本（针对服务器数据库，表中无数据）
python3 migrations/migrate_server_daily_reports.py database/history.db
```

**预期输出**：
```
📂 数据库路径: database/history.db
⏰ 开始时间: 2026-02-12 11:03:53

📊 当前表中有 0 条记录

开始迁移...
1. 检查当前表结构...
   当前字段: did, date, pet_name, summary, ...
   
2. 删除旧表...
   ✓ 旧表已删除
   
3. 创建新表结构...
   ✓ 新表已创建
   
4. 创建索引...
   ✓ 索引已创建
   
✅ 迁移完成！
```

### 步骤 4: 验证迁移结果

```bash
# 检查表结构
sqlite3 database/history.db "PRAGMA table_info(daily_reports);"

# 应该看到 16 个字段，包括：
# - id (PRIMARY KEY)
# - did, date, pet_name
# - summary, daily_tag, insight_text
# - llm_request, llm_response
# - generation_status, error_message, retry_count
# - analysis_data, video_count, total_duration
# - created_at, updated_at
```

### 步骤 5: 重启服务

```bash
# 启动后端服务
cd backend
nohup python3 main.py > logs/backend.log 2>&1 &

# 或使用 systemd
# sudo systemctl start pet-videos-backend

# 检查服务状态
curl http://localhost:8002/api/health
```

### 步骤 6: 验证功能

1. 访问前端，查看"宠物日报"标签页
2. 等待自动生成日报（5-23点每1.5小时，23-5点每3小时）
3. 或手动触发日报生成（如果实现了手动触发API）

---

## ⚠️ 如果迁移失败

### 回滚步骤

```bash
# 停止服务
pkill -f "python.*main.py" || true

# 恢复备份
cd backend
rm database/history.db
cp database/history.db.backup_XXXXXX database/history.db

# 回退代码到上一个版本
git checkout <previous-commit-hash>

# 重启服务
nohup python3 main.py > logs/backend.log 2>&1 &
```

### 常见问题

1. **错误：table daily_reports already exists**
   - 原因：表已经是新结构
   - 解决：检查表结构，可能不需要迁移

2. **错误：database is locked**
   - 原因：服务未完全停止
   - 解决：确保所有进程已停止 `ps aux | grep main.py`

3. **迁移后日报无法生成**
   - 检查后端日志：`tail -f backend/logs/backend.log`
   - 检查环境变量：`cat backend/.env | grep DAILY_REPORT`
   - 确认 DailyReportGenerator 是否自动启动

---

## 📝 迁移检查清单

- [ ] 备份数据库文件
- [ ] 检查 daily_reports 表数据量
- [ ] 停止后端服务
- [ ] 执行迁移脚本
- [ ] 验证表结构正确（16个字段）
- [ ] 验证索引已创建（4个索引）
- [ ] 重启后端服务
- [ ] 检查服务健康状态
- [ ] 验证日报功能正常
- [ ] 删除旧备份（确认无问题后）

---

## 📞 支持

如有问题，请检查：
1. 后端日志：`backend/logs/backend.log`
2. 迁移脚本：`backend/migrations/migrate_server_daily_reports.py`
3. 数据库结构：`sqlite3 database/history.db "PRAGMA table_info(daily_reports);"`

---

最后更新：2026-02-12
