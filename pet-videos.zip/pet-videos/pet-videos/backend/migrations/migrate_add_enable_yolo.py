"""添加 enable_yolo 字段到 stream_sources 表"""
import sqlite3
from pathlib import Path

def migrate():
    # 数据库路径
    db_path = Path(__file__).parent / "database" / "history.db"
    
    if not db_path.exists():
        print(f"数据库文件不存在: {db_path}")
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # 检查字段是否已存在
    cursor.execute("PRAGMA table_info(stream_sources)")
    columns = [col[1] for col in cursor.fetchall()]
    
    if 'enable_yolo' not in columns:
        print("正在添加 enable_yolo 字段...")
        cursor.execute("""
            ALTER TABLE stream_sources 
            ADD COLUMN enable_yolo INTEGER DEFAULT 1 NOT NULL
        """)
        conn.commit()
        print("✓ enable_yolo 字段添加成功（默认启用YOLO）")
    else:
        print("enable_yolo 字段已存在，跳过")
    
    conn.close()
    print("迁移完成")

if __name__ == "__main__":
    migrate()
