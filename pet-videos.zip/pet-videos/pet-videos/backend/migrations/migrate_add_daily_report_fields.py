#!/usr/bin/env python3
"""
数据库迁移脚本：为 daily_reports 表添加 daily_tag 和 insight_text 字段

使用方法：
    python3 migrations/migrate_add_daily_report_fields.py
"""
import sqlite3
from pathlib import Path
import sys

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import settings


def migrate():
    """执行迁移"""
    db_path = Path(settings.database_path)
    
    if not db_path.exists():
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    print(f"📂 数据库路径: {db_path}")
    
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # 检查表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='daily_reports'")
        if not cursor.fetchone():
            print("❌ daily_reports 表不存在")
            return False
        
        print("\n开始迁移：为 daily_reports 表添加 daily_tag 和 insight_text 字段")
        
        # 获取现有列
        cursor.execute("PRAGMA table_info(daily_reports)")
        columns = [row[1] for row in cursor.fetchall()]
        
        # 添加 daily_tag 列
        if 'daily_tag' not in columns:
            print("- 添加 daily_tag 列...")
            cursor.execute("""
                ALTER TABLE daily_reports 
                ADD COLUMN daily_tag VARCHAR(50)
            """)
            print("  ✓ daily_tag 列添加成功")
        else:
            print("- daily_tag 列已存在，跳过")
        
        # 添加 insight_text 列
        if 'insight_text' not in columns:
            print("- 添加 insight_text 列...")
            cursor.execute("""
                ALTER TABLE daily_reports 
                ADD COLUMN insight_text TEXT
            """)
            print("  ✓ insight_text 列添加成功")
        else:
            print("- insight_text 列已存在，跳过")
        
        conn.commit()
        print("\n✅ 迁移完成！")
        
        # 验证
        cursor.execute("PRAGMA table_info(daily_reports)")
        columns = cursor.fetchall()
        print("\n📋 daily_reports 表结构:")
        for col in columns:
            print(f"  - {col[1]} ({col[2]})")
        
        return True
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        conn.close()


if __name__ == "__main__":
    success = migrate()
    sys.exit(0 if success else 1)
