"""
数据库迁移脚本：添加 prompts.deleted 字段
用于实现提示词假删除功能
"""
import sqlite3
import sys
from pathlib import Path

def migrate():
    """执行迁移"""
    db_path = Path(__file__).parent / 'database' / 'history.db'
    
    if not db_path.exists():
        print(f"⚠️  数据库文件不存在: {db_path}")
        print("   如果是新安装，数据库会在首次启动时自动创建")
        return
    
    print(f"连接数据库: {db_path}")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 检查 prompts 表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='prompts'")
        if not cursor.fetchone():
            print("✓ prompts 表不存在，无需迁移")
            return
        
        # 检查字段是否存在
        cursor.execute("PRAGMA table_info(prompts)")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]
        
        if 'deleted' in column_names:
            print("✓ deleted 字段已存在，无需迁移")
            return
        
        print("正在添加 deleted 字段...")
        
        # 添加字段
        cursor.execute("""
            ALTER TABLE prompts 
            ADD COLUMN deleted BOOLEAN DEFAULT 0 NOT NULL
        """)
        
        # 添加索引
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_prompts_deleted 
            ON prompts(deleted)
        """)
        
        # 验证
        cursor.execute("SELECT COUNT(*) FROM prompts")
        total = cursor.fetchone()[0]
        
        conn.commit()
        
        print(f"✅ 迁移完成")
        print(f"   • 添加了 deleted 字段（默认值：0/False）")
        print(f"   • 添加了索引 idx_prompts_deleted")
        print(f"   • 现有 {total} 条提示词记录未受影响")
        
    except Exception as e:
        print(f"❌ 迁移失败: {e}")
        conn.rollback()
        sys.exit(1)
    finally:
        conn.close()

if __name__ == '__main__':
    print("="*60)
    print("数据库迁移: 添加提示词假删除支持")
    print("="*60)
    print()
    migrate()
    print()
    print("="*60)
