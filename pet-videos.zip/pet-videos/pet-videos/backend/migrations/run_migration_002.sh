#!/bin/bash
# Run migration 002: Add pets id

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DB_PATH="$SCRIPT_DIR/../database/history.db"

echo "========================================"
echo "Migration 002: Add pets id"
echo "========================================"
echo ""

# 检查数据库文件是否存在
if [ ! -f "$DB_PATH" ]; then
    echo "[ERROR] Database file not found: $DB_PATH"
    exit 1
fi

# 备份数据库
BACKUP_PATH="$DB_PATH.backup_$(date +%Y%m%d_%H%M%S)"
echo "[1/3] Backing up database..."
cp "$DB_PATH" "$BACKUP_PATH"
echo "      Backup saved to: $BACKUP_PATH"
echo ""

# 执行迁移
echo "[2/3] Running migration..."
sqlite3 "$DB_PATH" < "$SCRIPT_DIR/002_add_pets_id.sql"

if [ $? -eq 0 ]; then
    echo "      Migration completed successfully"
else
    echo "[ERROR] Migration failed!"
    echo "      Restoring from backup..."
    cp "$BACKUP_PATH" "$DB_PATH"
    echo "      Database restored"
    exit 1
fi
echo ""

# 验证结果
echo "[3/3] Verifying migration..."
RESULT=$(sqlite3 "$DB_PATH" "PRAGMA table_info(pets);" | grep "^0|id|INTEGER")

if [ -n "$RESULT" ]; then
    echo "      ✓ ID field added successfully"
    echo ""
    echo "Migration 002 completed!"
    echo ""
    echo "Table structure:"
    sqlite3 "$DB_PATH" "PRAGMA table_info(pets);"
else
    echo "[ERROR] Verification failed!"
    exit 1
fi
