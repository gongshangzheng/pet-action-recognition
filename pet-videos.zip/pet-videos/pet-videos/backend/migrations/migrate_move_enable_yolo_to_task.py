"""将 enable_yolo 从 stream_sources 移到 slicing_tasks 表"""
import sqlite3
from pathlib import Path

def migrate():
    # 数据库路径
    db_path = Path(__file__).parent / "database" / "history.db"
    
    if not db_path.exists():
        print(f"数据库文件不存在: {db_path}")
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # 1. 检查 slicing_tasks 表是否已有 enable_yolo 字段
    cursor.execute("PRAGMA table_info(slicing_tasks)")
    task_columns = [col[1] for col in cursor.fetchall()]
    
    if 'enable_yolo' not in task_columns:
        print("正在向 slicing_tasks 表添加 enable_yolo 字段...")
        cursor.execute("""
            ALTER TABLE slicing_tasks 
            ADD COLUMN enable_yolo INTEGER DEFAULT 1 NOT NULL
        """)
        conn.commit()
        print("✓ slicing_tasks.enable_yolo 字段添加成功（默认启用YOLO）")
    else:
        print("slicing_tasks.enable_yolo 字段已存在，跳过")
    
    # 2. 检查 stream_sources 表是否有 enable_yolo 字段
    cursor.execute("PRAGMA table_info(stream_sources)")
    source_columns = [col[1] for col in cursor.fetchall()]
    
    if 'enable_yolo' in source_columns:
        print("正在从 stream_sources 表删除 enable_yolo 字段...")
        # SQLite 不支持直接删除列，需要重建表
        cursor.execute("""
            CREATE TABLE stream_sources_new (
                id INTEGER NOT NULL,
                name VARCHAR(100) NOT NULL,
                alias VARCHAR(100) NOT NULL,
                stream_url VARCHAR(1000) NOT NULL,
                storage_path VARCHAR(1000) NOT NULL,
                is_active INTEGER NOT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                PRIMARY KEY (id)
            )
        """)
        
        # 复制数据（排除 enable_yolo）
        cursor.execute("""
            INSERT INTO stream_sources_new 
            SELECT id, name, alias, stream_url, storage_path, is_active, created_at, updated_at
            FROM stream_sources
        """)
        
        # 删除旧表
        cursor.execute("DROP TABLE stream_sources")
        
        # 重命名新表
        cursor.execute("ALTER TABLE stream_sources_new RENAME TO stream_sources")
        
        # 重建索引
        cursor.execute("CREATE INDEX ix_stream_sources_id ON stream_sources (id)")
        cursor.execute("CREATE INDEX ix_stream_sources_name ON stream_sources (name)")
        cursor.execute("CREATE UNIQUE INDEX ix_stream_sources_alias ON stream_sources (alias)")
        
        conn.commit()
        print("✓ stream_sources.enable_yolo 字段已删除")
    else:
        print("stream_sources 表中没有 enable_yolo 字段，跳过")
    
    conn.close()
    print("迁移完成：enable_yolo 已从源表移到任务表")

if __name__ == "__main__":
    migrate()
