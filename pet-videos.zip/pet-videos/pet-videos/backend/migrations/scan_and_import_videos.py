#!/usr/bin/env python3
"""扫描视频目录并导入数据库"""
import sys
import os
from pathlib import Path
from datetime import datetime
import re

# 添加 backend 目录到 Python 路径
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

# 使用绝对导入（作为独立脚本运行）
import sqlite3
from config import settings

# 手动创建数据库会话
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from models.database import Base, StreamSource, VideoRecord

# 创建数据库引擎
engine = create_engine(
    f"sqlite:///{settings.database_path}",
    connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def init_db():
    """初始化数据库表"""
    Base.metadata.create_all(bind=engine)

def parse_filename_date(filename: str) -> datetime:
    """从文件名解析日期时间"""
    # 尝试匹配格式：event_20260126_140122.mp4
    match = re.search(r'(\d{8})_(\d{6})', filename)
    if match:
        date_str = match.group(1)  # 20260126
        time_str = match.group(2)  # 140122
        return datetime.strptime(f"{date_str}{time_str}", "%Y%m%d%H%M%S")
    
    # 尝试匹配格式：VIDEO_1767494103401.mp4 (时间戳)
    match = re.search(r'VIDEO_(\d{13})', filename)
    if match:
        timestamp_ms = int(match.group(1))
        return datetime.fromtimestamp(timestamp_ms / 1000)
    
    # 默认使用文件修改时间
    return None

def get_file_size_mb(file_path: Path) -> float:
    """获取文件大小（MB）"""
    return file_path.stat().st_size / (1024 * 1024)

def scan_directory(db, source: StreamSource, dry_run: bool = False):
    """扫描指定源的视频目录"""
    storage_path = Path(source.storage_path)
    
    if not storage_path.exists():
        print(f"⚠️  目录不存在: {storage_path}")
        return 0
    
    print(f"\n扫描: {source.name} ({source.alias})")
    print(f"路径: {storage_path}")
    
    # 查找所有 mp4 文件
    mp4_files = list(storage_path.rglob("*.mp4"))
    print(f"找到 {len(mp4_files)} 个视频文件")
    
    imported_count = 0
    skipped_count = 0
    
    for mp4_file in mp4_files:
        # 检查数据库中是否已存在
        existing = db.query(VideoRecord).filter(
            VideoRecord.source_id == source.id,
            VideoRecord.file_name == mp4_file.name
        ).first()
        
        if existing:
            skipped_count += 1
            continue
        
        # 解析录制时间
        recorded_at = parse_filename_date(mp4_file.name)
        if not recorded_at:
            # 使用文件修改时间
            recorded_at = datetime.fromtimestamp(mp4_file.stat().st_mtime)
        
        # 计算相对路径
        try:
            relative_path = mp4_file.relative_to(storage_path)
        except ValueError:
            relative_path = mp4_file
        
        file_size_mb = get_file_size_mb(mp4_file)
        
        print(f"  + {mp4_file.name} ({file_size_mb:.1f}MB) - {recorded_at.strftime('%Y-%m-%d %H:%M:%S')}")
        
        if not dry_run:
            # 创建数据库记录
            video_record = VideoRecord(
                source_id=source.id,
                did=source.did if source.did else "0",  # 从源获取did
                file_name=mp4_file.name,
                file_path=str(relative_path),
                file_size=mp4_file.stat().st_size,
                recorded_at=recorded_at,
                created_at=datetime.now(),
                updated_at=datetime.now()
                # llm_status默认为None，不需要显式设置
            )
            db.add(video_record)
            imported_count += 1
    
    if not dry_run:
        db.commit()
    
    print(f"✓ 导入: {imported_count} 个, 跳过: {skipped_count} 个")
    return imported_count

def main():
    dry_run = '--dry-run' in sys.argv
    
    if dry_run:
        print("🔍 预览模式（不会实际导入）\n")
    else:
        print("📥 开始导入视频记录\n")
    
    # 初始化数据库
    init_db()
    
    db = SessionLocal()
    try:
        # 获取所有激活的视频源
        sources = db.query(StreamSource).filter(StreamSource.is_active == True).all()
        
        if not sources:
            print("⚠️  没有找到激活的视频源")
            print("请先在数据库中配置 stream_sources 表")
            return
        
        print(f"找到 {len(sources)} 个激活的视频源\n")
        
        total_imported = 0
        for source in sources:
            count = scan_directory(db, source, dry_run)
            total_imported += count
        
        print(f"\n{'[预览]' if dry_run else '[完成]'} 总计导入: {total_imported} 个视频记录")
        
        if dry_run:
            print("\n💡 移除 --dry-run 参数以实际导入")
    
    finally:
        db.close()

if __name__ == "__main__":
    main()
