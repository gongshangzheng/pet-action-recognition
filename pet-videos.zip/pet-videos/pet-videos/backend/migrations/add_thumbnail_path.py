"""
添加缩略图路径字段到 video_records 表

运行方式:
    python -m backend.migrations.add_thumbnail_path

功能:
    为 video_records 表添加 thumbnail_path 字段，用于存储视频缩略图路径
"""

import sys
import logging
from pathlib import Path
from sqlalchemy import text

# 添加 backend 目录到 Python 路径
backend_root = Path(__file__).parent.parent
sys.path.insert(0, str(backend_root))

from models.db import get_db

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def add_thumbnail_path():
    """添加 thumbnail_path 字段到 video_records 表"""
    db = next(get_db())
    try:
        # 检查字段是否已存在
        result = db.execute(text("PRAGMA table_info(video_records)")).fetchall()
        columns = [row[1] for row in result]
        
        if 'thumbnail_path' in columns:
            logger.info("字段 thumbnail_path 已存在，跳过")
            return
        
        logger.info("开始添加 thumbnail_path 字段...")
        
        # 添加字段
        db.execute(text("""
            ALTER TABLE video_records 
            ADD COLUMN thumbnail_path VARCHAR(1000) DEFAULT NULL
        """))
        db.commit()
        
        logger.info("✅ thumbnail_path 字段添加成功！")
        
        # 验证
        result = db.execute(text("PRAGMA table_info(video_records)")).fetchall()
        for row in result:
            if row[1] == 'thumbnail_path':
                logger.info(f"验证成功 - 字段信息: name={row[1]}, type={row[2]}, notnull={row[3]}, default={row[4]}")
        
        # 统计信息
        count_result = db.execute(text("SELECT COUNT(*) FROM video_records")).fetchone()
        total_records = count_result[0] if count_result else 0
        logger.info(f"当前 video_records 表共有 {total_records} 条记录")
        
        if total_records > 0:
            logger.info("注意: 现有记录的 thumbnail_path 为 NULL，需要重新生成缩略图或运行批量生成脚本")
        
    except Exception as e:
        logger.error(f"添加字段失败: {e}", exc_info=True)
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    logger.info("=" * 60)
    logger.info("开始数据库迁移: 添加 thumbnail_path 字段")
    logger.info("=" * 60)
    
    try:
        add_thumbnail_path()
        logger.info("=" * 60)
        logger.info("迁移完成！")
        logger.info("=" * 60)
    except Exception as e:
        logger.error("=" * 60)
        logger.error("迁移失败！")
        logger.error("=" * 60)
        sys.exit(1)
