"""添加 consecutive_failures 字段到 slicing_tasks 表"""
import sqlite3
from pathlib import Path

def migrate():
    # 数据库路径
    db_path = Path(__file__).parent / "database" / "history.db"
    
    if not db_path.exists():
        print(f"数据库文件不存在: {db_path}")
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # 检查字段是否已存在
    cursor.execute("PRAGMA table_info(slicing_tasks)")
    columns = [col[1] for col in cursor.fetchall()]
    
    if 'consecutive_failures' not in columns:
        print("正在添加 consecutive_failures 字段...")
        cursor.execute("""
            ALTER TABLE slicing_tasks 
            ADD COLUMN consecutive_failures INTEGER DEFAULT 0 NOT NULL
        """)
        conn.commit()
        print("✓ consecutive_failures 字段添加成功")
    else:
        print("consecutive_failures 字段已存在，跳过")
    
    conn.close()
    print("迁移完成")

if __name__ == "__main__":
    migrate()
