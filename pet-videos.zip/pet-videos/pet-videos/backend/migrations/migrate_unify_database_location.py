"""统一数据库位置到项目根目录

将 backend/database/history.db 迁移到 database/history.db
确保所有服务使用统一的数据库文件
"""
import os
import sys
import shutil
from pathlib import Path
from datetime import datetime

def get_project_root():
    """获取项目根目录"""
    return Path(__file__).parent.parent.parent

def migrate():
    """执行数据库位置统一"""
    project_root = get_project_root()
    
    root_db = project_root / "database" / "history.db"
    backend_db = project_root / "backend" / "database" / "history.db"
    
    print(f"项目根目录: {project_root}")
    print(f"根目录数据库: {root_db}")
    print(f"Backend数据库: {backend_db}")
    print()
    
    # 检查根目录数据库是否存在
    if not root_db.exists():
        print("❌ 根目录数据库不存在，请先创建 database/history.db")
        return False
    
    # 检查backend数据库是否存在
    if not backend_db.exists():
        print("✓ backend/database/history.db 不存在，无需迁移")
        print("✓ 当前已使用根目录数据库")
        return True
    
    print("发现 backend/database/history.db，开始迁移...")
    print()
    
    try:
        # Step 1: 备份根目录数据库
        print("[1/4] 备份根目录数据库...")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        root_backup = root_db.parent / f"history.db.backup_{timestamp}"
        shutil.copy2(root_db, root_backup)
        print(f"     备份成功: {root_backup}")
        print()
        
        # Step 2: 比较两个数据库大小
        print("[2/4] 比较数据库大小...")
        root_size = root_db.stat().st_size
        backend_size = backend_db.stat().st_size
        print(f"     根目录数据库: {root_size:,} bytes")
        print(f"     Backend数据库: {backend_size:,} bytes")
        print()
        
        # 选择较大的数据库（更新的）
        if backend_size > root_size:
            print("[INFO] Backend数据库更大，将覆盖根目录数据库")
            shutil.copy2(backend_db, root_db)
            print("     ✓ 复制成功")
        else:
            print("[INFO] 根目录数据库已是最新，无需覆盖")
        print()
        
        # Step 3: 重命名backend数据库目录
        print("[3/4] 重命名 backend/database 目录...")
        backend_db_dir = backend_db.parent
        backend_backup_dir = backend_db_dir.parent / f"database.backup_{timestamp}"
        backend_db_dir.rename(backend_backup_dir)
        print(f"     重命名成功: {backend_backup_dir}")
        print()
        
        # Step 4: 验证
        print("[4/4] 验证迁移结果...")
        if not root_db.exists():
            print("     ❌ 根目录数据库不存在")
            return False
        
        if backend_db.exists():
            print("     ❌ Backend数据库仍然存在")
            return False
        
        # 验证数据库完整性
        import sqlite3
        conn = sqlite3.connect(root_db)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
        table_count = cursor.fetchone()[0]
        conn.close()
        
        print(f"     ✓ 数据库表数量: {table_count}")
        print(f"     ✓ 数据库大小: {root_db.stat().st_size:,} bytes")
        print()
        
        print("=" * 50)
        print("✅ 迁移成功完成！")
        print("=" * 50)
        print()
        print(f"数据库位置: {root_db}")
        print(f"备份位置: {root_backup}")
        print(f"旧数据库: {backend_backup_dir}")
        print()
        print("下一步:")
        print("1. 检查 .env 中的 DATABASE_PATH 配置")
        print("2. 重启 Backend 服务")
        print("3. 重启 Service 服务")
        print("4. 验证服务使用根目录数据库")
        print()
        
        return True
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        print(f"\n可以从备份恢复: {root_backup if 'root_backup' in locals() else '未创建'}")
        return False

if __name__ == "__main__":
    print("=" * 50)
    print("数据库位置统一迁移")
    print("=" * 50)
    print()
    
    success = migrate()
    
    sys.exit(0 if success else 1)
