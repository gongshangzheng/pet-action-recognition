#!/usr/bin/env python3
"""
数据库迁移：为 slicing_tasks 表添加 script_file 字段
运行方式：python backend/migrations/add_script_file_to_tasks.py
"""
import sys
import os
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / "backend"))

from sqlalchemy import create_engine, text
from backend.config import settings

def migrate():
    """执行迁移"""
    database_url = f"sqlite:///{settings.database_path}"
    engine = create_engine(database_url)
    
    with engine.connect() as conn:
        # 检查列是否已存在
        result = conn.execute(text("PRAGMA table_info(slicing_tasks)"))
        columns = [row[1] for row in result]
        
        if 'script_file' in columns:
            print("✓ script_file 字段已存在，跳过迁移")
            return
        
        print("正在添加 script_file 字段...")
        
        # 添加 script_file 列，默认值为 'pet_monitor.py'
        conn.execute(text("""
            ALTER TABLE slicing_tasks 
            ADD COLUMN script_file VARCHAR(200) NOT NULL DEFAULT 'pet_monitor.py'
        """))
        conn.commit()
        
        print("✓ script_file 字段添加成功")
        print("✓ 迁移完成")

if __name__ == "__main__":
    try:
        migrate()
    except Exception as e:
        print(f"✗ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
