"""
修复服务器数据库迁移

问题：服务器上有pets_new表，但pets表被删除了，迁移中断
解决：完成迁移步骤，并添加avatar_color字段

执行方式：
python3 backend/migrations/migrate_fix_server_database.py
"""
import sqlite3
import os
import sys
from pathlib import Path
from datetime import datetime

def get_db_path():
    """动态获取数据库路径"""
    db_path = os.environ.get('DATABASE_PATH')
    if db_path:
        return db_path
    
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from config import settings
        return settings.database_path
    except:
        return str(Path(__file__).parent.parent / "database" / "history.db")

def backup_database(db_path):
    """备份数据库"""
    import shutil
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{db_path}.backup_{timestamp}"
    shutil.copy2(db_path, backup_path)
    print(f"✓ 数据库已备份: {backup_path}")
    return backup_path

def migrate():
    """执行修复迁移"""
    db_path = Path(get_db_path())
    
    if not db_path.exists():
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    print("=" * 60)
    print("修复服务器数据库迁移")
    print("=" * 60)
    print(f"\n数据库路径: {db_path}")
    
    # 备份数据库
    try:
        backup_path = backup_database(db_path)
    except Exception as e:
        print(f"❌ 备份失败: {e}")
        return False
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 检查表状态
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name IN ('pets', 'pets_new')
        """)
        existing_tables = [row[0] for row in cursor.fetchall()]
        
        print(f"\n当前表状态: {', '.join(existing_tables) if existing_tables else '无'}")
        
        # 情况1：有pets_new，没有pets（迁移中断）
        if 'pets_new' in existing_tables and 'pets' not in existing_tables:
            print("\n[修复] 检测到中断的迁移，继续完成...")
            
            # 重命名pets_new为pets
            print("  [1/3] 重命名 pets_new -> pets...")
            cursor.execute("ALTER TABLE pets_new RENAME TO pets")
            conn.commit()
            print("       ✓ 重命名成功")
            
        # 情况2：有pets，没有pets_new（正常）
        elif 'pets' in existing_tables and 'pets_new' not in existing_tables:
            print("\n[检查] pets表已存在")
            
        # 情况3：都没有
        elif not existing_tables:
            print("\n❌ pets表和pets_new表都不存在")
            print("请执行: python3 backend/migrations/migrate_init_all.py")
            return False
        
        # 情况4：都有（异常）
        else:
            print("\n⚠️  警告: pets和pets_new表都存在")
            print("请手动检查数据后删除其中一个")
            return False
        
        # 检查并添加avatar_color字段
        print("\n  [2/3] 检查并添加avatar_color字段...")
        cursor.execute("PRAGMA table_info(pets)")
        columns = [row[1] for row in cursor.fetchall()]
        
        if 'avatar_color' not in columns:
            print("       添加avatar_color字段...")
            cursor.execute("""
                ALTER TABLE pets ADD COLUMN avatar_color VARCHAR(10)
            """)
            cursor.execute("""
                UPDATE pets SET avatar_color = '#E5E7EB' WHERE avatar_color IS NULL
            """)
            conn.commit()
            print("       ✓ avatar_color字段添加成功")
        else:
            print("       ✓ avatar_color字段已存在")
        
        # 检查索引
        print("\n  [3/3] 检查并创建索引...")
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='index' AND tbl_name='pets' AND name='idx_pets_did_name'
        """)
        if not cursor.fetchone():
            cursor.execute("""
                CREATE UNIQUE INDEX idx_pets_did_name ON pets(did, pet_name)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_pets_did ON pets(did)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_pets_pet_name ON pets(pet_name)
            """)
            conn.commit()
            print("       ✓ 索引创建成功")
        else:
            print("       ✓ 索引已存在")
        
        # 验证最终结构
        print("\n验证数据库结构...")
        cursor.execute("PRAGMA table_info(pets)")
        columns = {col[1]: col for col in cursor.fetchall()}
        
        # 检查关键字段
        if 'id' not in columns:
            print("  ❌ 缺少id字段")
            return False
        if columns['id'][5] != 1:  # pk=1
            print("  ❌ id不是主键")
            return False
        if 'avatar_color' not in columns:
            print("  ❌ 缺少avatar_color字段")
            return False
        
        print("  ✓ id字段正确（主键，自增）")
        print("  ✓ avatar_color字段存在")
        
        # 检查数据
        cursor.execute("SELECT COUNT(*) FROM pets")
        count = cursor.fetchone()[0]
        print(f"  ✓ 数据记录数: {count}")
        
        # 显示示例数据
        if count > 0:
            cursor.execute("SELECT id, did, pet_name, avatar_color FROM pets LIMIT 3")
            rows = cursor.fetchall()
            print("\n示例数据:")
            for row in rows:
                print(f"    ID={row[0]}, DID={row[1]}, 名称={row[2]}, 背景色={row[3]}")
        
        print("\n" + "=" * 60)
        print("✅ 修复成功完成！")
        print("=" * 60)
        print(f"\n备份文件: {backup_path}")
        print("\n完成的操作:")
        print("  ✓ 完成中断的迁移（pets_new -> pets）")
        print("  ✓ 添加avatar_color字段")
        print("  ✓ 创建必要的索引")
        print("\n下一步:")
        print("  1. 重启 Backend 服务")
        print("  2. 重启 Service 服务")
        print("  3. 验证 API 接口")
        print()
        
        return True
        
    except Exception as e:
        print(f"\n❌ 修复失败: {e}")
        conn.rollback()
        print(f"\n可以从备份恢复: {backup_path}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        conn.close()

if __name__ == "__main__":
    success = migrate()
    sys.exit(0 if success else 1)
