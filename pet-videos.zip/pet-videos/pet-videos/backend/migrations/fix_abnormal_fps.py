#!/usr/bin/env python3
"""
修复数据库中异常的 FPS 值

问题：部分视频记录的 FPS 值异常高（如 11078, 1000000），这是因为使用了错误的帧率元数据
解决：重新从视频文件中提取正确的 FPS 值（使用 avg_frame_rate）

执行方式：
    python migrations/fix_abnormal_fps.py
"""

import sqlite3
import os
import sys
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def get_db_path():
    """动态获取数据库路径"""
    db_path = os.environ.get('DATABASE_PATH')
    if db_path:
        return db_path
    
    try:
        from config import settings
        return settings.database_path
    except:
        return str(Path(__file__).parent.parent / 'database' / 'history.db')

def fix_fps():
    """修复异常的 FPS 值"""
    db_path = get_db_path()
    print(f"📂 数据库路径: {db_path}")
    
    if not os.path.exists(db_path):
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        print("\n" + "="*70)
        print("🔧 修复异常 FPS 值")
        print("="*70 + "\n")
        
        # 查找异常 FPS 的记录（FPS > 120 被认为是异常）
        cursor.execute("""
            SELECT id, file_path, fps 
            FROM video_records 
            WHERE fps > 120 OR fps IS NULL
            ORDER BY id
        """)
        
        abnormal_records = cursor.fetchall()
        total = len(abnormal_records)
        
        if total == 0:
            print("✅ 没有发现异常 FPS 值")
            return True
        
        print(f"📊 发现 {total} 条异常记录\n")
        
        # 导入 VideoService
        from services.video_service import VideoService
        video_service = VideoService()
        
        success_count = 0
        fail_count = 0
        skip_count = 0
        
        for record_id, file_path, old_fps in abnormal_records:
            print(f"  [{success_count + fail_count + skip_count + 1}/{total}] ID={record_id}")
            print(f"      文件: {Path(file_path).name}")
            print(f"      旧 FPS: {old_fps}")
            
            # 检查文件是否存在
            if not os.path.exists(file_path):
                print(f"      ⚠️  文件不存在，跳过")
                skip_count += 1
                print()
                continue
            
            try:
                # 重新提取 FPS
                info = video_service.extract_info(file_path)
                new_fps = info.get('fps', 10.0)
                
                # 更新数据库
                cursor.execute("""
                    UPDATE video_records 
                    SET fps = ? 
                    WHERE id = ?
                """, (new_fps, record_id))
                
                print(f"      ✅ 新 FPS: {new_fps:.2f}")
                success_count += 1
                
            except Exception as e:
                print(f"      ❌ 提取失败: {e}")
                fail_count += 1
            
            print()
        
        conn.commit()
        
        print("="*70)
        print("📊 修复总结")
        print("="*70)
        print(f"总记录数: {total}")
        print(f"成功修复: {success_count}")
        print(f"失败: {fail_count}")
        print(f"跳过（文件不存在）: {skip_count}")
        print()
        
        if success_count > 0:
            print("✅ FPS 修复完成！")
        
        return True
        
    except Exception as e:
        conn.rollback()
        print(f"\n❌ 修复失败: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    success = fix_fps()
    sys.exit(0 if success else 1)
