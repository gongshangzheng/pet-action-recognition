#!/usr/bin/env python3
"""
服务器数据库迁移脚本：升级 daily_reports 表

变更说明：
1. 添加自增主键 id
2. 移除联合主键约束（did, date, pet_name 可重复）
3. 添加 daily_tag 和 insight_text 字段（V2.0）
4. 添加 llm_request 和 llm_response 字段（V3.0）
5. 添加 generation_status、error_message、retry_count 字段

使用方法：
    python3 migrations/migrate_server_daily_reports.py [数据库路径]
    
示例：
    python3 migrations/migrate_server_daily_reports.py database/server/history.db
"""
import sqlite3
from pathlib import Path
import sys
from datetime import datetime


def migrate(db_path: str):
    """执行迁移"""
    db_file = Path(db_path)
    
    if not db_file.exists():
        print(f"❌ 数据库文件不存在: {db_file}")
        return False
    
    print(f"📂 数据库路径: {db_file}")
    print(f"⏰ 开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    try:
        conn = sqlite3.connect(str(db_file))
        cursor = conn.cursor()
        
        # 检查表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='daily_reports'")
        table_exists = cursor.fetchone()
        
        if not table_exists:
            print("❌ daily_reports 表不存在")
            return False
        
        # 检查数据量
        record_count = cursor.execute("SELECT COUNT(*) FROM daily_reports").fetchone()[0]
        print(f"📊 当前表中有 {record_count} 条记录")
        
        if record_count > 0:
            print("\n⚠️  警告：表中有数据！")
            print("建议：")
            print("  1. 先备份数据库文件")
            print("  2. 使用 migrate_rebuild_daily_reports.py 进行数据迁移")
            confirm = input("\n是否继续？数据将丢失！(yes/no): ")
            if confirm.lower() != 'yes':
                print("❌ 已取消迁移")
                return False
        
        print("\n开始迁移...")
        
        # 1. 检查当前表结构
        print("1. 检查当前表结构...")
        cursor.execute("PRAGMA table_info(daily_reports)")
        old_columns = [col[1] for col in cursor.fetchall()]
        print(f"   当前字段: {', '.join(old_columns)}")
        
        # 2. 删除旧表
        print("\n2. 删除旧表...")
        cursor.execute("DROP TABLE daily_reports")
        print("   ✓ 旧表已删除")
        
        # 3. 创建新表（完整的V3.0结构）
        print("\n3. 创建新表结构...")
        cursor.execute("""
            CREATE TABLE daily_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                did VARCHAR(50) NOT NULL,
                date VARCHAR(10) NOT NULL,
                pet_name VARCHAR(100) NOT NULL,
                summary TEXT,
                daily_tag VARCHAR(50),
                insight_text TEXT,
                llm_request TEXT,
                llm_response TEXT,
                analysis_data TEXT,
                video_count INTEGER DEFAULT 0,
                total_duration FLOAT DEFAULT 0.0,
                generation_status VARCHAR(20) DEFAULT 'completed',
                error_message TEXT,
                retry_count INTEGER DEFAULT 0,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            )
        """)
        print("   ✓ 新表已创建")
        
        # 4. 创建索引
        print("\n4. 创建索引...")
        indexes = [
            ("idx_daily_reports_did", "did"),
            ("idx_daily_reports_date", "date"),
            ("idx_daily_reports_pet_name", "pet_name"),
            ("idx_daily_reports_created_at", "created_at")
        ]
        
        for idx_name, column in indexes:
            cursor.execute(f"CREATE INDEX {idx_name} ON daily_reports({column})")
            print(f"   ✓ 索引 {idx_name} 已创建")
        
        conn.commit()
        print("\n✅ 迁移完成！")
        
        # 5. 验证新表结构
        print("\n📋 新表结构:")
        cursor.execute("PRAGMA table_info(daily_reports)")
        columns = cursor.fetchall()
        for col in columns:
            pk_flag = " [PRIMARY KEY]" if col[5] == 1 else ""
            not_null = " NOT NULL" if col[3] == 1 else ""
            default = f" DEFAULT {col[4]}" if col[4] else ""
            print(f"  • {col[1]:20} {col[2]:15}{pk_flag}{not_null}{default}")
        
        # 6. 验证索引
        print("\n📋 索引列表:")
        cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='daily_reports'")
        indexes = cursor.fetchall()
        for idx in indexes:
            print(f"  • {idx[0]}")
        
        print(f"\n⏰ 完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        return True
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        conn.close()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 migrate_server_daily_reports.py <数据库路径>")
        print("示例: python3 migrate_server_daily_reports.py database/server/history.db")
        sys.exit(1)
    
    db_path = sys.argv[1]
    success = migrate(db_path)
    sys.exit(0 if success else 1)
