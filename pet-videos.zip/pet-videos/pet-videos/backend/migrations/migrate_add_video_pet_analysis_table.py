#!/usr/bin/env python3
"""
数据库迁移：创建 video_pet_analysis 表

用途：存储视频中宠物的 LLM 分析结果
"""
import sqlite3
import os
import sys
from pathlib import Path

def get_db_path():
    """动态获取数据库路径"""
    # 优先使用环境变量
    db_path = os.environ.get('DATABASE_PATH')
    if db_path:
        return db_path
    
    # 尝试从配置文件读取
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from config import settings
        return settings.database_path
    except:
        # 默认路径
        return str(Path(__file__).parent.parent / "database" / "history.db")

# 数据库路径
db_path = get_db_path()

print(f"连接数据库: {db_path}")
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

try:
    # 检查表是否存在
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name='video_pet_analysis'
    """)
    
    if not cursor.fetchone():
        print("正在创建 video_pet_analysis 表...")
        cursor.execute("""
            CREATE TABLE video_pet_analysis (
                video_id INTEGER NOT NULL,
                pet_name TEXT NOT NULL,
                did TEXT NOT NULL,
                actions TEXT,
                description TEXT,
                status TEXT,
                location TEXT,
                score INTEGER,
                raw_result TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (video_id, pet_name),
                FOREIGN KEY (video_id) REFERENCES video_records(id)
            )
        """)
        conn.commit()
        print("✓ video_pet_analysis 表创建成功")
        
        # 创建索引
        print("正在创建索引...")
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_video_pet_analysis_video_id
            ON video_pet_analysis(video_id)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_video_pet_analysis_pet_name
            ON video_pet_analysis(pet_name)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_video_pet_analysis_did
            ON video_pet_analysis(did)
        """)
        conn.commit()
        print("✓ 索引创建成功")
    else:
        print("video_pet_analysis 表已存在，跳过")
    
    print("\n迁移完成！")
    
except Exception as e:
    print(f"❌ 迁移失败: {e}")
    conn.rollback()
    raise
finally:
    conn.close()
