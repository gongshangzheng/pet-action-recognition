#!/usr/bin/env python3
"""
数据库迁移脚本：重建 daily_reports 表支持多版本记录

变更说明：
1. 添加自增主键 id
2. 移除联合主键约束（did, date, pet_name 可重复）
3. 添加 llm_request 和 llm_response 字段用于追踪
4. 每次LLM请求都插入新记录，用于问题追踪
5. 查询时按 (did, date, pet_name) 分组取最新记录

使用方法：
    python3 migrations/migrate_rebuild_daily_reports.py
"""
import sqlite3
from pathlib import Path
import sys

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import settings


def migrate():
    """执行迁移"""
    db_path = Path(settings.database_path)
    
    if not db_path.exists():
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    print(f"📂 数据库路径: {db_path}")
    
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # 检查表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='daily_reports'")
        table_exists = cursor.fetchone()
        
        if not table_exists:
            print("❌ daily_reports 表不存在")
            return False
        
        print("\n⚠️  警告：将重建 daily_reports 表，旧数据会迁移到新表")
        print("开始迁移...")
        
        # 1. 备份旧数据
        print("1. 备份旧数据...")
        cursor.execute("""
            CREATE TABLE daily_reports_backup AS 
            SELECT * FROM daily_reports
        """)
        
        backup_count = cursor.execute("SELECT COUNT(*) FROM daily_reports_backup").fetchone()[0]
        print(f"   ✓ 已备份 {backup_count} 条记录")
        
        # 2. 删除旧表
        print("2. 删除旧表...")
        cursor.execute("DROP TABLE daily_reports")
        print("   ✓ 旧表已删除")
        
        # 3. 创建新表（带自增主键）
        print("3. 创建新表结构...")
        cursor.execute("""
            CREATE TABLE daily_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                did VARCHAR(50) NOT NULL,
                date VARCHAR(10) NOT NULL,
                pet_name VARCHAR(100) NOT NULL,
                summary TEXT,
                daily_tag VARCHAR(50),
                insight_text TEXT,
                llm_request TEXT,
                llm_response TEXT,
                analysis_data TEXT,
                video_count INTEGER DEFAULT 0,
                total_duration FLOAT DEFAULT 0.0,
                generation_status VARCHAR(20) DEFAULT 'completed',
                error_message TEXT,
                retry_count INTEGER DEFAULT 0,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            )
        """)
        print("   ✓ 新表已创建")
        
        # 4. 创建索引
        print("4. 创建索引...")
        cursor.execute("CREATE INDEX idx_daily_reports_did ON daily_reports(did)")
        cursor.execute("CREATE INDEX idx_daily_reports_date ON daily_reports(date)")
        cursor.execute("CREATE INDEX idx_daily_reports_pet_name ON daily_reports(pet_name)")
        cursor.execute("CREATE INDEX idx_daily_reports_created_at ON daily_reports(created_at)")
        print("   ✓ 索引已创建")
        
        # 5. 迁移数据
        print("5. 迁移数据...")
        cursor.execute("""
            INSERT INTO daily_reports (
                did, date, pet_name, summary, daily_tag, insight_text,
                llm_request, llm_response, analysis_data,
                video_count, total_duration, generation_status,
                error_message, retry_count, created_at, updated_at
            )
            SELECT 
                did, date, pet_name, summary, daily_tag, insight_text,
                NULL as llm_request, NULL as llm_response, analysis_data,
                video_count, total_duration, generation_status,
                error_message, retry_count, created_at, updated_at
            FROM daily_reports_backup
        """)
        
        migrated_count = cursor.execute("SELECT COUNT(*) FROM daily_reports").fetchone()[0]
        print(f"   ✓ 已迁移 {migrated_count} 条记录")
        
        # 6. 删除备份表
        print("6. 清理备份表...")
        cursor.execute("DROP TABLE daily_reports_backup")
        print("   ✓ 备份表已删除")
        
        conn.commit()
        print("\n✅ 迁移完成！")
        
        # 验证新表结构
        cursor.execute("PRAGMA table_info(daily_reports)")
        columns = cursor.fetchall()
        print("\n📋 新表结构:")
        for col in columns:
            pk_flag = " (PRIMARY KEY)" if col[5] == 1 else ""
            print(f"  - {col[1]} ({col[2]}){pk_flag}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        
        # 尝试回滚
        try:
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='daily_reports_backup'")
            if cursor.fetchone():
                print("\n尝试恢复备份...")
                cursor.execute("DROP TABLE IF EXISTS daily_reports")
                cursor.execute("ALTER TABLE daily_reports_backup RENAME TO daily_reports")
                conn.commit()
                print("✓ 已从备份恢复")
        except Exception as restore_err:
            print(f"❌ 恢复失败: {restore_err}")
        
        return False
    finally:
        conn.close()


if __name__ == "__main__":
    success = migrate()
    sys.exit(0 if success else 1)
