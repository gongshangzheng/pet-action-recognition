#!/usr/bin/env python3
"""
数据库迁移：为 slicing_tasks 表添加缺失的字段
- consecutive_failures (连续失败次数)
- enable_yolo (是否启用YOLO检测)

运行方式：python backend/migrations/add_missing_task_fields.py
"""
import sys
import os
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / "backend"))

from sqlalchemy import create_engine, text, inspect
from backend.config import settings

def migrate():
    """执行迁移"""
    database_url = f"sqlite:///{settings.database_path}"
    engine = create_engine(database_url)
    
    with engine.connect() as conn:
        # 获取现有列
        inspector = inspect(engine)
        columns = {col['name'] for col in inspector.get_columns('slicing_tasks')}
        
        # 检查并添加 consecutive_failures 字段
        if 'consecutive_failures' not in columns:
            print("正在添加 consecutive_failures 字段...")
            conn.execute(text("""
                ALTER TABLE slicing_tasks 
                ADD COLUMN consecutive_failures INTEGER NOT NULL DEFAULT 0
            """))
            conn.commit()
            print("✓ consecutive_failures 字段添加成功")
        else:
            print("✓ consecutive_failures 字段已存在，跳过")
        
        # 检查并添加 enable_yolo 字段
        if 'enable_yolo' not in columns:
            print("正在添加 enable_yolo 字段...")
            conn.execute(text("""
                ALTER TABLE slicing_tasks 
                ADD COLUMN enable_yolo BOOLEAN NOT NULL DEFAULT 1
            """))
            conn.commit()
            print("✓ enable_yolo 字段添加成功")
        else:
            print("✓ enable_yolo 字段已存在，跳过")
        
        print("✓ 迁移完成")

if __name__ == "__main__":
    try:
        migrate()
    except Exception as e:
        print(f"✗ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
