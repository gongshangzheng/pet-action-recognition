#!/usr/bin/env python3
"""
统一视频分析记录表迁移脚本

功能：
1. 为 video_records 表添加新字段（用户ID、调用类型、分析参数、Token统计等）
2. 迁移 analysis_history 表的数据到 video_records
3. 为自动调用的记录补充 did 字段（从 stream_sources 获取）

执行方式：
    python migrations/migrate_unify_video_records.py
"""

import sqlite3
import os
import json
from pathlib import Path
from datetime import datetime

def get_db_path():
    """获取数据库路径"""
    db_path = os.environ.get('DATABASE_PATH')
    if not db_path:
        # 尝试从配置文件读取
        try:
            import sys
            backend_dir = Path(__file__).parent.parent
            sys.path.insert(0, str(backend_dir))
            from config import settings
            db_path = settings.database_path
        except:
            # 默认路径
            db_path = str(Path(__file__).parent.parent / 'database' / 'history.db')
    return db_path

def migrate():
    """执行迁移"""
    db_path = get_db_path()
    print(f"📂 数据库路径: {db_path}")
    
    if not os.path.exists(db_path):
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        print("\n" + "="*60)
        print("🚀 开始迁移：统一视频分析记录表")
        print("="*60 + "\n")
        
        # ===== 步骤 1: 添加新字段 =====
        print("📝 步骤 1: 为 video_records 添加新字段...")
        
        new_columns = [
            ("did", "VARCHAR(50) NOT NULL DEFAULT '0'", True),
            ("call_type", "VARCHAR(20) NOT NULL DEFAULT 'auto'", True),
            ("llm_raw_response", "TEXT", False),
            ("prompt", "TEXT", False),
            ("model_name", "VARCHAR(100)", True),
            ("analysis_fps", "FLOAT", False),
            ("max_pixels", "INTEGER", False),
            ("min_pixels", "INTEGER", False),
            ("vl_high_resolution_images", "BOOLEAN", False),
            ("input_tokens", "INTEGER", False),
            ("output_tokens", "INTEGER", False),
            ("total_tokens", "INTEGER", False),
            ("analysis_cost", "FLOAT", False),
            ("analysis_duration_sec", "FLOAT", False),
        ]
        
        # 检查并添加字段
        cursor.execute("PRAGMA table_info(video_records)")
        existing_columns = {row[1] for row in cursor.fetchall()}
        
        added_count = 0
        for col_name, col_type, need_index in new_columns:
            if col_name not in existing_columns:
                print(f"  ➕ 添加字段: {col_name} ({col_type})")
                cursor.execute(f"ALTER TABLE video_records ADD COLUMN {col_name} {col_type}")
                added_count += 1
            else:
                print(f"  ✓ 字段已存在: {col_name}")
        
        conn.commit()
        print(f"✅ 添加了 {added_count} 个新字段\n")
        
        # ===== 步骤 2: 创建索引 =====
        print("📝 步骤 2: 创建索引...")
        
        indexes = [
            ("idx_video_records_did", "did"),
            ("idx_video_records_call_type", "call_type"),
            ("idx_video_records_model_name", "model_name"),
        ]
        
        for idx_name, column in indexes:
            try:
                cursor.execute(f"""
                    CREATE INDEX IF NOT EXISTS {idx_name}
                    ON video_records({column})
                """)
                print(f"  ✓ 创建索引: {idx_name}")
            except Exception as e:
                print(f"  ⚠️  索引 {idx_name} 可能已存在: {e}")
        
        conn.commit()
        print("✅ 索引创建完成\n")
        
        # ===== 步骤 3: 迁移 analysis_history 数据 =====
        print("📝 步骤 3: 迁移 analysis_history 数据到 video_records...")
        
        # 检查 analysis_history 表是否存在
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='analysis_history'
        """)
        
        if not cursor.fetchone():
            print("  ℹ️  analysis_history 表不存在，跳过数据迁移")
        else:
            # 查询 analysis_history 的所有记录
            cursor.execute("SELECT COUNT(*) FROM analysis_history")
            total_count = cursor.fetchone()[0]
            print(f"  📊 找到 {total_count} 条历史记录")
            
            if total_count > 0:
                cursor.execute("""
                    SELECT 
                        id, video_name, video_path, dir_alias, video_duration_sec,
                        prompt, prompt_id, prompt_name, model_name,
                        fps, max_pixels, min_pixels, vl_high_resolution_images,
                        input_tokens, output_tokens, total_tokens, cost,
                        duration_sec, model_response, call_type, created_at
                    FROM analysis_history
                    ORDER BY id
                """)
                
                history_records = cursor.fetchall()
                migrated_count = 0
                
                for record in history_records:
                    (
                        hist_id, video_name, video_path, dir_alias, duration_sec,
                        prompt, prompt_id, prompt_name, model_name,
                        fps, max_pixels, min_pixels, vl_high_resolution,
                        input_tokens, output_tokens, total_tokens, cost,
                        analysis_duration, model_response, call_type, created_at
                    ) = record
                    
                    # 检查是否已经迁移过（通过 llm_analysis_id 关联）
                    cursor.execute("""
                        SELECT id FROM video_records 
                        WHERE llm_analysis_id = ?
                    """, (hist_id,))
                    
                    if cursor.fetchone():
                        continue  # 已经迁移过
                    
                    # 插入到 video_records
                    cursor.execute("""
                        INSERT INTO video_records (
                            source_id, did, call_type,
                            file_name, file_path, duration,
                            prompt, model_name, analysis_fps,
                            max_pixels, min_pixels, vl_high_resolution_images,
                            input_tokens, output_tokens, total_tokens,
                            analysis_cost, analysis_duration_sec,
                            llm_raw_response, llm_result,
                            llm_status, llm_prompt_id, llm_analysis_id,
                            llm_retry_count, llm_completed_at, 
                            recorded_at, created_at, updated_at
                        ) VALUES (
                            0, '0', ?,
                            ?, ?, ?,
                            ?, ?, ?,
                            ?, ?, ?,
                            ?, ?, ?,
                            ?, ?,
                            ?, ?,
                            'completed', ?, ?,
                            0, ?,
                            ?, ?, ?
                        )
                    """, (
                        call_type or 'manual',
                        video_name, video_path, duration_sec,
                        prompt, model_name, fps,
                        max_pixels, min_pixels, vl_high_resolution,
                        input_tokens, output_tokens, total_tokens,
                        cost, analysis_duration,
                        model_response, model_response,  # llm_raw_response 和 llm_result 都存
                        prompt_id, hist_id,
                        created_at,
                        created_at, created_at, created_at
                    ))
                    
                    migrated_count += 1
                
                conn.commit()
                print(f"  ✅ 迁移了 {migrated_count} 条历史记录\n")
        
        # ===== 步骤 4: 为自动调用记录补充 did =====
        print("📝 步骤 4: 为自动调用记录补充 did...")
        
        # 查询需要补充 did 的记录
        cursor.execute("""
            SELECT vr.id, vr.source_id, ss.alias
            FROM video_records vr
            LEFT JOIN stream_sources ss ON vr.source_id = ss.id
            WHERE vr.call_type = 'auto' AND (vr.did = '0' OR vr.did IS NULL)
        """)
        
        auto_records = cursor.fetchall()
        updated_count = 0
        
        for video_id, source_id, alias in auto_records:
            if alias:
                cursor.execute("""
                    UPDATE video_records 
                    SET did = ? 
                    WHERE id = ?
                """, (alias, video_id))
                updated_count += 1
        
        conn.commit()
        print(f"  ✅ 更新了 {updated_count} 条自动调用记录的 did\n")
        
        # ===== 完成 =====
        print("="*60)
        print("✅ 迁移完成！")
        print("="*60)
        print("\n📊 统计信息:")
        
        cursor.execute("SELECT call_type, COUNT(*) FROM video_records GROUP BY call_type")
        for call_type, count in cursor.fetchall():
            print(f"  - {call_type}: {count} 条")
        
        cursor.execute("SELECT COUNT(*) FROM video_records WHERE did != '0'")
        did_count = cursor.fetchone()[0]
        print(f"  - 关联用户的记录: {did_count} 条")
        
        print("\n⚠️  重要提示:")
        print("  1. 请更新相关API代码，使用统一的 video_records 表")
        print("  2. 前端分析API需要改为写入 video_records")
        print("  3. 可以考虑备份后删除 analysis_history 表")
        print("  4. 更新调用历史查询接口，改为查询 video_records")
        
        return True
        
    except Exception as e:
        conn.rollback()
        print(f"\n❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    success = migrate()
    exit(0 if success else 1)
