-- Migration: 002_add_pets_id
-- Description: 为pets表添加自增ID主键
-- Date: 2026-02-06

-- SQLite不支持直接修改主键，需要重建表

-- 1. 创建新表（带自增ID）
CREATE TABLE IF NOT EXISTS pets_new (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    did VARCHAR(50) NOT NULL,
    pet_name VARCHAR(100) NOT NULL,
    pet_type VARCHAR(50),
    breed VARCHAR(100),
    gender VARCHAR(10),
    birth_date VARCHAR(10),
    weight REAL,
    color VARCHAR(100),
    avatar_url VARCHAR(500),
    description TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 2. 复制旧数据（如果存在）
INSERT INTO pets_new (did, pet_name, pet_type, breed, gender, birth_date, weight, color, avatar_url, description, created_at, updated_at)
SELECT did, pet_name, pet_type, breed, gender, birth_date, weight, color, avatar_url, description, created_at, updated_at
FROM pets
WHERE EXISTS (SELECT 1 FROM sqlite_master WHERE type='table' AND name='pets');

-- 3. 删除旧表
DROP TABLE IF EXISTS pets;

-- 4. 重命名新表
ALTER TABLE pets_new RENAME TO pets;

-- 5. 创建索引（保证did+pet_name唯一）
CREATE UNIQUE INDEX idx_pets_did_name ON pets(did, pet_name);

-- 6. 创建其他索引（提高查询性能）
CREATE INDEX idx_pets_did ON pets(did);
CREATE INDEX idx_pets_pet_name ON pets(pet_name);
