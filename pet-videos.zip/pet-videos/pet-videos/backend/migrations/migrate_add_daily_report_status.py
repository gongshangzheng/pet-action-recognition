"""
添加日报生成状态字段
- generation_status: 生成状态（pending/processing/completed/failed）
- error_message: 错误信息
- retry_count: 重试次数
"""
import sqlite3
from pathlib import Path
import sys

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from config import settings

def migrate():
    """执行迁移"""
    db_path = Path(settings.database_path)
    
    if not db_path.exists():
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    print(f"📂 数据库路径: {db_path}")
    
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # 检查表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='daily_reports'")
        if not cursor.fetchone():
            print("❌ daily_reports 表不存在")
            conn.close()
            return False
        
        # 检查字段是否已存在
        cursor.execute("PRAGMA table_info(daily_reports)")
        columns = [col[1] for col in cursor.fetchall()]
        
        changes_made = False
        
        # 添加 generation_status 字段
        if 'generation_status' not in columns:
            print("➕ 添加 generation_status 字段...")
            cursor.execute("""
                ALTER TABLE daily_reports 
                ADD COLUMN generation_status VARCHAR(20) DEFAULT 'completed'
            """)
            changes_made = True
            print("   ✅ generation_status 字段添加成功")
        else:
            print("   ⏭️  generation_status 字段已存在")
        
        # 添加 error_message 字段
        if 'error_message' not in columns:
            print("➕ 添加 error_message 字段...")
            cursor.execute("""
                ALTER TABLE daily_reports 
                ADD COLUMN error_message TEXT
            """)
            changes_made = True
            print("   ✅ error_message 字段添加成功")
        else:
            print("   ⏭️  error_message 字段已存在")
        
        # 添加 retry_count 字段
        if 'retry_count' not in columns:
            print("➕ 添加 retry_count 字段...")
            cursor.execute("""
                ALTER TABLE daily_reports 
                ADD COLUMN retry_count INTEGER DEFAULT 0
            """)
            changes_made = True
            print("   ✅ retry_count 字段添加成功")
        else:
            print("   ⏭️  retry_count 字段已存在")
        
        if changes_made:
            conn.commit()
            print("\n✅ 迁移完成！")
        else:
            print("\n⏭️  所有字段都已存在，无需迁移")
        
        # 显示最终表结构
        print("\n📋 当前表结构:")
        cursor.execute("PRAGMA table_info(daily_reports)")
        columns = cursor.fetchall()
        for col in columns:
            print(f"   - {col[1]} ({col[2]})")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("=" * 60)
    print("日报状态字段迁移脚本")
    print("=" * 60)
    print()
    
    success = migrate()
    
    print()
    print("=" * 60)
    if success:
        print("✅ 迁移成功完成")
    else:
        print("❌ 迁移失败")
    print("=" * 60)
