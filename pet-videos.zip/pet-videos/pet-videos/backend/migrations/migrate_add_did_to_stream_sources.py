#!/usr/bin/env python3
"""
为 stream_sources 表添加 did 字段

执行：python3 migrations/migrate_add_did_to_stream_sources.py
"""

import sqlite3
import sys
from pathlib import Path

def get_db_path():
    """获取数据库路径"""
    try:
        backend_dir = Path(__file__).parent.parent
        sys.path.insert(0, str(backend_dir))
        from config import settings
        return settings.database_path
    except:
        return str(Path(__file__).parent.parent / 'database' / 'history.db')

def migrate():
    """执行迁移"""
    db_path = get_db_path()
    print(f"📂 数据库路径: {db_path}\n")
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        print("="*60)
        print("🚀 为 stream_sources 表添加 did 字段")
        print("="*60 + "\n")
        
        # 检查字段是否已存在
        cursor.execute("PRAGMA table_info(stream_sources)")
        columns = {row[1] for row in cursor.fetchall()}
        
        if 'did' in columns:
            print("  ℹ️  did 字段已存在，跳过添加\n")
            return True
        
        # 添加 did 字段
        print("  📝 添加 did 字段...")
        cursor.execute("""
            ALTER TABLE stream_sources 
            ADD COLUMN did VARCHAR(50)
        """)
        
        # 创建索引
        print("  📝 创建索引...")
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_stream_sources_did 
            ON stream_sources(did)
        """)
        
        # 使用 alias 作为初始 did 值
        print("  📝 使用 alias 初始化 did...")
        cursor.execute("""
            UPDATE stream_sources 
            SET did = alias 
            WHERE did IS NULL OR did = ''
        """)
        
        conn.commit()
        
        print("\n" + "="*60)
        print("✅ 迁移完成！")
        print("="*60)
        
        # 显示统计
        cursor.execute("SELECT COUNT(*), COUNT(DISTINCT did) FROM stream_sources WHERE did IS NOT NULL")
        total, unique_dids = cursor.fetchone()
        print(f"\n📊 统计: {total} 条记录, {unique_dids} 个不同的 did\n")
        
        return True
        
    except Exception as e:
        conn.rollback()
        print(f"\n❌ 迁移失败: {e}\n")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    success = migrate()
    sys.exit(0 if success else 1)
