"""
添加视频缩略图字段

Migration: add_thumbnail
Date: 2026-02-13
Description: 为 video_records 表添加缩略图路径字段
"""

import sys
import logging
from pathlib import Path
from sqlalchemy import text

# 添加父目录到 Python 路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.db import get_db

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def add_thumbnail_field():
    """添加缩略图字段到 video_records 表"""
    db = next(get_db())
    
    try:
        logger.info("=" * 60)
        logger.info("开始添加缩略图字段迁移...")
        logger.info("=" * 60)
        
        # 1. 检查字段是否已存在
        logger.info("[1/3] 检查 thumbnail_path 字段是否已存在...")
        result = db.execute(text("PRAGMA table_info(video_records)")).fetchall()
        columns = [row[1] for row in result]
        
        if 'thumbnail_path' in columns:
            logger.info("✓ thumbnail_path 字段已存在，跳过添加")
        else:
            logger.info("[2/3] 添加 thumbnail_path 字段...")
            db.execute(text("""
                ALTER TABLE video_records 
                ADD COLUMN thumbnail_path TEXT
            """))
            db.commit()
            logger.info("✓ thumbnail_path 字段添加成功")
        
        # 2. 验证字段
        logger.info("[3/3] 验证字段添加...")
        result = db.execute(text("PRAGMA table_info(video_records)")).fetchall()
        columns = {row[1]: row[2] for row in result}  # {column_name: column_type}
        
        if 'thumbnail_path' in columns:
            logger.info(f"✓ 验证成功: thumbnail_path ({columns['thumbnail_path']})")
        else:
            raise Exception("字段验证失败: thumbnail_path 不存在")
        
        # 3. 显示统计信息
        total_videos = db.execute(text("SELECT COUNT(*) FROM video_records")).scalar()
        videos_with_thumbnail = db.execute(text(
            "SELECT COUNT(*) FROM video_records WHERE thumbnail_path IS NOT NULL"
        )).scalar()
        
        logger.info("")
        logger.info("=" * 60)
        logger.info("迁移完成！")
        logger.info("=" * 60)
        logger.info(f"总视频记录数: {total_videos}")
        logger.info(f"已有缩略图记录数: {videos_with_thumbnail}")
        logger.info(f"待生成缩略图数: {total_videos - videos_with_thumbnail}")
        logger.info("")
        logger.info("说明：")
        logger.info("1. thumbnail_path 字段已添加（TEXT 类型）")
        logger.info("2. 现有记录的 thumbnail_path 为 NULL")
        logger.info("3. 缩略图将在视频切片时自动生成")
        logger.info("4. 可以运行 scripts/generate_thumbnails.py 批量生成历史视频的缩略图")
        logger.info("=" * 60)
        
    except Exception as e:
        logger.error(f"迁移失败: {e}", exc_info=True)
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    add_thumbnail_field()
