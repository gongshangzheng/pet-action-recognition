-- 安全的NULL状态迁移脚本
-- 使用ALTER TABLE重命名方式，避免数据丢失

BEGIN TRANSACTION;

-- 步骤1：重命名旧表
ALTER TABLE video_records RENAME TO video_records_old;

-- 步骤2：创建新表（llm_status允许NULL）
CREATE TABLE video_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id INTEGER NOT NULL,
    call_type VARCHAR(20) DEFAULT 'auto' NOT NULL,
    did VARCHAR(50) DEFAULT '0' NOT NULL,
    file_name VARCHAR(500) NOT NULL,
    file_path VARCHAR(1000) NOT NULL,
    file_size INTEGER,
    duration FLOAT,
    width INTEGER,
    height INTEGER,
    fps FLOAT,
    codec VARCHAR(50),
    detection_type VARCHAR(20),
    prompt TEXT,
    model_name VARCHAR(100),
    analysis_fps FLOAT,
    max_pixels INTEGER,
    min_pixels INTEGER,
    vl_high_resolution_images BOOLEAN,
    input_tokens INTEGER,
    output_tokens INTEGER,
    total_tokens INTEGER,
    analysis_cost FLOAT,
    analysis_duration_sec FLOAT,
    llm_status VARCHAR(20),  -- 允许NULL
    llm_prompt_id INTEGER,
    llm_result TEXT,
    llm_raw_response TEXT,
    llm_error TEXT,
    llm_analysis_id INTEGER,
    llm_started_at DATETIME,
    llm_completed_at DATETIME,
    llm_retry_count INTEGER DEFAULT 0 NOT NULL,
    llm_next_retry_at DATETIME,
    recorded_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
);

-- 步骤3：复制数据，将pending/expired转为NULL
INSERT INTO video_records (
    id, source_id, call_type, did, file_name, file_path, file_size,
    duration, width, height, fps, codec, detection_type,
    prompt, model_name, analysis_fps, max_pixels, min_pixels, vl_high_resolution_images,
    input_tokens, output_tokens, total_tokens, analysis_cost, analysis_duration_sec,
    llm_status, llm_prompt_id, llm_result, llm_raw_response, llm_error, llm_analysis_id,
    llm_started_at, llm_completed_at, llm_retry_count, llm_next_retry_at,
    recorded_at, created_at, updated_at
)
SELECT 
    id, source_id, call_type, did, file_name, file_path, file_size,
    duration, width, height, fps, codec, detection_type,
    prompt, model_name, analysis_fps, max_pixels, min_pixels, vl_high_resolution_images,
    input_tokens, output_tokens, total_tokens, analysis_cost, analysis_duration_sec,
    CASE 
        WHEN llm_status IN ('pending', 'expired') THEN NULL
        ELSE llm_status
    END as llm_status,
    llm_prompt_id, llm_result, llm_raw_response, llm_error, llm_analysis_id,
    llm_started_at, llm_completed_at, 
    COALESCE(llm_retry_count, 0) as llm_retry_count,
    llm_next_retry_at,
    recorded_at, created_at, updated_at
FROM video_records_old;

-- 步骤4：重置超时的processing为NULL
UPDATE video_records 
SET llm_status = NULL,
    llm_error = '任务超时，已重置',
    llm_retry_count = llm_retry_count + 1,
    llm_next_retry_at = NULL,
    updated_at = datetime('now', 'localtime')
WHERE llm_status = 'processing' 
  AND datetime(llm_started_at) < datetime('now', '-30 minutes', 'localtime');

-- 步骤5：重建索引
CREATE INDEX IF NOT EXISTS ix_video_records_source_id ON video_records (source_id);
CREATE INDEX IF NOT EXISTS ix_video_records_did ON video_records (did);
CREATE INDEX IF NOT EXISTS ix_video_records_file_name ON video_records (file_name);
CREATE INDEX IF NOT EXISTS ix_video_records_model_name ON video_records (model_name);
CREATE INDEX IF NOT EXISTS ix_video_records_llm_status ON video_records (llm_status);
CREATE INDEX IF NOT EXISTS ix_video_records_llm_prompt_id ON video_records (llm_prompt_id);
CREATE INDEX IF NOT EXISTS ix_video_records_llm_analysis_id ON video_records (llm_analysis_id);
CREATE INDEX IF NOT EXISTS ix_video_records_recorded_at ON video_records (recorded_at);

-- 步骤6：删除旧表
DROP TABLE video_records_old;

COMMIT;
