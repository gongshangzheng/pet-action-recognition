# 🚨 紧急修复指南：video_records 字段缺失

## 问题现象

```
ERROR - 保存视频记录失败: table video_records has no column named llm_next_retry_at
```

## 🔥 立即修复（不停机）

在服务器上执行以下命令：

```bash
# 1. 进入项目目录
cd /path/to/pet-videos

# 2. 拉取最新代码
git pull origin dev

# 3. 执行字段同步（不需要停止服务）
cd backend
python3 migrations/migrate_sync_video_records.py database/history.db
```

**预期输出**：
```
📂 数据库路径: database/history.db
⏰ 开始时间: 2026-02-12 11:13:34

🔍 检查表结构...

📝 需要添加 1 个字段:
  • llm_next_retry_at: 下次重试时间

开始迁移...

[1/1] 添加字段 llm_next_retry_at...
  ✓ llm_next_retry_at 字段已添加

✅ 迁移完成！
```

## ⚠️ 重要说明

1. **无需停止服务**：SQLite 的 `ALTER TABLE ADD COLUMN` 是安全操作
2. **只添加字段**：不会修改或删除任何现有数据
3. **立即生效**：添加后新请求会正常工作
4. **向下兼容**：旧代码也能继续运行（字段可为空）

## 🔍 验证修复

```bash
# 检查字段是否添加成功
cd backend
sqlite3 database/history.db "SELECT name FROM pragma_table_info('video_records') WHERE name = 'llm_next_retry_at';"

# 应该输出：
# llm_next_retry_at
```

## 📋 完整部署（后续）

如果想完整部署所有更新（包括 daily_reports 表升级），可以稍后执行：

```bash
cd backend/migrations
./deploy_to_server.sh
```

但这需要停止服务并执行完整迁移。

---

**创建时间**：2026-02-12  
**优先级**：🔥 紧急
