#!/usr/bin/env python3
"""
数据库迁移脚本：同步 video_records 表字段

变更说明：
1. 添加 llm_next_retry_at 字段（如果不存在）
2. 添加 call_type 字段（如果不存在）

使用方法：
    python3 migrations/migrate_sync_video_records.py [数据库路径]
    
示例：
    python3 migrations/migrate_sync_video_records.py database/server/history.db
    python3 migrations/migrate_sync_video_records.py  # 使用config中的路径
"""
import sqlite3
from pathlib import Path
import sys
from datetime import datetime

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))


def check_column_exists(cursor, table_name: str, column_name: str) -> bool:
    """检查列是否存在"""
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = [row[1] for row in cursor.fetchall()]
    return column_name in columns


def migrate(db_path: str):
    """执行迁移"""
    db_file = Path(db_path)
    
    if not db_file.exists():
        print(f"❌ 数据库文件不存在: {db_file}")
        return False
    
    print(f"📂 数据库路径: {db_file}")
    print(f"⏰ 开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    try:
        conn = sqlite3.connect(str(db_file))
        cursor = conn.cursor()
        
        # 检查表是否存在
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='video_records'")
        table_exists = cursor.fetchone()
        
        if not table_exists:
            print("❌ video_records 表不存在")
            return False
        
        print("🔍 检查表结构...")
        
        # 检查需要添加的字段
        fields_to_add = []
        
        # 1. 检查 llm_next_retry_at
        if not check_column_exists(cursor, 'video_records', 'llm_next_retry_at'):
            fields_to_add.append({
                'name': 'llm_next_retry_at',
                'sql': 'ALTER TABLE video_records ADD COLUMN llm_next_retry_at DATETIME',
                'description': '下次重试时间'
            })
        else:
            print("  ✓ llm_next_retry_at 字段已存在")
        
        # 2. 检查 call_type
        if not check_column_exists(cursor, 'video_records', 'call_type'):
            fields_to_add.append({
                'name': 'call_type',
                'sql': "ALTER TABLE video_records ADD COLUMN call_type VARCHAR(20) NOT NULL DEFAULT 'manual'",
                'description': '调用类型 (manual/auto)'
            })
        else:
            print("  ✓ call_type 字段已存在")
        
        if not fields_to_add:
            print("\n✅ 数据库结构已是最新，无需迁移")
            return True
        
        print(f"\n📝 需要添加 {len(fields_to_add)} 个字段:")
        for field in fields_to_add:
            print(f"  • {field['name']}: {field['description']}")
        
        print("\n开始迁移...")
        
        # 执行迁移
        for i, field in enumerate(fields_to_add, 1):
            print(f"\n[{i}/{len(fields_to_add)}] 添加字段 {field['name']}...")
            cursor.execute(field['sql'])
            print(f"  ✓ {field['name']} 字段已添加")
        
        # 如果添加了 call_type，创建索引
        if any(f['name'] == 'call_type' for f in fields_to_add):
            print("\n创建索引...")
            try:
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_video_records_call_type ON video_records(call_type)")
                print("  ✓ idx_video_records_call_type 索引已创建")
            except Exception as e:
                print(f"  ⚠️  索引创建失败（可能已存在）: {e}")
        
        conn.commit()
        print("\n✅ 迁移完成！")
        
        # 验证结果
        print("\n📋 迁移后的字段:")
        cursor.execute("PRAGMA table_info(video_records)")
        columns = cursor.fetchall()
        
        # 只显示新添加的字段
        added_names = [f['name'] for f in fields_to_add]
        for col in columns:
            if col[1] in added_names:
                not_null = " NOT NULL" if col[3] == 1 else ""
                default = f" DEFAULT {col[4]}" if col[4] else ""
                print(f"  ✓ {col[1]:25} {col[2]:15}{not_null}{default}")
        
        print(f"\n⏰ 完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        return True
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        conn.close()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        db_path = sys.argv[1]
    else:
        # 使用config中的路径
        try:
            from config import settings
            db_path = settings.database_path
        except Exception as e:
            print(f"❌ 无法加载配置: {e}")
            print("用法: python3 migrate_sync_video_records.py <数据库路径>")
            sys.exit(1)
    
    success = migrate(db_path)
    sys.exit(0 if success else 1)
