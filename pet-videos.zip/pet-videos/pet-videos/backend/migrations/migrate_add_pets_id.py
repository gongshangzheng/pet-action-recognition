"""为 pets 表添加自增ID主键

从联合主键 (did, pet_name) 改为自增ID主键
保留 (did, pet_name) 的唯一性约束
"""
import sqlite3
import os
import sys
from pathlib import Path
from datetime import datetime

def get_db_path():
    """动态获取数据库路径"""
    # 优先使用环境变量
    db_path = os.environ.get('DATABASE_PATH')
    if db_path:
        return db_path
    
    # 尝试从配置文件读取
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from config import settings
        return settings.database_path
    except:
        # 默认路径（backend/database）
        return str(Path(__file__).parent.parent / "database" / "history.db")

def backup_database(db_path):
    """备份数据库"""
    import shutil
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{db_path}.backup_{timestamp}"
    shutil.copy2(db_path, backup_path)
    print(f"✓ 数据库已备份: {backup_path}")
    return backup_path

def migrate():
    """执行迁移"""
    # 数据库路径
    db_path = Path(get_db_path())
    
    if not db_path.exists():
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    print(f"数据库路径: {db_path}")
    
    # 备份数据库
    try:
        backup_path = backup_database(db_path)
    except Exception as e:
        print(f"❌ 备份失败: {e}")
        return False
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 检查表是否存在
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='pets'
        """)
        
        if not cursor.fetchone():
            print("❌ pets 表不存在，请先创建表")
            return False
        
        # 检查是否已经有id字段
        cursor.execute("PRAGMA table_info(pets)")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]
        
        if 'id' in column_names:
            print("✓ pets 表已经有 id 字段，无需迁移")
            return True
        
        print("正在为 pets 表添加自增ID主键...")
        
        # Step 1: 创建新表（带自增ID）
        print("  [1/6] 创建新表 pets_new...")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS pets_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                did VARCHAR(50) NOT NULL,
                pet_name VARCHAR(100) NOT NULL,
                pet_type VARCHAR(50),
                breed VARCHAR(100),
                gender VARCHAR(10),
                birth_date VARCHAR(10),
                weight REAL,
                color VARCHAR(100),
                avatar_url VARCHAR(500),
                description TEXT,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Step 2: 复制旧数据
        print("  [2/6] 复制数据...")
        cursor.execute("""
            INSERT INTO pets_new (did, pet_name, pet_type, breed, gender, birth_date, 
                                  weight, color, avatar_url, description, created_at, updated_at)
            SELECT did, pet_name, pet_type, breed, gender, birth_date,
                   weight, color, avatar_url, description, created_at, updated_at
            FROM pets
        """)
        
        # 获取复制的记录数
        copied_rows = cursor.rowcount
        print(f"     已复制 {copied_rows} 条记录")
        
        # Step 3: 删除旧表
        print("  [3/6] 删除旧表...")
        cursor.execute("DROP TABLE pets")
        
        # Step 4: 重命名新表
        print("  [4/6] 重命名新表...")
        cursor.execute("ALTER TABLE pets_new RENAME TO pets")
        
        # Step 5: 创建索引
        print("  [5/6] 创建索引...")
        cursor.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_pets_did_name 
            ON pets(did, pet_name)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_pets_did 
            ON pets(did)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_pets_pet_name 
            ON pets(pet_name)
        """)
        
        # Step 6: 提交事务
        print("  [6/6] 提交事务...")
        conn.commit()
        
        # 验证迁移结果
        print("\n验证迁移结果...")
        cursor.execute("PRAGMA table_info(pets)")
        new_columns = cursor.fetchall()
        
        # 检查id字段
        id_col = next((col for col in new_columns if col[1] == 'id'), None)
        if id_col and id_col[5] == 1:  # pk=1表示主键
            print("  ✓ id 字段已创建（主键，自增）")
        else:
            print("  ❌ id 字段验证失败")
            return False
        
        # 检查数据完整性
        cursor.execute("SELECT COUNT(*) FROM pets")
        new_count = cursor.fetchone()[0]
        print(f"  ✓ 数据记录数: {new_count}")
        
        # 检查索引
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='index' AND tbl_name='pets'
        """)
        indexes = cursor.fetchall()
        print(f"  ✓ 索引数量: {len(indexes)}")
        
        print("\n✅ 迁移成功完成！")
        print(f"\n备份文件: {backup_path}")
        print("\n下一步:")
        print("1. 重启 Backend 服务")
        print("2. 重启 Service 服务")
        print("3. 测试 API 接口")
        
        return True
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        conn.rollback()
        print(f"\n可以从备份恢复: {backup_path}")
        return False
    finally:
        conn.close()

if __name__ == "__main__":
    print("=" * 50)
    print("Pets 表自增ID迁移")
    print("=" * 50)
    print()
    
    success = migrate()
    
    sys.exit(0 if success else 1)
