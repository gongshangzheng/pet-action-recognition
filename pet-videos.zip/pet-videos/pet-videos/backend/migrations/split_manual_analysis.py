#!/usr/bin/env python3
"""
分离手动分析表迁移脚本
将 video_records 表中的手动分析记录迁移到新的 manual_analysis 表
"""

import sqlite3
import sys
import os
from pathlib import Path
from datetime import datetime

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

def create_manual_analysis_table(cursor):
    """创建 manual_analysis 表"""
    print("创建 manual_analysis 表...")
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS manual_analysis (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            
            -- 文件信息
            file_name VARCHAR(500) NOT NULL,
            file_path VARCHAR(1000) NOT NULL,
            file_size INTEGER,
            
            -- 视频元信息
            duration FLOAT,
            width INTEGER,
            height INTEGER,
            fps FLOAT,
            codec VARCHAR(50),
            
            -- 分析参数
            prompt TEXT NOT NULL,
            model_name VARCHAR(100) NOT NULL,
            analysis_fps FLOAT NOT NULL,
            max_pixels INTEGER NOT NULL,
            min_pixels INTEGER NOT NULL,
            vl_high_resolution_images BOOLEAN NOT NULL DEFAULT 0,
            
            -- Token 统计和费用
            input_tokens INTEGER,
            output_tokens INTEGER,
            total_tokens INTEGER,
            analysis_cost FLOAT,
            analysis_duration_sec FLOAT,
            
            -- 分析结果
            llm_result TEXT,
            llm_raw_response TEXT,
            llm_error TEXT,
            
            -- 状态
            status VARCHAR(20) NOT NULL DEFAULT 'completed',
            
            -- 时间戳
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # 创建索引
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_manual_analysis_file_name ON manual_analysis(file_name)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_manual_analysis_file_path ON manual_analysis(file_path)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_manual_analysis_model_name ON manual_analysis(model_name)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_manual_analysis_status ON manual_analysis(status)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_manual_analysis_created_at ON manual_analysis(created_at)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_manual_analysis_file_path_created ON manual_analysis(file_path, created_at)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_manual_analysis_status_created ON manual_analysis(status, created_at)")
    
    print("✅ manual_analysis 表创建完成")

def migrate_manual_records(cursor):
    """迁移手动分析记录"""
    print("迁移手动分析记录...")
    
    # 查询所有手动分析记录
    cursor.execute("""
        SELECT 
            file_name, file_path, COALESCE(file_size, 0) as file_size,
            duration, width, height, fps, codec,
            COALESCE(prompt, '') as prompt, 
            COALESCE(model_name, '') as model_name, 
            COALESCE(analysis_fps, 1.0) as analysis_fps, 
            COALESCE(max_pixels, 655360) as max_pixels, 
            COALESCE(min_pixels, 4096) as min_pixels, 
            COALESCE(vl_high_resolution_images, 0) as vl_high_resolution_images,
            input_tokens, output_tokens, total_tokens, analysis_cost, analysis_duration_sec,
            llm_result, llm_raw_response, llm_error,
            CASE 
                WHEN llm_status = 'completed' THEN 'completed'
                ELSE 'failed'
            END as status,
            created_at, updated_at
        FROM video_records 
        WHERE call_type = 'manual'
        ORDER BY created_at
    """)
    
    manual_records = cursor.fetchall()
    print(f"找到 {len(manual_records)} 条手动分析记录")
    
    if not manual_records:
        print("没有手动分析记录需要迁移")
        return
    
    # 插入到 manual_analysis 表
    migrated_count = 0
    for record in manual_records:
        try:
            cursor.execute("""
                INSERT INTO manual_analysis (
                    file_name, file_path, file_size,
                    duration, width, height, fps, codec,
                    prompt, model_name, analysis_fps, max_pixels, min_pixels, vl_high_resolution_images,
                    input_tokens, output_tokens, total_tokens, analysis_cost, analysis_duration_sec,
                    llm_result, llm_raw_response, llm_error,
                    status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, record)  # 跳过原始 id
            migrated_count += 1
        except Exception as e:
            print(f"迁移记录失败: {record[2]} - {e}")
    
    print(f"✅ 成功迁移 {migrated_count} 条手动分析记录")

def clean_video_records(cursor):
    """清理 video_records 表中的手动记录"""
    print("清理 video_records 表中的手动记录...")
    
    # 删除手动分析记录
    cursor.execute("DELETE FROM video_records WHERE call_type = 'manual'")
    deleted_count = cursor.rowcount
    print(f"✅ 删除了 {deleted_count} 条手动分析记录")

def update_video_records_schema(cursor):
    """更新 video_records 表结构（移除手动相关字段）"""
    print("更新 video_records 表结构...")
    
    # SQLite 不支持 DROP COLUMN，需要重建表
    # 1. 创建新表结构（只保留自动分析相关字段）
    cursor.execute("""
        CREATE TABLE video_records_new (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_id INTEGER NOT NULL,
            
            -- 用户信息（从 stream_sources 获取）
            did VARCHAR(50) NOT NULL DEFAULT '0',
            
            -- 文件信息
            file_name VARCHAR(500) NOT NULL,
            file_path VARCHAR(1000) NOT NULL,
            file_size INTEGER,
            
            -- 视频元信息
            duration FLOAT,
            width INTEGER,
            height INTEGER,
            fps FLOAT,
            codec VARCHAR(50),
            
            -- 检测信息
            detection_type VARCHAR(20),  -- pet/motion
            
            -- LLM 分析参数（自动分析）
            prompt TEXT,  -- 替换后的完整提示词
            model_name VARCHAR(100),
            analysis_fps FLOAT,
            max_pixels INTEGER,
            min_pixels INTEGER,
            vl_high_resolution_images BOOLEAN,
            
            -- LLM Token 统计和费用
            input_tokens INTEGER,
            output_tokens INTEGER,
            total_tokens INTEGER,
            analysis_cost FLOAT,
            analysis_duration_sec FLOAT,
            
            -- LLM 任务队列字段
            llm_status VARCHAR(20) NOT NULL DEFAULT 'pending',  -- pending, processing, completed, failed, skipped
            llm_prompt_id INTEGER,
            llm_result TEXT,
            llm_raw_response TEXT,
            llm_error TEXT,
            llm_analysis_id INTEGER,
            llm_started_at DATETIME,
            llm_completed_at DATETIME,
            llm_retry_count INTEGER NOT NULL DEFAULT 0,
            llm_next_retry_at DATETIME,
            
            -- 时间戳
            recorded_at DATETIME NOT NULL,  -- 视频录制时间
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # 2. 复制自动分析记录到新表
    cursor.execute("""
        INSERT INTO video_records_new 
        SELECT 
            id, source_id, did,
            file_name, file_path, file_size,
            duration, width, height, fps, codec,
            detection_type,
            prompt, model_name, analysis_fps, max_pixels, min_pixels, vl_high_resolution_images,
            input_tokens, output_tokens, total_tokens, analysis_cost, analysis_duration_sec,
            llm_status, llm_prompt_id, llm_result, llm_raw_response, llm_error,
            llm_analysis_id, llm_started_at, llm_completed_at, llm_retry_count, llm_next_retry_at,
            recorded_at, created_at, updated_at
        FROM video_records 
        WHERE call_type = 'auto'
    """)
    
    # 3. 删除旧表，重命名新表
    cursor.execute("DROP TABLE video_records")
    cursor.execute("ALTER TABLE video_records_new RENAME TO video_records")
    
    # 4. 重建索引
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_video_records_source_id ON video_records(source_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_video_records_did ON video_records(did)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_video_records_file_name ON video_records(file_name)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_video_records_model_name ON video_records(model_name)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_video_records_llm_status ON video_records(llm_status)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_video_records_llm_prompt_id ON video_records(llm_prompt_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_video_records_llm_analysis_id ON video_records(llm_analysis_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_video_records_created_at ON video_records(created_at)")
    cursor.execute("CREATE INDEX IF NOT EXISTS ix_video_records_recorded_at ON video_records(recorded_at)")
    
    print("✅ video_records 表结构更新完成")

def main():
    """主函数"""
    print("=" * 60)
    print("开始分离手动分析表迁移")
    print("=" * 60)
    
    # 数据库路径
    db_path = project_root / "backend" / "database" / "history.db"
    if not db_path.exists():
        print(f"❌ 数据库文件不存在: {db_path}")
        sys.exit(1)
    
    # 备份数据库
    backup_path = db_path.with_suffix(f'.backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db')
    print(f"备份数据库到: {backup_path}")
    
    import shutil
    shutil.copy2(db_path, backup_path)
    print("✅ 数据库备份完成")
    
    # 连接数据库
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 开始事务
        conn.execute("BEGIN TRANSACTION")
        
        # 1. 创建 manual_analysis 表
        create_manual_analysis_table(cursor)
        
        # 2. 迁移手动分析记录
        migrate_manual_records(cursor)
        
        # 3. 更新 video_records 表结构
        update_video_records_schema(cursor)
        
        # 提交事务
        conn.commit()
        print("\n" + "=" * 60)
        print("✅ 迁移完成！")
        print("=" * 60)
        
        # 验证结果
        cursor.execute("SELECT COUNT(*) FROM manual_analysis")
        manual_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM video_records")
        auto_count = cursor.fetchone()[0]
        
        print(f"manual_analysis 表记录数: {manual_count}")
        print(f"video_records 表记录数: {auto_count}")
        
    except Exception as e:
        print(f"❌ 迁移失败: {e}")
        conn.rollback()
        sys.exit(1)
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    main()