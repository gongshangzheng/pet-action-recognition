# 数据库迁移工具

本目录包含数据库迁移脚本和部署工具。

## 📁 文件说明

### 迁移脚本

- **`migrate_server_daily_reports.py`** ⭐ 服务器部署专用
  - 升级 daily_reports 表到 V3.0 结构
  - 适用于表中**无数据**的情况（直接删除重建）
  - 用法：`python3 migrate_server_daily_reports.py <数据库路径>`

- **`migrate_sync_video_records.py`** ⭐ 同步表结构
  - 同步 video_records 表，添加缺失字段
  - 智能检测并只添加需要的字段（llm_next_retry_at, call_type）
  - 用法：`python3 migrate_sync_video_records.py <数据库路径>`

- **`migrate_rebuild_daily_reports.py`** 
  - 升级 daily_reports 表到 V3.0 结构
  - 适用于表中**有数据**的情况（备份、迁移、恢复）
  - 用法：`python3 migrate_rebuild_daily_reports.py`（读取 config.py 中的路径）

- **`migrate_add_daily_report_fields.py`**
  - 添加 daily_tag 和 insight_text 字段（V2.0）
  - 已被 `migrate_rebuild_daily_reports.py` 包含

### 部署工具

- **`deploy_to_server.sh`** ⭐ 一键部署脚本
  - 自动完成：备份、停止服务、迁移、重启服务
  - 用法：`./deploy_to_server.sh`

### 文档

- **`SERVER_MIGRATION_GUIDE.md`** - 详细的服务器迁移指南

## 🚀 快速开始

### 服务器部署（推荐）

```bash
# 1. 上传代码到服务器
git push origin dev

# 服务器执行
cd /path/to/pet-videos/backend/migrations
git pull origin dev

# 2. 一键部署
./deploy_to_server.sh
```

### 手动迁移

```bash
# 1. 备份数据库
cp backend/database/history.db backend/database/history.db.backup

# 2. 停止服务
pkill -f "python.*main.py"

# 3. 执行迁移（表中无数据）
cd backend
python3 migrations/migrate_server_daily_reports.py database/history.db

# 4. 重启服务
nohup python3 main.py > logs/backend.log 2>&1 &
```

## 📋 daily_reports 表结构变更历史

### V1.0（原始）
```sql
PRIMARY KEY (did, date, pet_name)
字段: did, date, pet_name, summary, analysis_data, video_count, total_duration
```

### V2.0（2026-02-11）
新增字段：
- `daily_tag` VARCHAR(50) - 日报标签
- `insight_text` TEXT - 洞察建议

### V3.0（2026-02-12）⭐ 当前版本
主键变更：
- `id` INTEGER PRIMARY KEY AUTOINCREMENT（替代复合主键）
- 支持同一天同一宠物的多条记录（用于追踪调试）

新增字段：
- `llm_request` TEXT - LLM原始请求
- `llm_response` TEXT - LLM原始响应
- `generation_status` VARCHAR(20) - 生成状态
- `error_message` TEXT - 错误信息
- `retry_count` INTEGER - 重试次数

## ⚠️ 注意事项

1. **始终先备份数据库**
2. **停止服务后再迁移**
3. **验证迁移结果**
4. **检查服务日志**

## 🔍 验证迁移结果

```bash
# 检查表结构（应该有16个字段）
sqlite3 database/history.db "PRAGMA table_info(daily_reports);"

# 检查索引（应该有4个）
sqlite3 database/history.db "SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='daily_reports';"

# 检查记录数
sqlite3 database/history.db "SELECT COUNT(*) FROM daily_reports;"
```

## 📞 问题排查

### 迁移失败
1. 检查数据库文件是否被占用
2. 确认服务已完全停止
3. 查看迁移脚本输出的错误信息

### 服务无法启动
1. 查看日志：`tail -f backend/logs/backend.log`
2. 检查端口占用：`lsof -i:8002`
3. 验证数据库结构是否正确

### 日报功能异常
1. 检查环境变量：`cat backend/.env | grep DAILY_REPORT`
2. 查看服务状态：`curl http://localhost:8002/api/daily-report-generator/status`
3. 检查数据库中是否有行为记录：`sqlite3 database/history.db "SELECT COUNT(*) FROM pet_behaviors;"`

---

**最后更新**：2026-02-12  
**维护者**：Pet Videos Team
