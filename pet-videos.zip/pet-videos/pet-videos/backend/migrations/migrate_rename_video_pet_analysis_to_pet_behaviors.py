#!/usr/bin/env python3
"""
数据库迁移：重命名 video_pet_analysis 表为 pet_behaviors

原因：
- video_pet_analysis 语义不清晰
- pet_behaviors 更直观地表达"宠物行为记录"的含义

执行方式：
    python migrations/migrate_rename_video_pet_analysis_to_pet_behaviors.py
"""

import sqlite3
import os
import sys
from pathlib import Path

def get_db_path():
    """获取数据库路径"""
    # 优先使用环境变量
    db_path = os.environ.get('DATABASE_PATH')
    if db_path:
        return db_path
    
    # 尝试从配置文件读取
    try:
        backend_dir = Path(__file__).parent.parent
        sys.path.insert(0, str(backend_dir))
        from config import settings
        return settings.database_path
    except:
        # 默认路径
        return str(Path(__file__).parent.parent / 'database' / 'history.db')

def migrate():
    """执行迁移"""
    db_path = get_db_path()
    print(f"📂 数据库路径: {db_path}")
    
    if not os.path.exists(db_path):
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        print("\n" + "="*60)
        print("🚀 开始迁移：重命名 video_pet_analysis → pet_behaviors")
        print("="*60 + "\n")
        
        # 检查旧表是否存在
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='video_pet_analysis'
        """)
        
        if not cursor.fetchone():
            print("  ℹ️  video_pet_analysis 表不存在，跳过迁移")
            
            # 检查新表是否已存在
            cursor.execute("""
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='pet_behaviors'
            """)
            
            if cursor.fetchone():
                print("  ✅ pet_behaviors 表已存在")
            return True
        
        # 检查新表是否已存在
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='pet_behaviors'
        """)
        
        if cursor.fetchone():
            print("  ⚠️  pet_behaviors 表已存在，将删除 video_pet_analysis 表")
            cursor.execute("DROP TABLE video_pet_analysis")
            conn.commit()
            print("  ✅ 已删除 video_pet_analysis 表")
            return True
        
        # 执行重命名
        print("  📝 重命名表...")
        cursor.execute("ALTER TABLE video_pet_analysis RENAME TO pet_behaviors")
        
        # 重建索引（如果有的话）
        print("  📝 重建索引...")
        
        # 删除旧索引
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='index' AND tbl_name='pet_behaviors'
        """)
        old_indexes = cursor.fetchall()
        for (idx_name,) in old_indexes:
            if idx_name.startswith('sqlite_'):
                continue
            print(f"    - 删除旧索引: {idx_name}")
            cursor.execute(f"DROP INDEX IF EXISTS {idx_name}")
        
        # 创建新索引
        indexes = [
            ("idx_pet_behaviors_video_id", "video_id"),
            ("idx_pet_behaviors_pet_name", "pet_name"),
            ("idx_pet_behaviors_did", "did"),
        ]
        
        for idx_name, column in indexes:
            cursor.execute(f"""
                CREATE INDEX IF NOT EXISTS {idx_name}
                ON pet_behaviors({column})
            """)
            print(f"    ✓ 创建索引: {idx_name}")
        
        conn.commit()
        
        # 统计数据
        cursor.execute("SELECT COUNT(*) FROM pet_behaviors")
        count = cursor.fetchone()[0]
        
        print("\n" + "="*60)
        print("✅ 迁移完成！")
        print("="*60)
        print(f"\n📊 统计: pet_behaviors 表共 {count} 条记录\n")
        
        print("⚠️  重要提示:")
        print("  1. 需要更新代码中的表名引用")
        print("  2. 需要更新 API 接口")
        print("  3. 建议重启应用服务")
        
        return True
        
    except Exception as e:
        conn.rollback()
        print(f"\n❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    success = migrate()
    sys.exit(0 if success else 1)
