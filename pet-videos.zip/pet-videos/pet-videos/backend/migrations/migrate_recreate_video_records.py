"""重建视频记录表（调整字段结构）"""
import sqlite3
from pathlib import Path

def migrate():
    db_path = Path(__file__).parent / "database" / "history.db"
    
    if not db_path.exists():
        print(f"数据库文件不存在: {db_path}")
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # 删除旧表
    print("删除旧的 video_records 表...")
    cursor.execute("DROP TABLE IF EXISTS video_records")
    
    # 创建新表
    print("创建新的 video_records 表...")
    cursor.execute("""
        CREATE TABLE video_records (
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            source_id INTEGER NOT NULL,
            
            -- 文件信息（不存储 mp4 文件本身）
            file_name VARCHAR(500) NOT NULL,
            file_path VARCHAR(1000) NOT NULL,
            file_size INTEGER,
            
            -- 视频元信息
            duration FLOAT,
            width INTEGER,
            height INTEGER,
            fps FLOAT,
            codec VARCHAR(50),
            
            -- 检测信息
            detection_type VARCHAR(20),
            
            -- LLM 任务队列字段
            llm_status VARCHAR(20) NOT NULL DEFAULT 'pending',
            llm_prompt_id INTEGER,
            llm_result TEXT,
            llm_error TEXT,
            llm_analysis_id INTEGER,
            llm_started_at DATETIME,
            llm_completed_at DATETIME,
            llm_retry_count INTEGER NOT NULL DEFAULT 0,
            
            -- 时间戳
            recorded_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL
        )
    """)
    
    # 创建索引
    print("创建索引...")
    cursor.execute("CREATE INDEX ix_video_records_id ON video_records (id)")
    cursor.execute("CREATE INDEX ix_video_records_source_id ON video_records (source_id)")
    cursor.execute("CREATE INDEX ix_video_records_file_name ON video_records (file_name)")
    cursor.execute("CREATE INDEX ix_video_records_llm_status ON video_records (llm_status)")
    cursor.execute("CREATE INDEX ix_video_records_llm_prompt_id ON video_records (llm_prompt_id)")
    cursor.execute("CREATE INDEX ix_video_records_llm_analysis_id ON video_records (llm_analysis_id)")
    cursor.execute("CREATE INDEX ix_video_records_recorded_at ON video_records (recorded_at)")
    
    conn.commit()
    conn.close()
    
    print("✓ video_records 表重建成功")
    print("✓ 索引创建完成")
    print("迁移完成")

if __name__ == "__main__":
    migrate()
