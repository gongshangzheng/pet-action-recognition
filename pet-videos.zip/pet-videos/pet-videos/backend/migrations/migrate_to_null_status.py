#!/usr/bin/env python3
"""
迁移到新的NULL状态设计

旧设计：pending → processing → completed/failed/expired
新设计：NULL → processing → completed/failed

迁移内容：
1. 将pending和expired状态改为NULL
2. 重置超时的processing状态为NULL
3. 保留completed和failed状态
"""
import sys
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from sqlalchemy import create_engine, text
from datetime import datetime, timedelta

def migrate_to_null_status(db_path: str = None):
    """迁移到NULL状态设计"""
    
    if db_path:
        engine = create_engine(f'sqlite:///{db_path}')
    else:
        from models.db import engine
    
    conn = engine.connect()
    trans = conn.begin()
    
    try:
        print("="*60)
        print("迁移到NULL状态设计")
        print("="*60)
        print()
        
        # 0. 修改表结构，允许llm_status为NULL
        print("步骤0：修改表结构，允许llm_status为NULL...")
        # SQLite不支持直接修改列约束，需要重建表
        conn.execute(text("""
            -- 临时禁用外键约束
            PRAGMA foreign_keys=OFF
        """))
        
        conn.execute(text("""
            -- 创建临时表
            CREATE TABLE video_records_new AS SELECT * FROM video_records
        """))
        
        conn.execute(text("""
            -- 删除旧表
            DROP TABLE video_records
        """))
        
        conn.execute(text("""
            -- 创建新表（llm_status允许NULL）
            CREATE TABLE video_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id INTEGER NOT NULL,
                call_type VARCHAR(20) DEFAULT 'auto' NOT NULL,
                did VARCHAR(50) DEFAULT '0' NOT NULL,
                file_name VARCHAR(500) NOT NULL,
                file_path VARCHAR(1000) NOT NULL,
                file_size INTEGER,
                duration FLOAT,
                width INTEGER,
                height INTEGER,
                fps FLOAT,
                codec VARCHAR(50),
                detection_type VARCHAR(20),
                prompt TEXT,
                model_name VARCHAR(100),
                analysis_fps FLOAT,
                max_pixels INTEGER,
                min_pixels INTEGER,
                vl_high_resolution_images BOOLEAN,
                input_tokens INTEGER,
                output_tokens INTEGER,
                total_tokens INTEGER,
                analysis_cost FLOAT,
                analysis_duration_sec FLOAT,
                llm_status VARCHAR(20),  -- 允许NULL
                llm_prompt_id INTEGER,
                llm_result TEXT,
                llm_raw_response TEXT,
                llm_error TEXT,
                llm_analysis_id INTEGER,
                llm_started_at DATETIME,
                llm_completed_at DATETIME,
                llm_retry_count INTEGER DEFAULT 0 NOT NULL,
                llm_next_retry_at DATETIME,
                recorded_at DATETIME NOT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            )
        """))
        
        conn.execute(text("""
            -- 复制数据回新表
            INSERT INTO video_records SELECT * FROM video_records_new
        """))
        
        conn.execute(text("""
            -- 删除临时表
            DROP TABLE video_records_new
        """))
        
        conn.execute(text("""
            -- 重新创建索引
            CREATE INDEX ix_video_records_source_id ON video_records (source_id);
            CREATE INDEX ix_video_records_did ON video_records (did);
            CREATE INDEX ix_video_records_file_name ON video_records (file_name);
            CREATE INDEX ix_video_records_model_name ON video_records (model_name);
            CREATE INDEX ix_video_records_llm_status ON video_records (llm_status);
            CREATE INDEX ix_video_records_llm_prompt_id ON video_records (llm_prompt_id);
            CREATE INDEX ix_video_records_llm_analysis_id ON video_records (llm_analysis_id);
            CREATE INDEX ix_video_records_recorded_at ON video_records (recorded_at)
        """))
        
        conn.execute(text("""
            -- 重新启用外键约束
            PRAGMA foreign_keys=ON
        """))
        
        print("  ✅ 表结构已修改，llm_status现在允许NULL")
        print()
        
        # 1. 查看当前状态分布
        print("当前状态分布:")
        result = conn.execute(text("""
            SELECT llm_status, COUNT(*) as count
            FROM video_records
            GROUP BY llm_status
            ORDER BY llm_status
        """))
        for row in result:
            status = row[0] if row[0] else 'NULL'
            print(f"  {status}: {row[1]} 条")
        print()
        
        # 2. 将pending和expired改为NULL
        print("步骤1：将pending和expired状态改为NULL...")
        result = conn.execute(text("""
            UPDATE video_records 
            SET llm_status = NULL,
                updated_at = datetime('now', 'localtime')
            WHERE llm_status IN ('pending', 'expired')
        """))
        pending_expired_count = result.rowcount
        print(f"  ✅ 更新了 {pending_expired_count} 条记录（pending/expired → NULL）")
        print()
        
        # 3. 重置超时的processing状态
        print("步骤2：重置超时的processing状态（超过30分钟）...")
        result = conn.execute(text("""
            UPDATE video_records 
            SET llm_status = NULL,
                llm_error = '任务超时，已重置',
                llm_retry_count = llm_retry_count + 1,
                llm_next_retry_at = NULL,
                updated_at = datetime('now', 'localtime')
            WHERE llm_status = 'processing' 
              AND datetime(llm_started_at) < datetime('now', '-30 minutes', 'localtime')
        """))
        timeout_count = result.rowcount
        print(f"  ✅ 重置了 {timeout_count} 条超时的processing任务")
        print()
        
        # 4. 提交事务
        trans.commit()
        
        # 5. 显示迁移后的状态分布
        print("迁移后的状态分布:")
        result = conn.execute(text("""
            SELECT llm_status, COUNT(*) as count
            FROM video_records
            GROUP BY llm_status
            ORDER BY llm_status
        """))
        for row in result:
            status = row[0] if row[0] else 'NULL (未处理)'
            print(f"  {status}: {row[1]} 条")
        print()
        
        # 6. 显示时间窗口统计
        print("时间窗口内未处理任务统计（1小时窗口）:")
        result = conn.execute(text("""
            SELECT COUNT(*) as count
            FROM video_records
            WHERE llm_status IS NULL
              AND datetime(created_at) >= datetime('now', '-1 hours', 'localtime')
        """))
        window_count = result.fetchone()[0]
        print(f"  窗口内未处理: {window_count} 条")
        
        result = conn.execute(text("""
            SELECT COUNT(*) as count
            FROM video_records
            WHERE llm_status IS NULL
              AND datetime(created_at) < datetime('now', '-1 hours', 'localtime')
        """))
        outside_count = result.fetchone()[0]
        print(f"  窗口外未处理: {outside_count} 条（不会被自动处理）")
        print()
        
        print("="*60)
        print(f"✅ 迁移完成！")
        print(f"   pending/expired → NULL: {pending_expired_count} 条")
        print(f"   processing超时重置: {timeout_count} 条")
        print("="*60)
        
        return pending_expired_count + timeout_count
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        trans.rollback()
        return 0
    finally:
        conn.close()

def main():
    import argparse
    parser = argparse.ArgumentParser(description="迁移到NULL状态设计")
    parser.add_argument('db_path', nargs='?', help='数据库文件路径（可选，默认使用配置中的数据库）')
    args = parser.parse_args()
    
    if args.db_path:
        print(f"使用数据库: {args.db_path}\n")
    else:
        print("使用默认配置数据库\n")
    
    migrate_to_null_status(args.db_path)

if __name__ == "__main__":
    main()
