"""
添加 video_records 表的日历查询索引

为了优化日历接口的查询性能，添加组合索引：
- source_id + recorded_at 组合索引（用于日历日期查询）
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.db import get_db
from sqlalchemy import text
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def add_calendar_index():
    """添加日历查询的组合索引"""
    db = next(get_db())
    
    try:
        # 检查索引是否已存在
        result = db.execute(text("""
            SELECT name FROM sqlite_master 
            WHERE type='index' AND name='ix_video_records_source_recorded'
        """)).fetchone()
        
        if result:
            logger.info("索引 ix_video_records_source_recorded 已存在，跳过")
            return
        
        logger.info("开始添加索引 ix_video_records_source_recorded...")
        
        # 创建组合索引
        db.execute(text("""
            CREATE INDEX ix_video_records_source_recorded 
            ON video_records(source_id, recorded_at)
        """))
        
        db.commit()
        logger.info("索引添加成功！")
        
        # 验证索引
        result = db.execute(text("""
            SELECT sql FROM sqlite_master 
            WHERE type='index' AND name='ix_video_records_source_recorded'
        """)).fetchone()
        
        if result:
            logger.info(f"索引创建语句: {result[0]}")
        
    except Exception as e:
        logger.error(f"添加索引失败: {e}", exc_info=True)
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    logger.info("=== 添加日历查询索引 ===")
    add_calendar_index()
    logger.info("=== 完成 ===")
