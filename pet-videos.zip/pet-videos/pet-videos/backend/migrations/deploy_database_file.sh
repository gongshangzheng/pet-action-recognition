#!/bin/bash

# 直接部署已迁移数据库文件的脚本
# 适用于：本地已完成数据库迁移，直接上传到服务器
# 用法: ./deploy_database_file.sh <服务器地址> <服务器路径>

set -e

echo "========================================="
echo "  数据库文件直接部署脚本"
echo "========================================="
echo ""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 配置
LOCAL_DB="database/server/history.db"
BACKEND_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# 检查参数
if [ $# -lt 2 ]; then
    echo -e "${RED}用法: $0 <服务器地址> <服务器项目路径>${NC}"
    echo ""
    echo "示例:"
    echo "  $0 user@server.com /path/to/pet-videos"
    echo "  $0 root@192.168.1.100 /opt/pet-videos"
    exit 1
fi

SERVER="$1"
SERVER_PATH="$2"
SERVER_DB_PATH="${SERVER_PATH}/backend/database/history.db"

echo -e "${BLUE}📂 本地数据库: ${LOCAL_DB}${NC}"
echo -e "${BLUE}🖥️  服务器: ${SERVER}${NC}"
echo -e "${BLUE}📂 服务器路径: ${SERVER_DB_PATH}${NC}"
echo ""

# 检查本地数据库文件
cd "${BACKEND_DIR}"
if [ ! -f "${LOCAL_DB}" ]; then
    echo -e "${RED}❌ 本地数据库文件不存在: ${LOCAL_DB}${NC}"
    exit 1
fi

# 显示文件信息
FILE_SIZE=$(ls -lh "${LOCAL_DB}" | awk '{print $5}')
echo -e "${GREEN}✓ 本地数据库文件存在 (${FILE_SIZE})${NC}"
echo ""

# 验证并同步本地数据库结构
echo -e "${YELLOW}验证并同步本地数据库结构...${NC}"

# 1. 检查 daily_reports 表
FIELD_COUNT=$(sqlite3 "${LOCAL_DB}" "PRAGMA table_info(daily_reports);" | wc -l)
if [ "${FIELD_COUNT}" -eq "16" ]; then
    echo -e "${GREEN}✓ daily_reports 表结构正确 (16个字段)${NC}"
else
    echo -e "${RED}❌ daily_reports 表结构异常，字段数: ${FIELD_COUNT}，期望: 16${NC}"
    exit 1
fi

# 2. 同步 video_records 表（添加缺失字段）
echo -e "${BLUE}同步 video_records 表...${NC}"
python3 migrations/migrate_sync_video_records.py "${LOCAL_DB}"
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ video_records 表同步失败${NC}"
    exit 1
fi
echo ""

# 确认部署
echo -e "${YELLOW}⚠️  警告：将替换服务器上的数据库文件${NC}"
echo -e "   服务器数据库将被备份到: history.db.backup_${TIMESTAMP}"
echo ""
read -p "确认部署？(yes/no): " confirm
if [ "${confirm}" != "yes" ]; then
    echo -e "${RED}❌ 已取消部署${NC}"
    exit 1
fi
echo ""

# 1. 在服务器上备份现有数据库
echo -e "${YELLOW}[1/4] 在服务器上备份数据库...${NC}"
ssh "${SERVER}" "cd ${SERVER_PATH}/backend && \
    mkdir -p database/backups && \
    cp database/history.db database/backups/history.db.backup_${TIMESTAMP} 2>/dev/null || true"
echo -e "${GREEN}✓ 服务器备份完成${NC}"
echo ""

# 2. 停止服务器服务
echo -e "${YELLOW}[2/4] 停止服务器服务...${NC}"
ssh "${SERVER}" "pkill -f 'python.*main.py' || echo '服务未运行或已停止'"
sleep 2
echo -e "${GREEN}✓ 服务已停止${NC}"
echo ""

# 3. 上传数据库文件
echo -e "${YELLOW}[3/4] 上传数据库文件...${NC}"
scp "${LOCAL_DB}" "${SERVER}:${SERVER_DB_PATH}"
echo -e "${GREEN}✓ 文件上传完成${NC}"
echo ""

# 4. 重启服务器服务
echo -e "${YELLOW}[4/4] 重启服务器服务...${NC}"
ssh "${SERVER}" "cd ${SERVER_PATH}/backend && \
    nohup python3 main.py > logs/backend.log 2>&1 & \
    echo \"服务已启动 (PID: \$!)\""
echo -e "${GREEN}✓ 服务已重启${NC}"
echo ""

# 等待服务启动
echo -e "${BLUE}等待服务启动 (5秒)...${NC}"
sleep 5

# 验证服务状态
echo -e "${YELLOW}验证服务状态...${NC}"
HEALTH_CHECK=$(ssh "${SERVER}" "curl -s http://localhost:8002/api/health 2>/dev/null || echo 'FAILED'")

if [[ "${HEALTH_CHECK}" == *"status"* ]]; then
    echo -e "${GREEN}✓ 服务运行正常${NC}"
else
    echo -e "${RED}⚠️  服务可能未正常启动，请检查日志${NC}"
    echo -e "${YELLOW}   查看日志: ssh ${SERVER} 'tail -f ${SERVER_PATH}/backend/logs/backend.log'${NC}"
fi
echo ""

# 完成
echo "========================================="
echo -e "${GREEN}✅ 部署完成！${NC}"
echo "========================================="
echo ""
echo "📋 后续步骤:"
echo "  1. 访问前端查看宠物日报功能"
echo "  2. 检查日志: ssh ${SERVER} 'tail -f ${SERVER_PATH}/backend/logs/backend.log'"
echo "  3. 验证数据: ssh ${SERVER} 'cd ${SERVER_PATH}/backend && sqlite3 database/history.db \"SELECT COUNT(*) FROM daily_reports;\"'"
echo ""
echo "🔙 如需回滚:"
echo "  ssh ${SERVER} 'cd ${SERVER_PATH}/backend && \\"
echo "    pkill -f \"python.*main.py\" && \\"
echo "    cp database/backups/history.db.backup_${TIMESTAMP} database/history.db && \\"
echo "    nohup python3 main.py > logs/backend.log 2>&1 &'"
echo ""
