#!/usr/bin/env python3
"""
迁移到新的NULL状态设计（简化版）

直接使用SQL修改，不重建表结构
"""
import sqlite3
import sys

def migrate_simple(db_path):
    """简化迁移"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        print("="*60)
        print("迁移到NULL状态设计（简化版）")
        print("="*60)
        print()
        
        # 1. 查看当前状态分布
        print("当前状态分布:")
        cursor.execute("""
            SELECT llm_status, COUNT(*) as count
            FROM video_records
            GROUP BY llm_status
            ORDER BY llm_status
        """)
        for row in cursor.fetchall():
            status = row[0] if row[0] else 'NULL'
            print(f"  {status}: {row[1]} 条")
        print()
        
        # 2. 使用临时值替代NULL（绕过NOT NULL约束）
        print("步骤1：将pending和expired状态改为临时标记...")
        cursor.execute("""
            UPDATE video_records 
            SET llm_status = '__TO_NULL__',
                updated_at = datetime('now', 'localtime')
            WHERE llm_status IN ('pending', 'expired')
        """)
        count1 = cursor.rowcount
        print(f"  ✅ 标记了 {count1} 条记录")
        print()
        
        # 3. 重置超时的processing
        print("步骤2：重置超时的processing状态...")
        cursor.execute("""
            UPDATE video_records 
            SET llm_status = '__TO_NULL__',
                llm_error = '任务超时，已重置',
                llm_retry_count = COALESCE(llm_retry_count, 0) + 1,
                llm_next_retry_at = NULL,
                updated_at = datetime('now', 'localtime')
            WHERE llm_status = 'processing' 
              AND datetime(llm_started_at) < datetime('now', '-30 minutes', 'localtime')
        """)
        count2 = cursor.rowcount
        print(f"  ✅ 重置了 {count2} 条超时任务")
        print()
        
        conn.commit()
        
        # 4. 显示迁移后的状态分布
        print("迁移后的状态分布:")
        cursor.execute("""
            SELECT 
                CASE 
                    WHEN llm_status = '__TO_NULL__' THEN 'NULL (待修复)'
                    ELSE llm_status
                END as status,
                COUNT(*) as count
            FROM video_records
            GROUP BY llm_status
            ORDER BY llm_status
        """)
        for row in cursor.fetchall():
            print(f"  {row[0]}: {row[1]} 条")
        print()
        
        print("="*60)
        print(f"✅ 第一阶段完成！")
        print(f"   标记为待迁移: {count1 + count2} 条")
        print(f"   需要部署新代码后，llm_status字段允许NULL")
        print(f"   然后运行第二阶段：将'__TO_NULL__'改为真正的NULL")
        print("="*60)
        
        return count1 + count2
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        conn.rollback()
        return 0
    finally:
        conn.close()

def main():
    if len(sys.argv) < 2:
        print("用法: python3 migrate_to_null_status_simple.py <数据库路径>")
        sys.exit(1)
    
    db_path = sys.argv[1]
    print(f"使用数据库: {db_path}\n")
    
    migrate_simple(db_path)

if __name__ == "__main__":
    main()
