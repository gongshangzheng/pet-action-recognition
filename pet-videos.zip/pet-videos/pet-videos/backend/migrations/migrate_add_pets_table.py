"""创建 pets 表"""
import sqlite3
import os
import sys
from pathlib import Path

def get_db_path():
    """动态获取数据库路径"""
    # 优先使用环境变量
    db_path = os.environ.get('DATABASE_PATH')
    if db_path:
        return db_path
    
    # 尝试从配置文件读取
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from config import settings
        return settings.database_path
    except:
        # 默认路径
        return str(Path(__file__).parent.parent / "database" / "history.db")

def migrate():
    # 数据库路径
    db_path = Path(get_db_path())
    
    if not db_path.exists():
        print(f"数据库文件不存在: {db_path}")
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # 检查表是否已存在
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name='pets'
    """)
    
    if not cursor.fetchone():
        print("正在创建 pets 表...")
        cursor.execute("""
            CREATE TABLE pets (
                did TEXT NOT NULL,
                pet_name TEXT NOT NULL,
                pet_type TEXT,
                breed TEXT,
                gender TEXT,
                birth_date TEXT,
                color TEXT,
                avatar_url TEXT,
                description TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (did, pet_name)
            )
        """)
        conn.commit()
        print("✓ pets 表创建成功")
        
        # 创建索引
        print("正在创建索引...")
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_pets_did 
            ON pets(did)
        """)
        conn.commit()
        print("✓ 索引创建成功")
    else:
        print("pets 表已存在，跳过")
    
    conn.close()
    print("迁移完成")

if __name__ == "__main__":
    migrate()
