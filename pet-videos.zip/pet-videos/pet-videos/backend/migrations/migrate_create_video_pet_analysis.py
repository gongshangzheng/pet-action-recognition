#!/usr/bin/env python3
"""
创建 video_pet_analysis 表

执行：python3 migrations/migrate_create_video_pet_analysis.py
"""

import sqlite3
import sys
from pathlib import Path

def get_db_path():
    """获取数据库路径"""
    try:
        backend_dir = Path(__file__).parent.parent
        sys.path.insert(0, str(backend_dir))
        from config import settings
        return settings.database_path
    except:
        return str(Path(__file__).parent.parent / 'database' / 'history.db')

def migrate():
    """执行迁移"""
    db_path = get_db_path()
    print(f"📂 数据库路径: {db_path}\n")
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        print("="*60)
        print("🚀 创建 video_pet_analysis 表")
        print("="*60 + "\n")
        
        # 检查表是否已存在
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='video_pet_analysis'
        """)
        
        if cursor.fetchone():
            print("  ℹ️  video_pet_analysis 表已存在，跳过创建\n")
            return True
        
        # 创建 video_pet_analysis 表
        print("  📝 创建 video_pet_analysis 表...")
        cursor.execute("""
            CREATE TABLE video_pet_analysis (
                video_id INTEGER NOT NULL,
                pet_name VARCHAR(100) NOT NULL,
                did VARCHAR(50) NOT NULL,
                actions VARCHAR(200),
                description TEXT,
                status VARCHAR(200),
                location VARCHAR(200),
                score INTEGER,
                raw_result TEXT,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (video_id, pet_name),
                FOREIGN KEY (video_id) REFERENCES video_records(id)
            )
        """)
        
        # 创建索引
        print("  📝 创建索引...")
        cursor.execute("""
            CREATE INDEX idx_video_pet_analysis_video_id 
            ON video_pet_analysis(video_id)
        """)
        cursor.execute("""
            CREATE INDEX idx_video_pet_analysis_pet_name 
            ON video_pet_analysis(pet_name)
        """)
        cursor.execute("""
            CREATE INDEX idx_video_pet_analysis_did 
            ON video_pet_analysis(did)
        """)
        
        conn.commit()
        
        print("\n" + "="*60)
        print("✅ 迁移完成！")
        print("="*60)
        print("\n📊 video_pet_analysis 表已创建\n")
        
        return True
        
    except Exception as e:
        conn.rollback()
        print(f"\n❌ 迁移失败: {e}\n")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    success = migrate()
    sys.exit(0 if success else 1)
