@echo off
REM Run migration 002: Add pets id

setlocal
set "SCRIPT_DIR=%~dp0"
set "DB_PATH=%SCRIPT_DIR%..\database\history.db"

echo ========================================
echo Migration 002: Add pets id
echo ========================================
echo.

REM 检查数据库文件是否存在
if not exist "%DB_PATH%" (
    echo [ERROR] Database file not found: %DB_PATH%
    exit /b 1
)

REM 备份数据库
for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate=%%c%%a%%b)
for /f "tokens=1-2 delims=/:" %%a in ('time /t') do (set mytime=%%a%%b)
set "BACKUP_PATH=%DB_PATH%.backup_%mydate%_%mytime%"

echo [1/3] Backing up database...
copy "%DB_PATH%" "%BACKUP_PATH%" >nul
echo       Backup saved to: %BACKUP_PATH%
echo.

REM 执行迁移
echo [2/3] Running migration...
sqlite3 "%DB_PATH%" < "%SCRIPT_DIR%002_add_pets_id.sql"

if %errorlevel% neq 0 (
    echo [ERROR] Migration failed!
    echo       Restoring from backup...
    copy "%BACKUP_PATH%" "%DB_PATH%" >nul
    echo       Database restored
    exit /b 1
)
echo       Migration completed successfully
echo.

REM 验证结果
echo [3/3] Verifying migration...
sqlite3 "%DB_PATH%" "PRAGMA table_info(pets);" | findstr /C:"0|id|INTEGER" >nul

if %errorlevel% equ 0 (
    echo       * ID field added successfully
    echo.
    echo Migration 002 completed!
    echo.
    echo Table structure:
    sqlite3 "%DB_PATH%" "PRAGMA table_info(pets);"
) else (
    echo [ERROR] Verification failed!
    exit /b 1
)

endlocal
