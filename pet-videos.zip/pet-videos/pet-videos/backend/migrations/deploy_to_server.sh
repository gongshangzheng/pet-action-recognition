#!/bin/bash

# 服务器数据库迁移部署脚本
# 用法: ./deploy_to_server.sh

set -e  # 遇到错误立即退出

echo "========================================="
echo "  服务器数据库迁移部署脚本"
echo "========================================="
echo ""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 配置
BACKEND_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DB_PATH="${BACKEND_DIR}/database/history.db"
BACKUP_DIR="${BACKEND_DIR}/database/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

echo -e "${BLUE}📂 后端目录: ${BACKEND_DIR}${NC}"
echo -e "${BLUE}📂 数据库路径: ${DB_PATH}${NC}"
echo ""

# 步骤 1: 检查数据库文件
echo -e "${YELLOW}[1/6] 检查数据库文件...${NC}"
if [ ! -f "${DB_PATH}" ]; then
    echo -e "${RED}❌ 数据库文件不存在: ${DB_PATH}${NC}"
    exit 1
fi
echo -e "${GREEN}✓ 数据库文件存在${NC}"
echo ""

# 步骤 2: 备份数据库
echo -e "${YELLOW}[2/6] 备份数据库...${NC}"
mkdir -p "${BACKUP_DIR}"
BACKUP_FILE="${BACKUP_DIR}/history.db.backup_${TIMESTAMP}"
cp "${DB_PATH}" "${BACKUP_FILE}"
echo -e "${GREEN}✓ 备份完成: ${BACKUP_FILE}${NC}"
echo ""

# 步骤 3: 检查 daily_reports 表数据量
echo -e "${YELLOW}[3/6] 检查 daily_reports 表数据量...${NC}"
RECORD_COUNT=$(sqlite3 "${DB_PATH}" "SELECT COUNT(*) FROM daily_reports;" 2>/dev/null || echo "0")
echo -e "   当前记录数: ${RECORD_COUNT}"

if [ "${RECORD_COUNT}" -gt "0" ]; then
    echo -e "${RED}⚠️  警告: 表中有 ${RECORD_COUNT} 条数据！${NC}"
    echo -e "${YELLOW}   建议使用 migrate_rebuild_daily_reports.py 进行数据迁移${NC}"
    read -p "   是否继续？数据将丢失！(yes/no): " confirm
    if [ "${confirm}" != "yes" ]; then
        echo -e "${RED}❌ 已取消迁移${NC}"
        exit 1
    fi
fi
echo ""

# 步骤 4: 停止后端服务
echo -e "${YELLOW}[4/6] 停止后端服务...${NC}"
pkill -f "python.*main.py" || echo -e "${YELLOW}   服务未运行或已停止${NC}"
sleep 2
echo -e "${GREEN}✓ 服务已停止${NC}"
echo ""

# 步骤 5: 执行迁移
echo -e "${YELLOW}[5/6] 执行数据库迁移...${NC}"
cd "${BACKEND_DIR}"

# 5.1 迁移 daily_reports 表
echo -e "${BLUE}  迁移 daily_reports 表...${NC}"
python3 migrations/migrate_server_daily_reports.py "${DB_PATH}"
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ daily_reports 迁移失败！正在恢复备份...${NC}"
    cp "${BACKUP_FILE}" "${DB_PATH}"
    echo -e "${GREEN}✓ 已从备份恢复${NC}"
    exit 1
fi

# 5.2 同步 video_records 表
echo -e "${BLUE}  同步 video_records 表...${NC}"
python3 migrations/migrate_sync_video_records.py "${DB_PATH}"
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ video_records 同步失败！正在恢复备份...${NC}"
    cp "${BACKUP_FILE}" "${DB_PATH}"
    echo -e "${GREEN}✓ 已从备份恢复${NC}"
    exit 1
fi
echo ""

# 步骤 6: 重启服务
echo -e "${YELLOW}[6/6] 重启后端服务...${NC}"
nohup python3 main.py > logs/backend.log 2>&1 &
BACKEND_PID=$!
echo -e "${GREEN}✓ 服务已启动 (PID: ${BACKEND_PID})${NC}"
echo ""

# 等待服务启动
echo -e "${BLUE}等待服务启动...${NC}"
sleep 5

# 验证服务状态
echo -e "${YELLOW}验证服务状态...${NC}"
HEALTH_CHECK=$(curl -s http://localhost:8002/api/health || echo "FAILED")

if [[ "${HEALTH_CHECK}" == *"status"* ]]; then
    echo -e "${GREEN}✓ 服务运行正常${NC}"
else
    echo -e "${RED}⚠️  服务可能未正常启动，请检查日志${NC}"
    echo -e "${YELLOW}   日志位置: ${BACKEND_DIR}/logs/backend.log${NC}"
fi
echo ""

# 完成
echo "========================================="
echo -e "${GREEN}✅ 部署完成！${NC}"
echo "========================================="
echo ""
echo "📋 后续步骤:"
echo "  1. 访问前端查看宠物日报功能"
echo "  2. 检查日志: tail -f ${BACKEND_DIR}/logs/backend.log"
echo "  3. 如无问题可删除备份: rm ${BACKUP_FILE}"
echo ""
echo "🔙 如需回滚:"
echo "  1. 停止服务: pkill -f 'python.*main.py'"
echo "  2. 恢复备份: cp ${BACKUP_FILE} ${DB_PATH}"
echo "  3. 重启服务: cd ${BACKEND_DIR} && nohup python3 main.py > logs/backend.log 2>&1 &"
echo ""
