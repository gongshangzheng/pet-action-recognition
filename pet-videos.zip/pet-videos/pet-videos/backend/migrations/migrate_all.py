#!/usr/bin/env python3
"""
统一数据库迁移脚本
自动检测并添加所有缺失的字段

运行方式：python backend/migrations/migrate_all.py
"""
import sys
import os
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / "backend"))

from sqlalchemy import create_engine, text, inspect
from backend.config import settings

def migrate():
    """执行所有迁移"""
    import os
    
    print("=" * 60)
    print("数据库迁移 - 检查并添加所有缺失字段")
    print("=" * 60)
    print()
    
    print(f"数据库路径: {settings.database_path}")
    print(f"绝对路径: {os.path.abspath(settings.database_path)}")
    print(f"文件存在: {os.path.exists(settings.database_path)}")
    print()
    
    database_url = f"sqlite:///{settings.database_path}"
    engine = create_engine(database_url)
    
    # 检查表是否存在
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    
    if 'slicing_tasks' not in tables:
        print("✗ slicing_tasks 表不存在！")
        print()
        print("正在自动创建所有表...")
        
        # 自动创建所有表
        try:
            from backend.models.database import Base
            Base.metadata.create_all(bind=engine)
            print("✓ 数据库表创建成功")
            print()
            
            # 重新获取表信息
            inspector = inspect(engine)
            tables = inspector.get_table_names()
            print(f"创建的表: {', '.join(tables)}")
            print()
        except Exception as e:
            print(f"✗ 创建表失败: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    with engine.connect() as conn:
        # 重新获取最新的表结构
        inspector = inspect(engine)
        
        # 确保表存在
        if 'slicing_tasks' not in inspector.get_table_names():
            print("✗ 表创建后仍然不存在，请检查模型定义")
            return False
        
        columns = {col['name'] for col in inspector.get_columns('slicing_tasks')}
        print(f"当前字段: {', '.join(sorted(columns))}")
        print()
        
        migrations = []
        
        # 1. script_file 字段
        if 'script_file' not in columns:
            print("[1/3] 添加 script_file 字段...")
            conn.execute(text("""
                ALTER TABLE slicing_tasks 
                ADD COLUMN script_file VARCHAR(200) NOT NULL DEFAULT 'pet_monitor.py'
            """))
            conn.commit()
            print("      ✓ script_file 字段添加成功")
            migrations.append('script_file')
        else:
            print("[1/3] ✓ script_file 字段已存在")
        
        # 2. consecutive_failures 字段
        if 'consecutive_failures' not in columns:
            print("[2/3] 添加 consecutive_failures 字段...")
            conn.execute(text("""
                ALTER TABLE slicing_tasks 
                ADD COLUMN consecutive_failures INTEGER NOT NULL DEFAULT 0
            """))
            conn.commit()
            print("      ✓ consecutive_failures 字段添加成功")
            migrations.append('consecutive_failures')
        else:
            print("[2/3] ✓ consecutive_failures 字段已存在")
        
        # 3. enable_yolo 字段
        if 'enable_yolo' not in columns:
            print("[3/3] 添加 enable_yolo 字段...")
            conn.execute(text("""
                ALTER TABLE slicing_tasks 
                ADD COLUMN enable_yolo BOOLEAN NOT NULL DEFAULT 1
            """))
            conn.commit()
            print("      ✓ enable_yolo 字段添加成功")
            migrations.append('enable_yolo')
        else:
            print("[3/3] ✓ enable_yolo 字段已存在")
        
        print()
        print("=" * 60)
        if migrations:
            print(f"✓ 迁移完成！添加了 {len(migrations)} 个字段: {', '.join(migrations)}")
        else:
            print("✓ 数据库已是最新版本，无需迁移")
        print("=" * 60)
        return True

if __name__ == "__main__":
    try:
        success = migrate()
        sys.exit(0 if success else 1)
    except Exception as e:
        print()
        print(f"✗ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
