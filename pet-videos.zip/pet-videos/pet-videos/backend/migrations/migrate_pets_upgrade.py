"""
Pets表升级迁移（合并版本）

包含的变更：
1. 添加自增ID主键（从联合主键改为自增ID）
2. 添加avatar_color字段（头像背景色）

执行方式：
python3 backend/migrations/migrate_pets_upgrade.py
"""
import sqlite3
import os
import sys
from pathlib import Path
from datetime import datetime

def get_db_path():
    """动态获取数据库路径"""
    # 优先使用环境变量
    db_path = os.environ.get('DATABASE_PATH')
    if db_path:
        return db_path
    
    # 尝试从配置文件读取
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from config import settings
        return settings.database_path
    except:
        # 默认路径（backend/database）
        return str(Path(__file__).parent.parent / "database" / "history.db")

def backup_database(db_path):
    """备份数据库"""
    import shutil
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{db_path}.backup_{timestamp}"
    shutil.copy2(db_path, backup_path)
    print(f"✓ 数据库已备份: {backup_path}")
    return backup_path

def check_and_add_id_field(cursor, conn):
    """检查并添加ID字段"""
    print("\n[1/2] 检查并添加自增ID主键...")
    
    # 首先检查pets表是否存在
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name='pets'
    """)
    if not cursor.fetchone():
        print("    ❌ pets表不存在")
        print("\n请先执行以下迁移脚本创建pets表：")
        print("    python3 backend/migrations/migrate_add_pets_table.py")
        print("或:")
        print("    python3 backend/migrations/migrate_create_pets_table.py")
        return False
    
    # 检查是否已经有id字段
    cursor.execute("PRAGMA table_info(pets)")
    columns = cursor.fetchall()
    column_names = [col[1] for col in columns]
    
    if 'id' in column_names:
        print("    ✓ ID字段已存在，跳过")
        return True
    
    print("    开始添加ID字段...")
    
    # Step 1: 创建新表（带自增ID）
    print("      [1.1] 创建新表 pets_new...")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS pets_new (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            did VARCHAR(50) NOT NULL,
            pet_name VARCHAR(100) NOT NULL,
            pet_type VARCHAR(50),
            breed VARCHAR(100),
            gender VARCHAR(10),
            birth_date VARCHAR(10),
            weight REAL,
            color VARCHAR(100),
            avatar_url VARCHAR(500),
            description TEXT,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Step 2: 复制旧数据
    print("      [1.2] 复制数据...")
    cursor.execute("""
        INSERT INTO pets_new (did, pet_name, pet_type, breed, gender, birth_date, 
                              weight, color, avatar_url, description, created_at, updated_at)
        SELECT did, pet_name, pet_type, breed, gender, birth_date,
               weight, color, avatar_url, description, created_at, updated_at
        FROM pets
    """)
    copied_rows = cursor.rowcount
    print(f"           已复制 {copied_rows} 条记录")
    
    # Step 3: 删除旧表
    print("      [1.3] 删除旧表...")
    cursor.execute("DROP TABLE pets")
    
    # Step 4: 重命名新表
    print("      [1.4] 重命名新表...")
    cursor.execute("ALTER TABLE pets_new RENAME TO pets")
    
    # Step 5: 创建索引
    print("      [1.5] 创建索引...")
    cursor.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS idx_pets_did_name 
        ON pets(did, pet_name)
    """)
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_pets_did 
        ON pets(did)
    """)
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_pets_pet_name 
        ON pets(pet_name)
    """)
    
    conn.commit()
    print("    ✓ ID字段添加成功")
    return True

def check_and_add_avatar_color(cursor, conn):
    """检查并添加avatar_color字段"""
    print("\n[2/2] 检查并添加avatar_color字段...")
    
    # 首先检查pets表是否存在
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name='pets'
    """)
    if not cursor.fetchone():
        print("    ❌ pets表不存在，跳过")
        return False
    
    # 检查avatar_color字段是否已存在
    cursor.execute("PRAGMA table_info(pets)")
    columns = [row[1] for row in cursor.fetchall()]
    
    if 'avatar_color' in columns:
        print("    ✓ avatar_color字段已存在，跳过")
        return True
    
    print("    开始添加avatar_color字段...")
    
    # 添加字段
    print("      [2.1] 添加字段...")
    cursor.execute("""
        ALTER TABLE pets ADD COLUMN avatar_color VARCHAR(10)
    """)
    
    # 设置默认值
    print("      [2.2] 设置默认值 #E5E7EB...")
    cursor.execute("""
        UPDATE pets SET avatar_color = '#E5E7EB' WHERE avatar_color IS NULL
    """)
    
    conn.commit()
    print("    ✓ avatar_color字段添加成功")
    return True

def verify_migration(cursor):
    """验证迁移结果"""
    print("\n验证迁移结果...")
    
    # 检查表结构
    cursor.execute("PRAGMA table_info(pets)")
    columns = cursor.fetchall()
    
    # 检查id字段
    id_col = next((col for col in columns if col[1] == 'id'), None)
    if id_col and id_col[5] == 1:  # pk=1表示主键
        print("  ✓ id字段已创建（主键，自增）")
    else:
        print("  ❌ id字段验证失败")
        return False
    
    # 检查avatar_color字段
    if any(col[1] == 'avatar_color' for col in columns):
        print("  ✓ avatar_color字段已创建")
    else:
        print("  ❌ avatar_color字段验证失败")
        return False
    
    # 检查数据完整性
    cursor.execute("SELECT COUNT(*) FROM pets")
    count = cursor.fetchone()[0]
    print(f"  ✓ 数据记录数: {count}")
    
    # 检查索引
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='index' AND tbl_name='pets'
    """)
    indexes = cursor.fetchall()
    print(f"  ✓ 索引数量: {len(indexes)}")
    
    return True

def migrate():
    """执行迁移"""
    db_path = Path(get_db_path())
    
    if not db_path.exists():
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    print("=" * 60)
    print("Pets表升级迁移（合并版本）")
    print("=" * 60)
    print(f"\n数据库路径: {db_path}")
    
    # 备份数据库
    try:
        backup_path = backup_database(db_path)
    except Exception as e:
        print(f"❌ 备份失败: {e}")
        return False
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 执行迁移
        success1 = check_and_add_id_field(cursor, conn)
        success2 = check_and_add_avatar_color(cursor, conn)
        
        if not (success1 and success2):
            print("\n❌ 迁移执行失败")
            return False
        
        # 验证迁移结果
        if not verify_migration(cursor):
            print("\n❌ 迁移验证失败")
            return False
        
        print("\n" + "=" * 60)
        print("✅ 迁移成功完成！")
        print("=" * 60)
        print(f"\n备份文件: {backup_path}")
        print("\n变更内容:")
        print("  1. ✓ 添加自增ID主键")
        print("  2. ✓ 添加avatar_color字段（默认值：#E5E7EB）")
        print("\n下一步:")
        print("  1. 重启 Backend 服务")
        print("  2. 重启 Service 服务")
        print("  3. 验证 API 接口")
        print()
        
        return True
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        conn.rollback()
        print(f"\n可以从备份恢复: {backup_path}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        conn.close()

if __name__ == "__main__":
    success = migrate()
    sys.exit(0 if success else 1)
