"""
数据库迁移脚本：添加 call_type 字段
用于区分手动调用和自动调用
"""
import sqlite3
import sys
from pathlib import Path

def migrate():
    """执行迁移"""
    db_path = Path(__file__).parent / 'database' / 'history.db'
    
    if not db_path.exists():
        print(f"⚠️  数据库文件不存在: {db_path}")
        print("   如果是新安装，数据库会在首次启动时自动创建")
        return
    
    print(f"连接数据库: {db_path}")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 检查字段是否存在
        cursor.execute("PRAGMA table_info(analysis_history)")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]
        
        if 'call_type' in column_names:
            print("✓ call_type 字段已存在，无需迁移")
            return
        
        print("正在添加 call_type 字段...")
        
        # 添加字段
        cursor.execute("""
            ALTER TABLE analysis_history 
            ADD COLUMN call_type VARCHAR(20) DEFAULT 'manual'
        """)
        
        # 添加索引
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_call_type 
            ON analysis_history(call_type)
        """)
        
        # 更新现有记录
        cursor.execute("""
            UPDATE analysis_history 
            SET call_type = 'manual' 
            WHERE call_type IS NULL
        """)
        
        conn.commit()
        
        # 验证
        cursor.execute("SELECT COUNT(*) FROM analysis_history")
        total = cursor.fetchone()[0]
        
        print(f"✅ 迁移完成")
        print(f"   • 添加了 call_type 字段")
        print(f"   • 添加了索引")
        print(f"   • 更新了 {total} 条现有记录")
        
    except Exception as e:
        print(f"❌ 迁移失败: {e}")
        conn.rollback()
        sys.exit(1)
    finally:
        conn.close()

if __name__ == '__main__':
    print("="*60)
    print("数据库迁移: 添加调用类型支持")
    print("="*60)
    print()
    migrate()
    print()
    print("="*60)
