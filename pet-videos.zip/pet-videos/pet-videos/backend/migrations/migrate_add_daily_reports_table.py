"""
添加 daily_reports 表的迁移脚本
创建宠物日报表，用于存储每日宠物行为汇总
"""
import sqlite3
import os
from pathlib import Path

def get_db_path():
    """获取数据库路径"""
    # 支持环境变量配置
    db_path = os.getenv('DATABASE_PATH')
    if db_path:
        return db_path
    
    # 尝试从配置文件读取
    try:
        import sys
        current_dir = Path(__file__).parent.parent
        sys.path.insert(0, str(current_dir))
        from config import settings
        return settings.database_path
    except:
        # 默认路径
        current_dir = Path(__file__).parent.parent
        return str(current_dir / 'database' / 'history.db')

def migrate():
    """执行迁移"""
    db_path = get_db_path()
    print(f"数据库路径: {db_path}")
    
    if not os.path.exists(db_path):
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 检查表是否已存在
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='daily_reports'
        """)
        
        if cursor.fetchone():
            print("ℹ️  daily_reports 表已存在，跳过创建")
            return True
        
        # 创建 daily_reports 表
        print("创建 daily_reports 表...")
        cursor.execute("""
            CREATE TABLE daily_reports (
                did VARCHAR(50) NOT NULL,
                date VARCHAR(10) NOT NULL,
                pet_name VARCHAR(100) NOT NULL,
                summary TEXT,
                analysis_data TEXT,
                video_count INTEGER DEFAULT 0,
                total_duration FLOAT DEFAULT 0.0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (did, date, pet_name)
            )
        """)
        
        # 创建索引
        print("创建索引...")
        cursor.execute("""
            CREATE INDEX idx_daily_reports_did 
            ON daily_reports(did)
        """)
        
        cursor.execute("""
            CREATE INDEX idx_daily_reports_date 
            ON daily_reports(date)
        """)
        
        cursor.execute("""
            CREATE INDEX idx_daily_reports_pet_name 
            ON daily_reports(pet_name)
        """)
        
        conn.commit()
        print("✅ daily_reports 表创建成功！")
        return True
        
    except Exception as e:
        conn.rollback()
        print(f"❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        conn.close()

if __name__ == '__main__':
    success = migrate()
    exit(0 if success else 1)
