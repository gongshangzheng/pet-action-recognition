"""
完整初始化迁移脚本

适用于全新部署或缺少表的服务器
会创建所有必需的表并升级到最新结构

执行方式：
python3 backend/migrations/migrate_init_all.py
"""
import sqlite3
import os
import sys
from pathlib import Path
from datetime import datetime

def get_db_path():
    """动态获取数据库路径"""
    db_path = os.environ.get('DATABASE_PATH')
    if db_path:
        return db_path
    
    try:
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from config import settings
        return settings.database_path
    except:
        return str(Path(__file__).parent.parent / "database" / "history.db")

def backup_database(db_path):
    """备份数据库"""
    import shutil
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{db_path}.backup_{timestamp}"
    shutil.copy2(db_path, backup_path)
    print(f"✓ 数据库已备份: {backup_path}")
    return backup_path

def create_pets_table(cursor, conn):
    """创建pets表（带ID和avatar_color）"""
    print("\n[1/1] 创建pets表...")
    
    # 检查表是否已存在
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name='pets'
    """)
    
    if cursor.fetchone():
        print("    ✓ pets表已存在，跳过创建")
        return True
    
    print("    正在创建pets表...")
    
    # 创建包含最新结构的表
    cursor.execute("""
        CREATE TABLE pets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            did VARCHAR(50) NOT NULL,
            pet_name VARCHAR(100) NOT NULL,
            pet_type VARCHAR(50),
            breed VARCHAR(100),
            gender VARCHAR(10),
            birth_date VARCHAR(10),
            weight REAL,
            color VARCHAR(100),
            avatar_url VARCHAR(500),
            avatar_color VARCHAR(10),
            description TEXT,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # 创建索引
    print("    正在创建索引...")
    cursor.execute("""
        CREATE UNIQUE INDEX idx_pets_did_name ON pets(did, pet_name)
    """)
    cursor.execute("""
        CREATE INDEX idx_pets_did ON pets(did)
    """)
    cursor.execute("""
        CREATE INDEX idx_pets_pet_name ON pets(pet_name)
    """)
    
    conn.commit()
    print("    ✓ pets表创建成功")
    return True

def verify_tables(cursor):
    """验证表结构"""
    print("\n验证数据库结构...")
    
    # 检查pets表
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name='pets'
    """)
    if not cursor.fetchone():
        print("  ❌ pets表不存在")
        return False
    print("  ✓ pets表存在")
    
    # 检查pets表结构
    cursor.execute("PRAGMA table_info(pets)")
    columns = {col[1]: col for col in cursor.fetchall()}
    
    required_fields = ['id', 'did', 'pet_name', 'avatar_color']
    missing_fields = [f for f in required_fields if f not in columns]
    
    if missing_fields:
        print(f"  ❌ pets表缺少字段: {', '.join(missing_fields)}")
        return False
    
    # 检查id是否为主键
    if columns['id'][5] != 1:  # pk标志
        print("  ❌ id字段不是主键")
        return False
    
    print("  ✓ id字段正确（主键，自增）")
    print("  ✓ avatar_color字段存在")
    
    # 检查索引
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='index' AND tbl_name='pets'
    """)
    indexes = cursor.fetchall()
    print(f"  ✓ 索引数量: {len(indexes)}")
    
    return True

def migrate():
    """执行迁移"""
    db_path = Path(get_db_path())
    
    print("=" * 60)
    print("完整初始化迁移")
    print("=" * 60)
    print(f"\n数据库路径: {db_path}")
    
    # 确保数据库目录存在
    db_path.parent.mkdir(parents=True, exist_ok=True)
    
    # 如果数据库不存在，创建它
    if not db_path.exists():
        print("\n数据库文件不存在，将创建新数据库")
        db_path.touch()
    
    # 备份数据库
    try:
        if db_path.stat().st_size > 0:  # 只有非空数据库才备份
            backup_path = backup_database(db_path)
        else:
            backup_path = None
            print("数据库为空，跳过备份")
    except Exception as e:
        print(f"备份失败: {e}")
        backup_path = None
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 创建pets表
        if not create_pets_table(cursor, conn):
            print("\n❌ 表创建失败")
            return False
        
        # 验证表结构
        if not verify_tables(cursor):
            print("\n❌ 表验证失败")
            return False
        
        print("\n" + "=" * 60)
        print("✅ 初始化成功完成！")
        print("=" * 60)
        if backup_path:
            print(f"\n备份文件: {backup_path}")
        print("\n创建的表:")
        print("  ✓ pets表（包含id主键和avatar_color字段）")
        print("\n下一步:")
        print("  1. 重启 Backend 服务")
        print("  2. 重启 Service 服务")
        print("  3. 验证 API 接口")
        print()
        
        return True
        
    except Exception as e:
        print(f"\n❌ 迁移失败: {e}")
        conn.rollback()
        if backup_path:
            print(f"\n可以从备份恢复: {backup_path}")
        import traceback
        traceback.print_exc()
        return False
    finally:
        conn.close()

if __name__ == "__main__":
    success = migrate()
    sys.exit(0 if success else 1)
