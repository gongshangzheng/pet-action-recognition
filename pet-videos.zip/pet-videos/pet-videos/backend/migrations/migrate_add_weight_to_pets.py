#!/usr/bin/env python3
"""
数据库迁移脚本：在 pets 表中添加 weight 字段

执行方式：
python3 backend/migrations/migrate_add_weight_to_pets.py
"""
import sqlite3
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def get_db_path():
    """动态获取数据库路径"""
    try:
        from config import settings
        return settings.database_path
    except:
        return 'database/history.db'

def migrate():
    db_path = get_db_path()
    print(f"连接到数据库: {db_path}")
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 1. 检查 weight 字段是否已存在
        cursor.execute("PRAGMA table_info(pets)")
        columns = [row[1] for row in cursor.fetchall()]
        
        if 'weight' in columns:
            print("✅ weight 字段已存在，无需迁移")
            return
        
        print("\n开始迁移...")
        
        # 2. 添加 weight 字段（体重，单位：kg）
        print("  - 添加 weight 字段...")
        cursor.execute("""
            ALTER TABLE pets ADD COLUMN weight REAL
        """)
        
        print("  - 创建索引...")
        # 可选：如果需要按体重筛选，可以创建索引
        # cursor.execute("CREATE INDEX idx_pets_weight ON pets(weight)")
        
        conn.commit()
        print("\n✅ 迁移成功！")
        print("\n变更内容：")
        print("  - pets 表新增 weight 字段（REAL 类型，可为空）")
        print("  - 单位：千克（kg）")
        
    except Exception as e:
        conn.rollback()
        print(f"\n❌ 迁移失败: {e}")
        raise
    finally:
        conn.close()

if __name__ == '__main__':
    migrate()
