"""
数据库迁移：添加 model_name 字段到 analysis_history 表
"""
import sqlite3
from pathlib import Path
import sys

# 添加 backend 目录到路径
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

from config import settings

def migrate():
    """执行迁移"""
    db_path = settings.database_path
    
    print(f"[迁移] 正在连接数据库: {db_path}")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 检查字段是否已存在
        cursor.execute("PRAGMA table_info(analysis_history)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'model_name' in columns:
            print("[迁移] model_name 字段已存在，跳过")
            return
        
        # 添加 model_name 字段
        print("[迁移] 添加 model_name 字段到 analysis_history 表...")
        cursor.execute("""
            ALTER TABLE analysis_history 
            ADD COLUMN model_name VARCHAR(100) DEFAULT 'qwen3-vl-plus'
        """)
        
        # 创建索引以提高查询性能
        print("[迁移] 创建 model_name 索引...")
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_analysis_history_model_name 
            ON analysis_history(model_name)
        """)
        
        conn.commit()
        print("[迁移] ✓ 迁移成功完成")
        
    except Exception as e:
        conn.rollback()
        print(f"[迁移] ✗ 迁移失败: {e}")
        raise
    finally:
        conn.close()

if __name__ == "__main__":
    migrate()
