#!/usr/bin/env python3
"""修复 video_records 表中的 did 字段
将 did 从 source_id 关联的 stream_sources 表中同步过来
"""
import sys
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from models.database import VideoRecord, StreamSource
from models.db import SessionLocal

def fix_video_records_did(db_path: str = None):
    """修复 video_records 的 did 字段"""
    
    # 如果提供了数据库路径，使用指定的数据库
    if db_path:
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker
        engine = create_engine(f'sqlite:///{db_path}')
        Session = sessionmaker(bind=engine)
        db = Session()
    else:
        db = SessionLocal()
    
    try:
        # 查询所有 video_records
        records = db.query(VideoRecord).all()
        
        print(f"总共找到 {len(records)} 条 video_records 记录")
        
        updated_count = 0
        skipped_count = 0
        error_count = 0
        
        # 按 source_id 分组处理，提高效率
        source_cache = {}
        
        for record in records:
            try:
                # 获取 source 信息（使用缓存）
                if record.source_id not in source_cache:
                    source = db.query(StreamSource).filter(StreamSource.id == record.source_id).first()
                    if source:
                        source_cache[record.source_id] = source.did if source.did else "0"
                    else:
                        source_cache[record.source_id] = "0"  # 源不存在，使用默认值
                
                correct_did = source_cache[record.source_id]
                
                # 检查是否需要更新
                if record.did != correct_did:
                    old_did = record.did
                    record.did = correct_did
                    updated_count += 1
                    
                    if updated_count <= 10:  # 只打印前10条示例
                        print(f"  更新 ID={record.id}: did '{old_did}' → '{correct_did}' (source_id={record.source_id})")
                else:
                    skipped_count += 1
                    
            except Exception as e:
                error_count += 1
                print(f"  ❌ 处理记录 ID={record.id} 失败: {e}")
        
        if updated_count > 0:
            db.commit()
            print(f"\n✅ 成功更新 {updated_count} 条记录")
        
        if skipped_count > 0:
            print(f"⏭️  跳过 {skipped_count} 条已正确的记录")
        
        if error_count > 0:
            print(f"❌ {error_count} 条记录处理失败")
        
        # 显示更新后的统计
        print("\n更新后的 did 分布:")
        from sqlalchemy import func
        did_stats = db.query(VideoRecord.did, func.count(VideoRecord.id)).group_by(VideoRecord.did).all()
        for did, count in did_stats:
            print(f"  did='{did}': {count} 条")
        
        return updated_count
        
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
        db.rollback()
        return 0
    finally:
        db.close()

def main():
    import argparse
    parser = argparse.ArgumentParser(description="修复 video_records 表的 did 字段")
    parser.add_argument('db_path', nargs='?', help='数据库文件路径（可选，默认使用配置中的数据库）')
    args = parser.parse_args()
    
    print("="*60)
    print("修复 video_records 表的 did 字段")
    print("="*60)
    print()
    
    if args.db_path:
        print(f"使用数据库: {args.db_path}\n")
    else:
        print("使用默认配置数据库\n")
    
    updated = fix_video_records_did(args.db_path)
    
    print("\n" + "="*60)
    if updated > 0:
        print(f"✅ 修复完成！共更新 {updated} 条记录")
    else:
        print("✅ 所有记录的 did 字段都已正确，无需更新")
    print("="*60)

if __name__ == "__main__":
    main()
