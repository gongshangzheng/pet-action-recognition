"""
添加 behavior_feedback 表的迁移脚本
存储用户对宠物行为的点赞/点踩反馈
"""
import sqlite3
import os
from pathlib import Path

def get_db_path():
    """获取数据库路径"""
    # 支持环境变量配置
    db_path = os.getenv('DATABASE_PATH')
    if db_path:
        return db_path
    
    # 尝试从配置文件读取
    try:
        import sys
        current_dir = Path(__file__).parent.parent
        sys.path.insert(0, str(current_dir))
        from config import settings
        return settings.database_path
    except:
        # 默认路径
        current_dir = Path(__file__).parent.parent
        return str(current_dir / 'database' / 'history.db')

def migrate():
    """执行迁移"""
    db_path = get_db_path()
    print(f"数据库路径: {db_path}")
    
    if not os.path.exists(db_path):
        print(f"❌ 数据库文件不存在: {db_path}")
        return False
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 检查表是否已存在
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='behavior_feedback'
        """)
        
        if cursor.fetchone():
            print("ℹ️  behavior_feedback 表已存在，跳过创建")
            return True
        
        # 创建 behavior_feedback 表
        print("创建 behavior_feedback 表...")
        cursor.execute("""
            CREATE TABLE behavior_feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video_id INTEGER NOT NULL,
                pet_name VARCHAR(100) NOT NULL,
                did VARCHAR(50) NOT NULL,
                action VARCHAR(10) NOT NULL CHECK(action IN ('like', 'dislike')),
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                
                FOREIGN KEY (video_id, pet_name) REFERENCES pet_behaviors(video_id, pet_name),
                UNIQUE(video_id, pet_name, did)
            )
        """)
        
        # 创建索引
        print("创建索引...")
        cursor.execute("""
            CREATE INDEX idx_behavior_feedback_lookup 
            ON behavior_feedback(video_id, pet_name, did)
        """)
        
        cursor.execute("""
            CREATE INDEX idx_behavior_feedback_did 
            ON behavior_feedback(did)
        """)
        
        cursor.execute("""
            CREATE INDEX idx_behavior_feedback_action 
            ON behavior_feedback(action)
        """)
        
        conn.commit()
        print("✅ behavior_feedback 表创建成功！")
        return True
        
    except Exception as e:
        conn.rollback()
        print(f"❌ 迁移失败: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        conn.close()

if __name__ == '__main__':
    success = migrate()
    exit(0 if success else 1)
