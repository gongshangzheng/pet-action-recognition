# Pet-Videos Database Migration Script (PowerShell)
# Usage: .\run_server_migration.ps1

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "🚀 服务器数据库迁移执行脚本" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

# 数据库路径
$DB_PATH = if ($env:DATABASE_PATH) { $env:DATABASE_PATH } else { "database\server_history.db" }

Write-Host "📂 数据库路径: $DB_PATH" -ForegroundColor Yellow
Write-Host ""

# 检查数据库文件是否存在
if (-not (Test-Path $DB_PATH)) {
    Write-Host "❌ 数据库文件不存在: $DB_PATH" -ForegroundColor Red
    Write-Host "请先将服务器数据库下载到该位置" -ForegroundColor Red
    exit 1
}

# 备份数据库
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$BACKUP_PATH = "$DB_PATH.backup.$timestamp"

Write-Host "📝 步骤 1: 备份数据库" -ForegroundColor Green
Write-Host "----------------------------------------------------------------------"
Copy-Item $DB_PATH $BACKUP_PATH
Write-Host "✅ 备份完成: $BACKUP_PATH" -ForegroundColor Green
Write-Host ""

# 迁移脚本列表
$migrations = @(
    @{Script="migrate_add_did_to_stream_sources.py"; Desc="添加 did 字段到 stream_sources"},
    @{Script="migrate_unify_video_records.py"; Desc="统一视频记录表"},
    @{Script="migrate_add_pets_table.py"; Desc="创建 pets 表"},
    @{Script="migrate_add_weight_to_pets.py"; Desc="添加 weight 字段到 pets"},
    @{Script="migrate_add_avatar_color_to_pets.py"; Desc="添加 avatar_color 字段到 pets"},
    @{Script="migrate_add_video_pet_analysis_table.py"; Desc="创建 video_pet_analysis 表"},
    @{Script="migrate_rename_video_pet_analysis_to_pet_behaviors.py"; Desc="重命名为 pet_behaviors 表"},
    @{Script="migrate_add_daily_reports_table.py"; Desc="创建 daily_reports 表"}
)

Write-Host "📝 步骤 2: 执行迁移脚本" -ForegroundColor Green
Write-Host "----------------------------------------------------------------------"
Write-Host ""

$successCount = 0
$failCount = 0

foreach ($migration in $migrations) {
    $scriptPath = "migrations\$($migration.Script)"
    
    if (-not (Test-Path $scriptPath)) {
        Write-Host "  ⚠️  脚本不存在: $($migration.Script)" -ForegroundColor Yellow
        $failCount++
        continue
    }
    
    Write-Host "  🔄 执行: $($migration.Desc)" -ForegroundColor Cyan
    Write-Host "     脚本: $($migration.Script)"
    
    $env:DATABASE_PATH = $DB_PATH
    $result = & python $scriptPath
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  ❌ 失败" -ForegroundColor Red
        $failCount++
        Write-Host ""
        Write-Host "迁移失败！可以回滚到备份：" -ForegroundColor Red
        Write-Host "  Copy-Item `"$BACKUP_PATH`" `"$DB_PATH`"" -ForegroundColor Yellow
        exit 1
    } else {
        Write-Host "  ✅ 成功" -ForegroundColor Green
        $successCount++
    }
    Write-Host ""
}

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "📊 迁移执行总结" -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

$totalCount = $successCount + $failCount
Write-Host "执行的迁移脚本: $totalCount"
Write-Host "成功: $successCount" -ForegroundColor Green
Write-Host "失败: $failCount" -ForegroundColor $(if ($failCount -eq 0) { "Green" } else { "Red" })
Write-Host ""

if ($failCount -eq 0) {
    Write-Host "✅ 所有迁移脚本执行成功！" -ForegroundColor Green
    Write-Host ""
    Write-Host "📝 后续操作:" -ForegroundColor Yellow
    Write-Host "  1. 验证数据库结构和数据完整性"
    Write-Host "  2. 将迁移后的数据库上传回服务器"
    Write-Host "  3. 重启服务器上的应用服务"
    Write-Host ""
    Write-Host "备份文件: $BACKUP_PATH" -ForegroundColor Yellow
    exit 0
} else {
    Write-Host "❌ 部分迁移失败" -ForegroundColor Red
    Write-Host ""
    Write-Host "备份文件: $BACKUP_PATH" -ForegroundColor Yellow
    exit 1
}
