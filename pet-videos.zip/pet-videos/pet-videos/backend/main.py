"""FastAPI 主程序入口"""
from fastapi import FastAPI, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from config import settings
import logging
from pathlib import Path
import time

# 配置日志
# 确保日志目录存在
log_file_path = Path(settings.log_file)
log_file_path.parent.mkdir(parents=True, exist_ok=True)

# 配置日志格式和编码（Windows 需要 UTF-8 编码）
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(settings.log_file, encoding='utf-8'),
        logging.StreamHandler()
    ]
)

# 为 StreamHandler 设置 UTF-8 编码（避免 Windows GBK 编码错误）
import sys
if sys.platform == 'win32':
    for handler in logging.getLogger().handlers:
        if isinstance(handler, logging.StreamHandler) and handler.stream == sys.stderr:
            # Windows 控制台使用 UTF-8（需要设置 PYTHONIOENCODING=utf-8）
            handler.setStream(open(sys.stderr.fileno(), mode='w', encoding='utf-8', buffering=1, closefd=False))

logger = logging.getLogger(__name__)

# 配置独立的性能日志
performance_logger = logging.getLogger("performance")
performance_logger.setLevel(logging.INFO)
performance_logger.handlers.clear()  # 清除已有 handlers，防止重复添加
performance_log_path = Path(settings.log_file).parent / "performance.log"
performance_handler = logging.FileHandler(performance_log_path, encoding='utf-8')
performance_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
performance_logger.addHandler(performance_handler)
performance_logger.propagate = False  # 不传播到根 logger

# 配置独立的 Push 推送日志
push_logger = logging.getLogger("push_detail")
push_logger.setLevel(logging.INFO)
push_logger.handlers.clear()
push_log_path = Path(settings.log_file).parent / "push.log"
push_handler = logging.FileHandler(push_log_path, encoding='utf-8')
push_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
push_logger.addHandler(push_handler)
push_logger.propagate = False  # 不传播到根 logger

# 检查数据库配置和表结构
def check_database():
    """启动时检查数据库配置"""
    import sqlite3
    from pathlib import Path
    
    db_path = Path(settings.database_path)
    logger.info(f"[Backend/启动] 数据库路径: {db_path}")
    logger.info(f"[Backend/启动] 数据库文件存在: {db_path.exists()}")
    
    if db_path.exists():
        try:
            conn = sqlite3.connect(str(db_path))
            cursor = conn.cursor()
            
            # 检查pets表
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='pets'")
            pets_exists = cursor.fetchone() is not None
            logger.info(f"[Backend/启动] pets表存在: {pets_exists}")
            
            if pets_exists:
                # 检查pets表结构
                cursor.execute("PRAGMA table_info(pets)")
                columns = cursor.fetchall()
                column_names = [col[1] for col in columns]
                logger.info(f"[Backend/启动] pets表字段: {', '.join(column_names)}")
                
                # 检查关键字段
                has_id = 'id' in column_names
                has_avatar_color = 'avatar_color' in column_names
                logger.info(f"[Backend/启动] pets表有id字段: {has_id}")
                logger.info(f"[Backend/启动] pets表有avatar_color字段: {has_avatar_color}")
                
                # 检查数据量
                cursor.execute("SELECT COUNT(*) FROM pets")
                count = cursor.fetchone()[0]
                logger.info(f"[Backend/启动] pets表记录数: {count}")
            
            conn.close()
        except Exception as e:
            logger.error(f"[Backend/启动] 数据库检查失败: {e}")
    else:
        logger.warning(f"[Backend/启动] 数据库文件不存在: {db_path}")

# 执行数据库检查
check_database()

# 创建 FastAPI 应用
app = FastAPI(
    title="Pet Videos Analysis API",
    description="视频分析工具 - 使用 Qwen3-VL-Plus 模型分析视频内容",
    version="1.0.0"
)

# 性能监控中间件
@app.middleware("http")
async def performance_monitoring(request: Request, call_next):
    """记录每个请求的耗时"""
    start_time = time.time()
    
    response = await call_next(request)
    
    elapsed_ms = (time.time() - start_time) * 1000
    
    # 记录到独立的性能日志
    performance_logger.info(
        f"{request.method} {request.url.path} "
        f"| 耗时: {elapsed_ms:.0f}ms "
        f"| 状态: {response.status_code}"
    )
    
    # 慢请求告警（超过 1 秒）- 同时记录到主日志和性能日志
    if elapsed_ms > 1000:
        log_msg = (
            f"[慢请求] {request.method} {request.url.path} "
            f"| 耗时: {elapsed_ms:.0f}ms "
            f"| 查询参数: {dict(request.query_params)}"
        )
        logger.warning(log_msg)
        performance_logger.warning(log_msg)
    
    # 添加响应头，便于前端监控
    response.headers["X-Process-Time"] = f"{elapsed_ms:.0f}ms"
    
    return response


# 配置 CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.get_cors_origins_list(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 导入路由（延迟导入，避免循环依赖）
from api import videos, analysis, history, auth, prompts, sources, tasks, pets, daily_reports, video_records, llm_queue, pet_behaviors, daily_report_generator, thumbnails, behavior_feedback

# 注册路由
app.include_router(auth.router)

# 公开API（无需JWT认证）
app.include_router(videos.public_router)  # 视频流API（stream_token已包含HMAC签名）
app.include_router(thumbnails.router)  # 缩略图API（使用与视频流相同的token验证）
app.include_router(analysis.public_router)  # 模型列表等配置API

# 内部API（供 Service 和切片脚本调用，无需JWT认证）
app.include_router(tasks.internal_router)  # 任务心跳等
app.include_router(sources.internal_router)  # 源管理（Service调用）
app.include_router(pets.internal_router)  # 宠物管理（Service调用）
app.include_router(daily_reports.internal_router)  # 日报（Service调用）
app.include_router(video_records.internal_router)  # 视频记录（Service调用）
app.include_router(llm_queue.internal_router)  # LLM 队列管理（内部调用）
app.include_router(thumbnails.internal_router)  # 缩略图（Service调用）
app.include_router(behavior_feedback.router)  # 行为反馈（Service调用）

# 需要JWT认证的API
app.include_router(videos.router, dependencies=[Depends(auth.verify_token)])
app.include_router(analysis.router, dependencies=[Depends(auth.verify_token)])
app.include_router(history.router, dependencies=[Depends(auth.verify_token)])
app.include_router(prompts.router, dependencies=[Depends(auth.verify_token)])
app.include_router(sources.router, dependencies=[Depends(auth.verify_token)])
app.include_router(tasks.router, dependencies=[Depends(auth.verify_token)])
app.include_router(pets.router, dependencies=[Depends(auth.verify_token)])
app.include_router(daily_reports.router, dependencies=[Depends(auth.verify_token)])
app.include_router(video_records.router, dependencies=[Depends(auth.verify_token)])
app.include_router(llm_queue.router, dependencies=[Depends(auth.verify_token)])
app.include_router(pet_behaviors.router, dependencies=[Depends(auth.verify_token)])  # 宠物行为管理（需认证）
app.include_router(daily_report_generator.router, dependencies=[Depends(auth.verify_token)])  # 日报生成器管理（需认证）


@app.get("/")
async def root():
    """根路径"""
    return {
        "name": "Pet Videos Analysis API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health")
async def health_check():
    """健康检查"""
    return {"status": "healthy"}


@app.get("/api/config")
async def get_config():
    """获取配置信息"""
    return {
        "max_pixels_presets": {
            "low": 256 * 32 * 32,
            "medium": 640 * 32 * 32,
            "high": 1280 * 32 * 32,
            "ultra": 2000 * 32 * 32
        },
        "min_pixels_default": 4 * 32 * 32,
        "fps_presets": [0.5, 1.0, 2.0, 5.0, 10.0],
        "video_dirs": settings.get_video_dirs(),
        "pricing": {
            "tiers": [
                {"name": "0-32K", "input": 0.001, "output": 0.01},
                {"name": "32K-128K", "input": 0.0015, "output": 0.015},
                {"name": "128K-256K", "input": 0.003, "output": 0.03}
            ]
        },
        "limits": {
            "max_video_size_mb": settings.max_video_size_mb,
            "api_timeout_seconds": settings.api_timeout_seconds,
            "video_max_pixels": 2048000
        }
    }


# 应用启动和关闭事件
@app.on_event("startup")
async def startup_event():
    """应用启动事件"""
    logger.info("Backend application starting up...")
    
    # 启动 LLM Worker 服务
    try:
        from services.llm_worker_service import llm_worker_service
        if getattr(settings, 'llm_worker_enabled', True) and getattr(settings, 'llm_worker_auto_start', True):
            llm_worker_service.start_worker()
            logger.info("LLM Worker Service started automatically")
        else:
            logger.info("LLM Worker Service disabled by configuration or auto_start=False")
    except Exception as e:
        logger.error(f"Failed to start LLM Worker Service: {e}")
    
    # 启动日报生成服务
    try:
        from services.daily_report_generator import daily_report_generator
        if getattr(settings, 'daily_report_enabled', True) and getattr(settings, 'daily_report_auto_start', True):
            daily_report_generator.start_worker()
            logger.info("Daily Report Generator Service started automatically")
        else:
            logger.info("Daily Report Generator Service disabled by configuration or auto_start=False")
    except Exception as e:
        logger.error(f"Failed to start Daily Report Generator Service: {e}")


@app.on_event("shutdown")
async def shutdown_event():
    """应用关闭事件"""
    logger.info("Backend application shutting down...")
    
    # 停止 LLM Worker 服务
    try:
        from services.llm_worker_service import llm_worker_service
        llm_worker_service.stop_worker()
        logger.info("LLM Worker Service stopped")
    except Exception as e:
        logger.error(f"Failed to stop LLM Worker Service: {e}")
    
    # 停止日报生成服务
    try:
        from services.daily_report_generator import daily_report_generator
        daily_report_generator.stop_worker()
        logger.info("Daily Report Generator Service stopped")
    except Exception as e:
        logger.error(f"Failed to stop Daily Report Generator Service: {e}")


if __name__ == "__main__":
    import uvicorn
    logger.info(f"Starting server on {settings.backend_host}:{settings.backend_port}")
    uvicorn.run(
        "main:app",
        host=settings.backend_host,
        port=settings.backend_port,
        reload=True
    )
