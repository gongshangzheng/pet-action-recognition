"""配置管理"""
import os
from pathlib import Path
from typing import List
from pydantic import Field
from pydantic_settings import BaseSettings

# 项目根目录
BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    """应用配置"""
    
    # 项目根目录
    BASE_DIR: Path = BASE_DIR
    
    # API Key
    dashscope_api_key: str = Field(..., alias="DASHSCOPE_API_KEY")
    
    # 登录配置
    admin_username: str = "admin"
    admin_password: str = "admin123"
    jwt_secret: str = "pet-videos-secret-key-2026"
    
    # 视频目录配置（格式：别名1:路径1,别名2:路径2）
    video_dirs: str
    
    # 服务配置
    backend_host: str = "0.0.0.0"
    backend_port: int = 8000
    frontend_port: int = 5173
    
    # 数据存储路径
    database_path: str = str(BASE_DIR / "database" / "history.db")
    
    # 日志配置
    log_level: str = "INFO"
    log_file: str = str(BASE_DIR / "logs" / "app.log")
    
    # CORS 配置
    cors_origins: str = "http://localhost:3000,http://localhost:5173,http://127.0.0.1:3000,http://127.0.0.1:5173"
    
    # API 限制配置
    max_video_size_mb: int = 100
    api_timeout_seconds: int = 300
    
    # LLM Worker 配置
    llm_worker_enabled: bool = True  # 系统级开关，控制是否允许启用 Worker
    llm_worker_max_concurrent: int = 2  # 最大并发任务数
    llm_worker_poll_interval: int = 10  # 轮询间隔（秒）
    llm_worker_auto_start: bool = True  # 应用启动时是否自动启动 Worker
    llm_worker_max_retries: int = 3  # 最大重试次数
    llm_worker_time_window_hours: int = 25  # 队列时间窗口，只处理最近N小时的记录
    llm_worker_retry_delays: str = "60,300,900"  # 重试延迟时间(秒)，逗号分隔
    llm_worker_processing_timeout_minutes: int = 30  # processing状态超时时间（分钟）
    
    # 日报生成器配置
    daily_report_enabled: bool = True  # 系统级开关，控制是否允许启用日报生成器
    daily_report_auto_start: bool = True  # 应用启动时是否自动启动日报生成器
    daily_report_peak_interval_minutes: int = 90  # 高峰时段间隔（5:00-23:00）：1.5小时
    daily_report_off_peak_interval_minutes: int = 180  # 低峰时段间隔（23:00-5:00）：3小时
    daily_report_peak_start_hour: int = 5  # 高峰时段开始时间
    daily_report_peak_end_hour: int = 23  # 高峰时段结束时间
    daily_report_max_concurrent: int = 2  # 最大并发任务数
    daily_report_max_retries: int = 3  # LLM调用最大重试次数
    daily_report_retry_delay_seconds: int = 60  # 重试延迟（秒）
    daily_report_queue_check_interval: int = 5  # 队列检查间隔（秒）
    daily_report_processing_timeout_minutes: int = 15  # processing状态超时时间（分钟）
    
    # 自动分析默认参数
    auto_analysis_fps: float = 1.0
    auto_analysis_max_pixels: int = 640 * 32 * 32
    auto_analysis_min_pixels: int = 4 * 32 * 32
    auto_analysis_model: str = 'qwen3-vl-plus'
    auto_analysis_high_res: bool = False
    
    model_config = {
        "env_file": str(BASE_DIR / ".env"),
        "env_file_encoding": "utf-8",
        "extra": "ignore"  # 忽略额外的环境变量字段
    }
    
    def get_video_dirs(self) -> List[str]:
        """获取视频目录路径列表（向后兼容）"""
        dirs_map = self.get_video_dirs_map()
        return list(dirs_map.values())
    
    def get_video_dirs_map(self) -> dict:
        """获取视频目录映射（别名 -> 路径）
        
        支持两种格式：
        1. 新格式（带别名）: "demo1:D:\\Videos,demo2:E:\\Records"
        2. 旧格式（无别名）: "D:\\Videos,E:\\Records" (自动生成别名 dir1, dir2...)
        
        Returns:
            dict: {别名: 路径}
        """
        dirs_map = {}
        parts = [p.strip() for p in self.video_dirs.split(',') if p.strip()]
        
        for idx, part in enumerate(parts, 1):
            if ':' in part:
                # 新格式: alias:path
                alias, path = part.split(':', 1)
                dirs_map[alias.strip()] = path.strip()
            else:
                # 旧格式: path (自动生成别名)
                dirs_map[f'dir{idx}'] = part
        
        return dirs_map
    
    def get_path_by_alias(self, alias: str) -> str:
        """根据别名获取路径（从数据库读取）"""
        from models.db import SessionLocal
        from models.database import StreamSource
        
        db = SessionLocal()
        try:
            source = db.query(StreamSource).filter(
                StreamSource.alias == alias,
                StreamSource.is_active == True
            ).first()
            
            if not source:
                raise ValueError(f"Invalid directory alias: {alias}")
            
            return source.storage_path
        finally:
            db.close()
    
    def get_alias_by_path(self, path: str) -> str:
        """根据路径获取别名（从数据库读取，优先级高于环境变量）"""
        from pathlib import Path
        from models.db import SessionLocal
        from models.database import StreamSource
        
        path_obj = Path(path).resolve()
        
        # 优先从数据库查找
        db = SessionLocal()
        try:
            sources = db.query(StreamSource).filter(StreamSource.is_active == True).all()
            for source in sources:
                storage_path_obj = Path(source.storage_path).resolve()
                if path_obj == storage_path_obj or str(path_obj).startswith(str(storage_path_obj)):
                    return source.alias
        finally:
            db.close()
        
        # 兜底：从环境变量配置查找（向后兼容）
        dirs_map = self.get_video_dirs_map()
        for alias, dir_path in dirs_map.items():
            dir_path_obj = Path(dir_path).resolve()
            if path_obj == dir_path_obj or str(path_obj).startswith(str(dir_path_obj)):
                return alias
        
        return None  # 找不到返回None，而不是抛异常
    
    def get_cors_origins_list(self) -> List[str]:
        """获取CORS允许的源列表"""
        return [o.strip() for o in self.cors_origins.split(',') if o.strip()]


# 全局配置实例
settings = Settings()

# qwen3-vl-plus 模型配置
# 默认模型
MODEL_NAME = 'qwen3-vl-plus'

# 可用模型列表
AVAILABLE_MODELS = [
    {
        "name": "qwen2.5-vl-32b-instruct",
        "label": "Qwen2.5-VL-32B-Instruct",
        "description": "32B参数，高性能视觉理解"
    },
    {
        "name": "qwen3-vl-plus",
        "label": "Qwen3-VL-Plus",
        "description": "最新版本，更强视觉推理"
    },
    {
        "name": "qwen2-vl-72b-instruct",
        "label": "Qwen2-VL-72B-Instruct",
        "description": "72B参数，最强性能"
    },
    {
        "name": "qwen2-vl-7b-instruct",
        "label": "Qwen2-VL-7B-Instruct",
        "description": "7B参数，快速推理"
    }
]

# 预设配置（按官方Qwen3-VL-Plus标准：32 * 32）
MAX_PIXELS_PRESETS = {
    "low": 256 * 32 * 32,       # 262,144 像素（256 blocks）
    "medium": 640 * 32 * 32,    # 655,360 像素（640 blocks，官方推荐）
    "high": 1280 * 32 * 32,     # 1,310,720 像素（1280 blocks）
    "ultra": 2000 * 32 * 32     # 2,048,000 像素（2000 blocks，API 最大限制）
}

MIN_PIXELS_DEFAULT = 4 * 32 * 32  # 4,096 像素（官方最小值）

# 官方限制
VIDEO_MAX_PIXELS_LIMIT = 2048000  # 2,048,000 像素（API 实际最大限制）
VIDEO_TOTAL_PIXELS = 1280 * 28 * 28  # 默认总像素限制

FPS_PRESETS = [0.5, 1.0, 2.0, 5.0, 10.0]  # 官方范围[0.1, 10]，默认2.0

# qwen3-vl-plus 梯度定价配置（元/1k tokens）
PRICING_TIERS = [
    {
        "name": "0-32K",
        "range": (0, 32000),
        "input_price": 0.001,
        "output_price": 0.01
    },
    {
        "name": "32K-128K",
        "range": (32000, 128000),
        "input_price": 0.0015,
        "output_price": 0.015
    },
    {
        "name": "128K-256K",
        "range": (128000, 256000),
        "input_price": 0.003,
        "output_price": 0.03
    }
]

# 确保必要的目录存在
for path in [Path(settings.database_path).parent, Path(settings.log_file).parent]:
    Path(path).mkdir(parents=True, exist_ok=True)

# 确保视频目录存在
for video_dir in settings.get_video_dirs():
    Path(video_dir).mkdir(parents=True, exist_ok=True)
