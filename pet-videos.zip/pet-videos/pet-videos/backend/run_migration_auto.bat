@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ======================================================================
echo Pet-Videos Database Migration Script (Auto-detect)
echo ======================================================================
echo.

REM Auto-detect database location
set "DB_PATH="

if exist "database\history.db" (
    set "DB_PATH=database\history.db"
    echo Found database: database\history.db
) else if exist "database\server_history.db" (
    set "DB_PATH=database\server_history.db"
    echo Found database: database\server_history.db
) else if exist "..\database\history.db" (
    set "DB_PATH=..\database\history.db"
    echo Found database: ..\database\history.db
) else (
    echo ERROR: Database file not found!
    echo.
    echo Checked locations:
    echo   - database\history.db
    echo   - database\server_history.db
    echo   - ..\database\history.db
    echo.
    echo Please ensure:
    echo   1. You are in the backend folder
    echo   2. Database file exists
    echo   3. Or set DATABASE_PATH manually:
    echo      set DATABASE_PATH=path\to\your\database.db
    echo      run_server_migration_simple.bat
    echo.
    pause
    exit /b 1
)

echo Database: %DB_PATH%
echo.

REM Ask for confirmation
set /p CONFIRM="Continue with migration? (y/n) "
if /i not "%CONFIRM%"=="y" (
    echo Migration cancelled
    exit /b 0
)

REM Backup database
set "TIMESTAMP=%date:~0,4%%date:~5,2%%date:~8,2%_%time:~0,2%%time:~3,2%%time:~6,2%"
set "TIMESTAMP=%TIMESTAMP: =0%"
set "BACKUP_PATH=%DB_PATH%.backup.%TIMESTAMP%"

echo.
echo Step 1: Backup database
echo ----------------------------------------------------------------------
copy "%DB_PATH%" "%BACKUP_PATH%" >nul
if errorlevel 1 (
    echo ERROR: Backup failed
    pause
    exit /b 1
)
echo OK: Backup completed: %BACKUP_PATH%
echo.

echo Step 2: Run migration scripts
echo ----------------------------------------------------------------------
echo.

set SUCCESS_COUNT=0
set FAIL_COUNT=0

REM Migration scripts
set "SCRIPTS[0]=migrate_add_did_to_stream_sources.py"
set "SCRIPTS[1]=migrate_unify_video_records.py"
set "SCRIPTS[2]=migrate_add_pets_table.py"
set "SCRIPTS[3]=migrate_add_weight_to_pets.py"
set "SCRIPTS[4]=migrate_add_avatar_color_to_pets.py"
set "SCRIPTS[5]=migrate_add_video_pet_analysis_table.py"
set "SCRIPTS[6]=migrate_rename_video_pet_analysis_to_pet_behaviors.py"
set "SCRIPTS[7]=migrate_add_daily_reports_table.py"

for /L %%i in (0,1,7) do (
    set "SCRIPT=!SCRIPTS[%%i]!"
    set /a NUM=%%i+1
    
    echo [!NUM!/8] !SCRIPT!
    
    if exist "migrations\!SCRIPT!" (
        set "DATABASE_PATH=%DB_PATH%"
        python "migrations\!SCRIPT!" >nul 2>&1
        
        if errorlevel 1 (
            echo    ERROR: Migration failed
            echo.
            echo Rollback command:
            echo    copy "%BACKUP_PATH%" "%DB_PATH%"
            echo.
            pause
            exit /b 1
        ) else (
            echo    OK
            set /a SUCCESS_COUNT+=1
        )
    ) else (
        echo    SKIP: File not found
    )
)

echo.
echo ======================================================================
echo Migration Summary
echo ======================================================================
echo.
echo Success: %SUCCESS_COUNT%/8
echo Database: %DB_PATH%
echo Backup: %BACKUP_PATH%
echo.
echo All migrations completed successfully!
echo.
echo Next steps:
echo   1. Verify database: sqlite3 "%DB_PATH%" ".tables"
echo   2. Fix FPS: python migrations\fix_abnormal_fps.py
echo   3. Restart services: cd .. ^&^& start_all.bat
echo.
echo ======================================================================

pause
