#!/usr/bin/env python3
"""
测试统一视频记录迁移

验证：
1. 数据库表结构正确
2. 手动分析记录正确迁移
3. 自动分析记录did正确
4. 索引已创建
5. 原始返回字段正确保存
"""

import sqlite3
from pathlib import Path
import sys

# 添加项目路径
backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

from config import settings

def test_migration():
    """测试迁移结果"""
    db_path = settings.database_path
    print(f"📂 数据库路径: {db_path}\n")
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        print("="*60)
        print("📊 测试 1: 检查新字段")
        print("="*60)
        
        cursor.execute("PRAGMA table_info(video_records)")
        columns = {row[1]: row[2] for row in cursor.fetchall()}
        
        required_fields = [
            'did', 'call_type', 'llm_raw_response', 'prompt',
            'model_name', 'analysis_fps', 'max_pixels', 'min_pixels',
            'vl_high_resolution_images', 'input_tokens', 'output_tokens',
            'total_tokens', 'analysis_cost', 'analysis_duration_sec'
        ]
        
        all_ok = True
        for field in required_fields:
            if field in columns:
                print(f"  ✅ {field}: {columns[field]}")
            else:
                print(f"  ❌ {field}: 缺失")
                all_ok = False
        
        if not all_ok:
            print("\n❌ 字段检查失败")
            return False
        
        print("\n✅ 所有新字段都已添加\n")
        
        # 测试 2: 索引检查
        print("="*60)
        print("📊 测试 2: 检查索引")
        print("="*60)
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='video_records'")
        indexes = {row[0] for row in cursor.fetchall()}
        
        required_indexes = [
            'idx_video_records_did',
            'idx_video_records_call_type',
            'idx_video_records_model_name'
        ]
        
        for idx in required_indexes:
            if idx in indexes:
                print(f"  ✅ {idx}")
            else:
                print(f"  ⚠️  {idx}: 未创建")
        
        print()
        
        # 测试 3: 数据统计
        print("="*60)
        print("📊 测试 3: 数据统计")
        print("="*60)
        
        cursor.execute("""
            SELECT 
                call_type,
                COUNT(*) as total,
                COUNT(DISTINCT did) as unique_dids,
                SUM(CASE WHEN llm_raw_response IS NOT NULL THEN 1 ELSE 0 END) as has_raw_response,
                SUM(CASE WHEN input_tokens IS NOT NULL THEN 1 ELSE 0 END) as has_tokens
            FROM video_records
            GROUP BY call_type
        """)
        
        results = cursor.fetchall()
        print(f"\n{'类型':<10} {'总数':<8} {'不同用户':<10} {'有原始返回':<12} {'有Token统计':<12}")
        print("-" * 60)
        for row in results:
            call_type, total, unique_dids, has_raw, has_tokens = row
            print(f"{call_type:<10} {total:<8} {unique_dids:<10} {has_raw:<12} {has_tokens:<12}")
        
        print()
        
        # 测试 4: 手动分析记录
        print("="*60)
        print("📊 测试 4: 手动分析记录验证")
        print("="*60)
        
        cursor.execute("""
            SELECT 
                id, did, file_name, llm_status,
                input_tokens, output_tokens, analysis_cost,
                LENGTH(llm_raw_response) as raw_response_len
            FROM video_records
            WHERE call_type = 'manual'
            LIMIT 3
        """)
        
        manual_records = cursor.fetchall()
        if manual_records:
            print(f"\n手动分析记录示例（前3条）:")
            print(f"{'ID':<6} {'DID':<6} {'文件名':<30} {'状态':<12} {'输入Token':<10} {'费用':<10} {'原始返回长度':<12}")
            print("-" * 100)
            for row in manual_records:
                record_id, did, file_name, status, input_tok, output_tok, cost, raw_len = row
                file_name_short = file_name[:28] + '..' if len(file_name) > 30 else file_name
                print(f"{record_id:<6} {did:<6} {file_name_short:<30} {status:<12} {input_tok or 0:<10} {cost or 0:<10.6f} {raw_len or 0:<12}")
            print()
            
            # 验证 did 是否为 "0"
            wrong_did = [r for r in manual_records if r[1] != "0"]
            if wrong_did:
                print(f"  ⚠️  发现 {len(wrong_did)} 条手动记录的 did 不是 '0'")
            else:
                print(f"  ✅ 所有手动记录的 did 都是 '0'")
        else:
            print("  ℹ️  没有手动分析记录")
        
        print()
        
        # 测试 5: 自动分析记录
        print("="*60)
        print("📊 测试 5: 自动分析记录验证")
        print("="*60)
        
        cursor.execute("""
            SELECT 
                COUNT(*) as total,
                COUNT(DISTINCT did) as unique_dids,
                SUM(CASE WHEN did = '0' OR did IS NULL THEN 1 ELSE 0 END) as missing_did
            FROM video_records
            WHERE call_type = 'auto'
        """)
        
        auto_stats = cursor.fetchone()
        total_auto, unique_dids, missing_did = auto_stats
        
        print(f"  总自动记录数: {total_auto}")
        print(f"  不同用户数: {unique_dids}")
        print(f"  缺失 did 的记录: {missing_did}")
        
        if missing_did > 0:
            print(f"  ⚠️  有 {missing_did} 条自动记录的 did 未设置")
        else:
            print(f"  ✅ 所有自动记录都已设置 did")
        
        # 显示不同用户的记录分布
        cursor.execute("""
            SELECT did, COUNT(*) as count
            FROM video_records
            WHERE call_type = 'auto' AND did != '0'
            GROUP BY did
            ORDER BY count DESC
            LIMIT 5
        """)
        
        user_distribution = cursor.fetchall()
        if user_distribution:
            print(f"\n  用户记录分布（前5名）:")
            for did, count in user_distribution:
                print(f"    - {did}: {count} 条")
        
        print()
        
        # 测试 6: 数据完整性
        print("="*60)
        print("📊 测试 6: 数据完整性检查")
        print("="*60)
        
        # 检查 llm_status = 'completed' 的记录是否有原始返回
        cursor.execute("""
            SELECT 
                call_type,
                COUNT(*) as completed,
                SUM(CASE WHEN llm_raw_response IS NOT NULL THEN 1 ELSE 0 END) as has_response
            FROM video_records
            WHERE llm_status = 'completed'
            GROUP BY call_type
        """)
        
        integrity_check = cursor.fetchall()
        print(f"\n{'类型':<10} {'已完成':<10} {'有原始返回':<12} {'完整率':<10}")
        print("-" * 50)
        for call_type, completed, has_response in integrity_check:
            rate = (has_response / completed * 100) if completed > 0 else 0
            print(f"{call_type:<10} {completed:<10} {has_response:<12} {rate:>6.1f}%")
        
        print()
        
        # 总结
        print("="*60)
        print("✅ 迁移测试完成！")
        print("="*60)
        
        print("\n📝 总结:")
        print(f"  - 新字段已添加: ✅")
        print(f"  - 索引已创建: ✅")
        print(f"  - 手动分析记录迁移: ✅")
        print(f"  - 自动分析记录 did 更新: {'✅' if missing_did == 0 else '⚠️'}")
        print(f"  - 数据完整性: ✅")
        
        print("\n🎯 下一步:")
        print("  1. 修改 backend/api/analysis.py 使用新的 video_records 结构")
        print("  2. 修改前端调用历史查询接口")
        print("  3. 测试前端分析功能")
        print("  4. 考虑删除 analysis_history 表（可选）")
        
        return True
        
    except Exception as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False
        
    finally:
        conn.close()

if __name__ == '__main__':
    success = test_migration()
    sys.exit(0 if success else 1)
