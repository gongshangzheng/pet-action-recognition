# YOLO/Ultralytics 安装说明

## 说明

本项目的监控脚本（`scripts/pet_monitor_pyav.py`）使用 **YOLOv13** 进行实时宠物检测。

`ultralytics`, `opencv-python`, `numpy` 等依赖由 **yolov13 项目独立管理**，不在 `backend/requirements.txt` 中重复指定。

## 安装方法

### 1. 安装 YOLOv13（如果还未安装）

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/yolov13
pip install -e .
```

这会以**可编辑模式**安装 ultralytics，自动处理所有依赖（包括 numpy, opencv-python 等）。

### 2. 验证安装

```bash
python3 -c "from ultralytics import YOLO; print('YOLOv13 安装成功')"
```

### 3. 测试 YOLO 模型

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/scripts
python3 -c "
from ultralytics import YOLO
model = YOLO('yolov13n.pt')
print('模型加载成功')
"
```

## 依赖说明

### backend/requirements.txt 中已注释的依赖

```python
# ultralytics>=8.0.0           # 通过 yolov13/ 安装
# numpy>=1.23.0,<2.0.0         # ultralytics 依赖
# opencv-python>=4.8.0         # ultralytics 依赖
```

这些包由 yolov13 项目的 `pyproject.toml` 管理，版本兼容性由 ultralytics 官方保证。

### 仅后端需要的依赖

后端 API 不需要 YOLO/ultralytics，可以独立安装运行：

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/backend
pip install -r requirements.txt
```

## 依赖分离的优势

1. ✅ **避免版本冲突**：ultralytics 在不同平台（macOS/Linux/Windows）有不同的依赖版本要求
2. ✅ **灵活更新**：可以独立更新 yolov13，不影响后端
3. ✅ **开发便利**：yolov13 以可编辑模式安装，修改代码立即生效
4. ✅ **后端轻量**：不使用 YOLO 时，后端依赖更少更快

## 使用场景

| 组件 | 是否需要 YOLOv13 | 安装方式 |
|------|-----------------|---------|
| 后端 API | ❌ 不需要 | `pip install -r backend/requirements.txt` |
| 前端界面 | ❌ 不需要 | `npm install` (frontend/) |
| 监控脚本 | ✅ 需要 | `pip install -e yolov13/` |

## 完整安装流程

### 方案1：只安装后端（快速启动）

```bash
# 1. 安装后端依赖
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/backend
pip install -r requirements.txt

# 2. 启动后端
cd ..
python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8002 --reload
```

### 方案2：完整安装（包含监控功能）

```bash
# 1. 安装 YOLOv13
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/yolov13
pip install -e .

# 2. 安装后端依赖
cd ../backend
pip install -r requirements.txt

# 3. 启动后端
cd ..
python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8002 --reload

# 4. 运行监控脚本（另一个终端）
cd scripts
python3 pet_monitor_pyav.py --source_id 1
```

## 更新 YOLOv13

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/yolov13
git pull  # 如果是 git 仓库
pip install -e . --upgrade
```

## 故障排查

### 问题1：numpy 版本冲突

**错误**：
```
ultralytics requires numpy<2.0.0; sys_platform == "darwin"
```

**解决**：
```bash
# 确保通过 yolov13 安装，会自动处理版本
cd yolov13
pip install -e .
```

### 问题2：找不到 ultralytics

**错误**：
```
ModuleNotFoundError: No module named 'ultralytics'
```

**解决**：
```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos/yolov13
pip install -e .
```

### 问题3：YOLO 模型文件缺失

**错误**：
```
FileNotFoundError: yolov13n.pt not found
```

**解决**：
```bash
# 检查模型文件
ls -lh scripts/yolov13n.pt

# 如果缺失，会自动下载（首次运行时）
```

## 相关文档

- [YOLOv13 项目](../yolov13/README.md)
- [监控脚本说明](../scripts/README.md)
- [后端安装说明](../docs/DEPLOY.md)

## 更新日志

| 日期 | 说明 |
|------|------|
| 2026-01-29 | 从 requirements.txt 移除 ultralytics 相关依赖，改为通过 yolov13/ 管理 |
