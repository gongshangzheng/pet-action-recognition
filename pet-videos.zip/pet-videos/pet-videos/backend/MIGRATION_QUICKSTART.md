# 数据库迁移快速指南

## 问题：Database file not found

如果你看到这个错误：
```
ERROR: Database file not found: database\server_history.db
```

说明数据库文件不在预期位置。

## 解决步骤

### 步骤 1：检查数据库位置

```batch
cd D:\pet-videos\backend
check_database.bat
```

这会显示数据库文件的实际位置。

### 步骤 2：根据情况选择方案

#### 情况 A：数据库文件是 `database\history.db`

**方案 1：使用自动检测脚本（推荐）**
```batch
run_migration_auto.bat
```

**方案 2：手动指定路径**
```batch
set DATABASE_PATH=database\history.db
run_server_migration_simple.bat
```

**方案 3：使用 PowerShell**
```powershell
$env:DATABASE_PATH="database\history.db"
.\run_server_migration.ps1
```

---

#### 情况 B：数据库文件不存在

如果是**首次部署**或**从服务器迁移**：

**1. 从服务器下载数据库**

使用远程桌面、FTP 或其他方式，将服务器上的数据库下载到：
```
D:\pet-videos\backend\database\history.db
```

**2. 或者创建新数据库**

如果是全新安装：
```batch
REM 创建数据库目录
mkdir database

REM 启动 Backend，会自动创建数据库
cd ..
start_backend.bat
```

等待服务启动后，数据库会自动创建在 `database\history.db`。

---

#### 情况 C：数据库在其他位置

如果数据库在自定义位置，例如 `D:\data\pet_videos.db`：

```batch
set DATABASE_PATH=D:\data\pet_videos.db
run_server_migration_simple.bat
```

---

## 完整部署流程

### 场景 1：服务器已有数据库（迁移现有数据）

```batch
REM 1. 进入 backend 目录
cd D:\pet-videos\backend

REM 2. 从服务器下载数据库到本地
REM    目标位置：D:\pet-videos\backend\database\history.db
REM    （使用 FTP、远程桌面等方式下载）

REM 3. 检查数据库是否存在
dir database\history.db

REM 4. 执行迁移（自动检测）
run_migration_auto.bat

REM 5. 修复 FPS（可选）
python migrations\fix_abnormal_fps.py

REM 6. 启动服务
cd ..
start_all.bat

REM 7. 验证
curl http://localhost:8002/api/sources/
```

---

### 场景 2：全新安装（无现有数据）

```batch
REM 1. 进入项目目录
cd D:\pet-videos

REM 2. 创建数据库目录
mkdir backend\database

REM 3. 启动服务（会自动创建数据库）
start_all.bat

REM 4. 等待 5 秒
timeout /t 5

REM 5. 停止服务
stop_all.bat

REM 6. 执行迁移
cd backend
run_migration_auto.bat

REM 7. 重新启动服务
cd ..
start_all.bat
```

---

## 常见错误及解决

### 错误 1：找不到数据库文件

```
ERROR: Database file not found: database\server_history.db
```

**原因**：
- 数据库文件名不对（应该是 `history.db` 而不是 `server_history.db`）
- 数据库文件不存在
- 当前目录不对

**解决**：
```batch
REM 检查当前目录
cd

REM 应该显示：D:\pet-videos\backend

REM 检查数据库
check_database.bat

REM 使用自动检测脚本
run_migration_auto.bat
```

---

### 错误 2：当前目录不对

如果你在 `D:\pet-videos` 而不是 `D:\pet-videos\backend`：

```batch
REM 进入 backend 目录
cd backend

REM 然后执行迁移
run_migration_auto.bat
```

---

### 错误 3：Python 找不到

```
'python' 不是内部或外部命令
```

**解决**：
```batch
REM 检查 Python 是否安装
where python

REM 如果找不到，激活虚拟环境
venv\Scripts\activate

REM 或使用完整路径
C:\Python39\python.exe migrations\migrate_*.py
```

---

## 快速命令参考

### 检查数据库
```batch
cd D:\pet-videos\backend
check_database.bat
```

### 自动迁移（推荐）
```batch
cd D:\pet-videos\backend
run_migration_auto.bat
```

### 手动指定数据库路径
```batch
cd D:\pet-videos\backend
set DATABASE_PATH=database\history.db
run_server_migration_simple.bat
```

### 使用 PowerShell（无编码问题）
```powershell
cd D:\pet-videos\backend
$env:DATABASE_PATH="database\history.db"
.\run_server_migration.ps1
```

### 验证迁移结果
```batch
REM 查看数据库表
sqlite3 database\history.db ".tables"

REM 应该看到：
REM   pet_behaviors
REM   pets  
REM   daily_reports
REM   video_records
REM   stream_sources
```

---

## 推荐方案

根据你的情况：

1. **如果数据库已存在**：
   ```batch
   cd D:\pet-videos\backend
   run_migration_auto.bat
   ```

2. **如果是全新安装**：
   ```batch
   cd D:\pet-videos
   start_all.bat
   REM 等待 5 秒后停止
   stop_all.bat
   cd backend
   run_migration_auto.bat
   cd ..
   start_all.bat
   ```

3. **如果遇到编码问题**：
   ```powershell
   cd D:\pet-videos\backend
   powershell -ExecutionPolicy Bypass -File run_server_migration.ps1
   ```

---

## 需要帮助？

如果以上方案都不行，请提供以下信息：

1. 当前目录：
   ```batch
   cd
   ```

2. 数据库检查结果：
   ```batch
   check_database.bat
   ```

3. 目录结构：
   ```batch
   dir /s database
   ```

4. 错误截图或完整错误信息
