#!/usr/bin/env python3
"""
测试 Backend API 修改

验证：
1. 分析 API 保存到 video_records 表
2. 历史记录 API 查询 video_records 表
3. 字段映射正确
"""

import sys
from pathlib import Path

# 添加项目路径
backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

def test_imports():
    """测试导入是否正确"""
    print("="*60)
    print("📊 测试 1: 检查导入")
    print("="*60)
    
    try:
        # 测试 analysis.py 导入
        from api import analysis
        print("  ✅ api.analysis 导入成功")
        
        # 检查是否使用 VideoRecord
        import inspect
        source = inspect.getsource(analysis.analyze_video)
        
        if 'VideoRecord(' in source:
            print("  ✅ analysis.py 使用 VideoRecord")
        else:
            print("  ❌ analysis.py 未使用 VideoRecord")
            return False
        
        if 'AnalysisHistory(' in source:
            print("  ❌ analysis.py 仍在使用 AnalysisHistory")
            return False
        else:
            print("  ✅ analysis.py 已移除 AnalysisHistory")
        
        # 测试 history.py 导入
        from api import history
        print("  ✅ api.history 导入成功")
        
        # 检查是否使用 VideoRecord
        source = inspect.getsource(history.get_history)
        
        if 'VideoRecord' in source:
            print("  ✅ history.py 使用 VideoRecord")
        else:
            print("  ❌ history.py 未使用 VideoRecord")
            return False
        
        if 'AnalysisHistory' in source:
            print("  ❌ history.py 仍在使用 AnalysisHistory")
            return False
        else:
            print("  ✅ history.py 已移除 AnalysisHistory")
        
        print("\n✅ 所有导入检查通过\n")
        return True
        
    except Exception as e:
        print(f"\n❌ 导入测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_field_mapping():
    """测试字段映射"""
    print("="*60)
    print("📊 测试 2: 检查字段映射")
    print("="*60)
    
    try:
        from api import analysis, history
        import inspect
        
        # 检查 analysis.py 的字段映射
        print("\n  analysis.py 字段映射检查:")
        source = inspect.getsource(analysis.analyze_video)
        
        required_fields = {
            'source_id=0': '手动调用固定为0',
            'did="0"': '手动调用固定为"0"',
            'call_type="manual"': '调用类型为manual',
            'file_name=': '文件名映射',
            'file_path=': '文件路径映射',
            'prompt=': '提示词映射',
            'model_name=': '模型名称映射',
            'analysis_fps=': '分析FPS映射',
            'input_tokens=': 'Token统计映射',
            'analysis_cost=': '费用映射',
            'llm_raw_response=': '原始返回映射',
            'llm_status="completed"': 'LLM状态映射',
        }
        
        all_ok = True
        for field, desc in required_fields.items():
            if field in source:
                print(f"    ✅ {desc}: {field}")
            else:
                print(f"    ❌ {desc}: 缺失")
                all_ok = False
        
        # 检查 history.py 的查询条件
        print("\n  history.py 查询条件检查:")
        source = inspect.getsource(history.get_history)
        
        if "call_type == 'manual'" in source:
            print("    ✅ 只查询手动分析记录")
        else:
            print("    ❌ 未添加 call_type 过滤条件")
            all_ok = False
        
        if 'file_name' in source:
            print("    ✅ 使用 file_name 字段")
        else:
            print("    ❌ 未使用 file_name 字段")
            all_ok = False
        
        if 'llm_raw_response' in source:
            print("    ✅ 使用 llm_raw_response 字段")
        else:
            print("    ❌ 未使用 llm_raw_response 字段")
            all_ok = False
        
        if all_ok:
            print("\n✅ 所有字段映射检查通过\n")
        else:
            print("\n⚠️  部分字段映射检查未通过\n")
        
        return all_ok
        
    except Exception as e:
        print(f"\n❌ 字段映射测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_database_query():
    """测试数据库查询"""
    print("="*60)
    print("📊 测试 3: 测试数据库查询")
    print("="*60)
    
    try:
        from models.database import VideoRecord
        from models.db import get_db
        
        db = next(get_db())
        
        # 查询手动分析记录
        manual_count = db.query(VideoRecord).filter(VideoRecord.call_type == 'manual').count()
        print(f"  手动分析记录数: {manual_count}")
        
        if manual_count > 0:
            # 查询最新一条
            latest = db.query(VideoRecord)\
                .filter(VideoRecord.call_type == 'manual')\
                .order_by(VideoRecord.created_at.desc())\
                .first()
            
            print(f"\n  最新手动记录:")
            print(f"    ID: {latest.id}")
            print(f"    DID: {latest.did}")
            print(f"    调用类型: {latest.call_type}")
            print(f"    文件名: {latest.file_name}")
            print(f"    输入Token: {latest.input_tokens}")
            print(f"    费用: {latest.analysis_cost}")
            print(f"    有原始返回: {'是' if latest.llm_raw_response else '否'}")
            
            # 验证关键字段
            errors = []
            if latest.did != "0":
                errors.append(f"did 应为 '0'，实际为 '{latest.did}'")
            if latest.call_type != "manual":
                errors.append(f"call_type 应为 'manual'，实际为 '{latest.call_type}'")
            if latest.source_id != 0:
                errors.append(f"source_id 应为 0，实际为 {latest.source_id}")
            
            if errors:
                print(f"\n  ⚠️  发现问题:")
                for error in errors:
                    print(f"    - {error}")
                return False
            else:
                print(f"\n  ✅ 关键字段验证通过")
        else:
            print("  ℹ️  没有手动分析记录（正常，等新分析产生）")
        
        print("\n✅ 数据库查询测试通过\n")
        return True
        
    except Exception as e:
        print(f"\n❌ 数据库查询测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """执行所有测试"""
    print("\n" + "="*60)
    print("🧪 Backend API 修改测试")
    print("="*60 + "\n")
    
    tests = [
        ("导入测试", test_imports),
        ("字段映射测试", test_field_mapping),
        ("数据库查询测试", test_database_query),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"\n❌ {name} 执行失败: {e}\n")
            results.append((name, False))
    
    # 总结
    print("="*60)
    print("📝 测试总结")
    print("="*60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ 通过" if result else "❌ 失败"
        print(f"  {name}: {status}")
    
    print(f"\n通过率: {passed}/{total} ({passed/total*100:.0f}%)")
    
    if passed == total:
        print("\n🎉 所有测试通过！")
        print("\n📝 下一步:")
        print("  1. 启动 Backend 服务: cd backend && python3 main.py")
        print("  2. 测试前端分析功能")
        print("  3. 检查调用历史是否正常显示")
        return True
    else:
        print("\n⚠️  部分测试未通过，请检查修改")
        return False

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
