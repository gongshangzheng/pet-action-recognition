# 🚀 服务器部署后快速启动指南

## 当前问题

重新部署后，LLM Worker显示"已停止"，需要手动启动。

---

## ⚡ 3步快速启动（推荐）

### Step 1: 清理旧任务（必须！）

服务器上有9,965个旧任务（超过25小时），需要先清理：

```bash
cd /path/to/pet-videos/backend

# 执行清理SQL脚本
sqlite3 database/history.db < scripts/cleanup_old_tasks.sql
```

**预期输出**：
```
=== 清理前统计 ===
pending: 9971 (99.19%)
completed: 81 (0.81%)

=== 时间窗口分布 ===
0-25小时(窗口内): 378
25-72小时(3天内): 740
3-7天: 1573
...

✓ 已清理 9593 条旧任务

=== 清理后统计 ===
pending: 378
expired: 9593
completed: 81
```

---

### Step 2: 启动Worker

**方法A：前端界面（最简单）**
1. 打开前端页面
2. 点击"系统管理"标签
3. 点击"启动Worker"按钮

**方法B：命令行（服务器）**
```bash
# Linux/Mac
cd scripts
./start_llm_worker.sh

# 或直接API
curl -X POST http://localhost:8002/api/llm-worker/start
```

---

### Step 3: 验证启动成功

前端页面应该显示：
```
Worker状态: 运行中 ✅
等待中: 378 → 逐渐减少
已完成: 86 → 逐渐增加
```

---

## 📊 处理时间预估

清理后，Worker将处理378个窗口内的任务：

- **并发数**: 2个任务同时处理
- **单任务耗时**: 10-30秒
- **总预计时间**: 3-6小时

---

## 🔧 如果Worker无法启动

### 检查1: 后端服务是否运行

```bash
curl http://localhost:8002/api/health
```

如果失败，说明后端服务未运行：
```bash
cd backend
nohup python3 main.py > logs/backend.log 2>&1 &
```

---

### 检查2: 查看启动日志

```bash
tail -100 backend/logs/backend.log | grep -i "llm worker"
```

**正常情况**：
```
INFO - LLM Worker Service started automatically
INFO - LLM Worker loop started
```

**异常情况**：
```
ERROR - LLM Worker failed: ...
```

根据错误信息排查。

---

### 检查3: API Key配置

```bash
# 检查API Key是否配置
env | grep DASHSCOPE_API_KEY

# 或查看.env文件
cat backend/.env | grep DASHSCOPE_API_KEY
```

如果未配置或为空，需要添加：
```env
DASHSCOPE_API_KEY=your-api-key-here
```

---

## 🎯 完整部署检查清单

部署后依次检查：

- [ ] **数据库迁移完成**
  ```bash
  sqlite3 database/history.db "PRAGMA table_info(daily_reports);" | wc -l
  # 应该输出: 16（新表结构）
  ```

- [ ] **字段同步完成**
  ```bash
  sqlite3 database/history.db "SELECT name FROM pragma_table_info('video_records') WHERE name = 'llm_next_retry_at';"
  # 应该输出: llm_next_retry_at
  ```

- [ ] **后端服务运行**
  ```bash
  curl http://localhost:8002/api/health
  # 应该返回: {"status": "ok"}
  ```

- [ ] **清理旧任务**
  ```bash
  sqlite3 database/history.db < scripts/cleanup_old_tasks.sql
  ```

- [ ] **启动Worker**
  ```bash
  curl -X POST http://localhost:8002/api/llm-worker/start
  ```

- [ ] **验证Worker运行**
  ```bash
  curl http://localhost:8002/api/llm-worker/status | grep "worker_running"
  # 应该输出: "worker_running": true
  ```

- [ ] **前端验证**
  - 访问前端页面
  - 查看"系统管理"标签
  - 确认Worker状态为"运行中"

---

## 🚨 紧急联系

如果所有方法都失败，请：

1. **收集信息**：
   ```bash
   # 完整日志
   tail -200 backend/logs/backend.log > error_report.log
   
   # Worker状态
   curl http://localhost:8002/api/llm-worker/status >> error_report.log
   
   # 环境变量
   env | grep LLM >> error_report.log
   ```

2. **发送错误报告**：error_report.log

3. **临时解决**：先清理旧任务，让新任务能正常处理

---

**文档版本**：1.0  
**最后更新**：2026-02-12
