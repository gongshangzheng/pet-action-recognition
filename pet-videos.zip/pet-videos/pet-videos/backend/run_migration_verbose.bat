@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ======================================================================
echo Pet-Videos Database Migration (Verbose Mode)
echo ======================================================================
echo.

set "DB_PATH=database\history.db"

if not exist "%DB_PATH%" (
    echo ERROR: Database not found: %DB_PATH%
    pause
    exit /b 1
)

echo Database: %DB_PATH%
echo.

REM Backup
set "TIMESTAMP=%date:~0,4%%date:~5,2%%date:~8,2%_%time:~0,2%%time:~3,2%%time:~6,2%"
set "TIMESTAMP=%TIMESTAMP: =0%"
set "BACKUP_PATH=%DB_PATH%.backup.%TIMESTAMP%"

echo Backing up to: %BACKUP_PATH%
copy "%DB_PATH%" "%BACKUP_PATH%" >nul
echo OK: Backup completed
echo.

echo ======================================================================
echo Running migrations (with full output)
echo ======================================================================
echo.

set "DATABASE_PATH=%DB_PATH%"

echo [1/8] migrate_add_did_to_stream_sources.py
echo ----------------------------------------------------------------------
python migrations\migrate_add_did_to_stream_sources.py
if errorlevel 1 (
    echo.
    echo ERROR: Migration failed!
    echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
    pause
    exit /b 1
)
echo.

echo [2/8] migrate_unify_video_records.py
echo ----------------------------------------------------------------------
python migrations\migrate_unify_video_records.py
if errorlevel 1 (
    echo.
    echo ERROR: Migration failed!
    echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
    pause
    exit /b 1
)
echo.

echo [3/8] migrate_add_pets_table.py
echo ----------------------------------------------------------------------
python migrations\migrate_add_pets_table.py
if errorlevel 1 (
    echo.
    echo ERROR: Migration failed!
    echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
    pause
    exit /b 1
)
echo.

echo [4/8] migrate_add_weight_to_pets.py
echo ----------------------------------------------------------------------
python migrations\migrate_add_weight_to_pets.py
if errorlevel 1 (
    echo.
    echo ERROR: Migration failed!
    echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
    pause
    exit /b 1
)
echo.

echo [5/8] migrate_add_avatar_color_to_pets.py
echo ----------------------------------------------------------------------
python migrations\migrate_add_avatar_color_to_pets.py
if errorlevel 1 (
    echo.
    echo ERROR: Migration failed!
    echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
    pause
    exit /b 1
)
echo.

echo [6/8] migrate_add_video_pet_analysis_table.py
echo ----------------------------------------------------------------------
python migrations\migrate_add_video_pet_analysis_table.py
if errorlevel 1 (
    echo.
    echo ERROR: Migration failed!
    echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
    pause
    exit /b 1
)
echo.

echo [7/8] migrate_rename_video_pet_analysis_to_pet_behaviors.py
echo ----------------------------------------------------------------------
python migrations\migrate_rename_video_pet_analysis_to_pet_behaviors.py
if errorlevel 1 (
    echo.
    echo ERROR: Migration failed!
    echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
    pause
    exit /b 1
)
echo.

echo [8/8] migrate_add_daily_reports_table.py
echo ----------------------------------------------------------------------
python migrations\migrate_add_daily_reports_table.py
if errorlevel 1 (
    echo.
    echo ERROR: Migration failed!
    echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
    pause
    exit /b 1
)
echo.

echo ======================================================================
echo SUCCESS: All migrations completed!
echo ======================================================================
echo.
echo Backup: %BACKUP_PATH%
echo.
pause
