@echo off
chcp 65001 >nul

echo ======================================================================
echo Database Location Checker
echo ======================================================================
echo.

echo Current directory:
cd
echo.

echo Checking database locations...
echo.

echo [1] Check: database\history.db
if exist "database\history.db" (
    echo    OK: Found at database\history.db
    dir database\history.db
    set "FOUND_DB=database\history.db"
) else (
    echo    NOT FOUND: database\history.db
)
echo.

echo [2] Check: database\server_history.db
if exist "database\server_history.db" (
    echo    OK: Found at database\server_history.db
    dir database\server_history.db
    set "FOUND_DB=database\server_history.db"
) else (
    echo    NOT FOUND: database\server_history.db
)
echo.

echo [3] Check: ..\database\history.db
if exist "..\database\history.db" (
    echo    OK: Found at ..\database\history.db
    dir ..\database\history.db
) else (
    echo    NOT FOUND: ..\database\history.db
)
echo.

echo [4] List all .db files in database folder:
if exist "database\" (
    dir /b database\*.db 2>nul
    if errorlevel 1 (
        echo    No .db files found in database folder
    )
) else (
    echo    database folder does not exist
)
echo.

echo ======================================================================
echo Solution
echo ======================================================================
echo.

if exist "database\history.db" (
    echo The database file is: database\history.db
    echo.
    echo To run migration with correct path:
    echo   set DATABASE_PATH=database\history.db
    echo   run_server_migration_simple.bat
    echo.
    echo Or use PowerShell:
    echo   $env:DATABASE_PATH="database\history.db"
    echo   .\run_server_migration.ps1
) else if exist "database\server_history.db" (
    echo The database file is: database\server_history.db
    echo Migration script should work correctly.
) else (
    echo ERROR: No database file found!
    echo.
    echo Please check:
    echo   1. Are you in the correct directory? (should be backend folder)
    echo   2. Has the database been created?
    echo   3. Is the database in a different location?
    echo.
    echo To create database folder:
    echo   mkdir database
    echo.
    echo If database is on server, download it to:
    echo   D:\pet-videos\backend\database\history.db
)

echo.
pause
