#!/usr/bin/env python3
"""扫描视频目录，将现有视频文件导入到数据库"""
import sys
from pathlib import Path
from datetime import datetime
import re

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from backend.models.database import VideoRecord, StreamSource, Base
from backend.models.db import SessionLocal, engine
from backend.config import settings

# 初始化数据库
Base.metadata.create_all(bind=engine)

def parse_filename(filename: str):
    """
    从文件名解析信息
    支持格式：
    - VIDEO_1767494103401.mp4 (时间戳毫秒)
    - 20260104_151703.mp4 (日期时间)
    - pet_20260104_151703.mp4 (前缀+日期时间)
    """
    # 尝试提取时间戳（毫秒）
    match = re.search(r'(\d{13})', filename)
    if match:
        timestamp_ms = int(match.group(1))
        created_at = datetime.fromtimestamp(timestamp_ms / 1000.0)
        return created_at
    
    # 尝试提取日期时间格式 YYYYMMDD_HHMMSS
    match = re.search(r'(\d{8})_(\d{6})', filename)
    if match:
        date_str = match.group(1)
        time_str = match.group(2)
        created_at = datetime.strptime(f"{date_str}{time_str}", "%Y%m%d%H%M%S")
        return created_at
    
    # 如果无法解析，返回 None
    return None

def import_videos_for_source(db, source: StreamSource, dry_run: bool = False):
    """导入指定源的视频文件"""
    storage_path = Path(source.storage_path)
    
    if not storage_path.exists():
        print(f"⚠️  路径不存在: {storage_path}")
        return 0
    
    # 查找所有视频文件
    video_files = list(storage_path.glob("*.mp4"))
    video_files.extend(storage_path.glob("*.avi"))
    video_files.extend(storage_path.glob("*.mkv"))
    
    print(f"\n{'[DRY RUN] ' if dry_run else ''}处理源: {source.name} ({source.alias})")
    print(f"  路径: {storage_path}")
    print(f"  找到 {len(video_files)} 个视频文件")
    
    imported_count = 0
    skipped_count = 0
    
    for video_file in sorted(video_files):
        # 检查是否已存在
        existing = db.query(VideoRecord).filter(
            VideoRecord.source_alias == source.alias,
            VideoRecord.filename == video_file.name
        ).first()
        
        if existing:
            skipped_count += 1
            continue
        
        # 解析创建时间
        created_at = parse_filename(video_file.name)
        if not created_at:
            # 如果无法从文件名解析，使用文件的修改时间
            created_at = datetime.fromtimestamp(video_file.stat().st_mtime)
        
        # 获取文件大小
        file_size = video_file.stat().st_size
        duration = 0  # 暂时无法获取，设为0
        
        if dry_run:
            print(f"  [预览] {video_file.name} - {created_at.strftime('%Y-%m-%d %H:%M:%S')} - {file_size/1024/1024:.1f}MB")
        else:
            # 创建记录
            record = VideoRecord(
                source_alias=source.alias,
                filename=video_file.name,
                duration=duration,
                size=file_size,
                created_at=created_at
            )
            db.add(record)
            imported_count += 1
    
    if not dry_run and imported_count > 0:
        db.commit()
        print(f"  ✅ 导入 {imported_count} 条记录")
    
    if skipped_count > 0:
        print(f"  ⏭️  跳过 {skipped_count} 条已存在记录")
    
    return imported_count

def main():
    import argparse
    parser = argparse.ArgumentParser(description="导入视频文件到数据库")
    parser.add_argument('--dry-run', action='store_true', help='预览模式，不实际导入')
    parser.add_argument('--alias', type=str, help='只导入指定别名的源')
    args = parser.parse_args()
    
    db = SessionLocal()
    
    try:
        # 获取所有活动的源
        sources = db.query(StreamSource).filter(StreamSource.is_active == True).all()
        
        if not sources:
            print("❌ 没有找到活动的视频源")
            return
        
        print(f"{'='*60}")
        print(f"{'[预览模式]' if args.dry_run else '[导入模式]'} 视频文件导入工具")
        print(f"{'='*60}")
        
        total_imported = 0
        
        for source in sources:
            if args.alias and source.alias != args.alias:
                continue
            
            count = import_videos_for_source(db, source, dry_run=args.dry_run)
            total_imported += count
        
        print(f"\n{'='*60}")
        if args.dry_run:
            print(f"预览完成！发现 {total_imported} 个可导入的视频文件")
            print(f"运行 'python3 {__file__} 执行实际导入")
        else:
            print(f"✅ 导入完成！共导入 {total_imported} 条视频记录")
        print(f"{'='*60}")
        
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == '__main__':
    main()
