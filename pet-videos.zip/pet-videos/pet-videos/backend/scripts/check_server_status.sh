#!/bin/bash

# 检查服务器数据库状态的脚本
# 用法: ./check_server_status.sh

echo "========================================="
echo "  服务器数据库状态检查"
echo "========================================="
echo ""

cd /path/to/pet-videos/backend

echo "1. pending任务月份分布："
echo "================================"
sqlite3 database/history.db "SELECT 
  strftime('%Y-%m', created_at) as year_month,
  COUNT(*) as count,
  MIN(DATE(created_at)) as earliest,
  MAX(DATE(created_at)) as latest,
  ROUND((julianday('now', 'localtime') - julianday(MIN(created_at))) * 24, 1) || '小时' as oldest_hours
FROM video_records 
WHERE llm_status = 'pending'
GROUP BY year_month
ORDER BY year_month DESC;"

echo ""
echo "2. 时间窗口分析（25小时窗口）："
echo "================================"
sqlite3 database/history.db "SELECT 
  CASE 
    WHEN hours_old <= 25 THEN '✅ 0-25小时(窗口内)'
    WHEN hours_old <= 72 THEN '⚠️  25-72小时(3天内)'
    WHEN hours_old <= 168 THEN '❌ 3-7天'
    WHEN hours_old <= 336 THEN '❌ 7-14天'
    ELSE '❌ 14天以上'
  END as time_range,
  COUNT(*) as count,
  ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM video_records WHERE llm_status = 'pending'), 2) || '%' as percentage
FROM (
  SELECT 
    (julianday('now', 'localtime') - julianday(created_at)) * 24 as hours_old
  FROM video_records 
  WHERE llm_status = 'pending'
)
GROUP BY time_range
ORDER BY 
  CASE 
    WHEN time_range LIKE '%窗口内%' THEN 1
    WHEN time_range LIKE '%3天内%' THEN 2
    WHEN time_range LIKE '%3-7天%' THEN 3
    WHEN time_range LIKE '%7-14天%' THEN 4
    ELSE 5
  END;"

echo ""
echo "3. 状态统计："
echo "================================"
sqlite3 database/history.db "SELECT 
  llm_status,
  COUNT(*) as count,
  ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM video_records), 2) || '%' as percentage
FROM video_records 
GROUP BY llm_status
ORDER BY count DESC;"

echo ""
echo "4. Worker状态："
echo "================================"
curl -s http://localhost:8002/api/llm-worker/status | python3 -m json.tool 2>/dev/null || echo "无法获取Worker状态"

echo ""
echo "========================================="
echo "  检查完成"
echo "========================================="
echo ""
echo "💡 建议："
echo "  - 如果看到大量超过25小时的pending任务，执行清理："
echo "    sqlite3 database/history.db < scripts/cleanup_old_tasks.sql"
echo ""
echo "  - 如果Worker已停止，启动它："
echo "    curl -X POST http://localhost:8002/api/llm-worker/start"
echo ""
