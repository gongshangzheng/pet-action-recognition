-- 清理超出时间窗口的旧任务
-- 用法: sqlite3 database/history.db < scripts/cleanup_old_tasks.sql

.mode column
.headers on

-- 显示当前状态
SELECT '=== 清理前统计 ===' as info;
SELECT 
  llm_status,
  COUNT(*) as count,
  ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM video_records), 2) || '%' as percentage
FROM video_records 
GROUP BY llm_status
ORDER BY count DESC;

-- 显示时间窗口分布
SELECT '' as blank;
SELECT '=== 时间窗口分布 (25小时窗口) ===' as info;
SELECT 
  CASE 
    WHEN hours_old <= 25 THEN '0-25小时(窗口内)'
    WHEN hours_old <= 72 THEN '25-72小时(3天内)'
    WHEN hours_old <= 168 THEN '3-7天'
    WHEN hours_old <= 336 THEN '7-14天'
    ELSE '14天以上'
  END as time_range,
  COUNT(*) as count
FROM (
  SELECT 
    (julianday('now', 'localtime') - julianday(created_at)) * 24 as hours_old
  FROM video_records 
  WHERE llm_status = 'pending'
)
GROUP BY time_range
ORDER BY 
  CASE time_range
    WHEN '0-25小时(窗口内)' THEN 1
    WHEN '25-72小时(3天内)' THEN 2
    WHEN '3-7天' THEN 3
    WHEN '7-14天' THEN 4
    ELSE 5
  END;

-- 执行清理
SELECT '' as blank;
SELECT '=== 开始清理超过25小时的旧任务 ===' as info;

UPDATE video_records 
SET llm_status = 'expired', 
    llm_error = '超出处理时间窗口(25小时)',
    updated_at = datetime('now', 'localtime')
WHERE llm_status = 'pending' 
AND (julianday('now', 'localtime') - julianday(created_at)) * 24 > 25;

SELECT '✓ 已清理 ' || changes() || ' 条旧任务' as result;

-- 显示清理后状态
SELECT '' as blank;
SELECT '=== 清理后统计 ===' as info;
SELECT 
  llm_status,
  COUNT(*) as count,
  ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM video_records), 2) || '%' as percentage
FROM video_records 
GROUP BY llm_status
ORDER BY count DESC;

SELECT '' as blank;
SELECT '✅ 清理完成！现在可以启动Worker了。' as info;
SELECT '' as blank;
SELECT '💡 启动Worker方法：' as info;
SELECT '   1. 前端页面点击"启动Worker"按钮' as method;
SELECT '   2. 或执行: curl -X POST http://localhost:8002/api/llm-worker/start' as method;
