# 快速启动脚本

## 🚀 一键启动LLM Worker

### Linux/Mac

```bash
cd /path/to/pet-videos/backend/scripts
./start_llm_worker.sh
```

### Windows

```cmd
cd D:\pet-videos\backend\scripts
start_llm_worker.bat
```

---

## ⚡ 最快的启动方式（推荐）

### 方法1：通过前端界面（最简单）

1. 打开前端页面
2. 点击 **系统管理** 标签
3. 在 **LLM分析** 区域点击 **启动Worker** 按钮

✅ 无需命令行，点击即可

---

### 方法2：API命令（服务器上）

```bash
# 一条命令启动
curl -X POST http://localhost:8002/api/llm-worker/start

# 验证状态
curl http://localhost:8002/api/llm-worker/status | grep "worker_running"
```

---

### 方法3：使用启动脚本

如果前两种方法都失败，使用提供的脚本：

**Linux/Mac**:
```bash
./start_llm_worker.sh
```

**Windows**:
```cmd
start_llm_worker.bat
```

脚本会自动：
- 检查后端服务状态
- 启动Worker
- 验证启动结果
- 显示队列状态

---

## 🔍 为什么Worker没有自动启动？

### 常见原因

#### 1. 环境变量禁用了自动启动

检查服务器上的环境变量：

```bash
# Linux
env | grep LLM_WORKER

# Windows (PowerShell)
Get-ChildItem Env: | Where-Object {$_.Name -like "*LLM_WORKER*"}
```

如果看到：
```
LLM_WORKER_AUTO_START=false
```

说明自动启动被禁用了。

**解决方法**：
```bash
export LLM_WORKER_AUTO_START=true
```

然后重启服务。

---

#### 2. `.env` 文件配置错误

检查 `backend/.env` 文件：

```bash
cd backend
cat .env | grep LLM_WORKER
```

应该看到：
```env
LLM_WORKER_ENABLED=true
LLM_WORKER_AUTO_START=true
```

如果是 `false`，改为 `true`，然后重启服务。

---

#### 3. 启动过程中出错

查看后端启动日志：

```bash
# Linux/Mac
tail -100 backend/logs/backend.log | grep -i "llm worker"

# Windows
type backend\logs\backend.log | findstr /i "llm worker"
```

**正常情况应该看到**：
```
INFO - LLM Worker Service started automatically
INFO - LLM Worker loop started
INFO - LLM Worker thread started
```

**如果看到错误**：
```
ERROR - LLM Worker failed to start: ...
```

根据错误信息排查问题（通常是API Key配置或数据库连接）。

---

#### 4. 服务重启后默认不启动

某些部署方式可能没有正确读取环境变量。

**解决方法**：手动启动Worker（不需要重启服务）

```bash
# API启动
curl -X POST http://localhost:8002/api/llm-worker/start

# 或使用脚本
./scripts/start_llm_worker.sh
```

---

## 📊 验证Worker状态

### 通过API

```bash
curl http://localhost:8002/api/llm-worker/status | python3 -m json.tool
```

**期望输出**：
```json
{
  "worker_running": true,        ← 应该是 true
  "processing_count": 2,
  "queue_stats": {
    "pending": 378,
    "completed": 86
  },
  "config": {
    "max_concurrent": 2,
    "poll_interval": 10
  }
}
```

### 通过前端

访问前端页面，**系统管理 > LLM分析** 区域，应该看到：

```
Worker状态: 运行中 ✅
处理进度: 2 / 2
等待中: 逐渐减少
```

---

## 🛠️ 故障排除

### Worker启动后立即停止

**原因**：可能是API Key无效或数据库错误

**排查**：
```bash
# 查看完整日志
tail -50 backend/logs/backend.log

# 检查API Key
env | grep DASHSCOPE_API_KEY
```

### Worker运行但不处理任务

**原因**：可能所有任务都超出时间窗口

**解决**：
```bash
# 清理旧任务
cd backend
sqlite3 database/history.db "UPDATE video_records 
SET llm_status = 'expired' 
WHERE llm_status = 'pending' 
AND (julianday('now', 'localtime') - julianday(created_at)) * 24 > 25;"

# 重启Worker
curl -X POST http://localhost:8002/api/llm-worker/restart
```

### 无法访问API

**原因**：端口配置错误

**检查**：
```bash
# 确认后端端口
curl http://localhost:8002/api/health

# 如果8002不通，尝试8000
curl http://localhost:8000/api/health
```

---

## 📞 需要帮助？

参考详细文档：
- [LLM_WORKER_TROUBLESHOOTING.md](../docs/LLM_WORKER_TROUBLESHOOTING.md) - 完整故障排查指南
- [START_LLM_WORKER.md](../docs/START_LLM_WORKER.md) - 快速启动指南
- [TIME_WINDOW_EXPLAINED.md](../docs/TIME_WINDOW_EXPLAINED.md) - 时间窗口机制详解
