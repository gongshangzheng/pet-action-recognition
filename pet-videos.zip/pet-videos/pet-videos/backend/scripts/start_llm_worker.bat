@echo off
REM LLM Worker 快速启动脚本 (Windows)
REM 用法: start_llm_worker.bat

echo =========================================
echo   LLM Worker 快速启动
echo =========================================
echo.

REM 检查后端服务
echo [1/3] 检查后端服务状态...
curl -s http://localhost:8002/api/health >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [错误] 后端服务未运行！
    echo.
    echo 请先启动后端服务：
    echo   cd backend
    echo   python main.py
    exit /b 1
)
echo [成功] 后端服务运行正常
echo.

REM 启动Worker
echo [2/3] 启动Worker...
curl -s -X POST http://localhost:8002/api/llm-worker/start
echo.
echo.

REM 等待验证
echo [3/3] 验证启动结果...
timeout /t 3 /nobreak >nul
echo.

REM 检查状态
curl -s http://localhost:8002/api/llm-worker/status
echo.
echo.

echo =========================================
echo   完成！
echo =========================================
echo.
echo 提示：
echo - 访问前端页面查看Worker运行状态
echo - 如果Worker未启动，请查看日志: backend\logs\backend.log
echo.
pause
