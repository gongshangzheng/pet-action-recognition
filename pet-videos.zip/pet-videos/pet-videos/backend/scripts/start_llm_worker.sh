#!/bin/bash

# LLM Worker 快速启动脚本
# 用法: ./start_llm_worker.sh

set -e

echo "========================================="
echo "  LLM Worker 快速启动"
echo "========================================="
echo ""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 检查后端是否运行
echo -e "${BLUE}[1/3] 检查后端服务状态...${NC}"
HEALTH_CHECK=$(curl -s http://localhost:8002/api/health 2>/dev/null || echo "FAILED")

if [[ "${HEALTH_CHECK}" != *"status"* ]]; then
    echo -e "${RED}❌ 后端服务未运行！${NC}"
    echo ""
    echo "请先启动后端服务："
    echo "  cd backend"
    echo "  nohup python3 main.py > logs/backend.log 2>&1 &"
    exit 1
fi

echo -e "${GREEN}✓ 后端服务运行正常${NC}"
echo ""

# 检查Worker状态
echo -e "${BLUE}[2/3] 检查Worker状态...${NC}"
STATUS=$(curl -s http://localhost:8002/api/llm-worker/status 2>/dev/null || echo "{}")
IS_RUNNING=$(echo "${STATUS}" | grep -o '"worker_running":[^,}]*' | grep -o 'true\|false')

if [ "${IS_RUNNING}" == "true" ]; then
    echo -e "${GREEN}✓ Worker已经在运行${NC}"
    echo ""
    echo "当前状态："
    echo "${STATUS}" | python3 -m json.tool 2>/dev/null || echo "${STATUS}"
    exit 0
fi

echo -e "${YELLOW}⚠️  Worker未运行${NC}"
echo ""

# 启动Worker
echo -e "${BLUE}[3/3] 启动Worker...${NC}"
RESULT=$(curl -s -X POST http://localhost:8002/api/llm-worker/start 2>/dev/null || echo "FAILED")

if [[ "${RESULT}" == *"success"* ]] || [[ "${RESULT}" == *"started"* ]] || [[ "${RESULT}" == *"运行"* ]]; then
    echo -e "${GREEN}✓ Worker启动成功${NC}"
else
    echo -e "${RED}❌ Worker启动失败${NC}"
    echo "响应: ${RESULT}"
    exit 1
fi

echo ""
echo "等待3秒，验证启动结果..."
sleep 3

# 验证启动结果
STATUS=$(curl -s http://localhost:8002/api/llm-worker/status 2>/dev/null || echo "{}")
IS_RUNNING=$(echo "${STATUS}" | grep -o '"worker_running":[^,}]*' | grep -o 'true\|false')

if [ "${IS_RUNNING}" == "true" ]; then
    echo -e "${GREEN}✅ Worker已成功启动并运行！${NC}"
    echo ""
    echo "📊 当前队列状态："
    
    # 提取并显示关键信息
    PENDING=$(echo "${STATUS}" | grep -o '"pending":[0-9]*' | grep -o '[0-9]*')
    PROCESSING=$(echo "${STATUS}" | grep -o '"processing_count":[0-9]*' | grep -o '[0-9]*')
    COMPLETED=$(echo "${STATUS}" | grep -o '"completed":[0-9]*' | grep -o '[0-9]*')
    
    echo "  等待中: ${PENDING:-N/A}"
    echo "  处理中: ${PROCESSING:-N/A}"
    echo "  已完成: ${COMPLETED:-N/A}"
    echo ""
    echo "🎯 Worker正在后台自动处理任务"
    echo "📈 可在前端页面监控处理进度"
else
    echo -e "${RED}❌ Worker启动后立即停止${NC}"
    echo ""
    echo "请查看日志排查问题："
    echo "  tail -100 backend/logs/backend.log | grep -i 'llm worker'"
    exit 1
fi

echo ""
echo "========================================="
echo -e "${GREEN}✅ 完成！${NC}"
echo "========================================="
