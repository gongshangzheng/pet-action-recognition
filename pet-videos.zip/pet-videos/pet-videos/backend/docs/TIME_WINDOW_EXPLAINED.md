# ⏰ LLM Worker 时间窗口机制详解

## 📊 问题现象

前端显示：
```
等待中: 9,967 个任务
```

但启动Worker后，实际只处理了很少一部分任务。

---

## 🔍 真相

**时间窗口逻辑是生效的！**前端显示的是所有pending任务，但Worker只处理窗口内的任务。

### 实际数据分布（服务器）

```
总pending任务: 9,971个

时间窗口分布：
├─ 0-25小时（窗口内）: 378个   ✅ Worker会处理
├─ 25-72小时（3天内）:  740个  ❌ 不会处理  
├─ 3-7天:              1,573个  ❌ 不会处理
├─ 7-14天:             1,046个  ❌ 不会处理
└─ 14天以上:           6,234个  ❌ 不会处理

会被处理:    378 个 (3.8%)
永不处理: 9,593 个 (96.2%)
```

---

## 💡 为什么要有时间窗口？

### 设计初衷

1. **避免资源浪费**
   - 历史数据价值递减
   - API调用有成本
   - 优先处理新数据

2. **快速进入正常运行**
   - 不被历史任务拖累
   - 新任务能及时处理
   - 系统响应性更好

3. **防止队列阻塞**
   - 大量历史任务会占用处理时间
   - 新产生的任务可能得不到及时处理
   - 时间窗口确保关注最新数据

### 默认配置

```env
LLM_WORKER_TIME_WINDOW_HOURS=25  # 只处理最近25小时的任务
```

---

## ✅ 解决方案

### 方案1：清理旧任务（推荐）⭐

将超出时间窗口的任务标记为"已过期"：

```bash
# 在服务器上执行
cd /path/to/pet-videos/backend

sqlite3 database/history.db "UPDATE video_records 
SET llm_status = 'expired', 
    llm_error = '超出处理时间窗口(25小时)' 
WHERE llm_status = 'pending' 
AND (julianday('now', 'localtime') - julianday(created_at)) * 24 > 25;"
```

**执行后效果**：
```
pending: 9,971 → 378
expired: 0 → 9,593
```

前端显示将变为：
```
等待中: 378 个
已过期: 9,593 个
```

---

### 方案2：扩大时间窗口

如果需要处理更多历史数据：

```bash
# 处理最近3天的任务
export LLM_WORKER_TIME_WINDOW_HOURS=72

# 或处理最近7天
export LLM_WORKER_TIME_WINDOW_HOURS=168

# 重启Worker
curl -X POST http://localhost:8002/api/llm-worker/restart
```

**对比**：
| 窗口 | 会处理的任务数 | 预计时间 |
|------|--------------|---------|
| 25小时 | 378个 | 3-6小时 |
| 72小时 | 1,118个 | 9-28小时 |
| 7天 | 2,691个 | 22-67小时 |

---

### 方案3：处理全部历史（不推荐）

```bash
# 取消时间限制
export LLM_WORKER_TIME_WINDOW_HOURS=999999

# 重启Worker
curl -X POST http://localhost:8002/api/llm-worker/restart
```

**注意**：
- ⏳ 需要83-250小时（3.5-10天）持续运行
- 💰 大量API调用费用
- 🔌 需要保证服务器稳定

---

## 🎯 推荐处理流程

### Step 1: 清理旧任务

```bash
# 标记超过25小时的任务为已过期
sqlite3 database/history.db "UPDATE video_records 
SET llm_status = 'expired', 
    llm_error = '超出处理时间窗口' 
WHERE llm_status = 'pending' 
AND (julianday('now', 'localtime') - julianday(created_at)) * 24 > 25;"
```

### Step 2: 启动Worker

```bash
# 通过API启动
curl -X POST http://localhost:8002/api/llm-worker/start

# 或前端点击"启动Worker"按钮
```

### Step 3: 监控处理进度

前端会显示：
```
Worker状态: 运行中 ✅
处理进度: 2 / 2
等待中: 378 → 逐渐减少
已完成: XX → 逐渐增加
```

预计3-6小时处理完成。

---

## 📈 新的API响应格式

更新后的 `/api/llm-worker/status` 返回：

```json
{
  "worker_running": true,
  "processing_count": 2,
  "queue_stats": {
    "pending": 9971,
    "completed": 81
  },
  "pending_in_window": 378,        // 新增：窗口内等待
  "pending_outside_window": 9593,  // 新增：窗口外等待
  "time_window_hours": 25,         // 新增：时间窗口配置
  "config": {
    "max_concurrent": 2,
    "poll_interval": 10
  }
}
```

---

## ⚙️ 配置说明

### 环境变量

```env
# 时间窗口（小时）
LLM_WORKER_TIME_WINDOW_HOURS=25

# 并发数（加快处理）
LLM_WORKER_MAX_CONCURRENT=2

# 轮询间隔（秒）
LLM_WORKER_POLL_INTERVAL=10
```

### 配置文件位置

- Windows: `D:\pet-videos\backend\.env`
- Linux: `/path/to/pet-videos/backend/.env`

修改后需要重启服务。

---

## 🔄 常见问题

### Q1: 为什么前端显示9967个等待，Worker只处理378个？

A: 前端显示的是**所有**pending状态的任务，但Worker只处理时间窗口内的。这是设计行为，不是bug。

### Q2: 那9593个旧任务怎么办？

A: 有三个选择：
1. 标记为expired（推荐）
2. 扩大时间窗口处理部分
3. 取消时间限制全部处理（不推荐）

### Q3: 时间窗口能动态调整吗？

A: 可以，修改环境变量后重启Worker即可。

### Q4: 标记为expired后还能再处理吗？

A: 不能。如果需要重新处理，需要将状态改回pending，但建议不要这么做。

---

## 📝 总结

- ✅ 时间窗口逻辑**正常工作**
- ✅ 设计目的是**优先处理新数据**
- ✅ 建议**清理旧任务**后再启动Worker
- ✅ 前端统计已优化，区分窗口内外任务

**下一步**：执行清理SQL → 启动Worker → 监控进度

---

**文档版本**：1.0  
**最后更新**：2026-02-12
