# 🚀 启动 LLM Worker 快速指南

## 当前状态

您看到：
```
Worker 状态: 已停止
等待中: 9,967 个任务
```

需要启动 Worker 来处理这些等待中的任务。

---

## ⚡ 最快解决方案（3种方法）

### 方法1：通过前端界面（最简单）👍

1. 打开浏览器，访问前端页面
2. 点击顶部导航 **"系统管理"** 标签
3. 找到 **"LLM分析"** 部分
4. 点击 **"启动Worker"** 按钮

✅ 几秒钟后Worker就会开始处理任务

---

### 方法2：使用API命令（适合服务器）

```bash
# 启动Worker
curl -X POST http://localhost:8002/api/llm-worker/start

# 验证是否启动成功
curl http://localhost:8002/api/llm-worker/status | grep "is_running"
```

**预期输出**：
```
"is_running": true
```

---

### 方法3：重启服务（如果其他方法无效）

```bash
# 进入项目目录
cd /path/to/pet-videos/backend

# 停止服务
pkill -f "python.*main.py"

# 确保环境变量正确
export LLM_WORKER_ENABLED=true
export LLM_WORKER_AUTO_START=true

# 重新启动服务
nohup python3 main.py > logs/backend.log 2>&1 &

# 查看日志确认启动
tail -f logs/backend.log | grep "LLM Worker"
```

**应该看到**：
```
INFO - LLM Worker Service started automatically
INFO - LLM Worker loop started
INFO - LLM Worker thread started
```

---

## 📊 启动后的效果

启动成功后，前端会显示：

```
Worker 状态: 运行中 ✅
处理进度: 正在处理...
等待中: 逐渐减少
已完成: 逐渐增加
```

Worker会以每次2个任务的速度并发处理（可配置）。

---

## ⏱️ 处理时间估算

- **并发数**：2个任务/次
- **单任务耗时**：约10-30秒
- **9,967个任务预计**：约14-42小时

如果想加快处理速度，可以：

### 增加并发数

```bash
# 编辑配置或设置环境变量
export LLM_WORKER_MAX_CONCURRENT=4  # 从2改为4

# 重启Worker使配置生效
curl -X POST http://localhost:8002/api/llm-worker/restart
```

**注意**：并发数越高，对API调用限额和服务器资源要求越高。

---

## 🔍 检查问题

如果启动失败，检查：

### 1. 查看日志

```bash
tail -100 /path/to/pet-videos/backend/logs/backend.log
```

### 2. 检查API Key

```bash
env | grep DASHSCOPE_API_KEY
# 或
cat .env | grep DASHSCOPE_API_KEY
```

确保API Key已配置且有效。

### 3. 检查数据库

```bash
cd backend
sqlite3 database/history.db "SELECT COUNT(*) FROM video_records WHERE llm_status='pending';"
```

应该看到等待中的任务数。

---

## 💡 提示

- Worker会自动跳过超过25小时的旧任务（可通过 `LLM_WORKER_TIME_WINDOW_HOURS` 配置）
- Worker会自动处理失败任务的重试（最多3次）
- 如果长时间没有进度，可以重启Worker

---

## 📞 需要帮助？

参考详细文档：[LLM_WORKER_TROUBLESHOOTING.md](./LLM_WORKER_TROUBLESHOOTING.md)
