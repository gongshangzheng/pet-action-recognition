# LLM Worker 问题排查指南

## 📊 问题现象

前端显示：
```
Worker 状态: 已停止
等待中: 9,967
已完成: 83
处理中: 2
```

大量任务堆积在队列中，但Worker没有运行。

---

## 🔍 排查步骤

### 1. 检查服务器日志

查看后端启动日志，确认Worker是否启动：

```bash
cd /path/to/pet-videos/backend
tail -100 logs/backend.log | grep -i "llm worker"
```

**正常情况应该看到**：
```
INFO - LLM Worker Service started automatically
INFO - LLM Worker loop started
INFO - LLM Worker thread started
```

**如果看到禁用提示**：
```
INFO - LLM Worker Service disabled by configuration or auto_start=False
```
说明配置中禁用了自动启动。

### 2. 检查环境变量配置

服务器上可能设置了环境变量禁用Worker：

```bash
# 检查环境变量
env | grep -i llm_worker

# 可能的输出：
# LLM_WORKER_ENABLED=false   # Worker被禁用
# LLM_WORKER_AUTO_START=false  # 自动启动被禁用
```

### 3. 检查配置文件

如果使用了 `.env` 文件：

```bash
cd backend
cat .env | grep -i llm_worker
```

---

## ✅ 解决方案

### 方案一：通过API启动（推荐）

在浏览器中打开前端，在"系统管理 > LLM分析"页面点击"启动Worker"按钮。

或者使用API：

```bash
curl -X POST http://your-server:8002/api/llm-worker/start \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 方案二：修改配置后重启

如果环境变量禁用了Worker，修改配置：

**Windows (PowerShell)**:
```powershell
# 编辑 .env 文件或设置环境变量
$env:LLM_WORKER_ENABLED = "true"
$env:LLM_WORKER_AUTO_START = "true"

# 重启服务
# 先停止现有进程，然后重新启动
```

**Linux**:
```bash
# 编辑 .env 文件
cd backend
nano .env

# 确保以下配置：
LLM_WORKER_ENABLED=true
LLM_WORKER_AUTO_START=true

# 或设置环境变量
export LLM_WORKER_ENABLED=true
export LLM_WORKER_AUTO_START=true

# 重启服务
pkill -f "python.*main.py"
nohup python3 main.py > logs/backend.log 2>&1 &
```

### 方案三：修改代码默认值

编辑 `backend/config.py`：

```python
# LLM Worker 配置
llm_worker_enabled: bool = True  # 确保是 True
llm_worker_auto_start: bool = True  # 确保是 True
```

然后重启服务。

---

## 🔧 配置说明

### 关键配置项

| 配置项 | 默认值 | 说明 |
|--------|--------|------|
| `LLM_WORKER_ENABLED` | `true` | Worker总开关 |
| `LLM_WORKER_AUTO_START` | `true` | 启动时自动启动Worker |
| `LLM_WORKER_MAX_CONCURRENT` | `2` | 最大并发分析数 |
| `LLM_WORKER_POLL_INTERVAL` | `10` | 轮询间隔（秒） |
| `LLM_WORKER_TIME_WINDOW_HOURS` | `25` | 只处理最近N小时的任务 |

### 性能调优

如果任务堆积严重，可以调整并发数：

```bash
# 增加并发数（适用于性能较好的服务器）
export LLM_WORKER_MAX_CONCURRENT=4

# 减少轮询间隔（更快响应）
export LLM_WORKER_POLL_INTERVAL=5
```

---

## 📈 监控Worker状态

### 通过API查看状态

```bash
curl http://your-server:8002/api/llm-worker/status
```

**返回示例**：
```json
{
  "is_running": true,
  "system_enabled": true,
  "auto_start": true,
  "pending_count": 9967,
  "processing_count": 2,
  "completed_count": 83,
  "max_concurrent": 2,
  "poll_interval": 10
}
```

### 通过前端监控

访问前端 **系统管理 > LLM分析** 页面，实时查看：
- Worker状态（运行中/已停止）
- 处理进度
- 队列状态
- 状态分布

---

## ⚠️ 常见问题

### Q1: Worker启动后立即停止

**原因**：可能是启动过程中出错

**解决**：
```bash
# 查看完整错误日志
tail -200 logs/backend.log
```

常见错误：
- API Key未配置或无效
- 数据库连接失败
- 内存不足

### Q2: Worker运行但不处理任务

**原因**：可能所有任务都超出时间窗口

**解决**：
```bash
# 查看任务创建时间
sqlite3 database/history.db "SELECT created_at, llm_status FROM video_records WHERE llm_status='pending' LIMIT 10;"

# 如果任务太旧（超过25小时），增加时间窗口
export LLM_WORKER_TIME_WINDOW_HOURS=72
```

### Q3: 任务一直在processing状态

**原因**：任务超时或Worker异常停止

**解决**：
```bash
# 重启Worker会自动重新处理超时任务
curl -X POST http://your-server:8002/api/llm-worker/restart
```

---

## 🚀 快速修复步骤

**如果Worker已停止且有大量等待任务**：

```bash
# 1. 进入项目目录
cd /path/to/pet-videos/backend

# 2. 检查日志确认原因
tail -50 logs/backend.log | grep -i "llm worker"

# 3. 通过API启动Worker（最快）
curl -X POST http://localhost:8002/api/llm-worker/start

# 4. 验证启动成功
curl http://localhost:8002/api/llm-worker/status | jq '.is_running'
# 应该返回: true
```

---

## 📞 技术支持

如果以上方法都无法解决问题，请提供：
1. 完整的启动日志（`logs/backend.log`）
2. Worker状态API返回结果
3. 环境变量配置
4. 系统资源使用情况

---

**文档版本**：1.0  
**最后更新**：2026-02-12
