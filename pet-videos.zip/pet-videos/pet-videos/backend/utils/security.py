"""安全工具函数"""
import hashlib
import base64
import logging
from pathlib import Path
from fastapi import HTTPException
from config import settings

logger = logging.getLogger(__name__)

# 只允许mp4文件
ALLOWED_VIDEO_EXTENSIONS = {'.mp4'}


def encode_video_token(dir_alias: str, filename: str) -> str:
    """将目录别名和文件名编码为安全的token
    
    Args:
        dir_alias: 目录别名
        filename: 文件名（不含路径）
        
    Returns:
        编码后的token字符串
    """
    # 组合: alias:filename
    data = f"{dir_alias}:{filename}"
    data_bytes = data.encode('utf-8')
    
    # 使用JWT_SECRET作为密钥生成签名
    signature = hashlib.sha256(
        (data + settings.jwt_secret).encode('utf-8')
    ).hexdigest()[:16]
    
    # 组合: base64(alias:filename) + . + signature
    encoded = base64.urlsafe_b64encode(data_bytes).decode('utf-8')
    return f"{encoded}.{signature}"


def encode_video_path(file_path: str) -> str:
    """将文件路径编码为安全的token（向后兼容，已废弃）
    
    推荐使用 encode_video_token(dir_alias, filename)
    """
    try:
        # 尝试将路径转换为别名+文件名
        path_obj = Path(file_path)
        filename = path_obj.name
        dir_alias = settings.get_alias_by_path(str(path_obj.parent))
        return encode_video_token(dir_alias, filename)
    except Exception as e:
        logger.warning(f"Failed to convert path to alias, using legacy method: {e}")
        # 降级到旧方法
        path_bytes = file_path.encode('utf-8')
        signature = hashlib.sha256(
            (file_path + settings.jwt_secret).encode('utf-8')
        ).hexdigest()[:16]
        encoded = base64.urlsafe_b64encode(path_bytes).decode('utf-8')
        return f"{encoded}.{signature}"


def decode_video_token(token: str) -> tuple:
    """解码视频token为目录别名和文件名
    
    Args:
        token: 编码的token字符串
        
    Returns:
        (dir_alias, filename) 元组
        
    Raises:
        ValueError: token无效或签名验证失败
    """
    try:
        # 分离编码数据和签名
        parts = token.rsplit('.', 1)
        if len(parts) != 2:
            raise ValueError("Invalid token format")
        
        encoded, signature = parts
        
        # 解码数据
        data_bytes = base64.urlsafe_b64decode(encoded)
        data = data_bytes.decode('utf-8')
        
        # 验证签名
        expected_signature = hashlib.sha256(
            (data + settings.jwt_secret).encode('utf-8')
        ).hexdigest()[:16]
        
        if signature != expected_signature:
            raise ValueError("Invalid signature")
        
        # 解析 alias:filename
        if ':' not in data:
            raise ValueError("Invalid token data format")
        
        dir_alias, filename = data.split(':', 1)
        return dir_alias, filename
        
    except Exception as e:
        logger.error(f"Failed to decode video token: {e}")
        raise ValueError("Invalid video token")


def decode_video_path(token: str) -> str:
    """解码视频token为文件路径（向后兼容，已废弃）
    
    推荐使用 decode_video_token(token) 返回 (alias, filename)
    """
    try:
        # 尝试新格式
        dir_alias, filename = decode_video_token(token)
        dir_path = settings.get_path_by_alias(dir_alias)
        return str(Path(dir_path) / filename)
    except:
        # 降级到旧格式
        parts = token.rsplit('.', 1)
        if len(parts) != 2:
            raise ValueError("Invalid token format")
        
        encoded, signature = parts
        path_bytes = base64.urlsafe_b64decode(encoded)
        file_path = path_bytes.decode('utf-8')
        
        expected_signature = hashlib.sha256(
            (file_path + settings.jwt_secret).encode('utf-8')
        ).hexdigest()[:16]
        
        if signature != expected_signature:
            raise ValueError("Invalid signature")
        
        return file_path


def validate_video_token(dir_alias: str, filename: str) -> Path:
    """验证视频token的安全性（使用别名+文件名）
    
    Args:
        dir_alias: 目录别名
        filename: 文件名
        
    Returns:
        验证后的完整路径Path对象
        
    Raises:
        HTTPException: 验证失败
    """
    try:
        # 1. 验证别名有效性
        try:
            dir_path = settings.get_path_by_alias(dir_alias)
        except ValueError:
            raise HTTPException(status_code=403, detail="Invalid directory alias")
        
        # 2. 构造完整路径
        file_path = Path(dir_path) / filename
        path = file_path.resolve()
        
        # 3. 验证文件存在
        if not path.exists():
            raise HTTPException(status_code=404, detail="Video file not found")
        
        if not path.is_file():
            raise HTTPException(status_code=400, detail="Not a valid file")
        
        # 4. 只允许mp4文件
        if path.suffix.lower() != '.mp4':
            raise HTTPException(
                status_code=403, 
                detail="Only MP4 files are allowed"
            )
        
        # 5. 验证文件必须在指定目录内（防止路径穿越）
        dir_path_resolved = Path(dir_path).resolve()
        if not str(path).startswith(str(dir_path_resolved)):
            logger.warning(f"Path traversal attempt: {path} not in {dir_path_resolved}")
            raise HTTPException(status_code=403, detail="Invalid file path")
        
        # 6. 防止文件名包含路径穿越字符
        if '..' in filename or '/' in filename or '\\' in filename:
            logger.warning(f"Invalid filename: {filename}")
            raise HTTPException(status_code=403, detail="Invalid filename")
        
        return path
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Video token validation error: {e}")
        raise HTTPException(status_code=500, detail="Validation failed")


def validate_video_path(file_path: str) -> Path:
    """验证视频路径的安全性
    
    Args:
        file_path: 文件路径
        
    Returns:
        验证后的Path对象
        
    Raises:
        HTTPException: 路径验证失败
    """
    try:
        # 转换为Path对象并解析为绝对路径
        path = Path(file_path).resolve()
        
        # 1. 检查文件是否存在
        if not path.exists():
            raise HTTPException(status_code=404, detail="Video file not found")
        
        if not path.is_file():
            raise HTTPException(status_code=400, detail="Not a valid file")
        
        # 2. 检查文件扩展名
        if path.suffix.lower() not in ALLOWED_VIDEO_EXTENSIONS:
            raise HTTPException(
                status_code=403, 
                detail=f"File type not allowed. Only video files are permitted."
            )
        
        # 3. 验证路径必须在配置的视频目录内
        video_dirs = [Path(d).resolve() for d in settings.get_video_dirs()]
        is_in_allowed_dir = any(
            str(path).startswith(str(video_dir)) 
            for video_dir in video_dirs
        )
        
        if not is_in_allowed_dir:
            logger.warning(f"Attempted to access file outside allowed directories: {path}")
            raise HTTPException(
                status_code=403, 
                detail="Access denied: file is outside allowed directories"
            )
        
        # 4. 防止路径穿越（额外检查）
        if '..' in file_path or file_path.startswith('/etc') or file_path.startswith('C:\\Windows'):
            logger.warning(f"Potential path traversal attempt: {file_path}")
            raise HTTPException(status_code=403, detail="Invalid path")
        
        return path
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Path validation error: {e}")
        raise HTTPException(status_code=500, detail="Path validation failed")
