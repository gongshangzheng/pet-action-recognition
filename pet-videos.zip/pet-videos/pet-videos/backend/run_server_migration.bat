@echo off
chcp 65001 >nul
REM 服务器数据库迁移执行脚本（Windows 版本）
REM 用途：按正确顺序执行所有迁移脚本
REM 适用于：Windows Server 2016+

setlocal enabledelayedexpansion

echo ======================================================================
echo 🚀 服务器数据库迁移执行脚本
echo ======================================================================
echo.

REM 数据库路径（可通过环境变量指定）
if "%DATABASE_PATH%"=="" (
    set "DB_PATH=database\server_history.db"
) else (
    set "DB_PATH=%DATABASE_PATH%"
)

echo 📂 数据库路径: %DB_PATH%
echo.

REM 检查数据库文件是否存在
if not exist "%DB_PATH%" (
    echo ❌ 数据库文件不存在: %DB_PATH%
    echo 请先将服务器数据库下载到该位置
    exit /b 1
)

REM 备份数据库
set "TIMESTAMP=%date:~0,4%%date:~5,2%%date:~8,2%_%time:~0,2%%time:~3,2%%time:~6,2%"
set "TIMESTAMP=%TIMESTAMP: =0%"
set "BACKUP_PATH=%DB_PATH%.backup.%TIMESTAMP%"

echo 📝 步骤 1: 备份数据库
echo ----------------------------------------------------------------------
copy "%DB_PATH%" "%BACKUP_PATH%" >nul
if errorlevel 1 (
    echo ❌ 备份失败
    exit /b 1
)
echo ✅ 备份完成: %BACKUP_PATH%
echo.

REM 迁移脚本列表（按顺序执行）
set "MIGRATIONS[0]=migrate_add_did_to_stream_sources.py:添加 did 字段到 stream_sources"
set "MIGRATIONS[1]=migrate_unify_video_records.py:统一视频记录表"
set "MIGRATIONS[2]=migrate_add_pets_table.py:创建 pets 表"
set "MIGRATIONS[3]=migrate_add_weight_to_pets.py:添加 weight 字段到 pets"
set "MIGRATIONS[4]=migrate_add_avatar_color_to_pets.py:添加 avatar_color 字段到 pets"
set "MIGRATIONS[5]=migrate_add_video_pet_analysis_table.py:创建 video_pet_analysis 表"
set "MIGRATIONS[6]=migrate_rename_video_pet_analysis_to_pet_behaviors.py:重命名为 pet_behaviors 表"
set "MIGRATIONS[7]=migrate_add_daily_reports_table.py:创建 daily_reports 表"

echo 📝 步骤 2: 执行迁移脚本
echo ----------------------------------------------------------------------
echo.

set SUCCESS_COUNT=0
set FAIL_COUNT=0

REM 执行迁移脚本
for /L %%i in (0,1,7) do (
    set "MIGRATION=!MIGRATIONS[%%i]!"
    
    REM 分割脚本名和描述
    for /f "tokens=1,2 delims=:" %%a in ("!MIGRATION!") do (
        set "SCRIPT=%%a"
        set "DESC=%%b"
        set "SCRIPT_PATH=migrations\%%a"
        
        if not exist "!SCRIPT_PATH!" (
            echo   ⚠️  脚本不存在: %%a
            set /a FAIL_COUNT+=1
        ) else (
            echo   🔄 执行: %%b
            echo      脚本: %%a
            
            REM 设置环境变量并执行 Python 脚本
            set "DATABASE_PATH=%DB_PATH%"
            python "!SCRIPT_PATH!"
            
            if errorlevel 1 (
                echo   ❌ 失败
                set /a FAIL_COUNT+=1
                echo.
                echo 迁移失败！可以回滚到备份：
                echo   copy "%BACKUP_PATH%" "%DB_PATH%"
                exit /b 1
            ) else (
                echo   ✅ 成功
                set /a SUCCESS_COUNT+=1
            )
            echo.
        )
    )
)

echo ======================================================================
echo 📊 迁移执行总结
echo ======================================================================
echo.

set /a TOTAL_COUNT=%SUCCESS_COUNT%+%FAIL_COUNT%
echo 执行的迁移脚本: %TOTAL_COUNT%
echo 成功: %SUCCESS_COUNT%
echo 失败: %FAIL_COUNT%
echo.

if %FAIL_COUNT% equ 0 (
    echo ✅ 所有迁移脚本执行成功！
    echo.
    echo 📝 后续操作:
    echo   1. 验证数据库结构和数据完整性
    echo   2. 将迁移后的数据库上传回服务器
    echo   3. 重启服务器上的应用服务
    echo.
    echo 备份文件: %BACKUP_PATH%
    exit /b 0
) else (
    echo ❌ 部分迁移失败
    echo.
    echo 备份文件: %BACKUP_PATH%
    exit /b 1
)
