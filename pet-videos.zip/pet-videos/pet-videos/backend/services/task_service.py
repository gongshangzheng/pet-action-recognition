import subprocess
import os
import signal
import logging
import threading
import time
import sys
from datetime import datetime, timedelta
from pathlib import Path
from sqlalchemy.orm import Session

from models.db import SessionLocal
from models.database import SlicingTask, StreamSource
from config import settings

logger = logging.getLogger(__name__)

# 确保日志目录存在
TASK_LOG_DIR = settings.BASE_DIR / "logs" / "tasks"
TASK_LOG_DIR.mkdir(parents=True, exist_ok=True)

def kill_process(pid: int, force: bool = False):
    """跨平台的进程终止函数
    
    Args:
        pid: 进程ID
        force: 是否强制终止（Windows上会被忽略，统一使用terminate）
    """
    if sys.platform == "win32":
        # Windows: 使用 taskkill
        import subprocess
        try:
            if force:
                subprocess.run(['taskkill', '/F', '/PID', str(pid)], 
                             capture_output=True, timeout=5)
            else:
                subprocess.run(['taskkill', '/PID', str(pid)], 
                             capture_output=True, timeout=5)
        except Exception:
            pass
    else:
        # Linux/macOS: 使用 signal
        try:
            if force:
                os.kill(pid, signal.SIGKILL)
            else:
                os.kill(pid, signal.SIGTERM)
        except OSError:
            pass

def is_process_running(pid: int) -> bool:
    """检查进程是否还在运行（跨平台）"""
    if sys.platform == "win32":
        # Windows: 使用 tasklist
        import subprocess
        try:
            result = subprocess.run(['tasklist', '/FI', f'PID eq {pid}'], 
                                  capture_output=True, text=True, timeout=5)
            # 更精确的检查：确保 PID 作为独立数字出现，且不是 "No tasks" 信息
            if "No tasks" in result.stdout or "INFO:" in result.stdout:
                return False
            # 检查 PID 是否在输出中（作为独立的列）
            for line in result.stdout.split('\n'):
                # tasklist 输出格式：进程名 空格 PID 空格 ...
                parts = line.split()
                if len(parts) >= 2 and parts[1] == str(pid):
                    return True
            return False
        except Exception:
            return False
    else:
        # Linux/macOS: 使用 os.kill(pid, 0)
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False

class TaskService:
    """切片任务管理服务"""
    
    _instance = None
    _monitor_thread = None
    _stop_monitor = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(TaskService, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, 'initialized'):
            self.initialized = True
            self.start_monitor()

    def start_monitor(self):
        """启动后台监控线程"""
        if self._monitor_thread and self._monitor_thread.is_alive():
            return
            
        self._stop_monitor = False
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()
        logger.info("Task monitor thread started")

    def stop_monitor(self):
        """停止后台监控线程"""
        self._stop_monitor = True
        if self._monitor_thread:
            self._monitor_thread.join(timeout=5)

    def _monitor_loop(self):
        """监控循环：检查心跳并自动拉起"""
        while not self._stop_monitor:
            db = SessionLocal()
            try:
                # 查找所有标记为 running 的任务
                tasks = db.query(SlicingTask).filter(SlicingTask.status == 'running').all()
                for task in tasks:
                    # 如果任务已稳定运行，清零失败计数
                    if self._is_task_stable(task) and task.consecutive_failures > 0:
                        logger.info(f"Task {task.source_id} is stable, resetting failure count")
                        task.consecutive_failures = 0
                        db.commit()
                    
                    # 检查是否需要重启
                    if self._should_restart(task):
                        # 如果连续失败次数已达阈值，不再重启
                        if task.consecutive_failures >= 3:
                            if task.status != 'error':
                                task.status = 'error'
                                task.error_msg = task.error_msg or "进程连续失败3次，已停止自动重启"
                                task.pid = None
                                db.commit()
                                logger.error(
                                    f"Task {task.source_id} already failed {task.consecutive_failures} times, "
                                    f"not restarting. Error: {task.error_msg[:200] if task.error_msg else 'Unknown'}"
                                )
                            continue
                        
                        # 读取日志文件获取错误信息
                        error_msg = self._read_last_error(task.source_id)
                        
                        # 增加失败计数
                        task.consecutive_failures += 1
                        
                        logger.warning(
                            f"Task for source {task.source_id} seems dead "
                            f"(failure #{task.consecutive_failures}/3)"
                        )
                        
                        # 如果这次是第 3 次失败，标记为错误状态，不重启
                        if task.consecutive_failures >= 3:
                            task.status = 'error'
                            task.error_msg = error_msg or "进程连续失败3次，已停止自动重启"
                            task.pid = None
                            db.commit()
                            logger.error(
                                f"Task {task.source_id} failed 3 times, giving up. Error: {task.error_msg[:200]}"
                            )
                        else:
                            # 还没到阈值，尝试重启
                            db.commit()  # 先提交失败计数
                            self.start_task(task.source_id, db)
            except Exception as e:
                logger.error(f"Error in monitor loop: {e}")
            finally:
                db.close()
            
            time.sleep(30)  # 每 30 秒检查一次

    def _should_restart(self, task: SlicingTask) -> bool:
        """判断任务是否需要重启"""
        now = datetime.now()
        
        # 调试日志
        logger.debug(
            f"Checking task {task.source_id}: "
            f"status={task.status}, pid={task.pid}, "
            f"last_start={task.last_start_time}, "
            f"last_heartbeat={task.last_heartbeat}"
        )
        
        if not task.last_heartbeat:
            # 如果刚启动不久还没心跳，给 1 分钟宽限期
            if task.last_start_time and now - task.last_start_time < timedelta(minutes=1):
                logger.debug(f"Task {task.source_id}: Waiting for first heartbeat (grace period)")
                return False
            logger.warning(f"Task {task.source_id}: No heartbeat received")
            return True
            
        # 如果心跳超过 2 分钟未更新，认为进程挂了（临时延长，方便调试）
        heartbeat_age = now - task.last_heartbeat
        if heartbeat_age > timedelta(minutes=2):
            logger.warning(f"Task {task.source_id}: Heartbeat timeout ({heartbeat_age.total_seconds()}s)")
            return True
            
        # 检查 PID 是否还在
        if task.pid:
            if not is_process_running(task.pid):
                logger.warning(f"Task {task.source_id}: Process {task.pid} not running")
                return True
            logger.debug(f"Task {task.source_id}: Process {task.pid} is running, heartbeat age: {heartbeat_age.total_seconds()}s")
                
        return False
    
    def _read_last_error(self, source_id: int, lines: int = 30) -> str:
        """读取任务日志文件的最后几行，提取错误信息"""
        log_path = TASK_LOG_DIR / f"task_{source_id}.log"
        if not log_path.exists():
            return ""
        
        try:
            with open(log_path, 'r', encoding='utf-8') as f:
                content = f.readlines()
                if not content:
                    return ""
                
                # 取最后 N 行
                last_lines = content[-lines:]
                error_text = ''.join(last_lines)
                
                # 如果有明显的异常信息，只返回关键部分
                if 'Traceback' in error_text or 'Error' in error_text:
                    # 找到最后一个 Traceback 或 Error 的位置
                    lines_list = error_text.split('\n')
                    error_start = -1
                    for i in range(len(lines_list) - 1, -1, -1):
                        if 'Traceback' in lines_list[i]:
                            error_start = i
                            break
                    
                    if error_start >= 0:
                        return '\n'.join(lines_list[error_start:])
                
                return error_text.strip()
        except Exception as e:
            logger.error(f"Failed to read log file {log_path}: {e}")
            return ""
    
    def _is_task_stable(self, task: SlicingTask) -> bool:
        """判断任务是否已稳定运行（超过2分钟且有心跳）"""
        if not task.last_start_time or not task.last_heartbeat:
            return False
        
        # 启动超过 2 分钟，且心跳正常
        running_time = datetime.now() - task.last_start_time
        if running_time > timedelta(minutes=2):
            heartbeat_age = datetime.now() - task.last_heartbeat
            if heartbeat_age < timedelta(minutes=2):
                return True
        
        return False

    def start_task(self, source_id: int, db: Session) -> bool:
        """启动切片任务"""
        source = db.query(StreamSource).filter(StreamSource.id == source_id).first()
        if not source:
            logger.error(f"Source {source_id} not found")
            return False
            
        task = db.query(SlicingTask).filter(SlicingTask.source_id == source_id).first()
        if not task:
            logger.error(f"Task for source {source_id} not found, cannot start")
            return False

        # 如果已有运行中的进程，先尝试杀掉
        if task.pid:
            kill_process(task.pid, force=False)
            time.sleep(0.5)

        # 准备启动脚本（使用任务配置的脚本文件）
        script_file = task.script_file if task.script_file else "pet_monitor.py"
        script_path = str(settings.BASE_DIR / "scripts" / script_file)
        
        # 验证脚本文件是否存在
        if not os.path.exists(script_path):
            logger.error(f"Script file not found: {script_path}")
            task.status = 'error'
            task.error_msg = f"脚本文件不存在: {script_file}"
            db.commit()
            return False
        
        # 根据操作系统选择正确的 Python 可执行文件路径
        if sys.platform == "win32":
            venv_python = str(settings.BASE_DIR / "backend" / "venv" / "Scripts" / "python.exe")
        else:
            venv_python = str(settings.BASE_DIR / "backend" / "venv" / "bin" / "python")
        
        model_path = str(settings.BASE_DIR / "scripts" / "yolov13n.pt")
        
        # 如果 scripts 下没找到模型，就用模型名让 YOLO 自己去下载/查找
        if not os.path.exists(model_path):
            model_path = "yolov13n.pt"
            
        # 命令行参数（使用配置的端口）
        api_base_url = f"http://127.0.0.1:{settings.backend_port}/api"
        cmd = [
            venv_python,
            "-u",  # 无缓冲模式，确保日志立即输出
            script_path,
            "--url", source.stream_url,
            "--path", source.storage_path,
            "--source_id", str(source_id),
            "--api-url", api_base_url,
            "--model", model_path,
            "--enable-yolo", "true" if task.enable_yolo else "false"
        ]
        
        # 打开日志文件，重定向输出
        log_path = TASK_LOG_DIR / f"task_{source_id}.log"
        log_file = None
        try:
            # 使用行缓冲（跨平台兼容）
            log_file = open(log_path, 'w', buffering=1, encoding='utf-8')
        except Exception as e:
            logger.error(f"Failed to open log file {log_path}: {e}")
        
        try:
            # Windows 需要特殊的进程组创建方式
            extra_kwargs = {}
            if sys.platform == "win32":
                # Windows: 使用 CREATE_NEW_PROCESS_GROUP
                extra_kwargs['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
                # 设置环境变量，确保 Python 无缓冲输出
                env = os.environ.copy()
                env['PYTHONUNBUFFERED'] = '1'
                extra_kwargs['env'] = env
            else:
                # Linux/macOS: 使用 start_new_session
                extra_kwargs['start_new_session'] = True
            
            # 启动异步进程，将输出重定向到日志文件
            process = subprocess.Popen(
                cmd,
                stdout=log_file if log_file else subprocess.DEVNULL,
                stderr=subprocess.STDOUT,  # 错误输出合并到标准输出
                **extra_kwargs
            )
            
            task.pid = process.pid
            task.status = 'running'
            task.last_start_time = datetime.now()
            task.last_heartbeat = None
            task.error_msg = None
            # 不清零 consecutive_failures，由监控线程在稳定运行后清零
            db.commit()
            
            logger.info(f"Started slicing task for source {source.alias} (PID: {process.pid})")
            
            # 注意：log_file 不关闭，让子进程继续使用
            # 父进程失去引用后，GC 会处理，但文件描述符会被子进程继承
            
            return True
        except Exception as e:
            logger.error(f"Failed to start task: {e}")
            task.status = 'error'
            task.error_msg = str(e)
            task.consecutive_failures += 1
            db.commit()
            
            # 关闭日志文件
            if log_file:
                try:
                    log_file.close()
                except:
                    pass
            return False

    def stop_task(self, source_id: int, db: Session) -> bool:
        """停止切片任务"""
        task = db.query(SlicingTask).filter(SlicingTask.source_id == source_id).first()
        if not task:
            return True
            
        if task.pid:
            # 保存 PID，因为后面会清空
            pid_to_kill = task.pid
            
            # 杀死进程组（包括所有子进程）
            if sys.platform == "win32":
                # Windows: 使用 taskkill /T 杀死进程树
                try:
                    subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid_to_kill)], 
                                 capture_output=True, timeout=5)
                    logger.info(f"Killed process tree for task {source_id} (PID: {pid_to_kill})")
                except Exception as e:
                    logger.error(f"Failed to kill process tree: {e}")
            else:
                # Linux/macOS: 杀死整个进程组
                try:
                    # 负数 PID 表示杀死整个进程组
                    os.killpg(os.getpgid(pid_to_kill), signal.SIGTERM)
                    logger.info(f"Sent SIGTERM to process group of task {source_id} (PGID: {pid_to_kill})")
                    
                    # 启动一个后台线程来强制杀死进程组（如果需要）
                    def force_kill():
                        time.sleep(3)  # 等待 3 秒
                        try:
                            # 检查进程是否还在
                            if is_process_running(pid_to_kill):
                                os.killpg(os.getpgid(pid_to_kill), signal.SIGKILL)
                                logger.info(f"Force killed process group of task {source_id}")
                        except (OSError, ProcessLookupError):
                            # 进程已经不存在了，正常情况
                            pass
                    
                    threading.Thread(target=force_kill, daemon=True).start()
                except (OSError, ProcessLookupError) as e:
                    # 进程可能已经不存在，尝试直接杀主进程
                    logger.warning(f"Failed to kill process group, trying to kill main process: {e}")
                    kill_process(pid_to_kill, force=True)
                
        task.status = 'stopped'
        task.pid = None
        db.commit()
        logger.info(f"Stopped slicing task for source {source_id}")
        return True
