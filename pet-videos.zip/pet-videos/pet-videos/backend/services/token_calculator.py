"""官方 Token 计算器（基于阿里云文档）"""
import math
import logging
import cv2
from typing import Dict, Tuple

logger = logging.getLogger(__name__)

# Qwen3-VL-Plus 模型常量
FRAME_FACTOR = 2
IMAGE_FACTOR = 32  # Qwen3-VL 图像缩放因子
MAX_RATIO = 200  # 视频帧的最大长宽比
VIDEO_MIN_PIXELS = 4 * 32 * 32  # 视频帧的像素下限
VIDEO_MAX_PIXELS = 640 * 32 * 32  # Qwen3-VL-Plus 像素上限
FPS_DEFAULT = 2.0  # 默认 fps
FPS_MIN_FRAMES = 4  # 最少抽取帧数
FPS_MAX_FRAMES = 2000  # Qwen3-VL-Plus 最大抽取帧数
VIDEO_TOTAL_PIXELS = 131072 * 32 * 32  # Qwen3-VL-Plus 总像素上限


def round_by_factor(number: int, factor: int) -> int:
    """返回与 number 最接近的整数，该整数可被 factor 整除"""
    return round(number / factor) * factor


def ceil_by_factor(number: int, factor: int) -> int:
    """返回大于或等于 number 且可被 factor 整除的最小整数"""
    return math.ceil(number / factor) * factor


def floor_by_factor(number: int, factor: int) -> int:
    """返回小于或等于 number 且可被 factor 整除的最大整数"""
    return math.floor(number / factor) * factor


def get_video_info(video_path: str) -> Tuple[int, int, int, float]:
    """获取视频基本信息
    
    Returns:
        (height, width, total_frames, fps)
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"无法打开视频文件: {video_path}")
    
    try:
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        video_fps = cap.get(cv2.CAP_PROP_FPS)
        
        return height, width, total_frames, video_fps
    finally:
        cap.release()


def smart_nframes(
    fps: float,
    total_frames: int,
    video_fps: float,
    min_frames: int = FPS_MIN_FRAMES,
    max_frames: int = FPS_MAX_FRAMES
) -> int:
    """计算抽取的视频帧数（官方算法）"""
    
    min_frames = ceil_by_factor(min_frames, FRAME_FACTOR)
    max_frames = floor_by_factor(min(max_frames, total_frames), FRAME_FACTOR)
    
    duration = total_frames / video_fps if video_fps != 0 else 0
    
    # 根据 duration 调整 total_frames
    if duration - int(duration) > (1 / fps):
        total_frames = math.ceil(duration * video_fps)
    else:
        total_frames = math.ceil(int(duration) * video_fps)
    
    nframes = total_frames / video_fps * fps
    
    if nframes > total_frames:
        logger.warning(f"smart_nframes: nframes[{nframes}] > total_frames[{total_frames}]")
    
    nframes = int(min(min(max(nframes, min_frames), max_frames), total_frames))
    
    if not (FRAME_FACTOR <= nframes <= total_frames):
        raise ValueError(
            f"nframes should in interval [{FRAME_FACTOR}, {total_frames}], but got {nframes}."
        )
    
    return nframes


def smart_resize(
    height: int,
    width: int,
    nframes: int,
    min_pixels: int = VIDEO_MIN_PIXELS,
    max_pixels: int = VIDEO_MAX_PIXELS,
    factor: int = IMAGE_FACTOR,
    total_pixels: int = None
) -> Tuple[int, int]:
    """智能调整视频帧尺寸（官方算法）
    
    Args:
        total_pixels: 总像素预算，如果为None则使用默认的VIDEO_TOTAL_PIXELS
                     高分辨率模式下可以传入更大的值或None（不限制）
    """
    
    # 计算每帧的最大像素
    if total_pixels is None:
        total_pixels = VIDEO_TOTAL_PIXELS
    
    # 如果total_pixels非常大（高分辨率模式），则不应用总像素限制
    # 直接使用用户设置的max_pixels
    if total_pixels > VIDEO_TOTAL_PIXELS * 10:  # 远大于普通限制，视为高分辨率模式
        max_pixels_per_frame = max(max_pixels, int(min_pixels * 1.05))
    else:
        max_pixels_per_frame = max(
            min(max_pixels, total_pixels / nframes * FRAME_FACTOR),
            int(min_pixels * 1.05)
        )
    
    # 检查长宽比
    if max(height, width) / min(height, width) > MAX_RATIO:
        raise ValueError(
            f"视频长宽比必须小于 {MAX_RATIO}, 当前为 {max(height, width) / min(height, width)}"
        )
    
    # 初始调整
    h_bar = max(factor, round_by_factor(height, factor))
    w_bar = max(factor, round_by_factor(width, factor))
    
    # 如果超过最大像素，缩小
    if h_bar * w_bar > max_pixels_per_frame:
        beta = math.sqrt((height * width) / max_pixels_per_frame)
        h_bar = floor_by_factor(height / beta, factor)
        w_bar = floor_by_factor(width / beta, factor)
    # 如果小于最小像素，放大
    elif h_bar * w_bar < min_pixels:
        beta = math.sqrt(min_pixels / (height * width))
        h_bar = ceil_by_factor(height * beta, factor)
        w_bar = ceil_by_factor(width * beta, factor)
    
    return h_bar, w_bar


def calculate_video_tokens(
    video_path: str,
    fps: float,
    min_pixels: int = VIDEO_MIN_PIXELS,
    max_pixels: int = VIDEO_MAX_PIXELS,
    video_info: Dict = None,
    total_pixels: int = None
) -> Dict:
    """计算视频 token 数量（官方算法）
    
    Args:
        video_path: 视频文件路径
        fps: 抽帧频率
        min_pixels: 最小像素数
        max_pixels: 最大像素数
        video_info: 可选的视频信息字典（来自ffprobe），如果提供则使用它，保证与真实调用一致
        total_pixels: 总像素预算，高分辨率模式下传入更大值或None以取消限制
    
    Returns:
        包含 token 计算详情的字典
    """
    
    # 1. 获取视频信息（优先使用传入的video_info以保持与真实调用的一致性）
    if video_info:
        width = video_info.get('width')
        height = video_info.get('height')
        video_fps = video_info.get('fps')
        # 计算总帧数：时长 * 帧率
        duration_sec = video_info.get('duration_sec', 0)
        total_frames = int(duration_sec * video_fps) if duration_sec > 0 else 0
    else:
        height, width, total_frames, video_fps = get_video_info(video_path)
    
    # 2. 计算抽取帧数
    nframes = smart_nframes(fps, total_frames, video_fps)
    
    # 3. 计算调整后的尺寸
    resized_height, resized_width = smart_resize(
        height, width, nframes, min_pixels, max_pixels, IMAGE_FACTOR, total_pixels
    )
    
    # 4. 计算 token 数量（官方公式）
    video_token = int(math.ceil(nframes / 2) * resized_height / 32 * resized_width / 32)
    video_token += 2  # 系统自动添加 <|vision_bos|> 和 <|vision_eos|> 标记
    
    return {
        'original_resolution': f"{height}x{width}",
        'resized_resolution': f"{resized_height}x{resized_width}",
        'total_frames': total_frames,
        'video_fps': video_fps,
        'extracted_frames': nframes,
        'video_tokens': video_token,
        'tokens_per_frame': round(video_token / nframes, 2) if nframes > 0 else 0
    }

