"""DashScope API 调用服务"""
import time
import urllib.parse
import os
from typing import Dict
from dashscope import MultiModalConversation, Generation
from config import settings, MODEL_NAME


class DashScopeService:
    """DashScope API 调用服务"""
    
    def __init__(self):
        self.api_key = settings.dashscope_api_key
        if not self.api_key or self.api_key == "your-api-key-here":
            raise ValueError("DASHSCOPE_API_KEY not configured properly")
        self.model = MODEL_NAME
    
    def analyze_video(
        self,
        video_path: str,
        prompt: str,
        fps: float,
        max_pixels: int,
        min_pixels: int,
        vl_high_resolution_images: bool = False,
        model_name: str = None
    ) -> Dict:
        """调用 Qwen3-VL-Plus 分析视频
        
        Args:
            video_path: 视频文件路径
            prompt: 提示词
            fps: 抽帧频率
            max_pixels: 最大像素数
            min_pixels: 最小像素数
            vl_high_resolution_images: 是否使用高分辨率模式
            model_name: 模型名称（可选，默认使用配置的模型）
        
        Returns:
            调用结果字典
        """
        
        start_time = time.time()
        
        # 使用指定的模型或默认模型
        model_to_use = model_name if model_name else self.model
        
        try:
            # 这里的格式必须和成功的 pet 项目完全一致
            # 成功的 pet 项目使用的是 file://{video_path}，且没有进行 urllib 编码
            video_url = f"file://{video_path}"

            # 打印关键调试信息
            print(f"\n[DEBUG] DASH_SCOPE CALL (PET-VIDEOS):")
            print(f"  - Model: {model_to_use}")
            print(f"  - Video URL: {video_url}")
            print(f"  - API Key: {self.api_key[:4]}...")

            # 构建消息
            messages = [{
                'role': 'user',
                'content': [
                    {
                        'video': video_url,
                        'fps': fps,
                        'max_pixels': max_pixels,
                        'min_pixels': min_pixels
                    },
                    {'text': prompt}
                ]
            }]
            
            # 调用 API
            # 注意：vl_high_resolution_images 通过 kwargs 传递
            response = MultiModalConversation.call(
                api_key=self.api_key,
                model=model_to_use,
                messages=messages,
                vl_high_resolution_images=vl_high_resolution_images
            )
            
            duration = time.time() - start_time
            
            # 检查响应状态
            if response.status_code != 200:
                return {
                    'success': False,
                    'error': f"API returned status {response.status_code}: {response.message}",
                    'duration_sec': duration
                }
            
            # 提取响应数据
            usage = response.usage
            content = response.output.choices[0].message.content[0]['text']
            
            return {
                'success': True,
                'model_response': content,
                'input_tokens': usage.input_tokens,
                'output_tokens': usage.output_tokens,
                'total_tokens': usage.total_tokens,
                'duration_sec': round(duration, 1)
            }
            
        except Exception as e:
            duration = time.time() - start_time
            return {
                'success': False,
                'error': str(e),
                'duration_sec': duration
            }
    
    def generate_text(
        self,
        prompt: str,
        model_name: str = 'qwen-plus'
    ) -> Dict:
        """调用文本生成模型
        
        Args:
            prompt: 提示词
            model_name: 模型名称（如 qwen-plus, qwen-max 等）
        
        Returns:
            生成结果字典
        """
        start_time = time.time()
        
        try:
            # 构建消息
            messages = [
                {'role': 'user', 'content': prompt}
            ]
            
            # 调用文本生成 API
            response = Generation.call(
                api_key=self.api_key,
                model=model_name,
                messages=messages,
                result_format='message'
            )
            
            duration = time.time() - start_time
            
            # 检查响应状态
            if response.status_code != 200:
                return {
                    'success': False,
                    'error': f"API returned status {response.status_code}: {response.message}",
                    'duration_sec': duration
                }
            
            # 提取响应数据
            usage = response.usage
            content = response.output.choices[0].message.content
            
            return {
                'success': True,
                'content': content,
                'input_tokens': usage.input_tokens,
                'output_tokens': usage.output_tokens,
                'total_tokens': usage.total_tokens,
                'duration_sec': round(duration, 1)
            }
            
        except Exception as e:
            duration = time.time() - start_time
            return {
                'success': False,
                'error': str(e),
                'duration_sec': duration
            }
