"""
视频缩略图生成服务
"""

import subprocess
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class ThumbnailService:
    """视频缩略图生成服务"""
    
    def __init__(self):
        """初始化缩略图服务"""
        # 缩略图存储目录：backend/thumbnails/
        # 使用相对于当前文件的路径
        backend_dir = Path(__file__).parent.parent
        self.thumbnail_dir = backend_dir / "thumbnails"
        self.thumbnail_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"缩略图目录: {self.thumbnail_dir}")
    
    def generate_thumbnail(
        self, 
        video_path: str, 
        video_id: int,
        timestamp: str = None,
        width: int = 320,
        quality: int = 2
    ) -> Optional[str]:
        """
        从视频生成缩略图
        
        Args:
            video_path: 视频文件路径
            video_id: 视频记录 ID
            timestamp: 截图时间点（格式: HH:MM:SS），None表示自动选择最佳帧
            width: 缩略图宽度（高度自动按比例），默认 320px
            quality: JPEG 质量 (1-31，数字越小质量越高)，默认 2
        
        Returns:
            缩略图文件路径，失败返回 None
        """
        try:
            video_path_obj = Path(video_path)
            
            # 检查视频文件是否存在
            if not video_path_obj.exists():
                logger.error(f"视频文件不存在: {video_path}")
                return None
            
            # 生成缩略图文件名: {video_id}.jpg
            thumbnail_filename = f"{video_id}.jpg"
            thumbnail_path = self.thumbnail_dir / thumbnail_filename
            
            # 如果缩略图已存在，直接返回
            if thumbnail_path.exists():
                logger.debug(f"缩略图已存在: {thumbnail_path}")
                return str(thumbnail_path)
            
            # 使用 ffmpeg 生成缩略图
            if timestamp:
                # 手动指定时间点
                # -ss: 从视频的指定时间点开始
                # -i: 输入文件
                # -vframes 1: 只提取1帧
                # -vf scale: 缩放（宽度=320，高度按比例）
                # -q:v: JPEG质量（1-31，数字越小质量越高）
                cmd = [
                    'ffmpeg',
                    '-ss', timestamp,
                    '-i', str(video_path),
                    '-vframes', '1',
                    '-vf', f'scale={width}:-1',
                    '-q:v', str(quality),
                    '-y',
                    str(thumbnail_path)
                ]
                logger.info(f"生成缩略图: video_id={video_id}, timestamp={timestamp}")
            else:
                # 自动选择最佳帧（智能模式）
                # thumbnail 过滤器会自动分析视频，选择最有代表性的一帧
                # 参数 n=100 表示分析前100帧
                cmd = [
                    'ffmpeg',
                    '-i', str(video_path),
                    '-vf', f'thumbnail=n=100,scale={width}:-1',  # 自动选择最佳帧并缩放
                    '-frames:v', '1',  # 只输出1帧
                    '-q:v', str(quality),
                    '-y',
                    str(thumbnail_path)
                ]
                logger.info(f"生成缩略图（智能模式）: video_id={video_id}")
            
            # 执行 ffmpeg 命令
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30  # 30秒超时
            )
            
            # 检查是否成功
            if result.returncode != 0:
                logger.error(f"ffmpeg 执行失败: {result.stderr}")
                return None
            
            # 验证缩略图文件是否生成
            if not thumbnail_path.exists():
                logger.error(f"缩略图文件未生成: {thumbnail_path}")
                return None
            
            # 检查文件大小
            file_size = thumbnail_path.stat().st_size
            if file_size == 0:
                logger.error(f"缩略图文件为空: {thumbnail_path}")
                thumbnail_path.unlink()  # 删除空文件
                return None
            
            logger.info(f"✓ 缩略图生成成功: {thumbnail_path} ({file_size} bytes)")
            return str(thumbnail_path)
            
        except subprocess.TimeoutExpired:
            logger.error(f"ffmpeg 执行超时: video_id={video_id}")
            return None
        except Exception as e:
            logger.error(f"生成缩略图失败: video_id={video_id}, error={e}", exc_info=True)
            return None
    
    def delete_thumbnail(self, thumbnail_path: str) -> bool:
        """
        删除缩略图文件
        
        Args:
            thumbnail_path: 缩略图文件路径
        
        Returns:
            是否删除成功
        """
        try:
            path = Path(thumbnail_path)
            if path.exists():
                path.unlink()
                logger.info(f"✓ 缩略图已删除: {thumbnail_path}")
                return True
            else:
                logger.warning(f"缩略图文件不存在: {thumbnail_path}")
                return False
        except Exception as e:
            logger.error(f"删除缩略图失败: {thumbnail_path}, error={e}")
            return False
    
    def get_thumbnail_url(self, video_id: int) -> Optional[str]:
        """
        获取缩略图访问URL
        
        Args:
            video_id: 视频记录 ID
        
        Returns:
            缩略图URL，不存在返回 None
        """
        thumbnail_filename = f"{video_id}.jpg"
        thumbnail_path = self.thumbnail_dir / thumbnail_filename
        
        if not thumbnail_path.exists():
            return None
        
        # 返回相对路径（由 API 层拼接完整 URL）
        return f"/api/video/thumbnail/{video_id}"


# 全局服务实例
thumbnail_service = ThumbnailService()
