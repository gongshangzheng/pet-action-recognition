"""视频元信息缓存服务

性能优化：避免重复调用 ffprobe
- 缓存基于文件路径 + 修改时间（mtime）
- 文件修改后自动失效（mtime 变化）
- 内存缓存 + 磁盘持久化
- 无需 TTL：mtime 机制已保证缓存准确性
"""
import json
import hashlib
from pathlib import Path
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)


class VideoCache:
    """视频元信息缓存（基于 mtime 的自动失效机制）"""
    
    def __init__(self, cache_dir: Optional[Path] = None):
        """
        Args:
            cache_dir: 缓存目录（持久化），None表示仅内存缓存
        """
        self.cache_dir = cache_dir
        self._memory_cache: Dict[str, Dict] = {}
        
        # 确保缓存目录存在
        if cache_dir:
            try:
                cache_dir.mkdir(parents=True, exist_ok=True)
                logger.info(f"Video cache initialized at {cache_dir}")
            except Exception as e:
                logger.error(f"Failed to create cache directory {cache_dir}: {e}")
                self.cache_dir = None  # 降级到仅内存缓存
    
    def _get_cache_key(self, video_path: str, mtime: float) -> str:
        """生成缓存键：路径+修改时间的hash"""
        key_str = f"{video_path}:{mtime}"
        return hashlib.md5(key_str.encode()).hexdigest()
    
    def _get_cache_file(self, cache_key: str) -> Optional[Path]:
        """获取缓存文件路径"""
        if not self.cache_dir:
            return None
        return self.cache_dir / f"{cache_key}.json"
    
    def get(self, video_path: str) -> Optional[Dict]:
        """
        获取缓存的视频信息
        
        基于 mtime 的缓存机制：
        - 文件修改 → mtime 改变 → cache_key 改变 → 缓存自动失效
        
        Returns:
            视频信息字典，如果缓存未命中则返回 None
        """
        try:
            video_file = Path(video_path)
            if not video_file.exists():
                return None
            
            mtime = video_file.stat().st_mtime
            cache_key = self._get_cache_key(video_path, mtime)
            
            # 1. 先查内存缓存
            if cache_key in self._memory_cache:
                logger.debug(f"Memory cache hit: {video_path}")
                return self._memory_cache[cache_key]['info']
            
            # 2. 查文件缓存
            cache_file = self._get_cache_file(cache_key)
            if cache_file and cache_file.exists():
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cache_data = json.load(f)
                
                logger.debug(f"Disk cache hit: {video_path}")
                # 加载到内存
                self._memory_cache[cache_key] = cache_data
                return cache_data['info']
            
            return None
            
        except Exception as e:
            logger.warning(f"Cache get error for {video_path}: {e}")
            return None
    
    def set(self, video_path: str, video_info: Dict):
        """
        设置缓存
        
        Args:
            video_path: 视频文件路径
            video_info: 视频元信息字典
        """
        try:
            video_file = Path(video_path)
            if not video_file.exists():
                return
            
            mtime = video_file.stat().st_mtime
            cache_key = self._get_cache_key(video_path, mtime)
            
            cache_data = {
                'info': video_info,
                'video_path': video_path,
                'mtime': mtime
            }
            
            # 1. 清理同一视频的旧缓存（基于不同mtime的旧缓存）
            self._cleanup_old_cache(video_path, cache_key)
            
            # 2. 存入内存
            self._memory_cache[cache_key] = cache_data
            
            # 3. 持久化到文件
            cache_file = self._get_cache_file(cache_key)
            if cache_file:
                with open(cache_file, 'w', encoding='utf-8') as f:
                    json.dump(cache_data, f, ensure_ascii=False, indent=2)
                logger.debug(f"Cached: {video_path}")
            
        except Exception as e:
            logger.warning(f"Cache set error for {video_path}: {e}")
    
    def _cleanup_old_cache(self, video_path: str, current_cache_key: str):
        """清理同一视频的旧缓存文件
        
        当视频文件的mtime改变时，旧的缓存文件会成为垃圾
        这个方法会查找并删除这些旧缓存
        
        Args:
            video_path: 视频文件路径
            current_cache_key: 当前有效的缓存key
        """
        if not self.cache_dir or not self.cache_dir.exists():
            return
        
        try:
            # 遍历所有缓存文件，查找属于同一视频的旧缓存
            for cache_file in self.cache_dir.glob("*.json"):
                if cache_file.stem == current_cache_key:
                    continue  # 跳过当前缓存
                
                try:
                    with open(cache_file, 'r', encoding='utf-8') as f:
                        old_cache = json.load(f)
                    
                    # 如果是同一个视频的旧缓存，删除它
                    if old_cache.get('video_path') == video_path:
                        cache_file.unlink()
                        logger.debug(f"Cleaned old cache: {cache_file.name}")
                except:
                    pass  # 忽略损坏的缓存文件
        except Exception as e:
            logger.warning(f"Cleanup error: {e}")
    
    def clear(self):
        """清空所有缓存"""
        self._memory_cache.clear()
        
        if self.cache_dir and self.cache_dir.exists():
            for cache_file in self.cache_dir.glob("*.json"):
                cache_file.unlink()
            logger.info("Cache cleared")
    
    def get_stats(self) -> Dict:
        """获取缓存统计信息"""
        memory_count = len(self._memory_cache)
        disk_count = 0
        
        if self.cache_dir and self.cache_dir.exists():
            disk_count = len(list(self.cache_dir.glob("*.json")))
        
        return {
            'memory_cached': memory_count,
            'disk_cached': disk_count
        }
