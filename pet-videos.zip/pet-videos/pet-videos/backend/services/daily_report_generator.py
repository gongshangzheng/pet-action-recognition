"""宠物日报定时生成服务"""
import threading
import time
import logging
import json
from datetime import datetime, timedelta, time as dt_time
from typing import List, Dict, Any, Optional, Union
from sqlalchemy.orm import Session
from sqlalchemy import func, and_

from models.db import SessionLocal
from models.database import VideoRecord, PetBehavior, DailyReport, Pet
from services.dashscope_service import DashScopeService
from services.estimate_service import EstimateService
from config import settings

logger = logging.getLogger(__name__)


class DailyReportGenerator:
    """日报生成服务（定时任务）"""
    
    _instance = None
    _worker_thread = None
    _stop_worker = False
    
    # 配置参数（从配置文件读取）
    PEAK_INTERVAL_MINUTES = getattr(settings, 'daily_report_peak_interval_minutes', 90)  # 高峰时段间隔（5:00-23:00）：1.5小时
    OFF_PEAK_INTERVAL_MINUTES = getattr(settings, 'daily_report_off_peak_interval_minutes', 180)  # 低峰时段间隔（23:00-5:00）：3小时
    PEAK_START_HOUR = getattr(settings, 'daily_report_peak_start_hour', 5)  # 高峰时段开始时间
    PEAK_END_HOUR = getattr(settings, 'daily_report_peak_end_hour', 23)  # 高峰时段结束时间
    MAX_RETRIES = getattr(settings, 'daily_report_max_retries', 3)  # LLM调用最大重试次数
    RETRY_DELAY_SECONDS = getattr(settings, 'daily_report_retry_delay_seconds', 60)  # 重试延迟（秒）
    MAX_CONCURRENT_TASKS = getattr(settings, 'daily_report_max_concurrent', 2)  # 最大并发任务数
    QUEUE_CHECK_INTERVAL = getattr(settings, 'daily_report_queue_check_interval', 5)  # 队列检查间隔（秒）
    PROCESSING_TIMEOUT_MINUTES = getattr(settings, 'daily_report_processing_timeout_minutes', 15)  # processing状态超时时间（分钟）
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(DailyReportGenerator, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, 'initialized'):
            self.initialized = True
            self.dashscope_service = None
            self.estimate_service = None
            self._last_generation_time = None
            self._processing_reports = set()  # 正在处理的日报标识 (did, date, pet_name)
            self._report_queue = []  # 待生成队列

    def get_dashscope_service(self):
        """获取 DashScope 服务实例（延迟初始化）"""
        if self.dashscope_service is None:
            self.dashscope_service = DashScopeService()
        return self.dashscope_service

    def get_estimate_service(self):
        """获取预估服务实例（延迟初始化）"""
        if self.estimate_service is None:
            self.estimate_service = EstimateService()
        return self.estimate_service

    def start_worker(self):
        """启动日报生成线程"""
        if self._worker_thread and self._worker_thread.is_alive():
            logger.info("DailyReportGenerator already running")
            return
            
        self._stop_worker = False
        self._worker_thread = threading.Thread(
            target=self._worker_loop, 
            daemon=True, 
            name="DailyReportGenerator"
        )
        self._worker_thread.start()
        logger.info("DailyReportGenerator thread started")

    def stop_worker(self):
        """停止日报生成线程"""
        self._stop_worker = True
        if self._worker_thread:
            self._worker_thread.join(timeout=30)
            logger.info("DailyReportGenerator thread stopped")

    def is_running(self) -> bool:
        """检查 Worker 是否在运行"""
        return self._worker_thread and self._worker_thread.is_alive() and not self._stop_worker

    def get_status(self) -> Dict[str, Any]:
        """获取服务状态"""
        db = SessionLocal()
        try:
            # 统计今日已生成的日报数
            today = datetime.now().strftime('%Y-%m-%d')
            today_reports_count = db.query(func.count(DailyReport.pet_name)).filter(
                DailyReport.date == today
            ).scalar()
            
            # 统计总日报数
            total_reports_count = db.query(func.count(DailyReport.pet_name)).scalar()
            
            # 统计各状态的日报数
            today_stats = db.query(
                DailyReport.generation_status,
                func.count(DailyReport.pet_name)
            ).filter(
                DailyReport.date == today
            ).group_by(DailyReport.generation_status).all()
            
            status_stats = dict(today_stats)
            
            return {
                'worker_running': self.is_running(),
                'last_generation_time': self._last_generation_time.isoformat() if self._last_generation_time else None,
                'today_reports_count': today_reports_count,
                'total_reports_count': total_reports_count,
                'processing_count': len(self._processing_reports),
                'queue_size': len(self._report_queue),
                'status_stats': status_stats,
                'system_enabled': getattr(settings, 'daily_report_enabled', True),
                'config': {
                    'peak_interval_minutes': self.PEAK_INTERVAL_MINUTES,
                    'off_peak_interval_minutes': self.OFF_PEAK_INTERVAL_MINUTES,
                    'peak_hours': f'{self.PEAK_START_HOUR}:00-{self.PEAK_END_HOUR}:00',
                    'max_concurrent': self.MAX_CONCURRENT_TASKS,
                    'auto_start': getattr(settings, 'daily_report_auto_start', True)
                }
            }
        finally:
            db.close()

    def _worker_loop(self):
        """Worker 主循环"""
        logger.info("DailyReportGenerator loop started")
        
        while not self._stop_worker:
            try:
                current_time = datetime.now()
                
                # 计算下次生成时间
                next_run_time = self._calculate_next_run_time(current_time)
                
                if current_time >= next_run_time:
                    # 执行日报生成
                    self._generate_all_daily_reports()
                    self._last_generation_time = current_time
                    
                    # 重新计算下次运行时间
                    next_run_time = self._calculate_next_run_time(datetime.now())
                
                # 计算需要等待的秒数
                wait_seconds = (next_run_time - datetime.now()).total_seconds()
                if wait_seconds > 0:
                    logger.info(f"下次日报生成时间: {next_run_time.strftime('%Y-%m-%d %H:%M:%S')} (等待 {wait_seconds:.0f} 秒)")
                    
                    # 分段等待，以便能及时响应停止信号
                    while wait_seconds > 0 and not self._stop_worker:
                        sleep_time = min(60, wait_seconds)  # 每次最多睡眠60秒
                        time.sleep(sleep_time)
                        wait_seconds -= sleep_time
                
            except Exception as e:
                logger.error(f"DailyReportGenerator loop error: {e}")
                time.sleep(60)  # 发生错误后等待1分钟再继续
        
        logger.info("DailyReportGenerator loop stopped")

    def _cleanup_zombie_processing(self, db: Session):
        """清理僵尸 processing 状态（超时未完成的任务）"""
        try:
            # 查找超时的 processing 记录
            timeout_threshold = datetime.now() - timedelta(minutes=self.PROCESSING_TIMEOUT_MINUTES)
            
            zombie_reports = db.query(DailyReport).filter(
                DailyReport.generation_status == 'processing',
                DailyReport.updated_at < timeout_threshold
            ).all()
            
            if zombie_reports:
                logger.warning(f"发现 {len(zombie_reports)} 个僵尸 processing 状态")
                
                for report in zombie_reports:
                    # 重置状态为 failed，标记为超时
                    report.generation_status = 'failed'
                    report.error_message = f"任务超时（超过{self.PROCESSING_TIMEOUT_MINUTES}分钟未完成）"
                    report.retry_count += 1
                    report.updated_at = datetime.now()
                    
                    logger.info(f"清理僵尸状态: {report.did}/{report.pet_name}/{report.date}")
                
                db.commit()
                logger.info(f"已清理 {len(zombie_reports)} 个僵尸 processing 状态")
                
        except Exception as e:
            logger.error(f"清理僵尸状态失败: {e}")
            db.rollback()
    
    def _calculate_next_run_time(self, current_time: datetime) -> datetime:
        """计算下次运行时间"""
        current_hour = current_time.hour
        
        # 判断当前是否在高峰时段
        if self.PEAK_START_HOUR <= current_hour < self.PEAK_END_HOUR:
            # 高峰时段：每1.5小时
            interval_minutes = self.PEAK_INTERVAL_MINUTES
        else:
            # 低峰时段：每3小时
            interval_minutes = self.OFF_PEAK_INTERVAL_MINUTES
        
        # 如果是第一次运行，立即执行
        if self._last_generation_time is None:
            return current_time
        
        # 计算下次运行时间
        next_time = self._last_generation_time + timedelta(minutes=interval_minutes)
        
        # 如果计算出的时间已经过去，使用当前时间
        if next_time <= current_time:
            next_time = current_time
        
        return next_time

    def _generate_all_daily_reports(self):
        """生成所有宠物的日报（使用队列管理）"""
        db = SessionLocal()
        try:
            logger.info("开始扫描待生成日报...")
            
            # 清理僵尸 processing 状态
            self._cleanup_zombie_processing(db)
            
            # 获取所有有数据的宠物（直接查询 pet_behaviors）
            today = datetime.now().strftime('%Y-%m-%d')
            today_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            today_end = datetime.now().replace(hour=23, minute=59, second=59, microsecond=999999)
            
            # 查询今天有行为记录的所有did
            dids_with_data = db.query(
                VideoRecord.did
            ).join(
                PetBehavior,
                PetBehavior.video_id == VideoRecord.id
            ).filter(
                VideoRecord.recorded_at >= today_start,
                VideoRecord.recorded_at <= today_end
            ).distinct().all()
            
            if not dids_with_data:
                logger.info("今日没有行为数据，跳过日报生成")
                return
            
            logger.info(f"找到 {len(dids_with_data)} 个用户有今日数据")
            
            # 构建待生成任务列表
            from models.database import Pet
            tasks_to_add = []
            
            for (did,) in dids_with_data:
                # 检查该did是否在pets表中有配置
                configured_pets = db.query(Pet).filter(Pet.did == did).all()
                
                if configured_pets:
                    # 有配置：为每个宠物生成日报
                    logger.info(f"用户 {did} 已配置 {len(configured_pets)} 只宠物")
                    for pet in configured_pets:
                        pet_name = pet.pet_name
                        task_id = (did, today, pet_name)
                        
                        # 检查是否已在处理中
                        if task_id in self._processing_reports:
                            logger.debug(f"日报正在处理中，跳过: {did}/{pet_name}/{today}")
                            continue
                        
                        # 检查是否已在队列中
                        if task_id in self._report_queue:
                            logger.debug(f"日报已在队列中，跳过: {did}/{pet_name}/{today}")
                            continue
                        
                        # 不检查数据库状态，允许生成多条日报（前端取最新的）
                        tasks_to_add.append(task_id)
                        logger.info(f"添加日报生成任务: {did}/{pet_name}/{today}")
                else:
                    # 无配置：生成一份不区分宠物的日报
                    logger.info(f"用户 {did} 未配置宠物信息，生成不区分宠物的日报")
                    pet_name = "全部宠物"  # 统一名称
                    task_id = (did, today, pet_name)
                    
                    # 检查是否已在处理中
                    if task_id in self._processing_reports:
                        logger.debug(f"日报正在处理中，跳过: {did}/{today}")
                        continue
                    
                    # 检查是否已在队列中
                    if task_id in self._report_queue:
                        logger.debug(f"日报已在队列中，跳过: {did}/{today}")
                        continue
                    
                    # 不检查数据库状态，允许生成多条日报（前端取最新的）
                    
                    tasks_to_add.append(task_id)
                    logger.info(f"添加日报生成任务: {did}/{today}")
            
            # 添加到队列
            if tasks_to_add:
                self._report_queue.extend(tasks_to_add)
                logger.info(f"已添加 {len(tasks_to_add)} 个日报生成任务到队列")
            else:
                logger.info("没有待生成的日报任务")
            
            # 处理队列
            self._process_queue()
            
        finally:
            db.close()
    
    def _process_queue(self):
        """处理队列中的任务"""
        while self._report_queue and len(self._processing_reports) < self.MAX_CONCURRENT_TASKS:
            # 从队列头部取出任务
            task_id = self._report_queue.pop(0)
            did, date, pet_name = task_id
            
            # 标记为处理中
            self._processing_reports.add(task_id)
            
            # 异步处理
            threading.Thread(
                target=self._generate_pet_daily_report_async,
                args=(did, date, pet_name),
                daemon=True
            ).start()
            
            logger.info(f"启动日报生成任务: {did}/{pet_name}/{date} (队列剩余: {len(self._report_queue)})")
    
    def _generate_pet_daily_report_async(self, did: str, date: str, pet_name: str):
        """异步生成单只宠物的日报"""
        task_id = (did, date, pet_name)
        db = SessionLocal()
        
        try:
            self._generate_pet_daily_report(did, date, pet_name, db)
            logger.info(f"[成功] 日报生成成功: {did}/{pet_name}/{date}")
        except Exception as e:
            logger.error(f"[失败] 日报生成失败: {did}/{pet_name}/{date}, 错误: {e}")
        finally:
            # 从处理中集合移除
            self._processing_reports.discard(task_id)
            db.close()
            
            # 继续处理队列中的下一个任务
            self._process_queue()

    def _generate_pet_daily_report(self, did: str, date: str, pet_name: str, db: Session):
        """生成单只宠物的日报（或不区分宠物的日报）"""
        if pet_name and pet_name != "全部宠物":
            logger.info(f"开始生成日报: {did} / {pet_name} / {date}")
        else:
            logger.info(f"开始生成不区分宠物的日报: {did} / {date}")
        
        try:
            # 1. 查询行为记录
            # 将日期字符串转换为日期范围
            date_obj = datetime.strptime(date, '%Y-%m-%d')
            date_start = date_obj.replace(hour=0, minute=0, second=0, microsecond=0)
            date_end = date_obj.replace(hour=23, minute=59, second=59, microsecond=999999)
            
            # 构建查询条件
            query = db.query(PetBehavior).join(
                VideoRecord,
                PetBehavior.video_id == VideoRecord.id
            ).filter(
                PetBehavior.did == did,
                VideoRecord.recorded_at >= date_start,
                VideoRecord.recorded_at <= date_end
            )
            
            # 如果指定了具体宠物名称（不是"全部宠物"），按宠物过滤
            if pet_name and pet_name != "全部宠物":
                query = query.filter(PetBehavior.pet_name == pet_name)
            
            pet_behaviors = query.all()
            
            if not pet_behaviors:
                if pet_name and pet_name != "全部宠物":
                    logger.info(f"宠物 {pet_name} 在 {date} 没有行为记录")
                else:
                    logger.info(f"用户 {did} 在 {date} 没有行为记录")
                return
            
            # 2. 通过行为记录反查视频记录
            video_ids = [behavior.video_id for behavior in pet_behaviors]
            video_records = db.query(VideoRecord).filter(
                VideoRecord.id.in_(video_ids)
            ).all()
            
            if not video_records:
                logger.warning(f"宠物 {pet_name} 的行为记录找不到对应的视频记录")
                return
            
            # 3. 构建视频ID到视频记录的映射
            video_map = {record.id: record for record in video_records}
            
            # 4. 统计数据
            video_count = len(pet_behaviors)
            total_duration = sum(record.duration for record in video_records if record.duration)
            
            # 5. 准备分析数据（包含视频录制时间）
            analysis_data = []
            for behavior in pet_behaviors:
                video_record = video_map.get(behavior.video_id)
                
                analysis_data.append({
                    'pet_name': behavior.pet_name,
                    'actions': behavior.actions,
                    'description': behavior.description,
                    'status': behavior.status,
                    'location': behavior.location,
                    'score': behavior.score,
                    'recorded_at': video_record.recorded_at.isoformat() if video_record and video_record.recorded_at else None,  # 视频录制时间（真实行为发生时间）
                    'duration': video_record.duration if video_record else 0,  # 视频时长
                    'video_id': behavior.video_id  # 视频ID用于追踪
                })
            
            # 5. 调用LLM生成日报摘要（带重试）
            result_data, success, llm_request, llm_response = self._generate_summary_with_llm_retry(
                did, pet_name, date, analysis_data, db
            )
            
            # 6. 创建新的日报记录（每次LLM请求都插入新记录用于追踪）
            new_report = DailyReport(
                did=did,
                date=date,
                pet_name=pet_name,
                analysis_data=json.dumps(analysis_data, ensure_ascii=False),
                video_count=video_count,
                total_duration=total_duration,
                llm_request=llm_request,  # 保存LLM请求
                llm_response=llm_response,  # 保存LLM原始返回
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            
            # 7. 设置日报状态和内容
            if success:
                # 解析JSON格式的返回
                new_report.summary = result_data.get('summary', '')
                new_report.daily_tag = result_data.get('daily_tag', '')
                new_report.insight_text = result_data.get('insight_text', '')
                new_report.generation_status = 'completed'
                new_report.error_message = None
                new_report.retry_count = 0
                logger.info(f"[成功] 日报生成成功: {did} / {pet_name} / {date}, 标签: {new_report.daily_tag}")
            else:
                new_report.generation_status = 'failed'
                new_report.error_message = result_data if isinstance(result_data, str) else json.dumps(result_data)
                new_report.retry_count = 1
                logger.error(f"[失败] 日报生成失败: {did} / {pet_name} / {date}")
            
            db.add(new_report)
            db.commit()
            
        except Exception as e:
            logger.error(f"生成日报异常: {did} / {pet_name} / {date}, 错误: {e}")
            db.rollback()
            
            # 记录失败状态
            try:
                report = db.query(DailyReport).filter(
                    DailyReport.did == did,
                    DailyReport.date == date,
                    DailyReport.pet_name == pet_name
                ).first()
                
                if report:
                    report.generation_status = 'failed'
                    report.error_message = str(e)
                    report.retry_count += 1
                    report.updated_at = datetime.now()
                    db.commit()
            except Exception as inner_e:
                logger.error(f"记录失败状态时发生错误: {inner_e}")

    def _generate_summary_with_llm_retry(
        self, 
        did: str, 
        pet_name: str, 
        date: str, 
        analysis_data: List[Dict[str, Any]], 
        db: Session
    ) -> tuple[Union[Dict[str, str], str], bool, str, str]:
        """使用LLM生成日报摘要（带重试机制）
        
        Returns:
            (result_data, success, llm_request, llm_response): 
            - result_data: 解析后的字典或错误信息字符串
            - success: 是否成功
            - llm_request: LLM请求的原始提示词
            - llm_response: LLM返回的原始内容
        """
        last_error = None
        saved_prompt = ""
        saved_response = ""
        
        for attempt in range(self.MAX_RETRIES):
            try:
                logger.info(f"LLM调用尝试 {attempt + 1}/{self.MAX_RETRIES}: {did}/{pet_name}/{date}")
                
                # 获取日报生成提示词
                prompt_template = self._get_daily_report_prompt(db)
                
                # 构建提示词
                behaviors_summary = self._format_behaviors_for_prompt(analysis_data)
                
                # 根据是否有具体宠物名称调整prompt
                if pet_name and pet_name != "全部宠物":
                    # 有具体宠物名称
                    prompt = prompt_template.format(
                        pet_name=pet_name,
                        date=date,
                        video_count=len(analysis_data),
                        behaviors_summary=behaviors_summary
                    )
                else:
                    # 没有配置宠物，使用"您的宠物"替代
                    prompt = prompt_template.format(
                        pet_name="您的宠物",
                        date=date,
                        video_count=len(analysis_data),
                        behaviors_summary=behaviors_summary
                    )
                
                # 保存请求提示词
                saved_prompt = prompt
                
                # 调用LLM（使用文本模型，不需要视频）
                ds_service = self.get_dashscope_service()
                
                # 使用通用的文本生成方法
                result = ds_service.generate_text(
                    prompt=prompt,
                    model_name=getattr(settings, 'daily_report_model', 'qwen-plus')
                )
                
                if result.get('success'):
                    content = result.get('content', '').strip()
                    saved_response = content  # 保存原始返回
                    
                    if content:
                        # 尝试解析JSON
                        try:
                            # 清理可能的Markdown代码块标记
                            cleaned_content = content
                            if content.startswith('```json'):
                                cleaned_content = content.replace('```json', '').replace('```', '').strip()
                            elif content.startswith('```'):
                                cleaned_content = content.replace('```', '').strip()
                            
                            # 解析JSON
                            result_data = json.loads(cleaned_content)
                            
                            # 验证必需字段
                            if not isinstance(result_data, dict):
                                last_error = f"LLM返回的不是JSON对象: {type(result_data)}"
                                logger.warning(f"⚠️ {last_error}（第{attempt + 1}次尝试）")
                                continue
                            
                            required_fields = ['summary', 'daily_tag', 'insight_text']
                            missing_fields = [f for f in required_fields if f not in result_data]
                            if missing_fields:
                                last_error = f"JSON缺少必需字段: {missing_fields}"
                                logger.warning(f"⚠️ {last_error}（第{attempt + 1}次尝试）")
                                continue
                            
                            logger.info(f"[成功] LLM调用成功（第{attempt + 1}次尝试）")
                            logger.debug(f"解析结果: summary长度={len(result_data['summary'])}, tag={result_data['daily_tag']}")
                            return result_data, True, saved_prompt, saved_response
                            
                        except json.JSONDecodeError as je:
                            last_error = f"JSON解析失败: {je}, 原始内容: {content[:200]}"
                            logger.warning(f"⚠️ {last_error}（第{attempt + 1}次尝试）")
                    else:
                        last_error = "LLM返回空内容"
                        logger.warning(f"⚠️ LLM返回空内容（第{attempt + 1}次尝试）")
                else:
                    last_error = result.get('error', '未知错误')
                    logger.warning(f"⚠️ LLM调用失败（第{attempt + 1}次尝试）: {last_error}")
                    
            except Exception as e:
                last_error = str(e)
                logger.error(f"[异常] LLM调用异常（第{attempt + 1}次尝试）: {e}")
            
            # 如果不是最后一次尝试，等待后重试
            if attempt < self.MAX_RETRIES - 1:
                logger.info(f"等待 {self.RETRY_DELAY_SECONDS} 秒后重试...")
                time.sleep(self.RETRY_DELAY_SECONDS)
        
        # 所有重试都失败
        error_msg = f"LLM调用失败（已重试{self.MAX_RETRIES}次）: {last_error}"
        logger.error(f"[失败] {error_msg}")
        return error_msg, False, saved_prompt, saved_response
    
    def _generate_summary_with_llm(
        self, 
        did: str, 
        pet_name: str, 
        date: str, 
        analysis_data: List[Dict[str, Any]], 
        db: Session
    ) -> str:
        """使用LLM生成日报摘要（不带重试，已废弃，保留兼容性）"""
        summary, success, _, _ = self._generate_summary_with_llm_retry(
            did, pet_name, date, analysis_data, db
        )
        return summary

    def _format_behaviors_for_prompt(self, analysis_data: List[Dict[str, Any]]) -> str:
        """格式化行为数据用于提示词（结构化JSON格式）"""
        if not analysis_data:
            return "[]"
        
        # 构建结构化数据
        formatted_behaviors = []
        for behavior in analysis_data:
            # 解析时间（使用视频录制时间，即真实行为发生时间）
            recorded_at = behavior.get('recorded_at', '')
            if recorded_at:
                try:
                    # 从ISO格式提取时间部分 (HH:MM:SS)
                    time_str = recorded_at.split('T')[1].split('.')[0] if 'T' in recorded_at else recorded_at
                except:
                    time_str = '未知'
            else:
                time_str = '未知'
            
            formatted_behaviors.append({
                'time': time_str,  # 行为发生时间点（HH:MM:SS）
                'duration': round(behavior.get('duration', 0), 1),  # 视频片段时长（秒）
                'actions': behavior.get('actions', '未知'),  # 行为类型
                'description': behavior.get('description', '无描述'),  # 详细描述
                'status': behavior.get('status', '未知'),  # 状态
                'location': behavior.get('location', '未知'),  # 位置
                'confidence': round(behavior.get('score', 0), 2) if behavior.get('score') else 0  # 识别置信度（0-1）
            })
        
        # 按时间排序
        formatted_behaviors.sort(key=lambda x: x['time'])
        
        # 返回格式化的JSON字符串
        import json
        return json.dumps(formatted_behaviors, ensure_ascii=False, indent=2)

    def _get_daily_report_prompt(self, db: Session) -> str:
        """获取日报生成提示词模板"""
        return """你是一个专业的宠物行为分析师，请根据以下信息生成一份智能日报。

宠物名称：{pet_name}
日期：{date}
视频片段数：{video_count}

今日行为记录（结构化JSON数据）：
{behaviors_summary}

**数据字段说明：**
- time: 行为发生时间点（HH:MM:SS格式，按时间排序）
- duration: 视频片段时长（秒）
- actions: 行为类型（如"休息,观察"、"活动,玩耍"、"进食/进水"等）
- description: 详细描述
- status: 状态描述（如"正常，看起来很放松"）
- location: 发生位置
- confidence: 情感反应得分（0-10分，表示该行为引起人类情感反应的程度，分数越高越吸引人）

## 生成要求

1. **摘要 (summary)**：
   - 50-80字的总结
   - 风格风趣幽默
   - 必须使用 Markdown **加粗** 关键事件（如跑酷、进食、玩耍、休息等）
   - 可以结合时间点，如"上午10:30**玩耍**，下午15:00**休息**"
   - 示例："{pet_name}今天早上**跑酷**了3次表现活跃，中午**进食**正常，下午**休息**时间较长。"

2. **标签 (daily_tag)**：
   - 根据全天行为频率和时间分布给出一个短标签（3-5个字）
   - 可选标签：精力过剩 / 岁月静好 / 饭桶 / 活力满满 / 懒洋洋 / 好奇宝宝 / 安静天使 / 调皮捣蛋
   - 根据实际行为选择最合适的标签

3. **洞察建议 (insight_text)**：
   - **长度严格限制在15字以内**
   - 综合分析一天的行为模式和时间分布
   - 逻辑判断（简短建议）：
     - 若活动行为（run/play）少 → "建议增加互动游戏"
     - 若进食/饮水记录少 → "注意饮食饮水"
     - 若出现异常行为（vomit等） → "建议健康检查"
     - 若高分行为多（情感反应强） → "今日表现优秀"
     - 若一切正常 → "状态良好保持"
   - 语言简洁、实用
   - **示例**："活力充沛保持互动" / "注意饮水量" / "状态优秀继续保持"

## 输出格式

**必须严格输出以下JSON格式，不要包含任何Markdown代码块标记（如 ```json）：**

{{
  "summary": "Markdown字符串，包含加粗的关键事件，可以包含时间点",
  "daily_tag": "标签字符串",
  "insight_text": "洞察建议字符串"
}}

请直接输出JSON，不要添加任何其他内容。"""

    def trigger_immediate_generation(self, did: Optional[str] = None, pet_name: Optional[str] = None):
        """手动触发立即生成日报"""
        if not self.is_running():
            raise Exception("DailyReportGenerator 未运行，无法触发生成")
        
        db = SessionLocal()
        try:
            today = datetime.now().strftime('%Y-%m-%d')
            
            if did and pet_name:
                # 生成指定宠物的日报
                logger.info(f"手动触发生成日报: {did} / {pet_name} / {today}")
                self._generate_pet_daily_report(did, today, pet_name, db)
                logger.info(f"手动生成日报完成: {did} / {pet_name} / {today}")
            else:
                # 生成所有宠物的日报
                logger.info("手动触发生成所有日报")
                self._generate_all_daily_reports()
                logger.info("手动生成所有日报完成")
                
        except Exception as e:
            logger.error(f"手动触发生成日报失败: {e}")
            raise
        finally:
            db.close()


# 全局实例
daily_report_generator = DailyReportGenerator()
