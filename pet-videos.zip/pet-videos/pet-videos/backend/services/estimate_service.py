"""费用预估服务（梯度定价，不四舍五入）"""
from typing import Dict
from config import PRICING_TIERS
from services.token_calculator import calculate_video_tokens
from services.video_service import VideoService


class EstimateService:
    """费用预估服务（支持梯度定价）"""
    
    @staticmethod
    def calculate_cost_with_breakdown(tokens: int, is_input: bool = True) -> Dict:
        """根据梯度定价计算成本（带详细计算过程，不四舍五入）
        
        Args:
            tokens: token 数量
            is_input: 是否为输入token（True=输入，False=输出）
        
        Returns:
            包含总成本和详细计算过程的字典
        """
        total_cost = 0.0
        remaining_tokens = tokens
        breakdown_details = []
        
        for tier in PRICING_TIERS:
            tier_min, tier_max = tier['range']
            price_per_1k = tier['input_price'] if is_input else tier['output_price']
            tier_name = tier['name']
            
            # 当前区间没有使用到
            if remaining_tokens <= 0 or tokens <= tier_min:
                continue
            
            # 计算在当前区间使用的 token 数
            if tokens <= tier_max:
                # 完全在当前区间内
                tokens_in_tier = min(remaining_tokens, tokens - tier_min)
            else:
                # 跨越到下一个区间
                tokens_in_tier = tier_max - max(tier_min, tokens - remaining_tokens)
            
            # 计算当前区间的成本（不四舍五入）
            tier_cost = (tokens_in_tier / 1000) * price_per_1k
            total_cost += tier_cost
            
            # 记录详细信息
            breakdown_details.append({
                'tier_name': tier_name,
                'tier_range': f"{tier_min//1000}K-{tier_max//1000}K",
                'tokens_in_tier': tokens_in_tier,
                'price_per_1k': price_per_1k,
                'tier_cost': tier_cost
            })
            
            remaining_tokens -= tokens_in_tier
            
            if remaining_tokens <= 0:
                break
        
        return {
            'total_cost': total_cost,
            'breakdown': breakdown_details
        }
    
    @staticmethod
    def calculate_cost_by_tier(tokens: int, is_input: bool = True) -> float:
        """根据梯度定价计算成本（不四舍五入）
        
        Args:
            tokens: token 数量
            is_input: 是否为输入token（True=输入，False=输出）
        
        Returns:
            成本（元）
        """
        total_cost = 0.0
        remaining_tokens = tokens
        
        for tier in PRICING_TIERS:
            tier_min, tier_max = tier['range']
            price_per_1k = tier['input_price'] if is_input else tier['output_price']
            
            # 当前区间没有使用到
            if remaining_tokens <= 0 or tokens <= tier_min:
                continue
            
            # 计算在当前区间使用的 token 数
            if tokens <= tier_max:
                # 完全在当前区间内
                tokens_in_tier = min(remaining_tokens, tokens - tier_min)
            else:
                # 跨越到下一个区间
                tokens_in_tier = tier_max - max(tier_min, tokens - remaining_tokens)
            
            # 计算当前区间的成本（不四舍五入）
            tier_cost = (tokens_in_tier / 1000) * price_per_1k
            total_cost += tier_cost
            remaining_tokens -= tokens_in_tier
            
            if remaining_tokens <= 0:
                break
        
        return total_cost
    
    def estimate(
        self, 
        video_path: str,
        fps: float,
        max_pixels: int,
        min_pixels: int,
        prompt_length: int = 50,
        vl_high_resolution_images: bool = False
    ) -> Dict:
        """预估 token 消耗和费用
        
        Args:
            video_path: 视频文件路径
            fps: 抽帧频率
            max_pixels: 最大像素数
            min_pixels: 最小像素数
            prompt_length: 提示词长度（token数）
            vl_high_resolution_images: 高分辨率模式
        
        Returns:
            预估结果字典
        """
        
        # 1. 使用ffprobe获取视频信息
        video_service = VideoService()
        try:
            video_info = video_service.extract_info(video_path)
        except Exception:
            video_info = None
        
        # 2. 高分辨率模式处理
        effective_max_pixels = max_pixels
        effective_total_pixels = None  # 使用默认VIDEO_TOTAL_PIXELS
        
        # 3. 使用官方算法计算视频 tokens
        token_info = calculate_video_tokens(
            video_path, fps, min_pixels, effective_max_pixels, video_info, effective_total_pixels
        )
        
        # 4. 提取计算结果
        video_tokens = token_info['video_tokens']
        frame_count = token_info['extracted_frames']
        tokens_per_frame = token_info['tokens_per_frame']
        
        # 5. 加上提示词 tokens
        prompt_tokens = prompt_length
        total_input_tokens = video_tokens + prompt_tokens
        
        # 6. 估算输出 token（保守估计）
        estimated_output_tokens = 500
        
        # 7. 计算成本（使用梯度定价，不四舍五入）
        input_cost_breakdown = self.calculate_cost_with_breakdown(total_input_tokens, is_input=True)
        output_cost_breakdown = self.calculate_cost_with_breakdown(estimated_output_tokens, is_input=False)
        
        total_cost = input_cost_breakdown['total_cost'] + output_cost_breakdown['total_cost']
        
        return {
            'frame_count': frame_count,
            'tokens_per_frame': tokens_per_frame,
            'video_tokens': video_tokens,
            'prompt_tokens': prompt_tokens,
            'total_input_tokens': total_input_tokens,
            'estimated_output_tokens': estimated_output_tokens,
            'estimated_total_tokens': total_input_tokens + estimated_output_tokens,
            'estimated_cost': total_cost,
            'breakdown': {
                'input_cost': input_cost_breakdown['total_cost'],
                'output_cost': output_cost_breakdown['total_cost'],
                'input_details': input_cost_breakdown['breakdown'],
                'output_details': output_cost_breakdown['breakdown']
            },
            'video_info': {
                'original_resolution': token_info['original_resolution'],
                'resized_resolution': token_info['resized_resolution'],
                'total_frames': token_info['total_frames'],
                'video_fps': token_info['video_fps']
            }
        }
    
    def calculate_accuracy(self, estimated: int, actual: int) -> float:
        """计算预估准确率"""
        if actual == 0:
            return 0.0
        
        accuracy = (1 - abs(estimated - actual) / actual) * 100
        return round(max(0, accuracy), 1)
