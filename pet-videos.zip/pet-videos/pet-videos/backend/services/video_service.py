"""视频信息提取服务"""
import subprocess
import json
import logging
from pathlib import Path
from typing import List, Dict, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from config import settings
from utils.security import encode_video_token
from services.video_cache import VideoCache
from models.db import SessionLocal
from models.database import StreamSource, VideoRecord
from sqlalchemy import func

logger = logging.getLogger(__name__)


class VideoService:
    """视频信息提取服务（支持多目录，从数据库动态加载别名）"""
    
    SUPPORTED_EXTENSIONS = ['.mp4']  # 只允许mp4文件
    
    def __init__(self):
        # 初始化缓存（基于 mtime 的自动失效机制，无需 TTL）
        cache_dir = Path("database/video_cache")
        self.cache = VideoCache(cache_dir=cache_dir)
        logger.info(f"VideoService initialized with cache: {self.cache.get_stats()}")
    
    def _get_dirs_map(self) -> Dict[str, str]:
        """从数据库获取别名映射"""
        db = SessionLocal()
        try:
            sources = db.query(StreamSource).filter(StreamSource.is_active == True).all()
            return {s.alias: s.storage_path for s in sources}
        finally:
            db.close()

    def get_directories(self) -> List[Dict]:
        """获取所有配置的视频目录信息（从数据库读取）"""
        directories = []
        dirs_map = self._get_dirs_map()
        for alias, dir_path in dirs_map.items():
            path = Path(dir_path)
            exists = path.exists() and path.is_dir()
            
            # 统计视频文件数量
            video_count = 0
            if exists:
                try:
                    video_count = len(self.scan_directory(dir_path))
                except Exception:
                    video_count = 0
            
            directories.append({
                'alias': alias,
                'name': path.name if path.name else path.as_posix(),
                'video_count': video_count,
                'exists': exists
            })
        
        return directories
    
    def scan_directory(self, dir_path: str) -> List[str]:
        """扫描目录下所有视频文件"""
        path = Path(dir_path)
        
        if not path.exists():
            raise FileNotFoundError(f"Directory not found: {dir_path}")
        
        if not path.is_dir():
            raise ValueError(f"Not a directory: {dir_path}")
        
        videos = set()
        for ext in self.SUPPORTED_EXTENSIONS:
            # glob 在某些系统（如 macOS）上可能不区分大小写，
            # 导致 *.mp4 和 *.MP4 匹配到相同的文件，从而产生重复
            for v in path.glob(f'*{ext}'):
                videos.add(v.absolute())
            for v in path.glob(f'*{ext.upper()}'):
                videos.add(v.absolute())
        
        # 按修改时间倒序排列，通常切片是按顺序生成的
        # 增加路径作为第二排序键，确保排序稳定性
        return sorted(
            [str(v) for v in videos], 
            key=lambda x: (Path(x).stat().st_mtime, x), 
            reverse=True
        )

    def get_video_date(self, video_path: str) -> str:
        """从文件名或文件属性获取日期 (YYYY-MM-DD)"""
        filename = Path(video_path).stem
        # 尝试从 VIDEO_1767494103401 这种格式提取
        if filename.startswith('VIDEO_'):
            try:
                ts_str = filename.split('_')[1]
                # 有些是毫秒，有些是秒
                ts = float(ts_str)
                if ts > 10**11: # 毫秒
                    ts /= 1000
                import datetime
                return datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
            except (IndexError, ValueError):
                pass
        
        # 兜底：使用文件修改日期
        import datetime
        mtime = Path(video_path).stat().st_mtime
        return datetime.datetime.fromtimestamp(mtime).strftime('%Y-%m-%d')

    def get_video_stats(self) -> List[Dict]:
        """获取所有目录的每日视频统计（从数据库读取）"""
        db = SessionLocal()
        try:
            stats = []
            
            # 获取所有激活的源
            sources = db.query(StreamSource).filter(StreamSource.is_active == True).all()
            
            for source in sources:
                # 从数据库统计每日视频数量
                daily_stats_query = db.query(
                    func.date(VideoRecord.recorded_at).label('date'),
                    func.count(VideoRecord.id).label('count')
                ).filter(
                    VideoRecord.source_id == source.id
                ).group_by(
                    func.date(VideoRecord.recorded_at)
                ).order_by(
                    func.date(VideoRecord.recorded_at).desc()
                ).all()
                
                # 转换为前端需要的格式
                daily_stats = [
                    {'date': str(row.date), 'count': row.count}
                    for row in daily_stats_query
                ]
                
                stats.append({
                    'alias': source.alias,
                    'name': source.name,
                    'daily_stats': daily_stats
                })
            
            return stats
        finally:
            db.close()

    def get_videos_by_date(self, source_id: int, date_str: str, page: int = 1, page_size: int = 20) -> Dict:
        """获取指定源和日期的视频（从数据库读取，支持分页）
        
        Args:
            source_id: 源 ID
            date_str: 日期字符串 (YYYY-MM-DD)
            page: 页码（从1开始）
            page_size: 每页数量
        
        Returns:
            包含videos列表和分页信息的字典
        """
        from datetime import datetime, timedelta
        
        db = SessionLocal()
        try:
            # 解析日期
            date = datetime.strptime(date_str, '%Y-%m-%d').date()
            
            logger.info(f"Querying videos: source_id={source_id}, date_str={date_str}, page={page}, page_size={page_size}")
            
            # 统计总数
            total = db.query(VideoRecord).filter(
                VideoRecord.source_id == source_id,
                func.date(VideoRecord.recorded_at) == date
            ).count()
            
            logger.info(f"Total {total} videos for source_id={source_id}, date={date_str}")
            
            # 分页查询（按时间降序，最新的在前）
            offset = (page - 1) * page_size
            records = db.query(VideoRecord).filter(
                VideoRecord.source_id == source_id,
                func.date(VideoRecord.recorded_at) == date
            ).order_by(VideoRecord.recorded_at.desc())\
             .offset(offset)\
             .limit(page_size)\
             .all()
            
            logger.info(f"Fetched {len(records)} videos for page {page}")
            
            # 获取源信息（用于生成 stream_token）
            source = db.query(StreamSource).filter(StreamSource.id == source_id).first()
            if not source:
                logger.error(f"Source not found: id={source_id}")
                return {'videos': [], 'total': 0, 'page': page, 'page_size': page_size}
            
            # 转换为前端需要的格式
            videos = []
            for record in records:
                stream_token = self.generate_stream_token(source.alias, record.file_name)
                
                videos.append({
                    'id': record.id,
                    'filename': record.file_name,
                    'file_name': record.file_name,
                    'dir_alias': source.alias,
                    'path': record.file_path,
                    'resolution': f"{record.width}x{record.height}" if record.width and record.height else '-',
                    'width': record.width if record.width else 0,
                    'height': record.height if record.height else 0,
                    'duration_formatted': self._format_duration(record.duration) if record.duration else '-',
                    'duration_sec': record.duration if record.duration else 0,
                    'size_mb': record.file_size / (1024 * 1024) if record.file_size else 0,
                    'fps': record.fps if record.fps else 0,
                    'codec': record.codec if record.codec else '-',
                    'bitrate_mbps': 0,  # 暂不计算
                    'stream_token': stream_token,
                    'created_at': record.recorded_at.isoformat() if record.recorded_at else None,
                    'detection_type': record.detection_type,
                    'llm_status': record.llm_status
                })
            
            return {
                'videos': videos,
                'total': total,
                'page': page,
                'page_size': page_size
            }
        finally:
            db.close()
    
    def get_videos_by_date_multi_source(self, source_ids: List[int], date_str: str, 
                                         pet_name: Optional[str] = None,
                                         page: int = 1, page_size: int = 20, 
                                         db: any = None) -> Dict:
        """获取多个源和日期的视频（支持宠物过滤，支持分页）
        
        Args:
            source_ids: 源 ID 列表
            date_str: 日期字符串 (YYYY-MM-DD)
            pet_name: 宠物名称（可选，用于过滤）
            page: 页码（从1开始）
            page_size: 每页数量
            db: 数据库会话（如果为None，会创建新会话）
        
        Returns:
            包含videos列表和分页信息的字典
        """
        from datetime import datetime
        from models.database import PetBehavior
        from typing import Optional
        
        should_close_db = False
        if db is None:
            db = SessionLocal()
            should_close_db = True
            
        try:
            logger.info(f"[get_videos_by_date_multi_source] START - source_ids={source_ids}, date_str={date_str}, pet_name={pet_name}, page={page}, page_size={page_size}")
            
            # 解析日期
            date = datetime.strptime(date_str, '%Y-%m-%d').date()
            logger.info(f"[get_videos_by_date_multi_source] Parsed date: {date}")
            
            # 构建基础查询
            query = db.query(VideoRecord).filter(
                VideoRecord.source_id.in_(source_ids),
                func.date(VideoRecord.recorded_at) == date
            )
            logger.info(f"[get_videos_by_date_multi_source] Built base query")
            
            # 如果指定了宠物名称，JOIN video_pet_analysis 表
            if pet_name:
                logger.info(f"[get_videos_by_date_multi_source] Adding pet_name filter: {pet_name}")
                query = query.join(
                    PetBehavior,
                    (VideoRecord.id == PetBehavior.video_id) &
                    (PetBehavior.pet_name == pet_name)
                ).distinct()
            
            # 统计总数
            logger.info(f"[get_videos_by_date_multi_source] Counting total...")
            total = query.count()
            logger.info(f"[get_videos_by_date_multi_source] Total videos found: {total}")
            
            # 分页查询（按时间降序）
            offset = (page - 1) * page_size
            logger.info(f"[get_videos_by_date_multi_source] Fetching page {page} (offset={offset}, limit={page_size})...")
            records = query.order_by(VideoRecord.recorded_at.desc())\
                           .offset(offset)\
                           .limit(page_size)\
                           .all()
            
            logger.info(f"[get_videos_by_date_multi_source] Fetched {len(records)} video records")
            
            # 获取源信息映射（用于生成 stream_token）
            logger.info(f"[get_videos_by_date_multi_source] Loading source info for source_ids={source_ids}...")
            sources = db.query(StreamSource).filter(StreamSource.id.in_(source_ids)).all()
            source_map = {s.id: s for s in sources}
            logger.info(f"[get_videos_by_date_multi_source] Loaded {len(sources)} sources")
            
            # 转换为前端需要的格式
            videos = []
            for i, record in enumerate(records):
                logger.info(f"[get_videos_by_date_multi_source] Processing record {i+1}/{len(records)}: id={record.id}, file_name={record.file_name}")
                
                source = source_map.get(record.source_id)
                if not source:
                    logger.warning(f"[get_videos_by_date_multi_source] Source not found for video record: source_id={record.source_id}")
                    continue
                    
                stream_token = self.generate_stream_token(source.alias, record.file_name)
                
                videos.append({
                    'id': record.id,
                    'filename': record.file_name,
                    'file_name': record.file_name,
                    'source_id': record.source_id,
                    'dir_alias': source.alias,
                    'path': record.file_path,
                    'resolution': f"{record.width}x{record.height}" if record.width and record.height else '-',
                    'width': record.width if record.width else 0,
                    'height': record.height if record.height else 0,
                    'duration_formatted': self._format_duration(record.duration) if record.duration else '-',
                    'duration_sec': record.duration if record.duration else 0,
                    'size_mb': record.file_size / (1024 * 1024) if record.file_size else 0,
                    'fps': record.fps if record.fps else 0,
                    'codec': record.codec if record.codec else '-',
                    'bitrate_mbps': 0,  # 暂不计算
                    'stream_token': stream_token,
                    'created_at': record.recorded_at.isoformat() if record.recorded_at else None,
                    'detection_type': record.detection_type,
                    'llm_status': record.llm_status
                })
            
            logger.info(f"[get_videos_by_date_multi_source] SUCCESS - Returning {len(videos)} videos")
            return {
                'videos': videos,
                'total': total,
                'page': page,
                'page_size': page_size
            }
        except Exception as e:
            logger.error(f"[get_videos_by_date_multi_source] ERROR: {type(e).__name__}: {str(e)}")
            logger.error(f"[get_videos_by_date_multi_source] Parameters: source_ids={source_ids}, date_str={date_str}, pet_name={pet_name}")
            import traceback
            logger.error(f"[get_videos_by_date_multi_source] Traceback:\n{traceback.format_exc()}")
            raise
        finally:
            if should_close_db:
                db.close()
                logger.info(f"[get_videos_by_date_multi_source] DB session closed")
    
    def _batch_extract_info(self, video_paths: List[str], max_workers: int = 4) -> List[Dict]:
        """批量提取视频信息（带缓存+并行处理）
        
        Args:
            video_paths: 视频文件路径列表
            max_workers: 最大并行worker数量
        
        Returns:
            视频信息列表
        """
        videos = []
        uncached_paths = []
        
        # 步骤1: 检查缓存
        for v_path in video_paths:
            cached_info = self.cache.get(v_path)
            if cached_info:
                videos.append(cached_info)
            else:
                uncached_paths.append(v_path)
        
        cache_hit_rate = (len(videos) / len(video_paths) * 100) if video_paths else 0
        logger.info(f"Cache: {len(videos)}/{len(video_paths)} hit ({cache_hit_rate:.1f}%), {len(uncached_paths)} need extraction")
        
        # 步骤2: 并行提取未缓存的视频信息
        if uncached_paths:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                # 提交所有任务
                future_to_path = {
                    executor.submit(self._extract_and_cache, path): path 
                    for path in uncached_paths
                }
                
                # 收集结果
                for future in as_completed(future_to_path):
                    path = future_to_path[future]
                    try:
                        info = future.result()
                        if info:
                            videos.append(info)
                    except Exception as e:
                        logger.warning(f"Failed to extract {path}: {e}")
                        # 提供降级数据
                        videos.append(self._get_fallback_info(path))
        
        return videos
    
    def _extract_and_cache(self, video_path: str) -> Dict:
        """提取视频信息并缓存（ffprobe调用发生在这里）"""
        info = self.extract_info(video_path)
        self.cache.set(video_path, info)
        return info
    
    def _get_fallback_info(self, video_path: str) -> Dict:
        """获取降级视频信息（当 ffprobe 失败时）"""
        from datetime import datetime
        mtime = Path(video_path).stat().st_mtime if Path(video_path).exists() else 0
        created_at = datetime.fromtimestamp(mtime).isoformat() if mtime else None
        
        return {
            'filename': Path(video_path).name,
            'dir_alias': self._try_get_alias(video_path),
            'path': video_path,
            'stream_token': encode_video_token(
                self._try_get_alias(video_path), 
                Path(video_path).name
            ),
            'size_mb': Path(video_path).stat().st_size / (1024 * 1024) if Path(video_path).exists() else 0,
            'duration_sec': 0,
            'duration_formatted': 'unknown',
            'resolution': 'unknown',
            'width': 0,
            'height': 0,
            'fps': 0,
            'codec': 'unknown',
            'bitrate_mbps': 0,
            'created_at': created_at
        }
    
    def _try_get_alias(self, video_path: str) -> str:
        """尝试获取视频路径的别名（从数据库读取）"""
        try:
            return self.get_alias_by_path(str(Path(video_path).parent))
        except:
            return "unknown"
    
    def get_alias_by_path(self, path: str) -> str:
        """根据路径获取别名"""
        path_obj = Path(path).resolve()
        dirs_map = self._get_dirs_map()
        
        for alias, dir_path in dirs_map.items():
            dir_path_obj = Path(dir_path).resolve()
            if path_obj == dir_path_obj or str(path_obj).startswith(str(dir_path_obj)):
                return alias
        
        raise ValueError(f"Path not found in configured database sources: {path}")

    def extract_info(self, video_path: str) -> Dict:
        """使用 ffprobe 提取视频信息"""
        import os
        import platform
        
        cmd = [
            'ffprobe', '-v', 'error',
            '-show_entries', 'format=duration,size,bit_rate,tags=creation_time',
            '-show_entries', 'stream=codec_name,width,height,r_frame_rate,avg_frame_rate,bit_rate,codec_type',
            '-of', 'json',
            video_path
        ]
        
        try:
            # 在 Windows 下，如果环境变量没设好，可能需要 shell=True
            use_shell = platform.system().lower() == 'windows'
            result = subprocess.run(cmd, capture_output=True, text=True, check=True, shell=use_shell)
            data = json.loads(result.stdout)
        except subprocess.CalledProcessError as e:
            logger.error(f"ffprobe error: {e.stderr}")
            raise ValueError(f"Failed to extract info from {video_path}: {e.stderr}")
        except FileNotFoundError:
            raise RuntimeError("ffprobe not found. Please install FFmpeg and add it to your PATH.")
        
        # 查找视频流
        video_stream = None
        for stream in data['streams']:
            if stream.get('codec_type') == 'video' or stream.get('width'):
                video_stream = stream
                break
        
        if not video_stream:
            raise ValueError(f"No video stream found in {video_path}")
        
        duration = float(data['format']['duration'])
        size_bytes = int(data['format']['size'])
        
        # 解析帧率 - 优先使用 avg_frame_rate（实际帧率），fallback 到 r_frame_rate
        def parse_fps(fps_str: str) -> float:
            """解析帧率字符串"""
            if '/' in fps_str:
                num, den = fps_str.split('/')
                return float(num) / float(den) if float(den) != 0 else 0
            return float(fps_str)
        
        # 尝试使用 avg_frame_rate（更准确）
        fps = 0
        if 'avg_frame_rate' in video_stream and video_stream['avg_frame_rate'] != '0/0':
            fps = parse_fps(video_stream['avg_frame_rate'])
        
        # 如果 avg_frame_rate 不可用或异常，使用 r_frame_rate
        if fps <= 0 or fps > 120:  # 合理性检查：FPS 应该在 0-120 之间
            if 'r_frame_rate' in video_stream:
                fps_candidate = parse_fps(video_stream['r_frame_rate'])
                # 只有在合理范围内才使用 r_frame_rate
                if 0 < fps_candidate <= 120:
                    fps = fps_candidate
                else:
                    # 如果两个都不合理，使用默认值
                    logger.warning(f"Abnormal FPS detected: avg={video_stream.get('avg_frame_rate')}, r={video_stream.get('r_frame_rate')}, using default 10")
                    fps = 10.0
        
        # 获取目录别名
        filename = Path(video_path).name
        try:
            dir_alias = self.get_alias_by_path(str(Path(video_path).parent))
        except ValueError:
            # 如果找不到别名，使用路径作为降级方案
            logger.warning(f"Cannot find alias for path: {video_path}")
            dir_alias = "unknown"
        
        # 提取视频创建时间
        creation_time = None
        try:
            # 尝试从元数据获取
            if 'tags' in data['format'] and 'creation_time' in data['format']['tags']:
                creation_time = data['format']['tags']['creation_time']
            # 如果元数据没有，尝试从文件名提取 (VIDEO_1767494233478.mp4)
            elif filename.startswith('VIDEO_'):
                ts_str = filename.split('_')[1].split('.')[0]
                ts = float(ts_str)
                if ts > 10**11:  # 毫秒
                    ts /= 1000
                from datetime import datetime
                creation_time = datetime.fromtimestamp(ts).isoformat()
            # 最后降级使用文件修改时间
            else:
                from datetime import datetime
                mtime = Path(video_path).stat().st_mtime
                creation_time = datetime.fromtimestamp(mtime).isoformat()
        except Exception as e:
            logger.warning(f"Failed to extract creation_time for {filename}: {e}")
            # 降级使用文件修改时间
            from datetime import datetime
            mtime = Path(video_path).stat().st_mtime
            creation_time = datetime.fromtimestamp(mtime).isoformat()
        
        return {
            'filename': filename,
            'dir_alias': dir_alias,
            'path': video_path,  # 保留用于后端分析
            'stream_token': encode_video_token(dir_alias, filename),  # 使用别名+文件名生成token
            'size_mb': round(size_bytes / 1024 / 1024, 2),
            'duration_sec': round(duration, 2),
            'duration_formatted': self._format_duration(duration),
            'resolution': f"{video_stream['width']}x{video_stream['height']}",
            'width': video_stream['width'],
            'height': video_stream['height'],
            'fps': round(fps, 2),
            'codec': video_stream['codec_name'],
            'bitrate_mbps': round(int(data['format']['bit_rate']) / 1_000_000, 2),
            'created_at': creation_time  # 视频创建时间（ISO格式）
        }
    
    def get_videos_from_directory(self, dir_path: str, page: int = 1, page_size: int = 10) -> Dict:
        """获取指定目录下的视频信息（支持分页，带缓存+并行）"""
        video_paths = self.scan_directory(dir_path)
        total = len(video_paths)
        
        # 分页处理
        start = (page - 1) * page_size
        end = start + page_size
        paged_paths = video_paths[start:end]
        
        # 使用缓存+并行批量提取
        videos = self._batch_extract_info(paged_paths)
        
        return {
            'videos': videos,
            'total': total,
            'page': page,
            'page_size': page_size
        }
    
    def _format_duration(self, seconds: float) -> str:
        """格式化时长为 "X分Y秒" """
        mins = int(seconds // 60)
        secs = int(seconds % 60)
        if mins > 0:
            return f"{mins}分{secs}秒"
        return f"{secs}秒"
    
    def _format_size(self, size_bytes: int) -> str:
        """格式化文件大小"""
        if size_bytes < 1024:
            return f"{size_bytes}B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes / 1024:.1f}KB"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{size_bytes / (1024 * 1024):.1f}MB"
        else:
            return f"{size_bytes / (1024 * 1024 * 1024):.2f}GB"
    
    def generate_stream_token(self, alias: str, filename: str) -> str:
        """生成视频流 token"""
        return encode_video_token(alias, filename)
