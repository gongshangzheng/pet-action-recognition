"""
宠物行为反馈服务
处理点赞/点踩逻辑
"""
from typing import Optional, Dict, List, Tuple
from sqlalchemy.orm import Session
from sqlalchemy import tuple_
from datetime import datetime
import logging

from models.database import BehaviorFeedback, PetBehavior

logger = logging.getLogger(__name__)


class BehaviorFeedbackService:
    """宠物行为反馈服务类"""
    
    def submit_feedback(self, video_id: int, pet_name: str, did: str, 
                       action: str, db: Session) -> str:
        """
        提交反馈（幂等操作）
        
        Args:
            video_id: 视频ID
            pet_name: 宠物名称
            did: 用户ID
            action: 'like' 或 'dislike'
            db: 数据库会话
            
        Returns:
            当前反馈状态: 'like' 或 'dislike'
            
        Raises:
            ValueError: 行为记录不存在
        """
        # 1. 检查 pet_behaviors 是否存在
        behavior = db.query(PetBehavior).filter(
            PetBehavior.video_id == video_id,
            PetBehavior.pet_name == pet_name
        ).first()
        
        if not behavior:
            logger.warning(f"行为记录不存在: video_id={video_id}, pet_name={pet_name}")
            raise ValueError(f"行为记录不存在")
        
        # 2. 查询现有反馈
        feedback = db.query(BehaviorFeedback).filter(
            BehaviorFeedback.video_id == video_id,
            BehaviorFeedback.pet_name == pet_name,
            BehaviorFeedback.did == did
        ).first()
        
        if feedback:
            # 已有反馈
            if feedback.action == action:
                # 重复提交，直接返回（幂等）
                logger.info(f"重复提交反馈: video_id={video_id}, pet_name={pet_name}, did={did}, action={action}")
                return action
            else:
                # 切换反馈（赞→踩 或 踩→赞）
                logger.info(f"切换反馈: video_id={video_id}, pet_name={pet_name}, did={did}, {feedback.action} -> {action}")
                feedback.action = action
                feedback.updated_at = datetime.now()
        else:
            # 新反馈
            logger.info(f"新增反馈: video_id={video_id}, pet_name={pet_name}, did={did}, action={action}")
            feedback = BehaviorFeedback(
                video_id=video_id,
                pet_name=pet_name,
                did=did,
                action=action
            )
            db.add(feedback)
        
        db.commit()
        db.refresh(feedback)
        
        return action
    
    def cancel_feedback(self, video_id: int, pet_name: str, did: str, 
                       db: Session) -> None:
        """
        取消反馈
        
        Args:
            video_id: 视频ID
            pet_name: 宠物名称
            did: 用户ID
            db: 数据库会话
        """
        deleted_count = db.query(BehaviorFeedback).filter(
            BehaviorFeedback.video_id == video_id,
            BehaviorFeedback.pet_name == pet_name,
            BehaviorFeedback.did == did
        ).delete()
        
        db.commit()
        
        logger.info(f"取消反馈: video_id={video_id}, pet_name={pet_name}, did={did}, deleted={deleted_count}")
    
    def get_user_feedback(self, video_id: int, pet_name: str, did: str, 
                         db: Session) -> Optional[str]:
        """
        查询用户反馈状态
        
        Args:
            video_id: 视频ID
            pet_name: 宠物名称
            did: 用户ID
            db: 数据库会话
            
        Returns:
            'like'/'dislike'/None
        """
        feedback = db.query(BehaviorFeedback).filter(
            BehaviorFeedback.video_id == video_id,
            BehaviorFeedback.pet_name == pet_name,
            BehaviorFeedback.did == did
        ).first()
        
        return feedback.action if feedback else None
    
    def batch_get_user_feedback(self, items: List[Tuple[int, str]], 
                               did: str, db: Session) -> Dict[Tuple[int, str], Optional[str]]:
        """
        批量查询用户反馈状态
        
        Args:
            items: [(video_id, pet_name), ...]
            did: 用户ID
            db: 数据库会话
            
        Returns:
            {(video_id, pet_name): 'like'/'dislike'/None}
        """
        if not items:
            return {}
        
        logger.info(f"批量查询反馈: did={did}, items_count={len(items)}")
        
        # 构建 IN 查询条件
        feedbacks = db.query(BehaviorFeedback).filter(
            tuple_(BehaviorFeedback.video_id, BehaviorFeedback.pet_name).in_(items),
            BehaviorFeedback.did == did
        ).all()
        
        # 构建映射（默认都是 None）
        result = {item: None for item in items}
        for f in feedbacks:
            result[(f.video_id, f.pet_name)] = f.action
        
        logger.info(f"批量查询完成: did={did}, 查询{len(items)}条, 有反馈{len(feedbacks)}条")
        
        return result
