"""LLM 分析队列管理服务"""
import threading
import time
import logging
import json
from datetime import datetime, timedelta
from typing import List, Set, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import func

from models.db import SessionLocal
from models.database import VideoRecord, StreamSource, Prompt, PetBehavior
from services.dashscope_service import DashScopeService
from services.estimate_service import EstimateService
from config import settings

logger = logging.getLogger(__name__)

class LLMWorkerService:
    """LLM 分析队列管理服务"""
    
    _instance = None
    _worker_thread = None
    _stop_worker = False
    
    # 配置参数
    MAX_CONCURRENT_TASKS = getattr(settings, 'llm_worker_max_concurrent', 2)
    POLL_INTERVAL = getattr(settings, 'llm_worker_poll_interval', 10)
    MAX_RETRIES = getattr(settings, 'llm_worker_max_retries', 3)
    TIME_WINDOW_HOURS = getattr(settings, 'llm_worker_time_window_hours', 25)  # 时间窗口（小时）
    PROCESSING_TIMEOUT_MINUTES = getattr(settings, 'llm_worker_processing_timeout_minutes', 30)  # processing状态超时时间（分钟）
    
    # 解析重试延迟配置
    @classmethod
    def get_retry_delays(cls):
        retry_delays_str = getattr(settings, 'llm_worker_retry_delays', '60,300,900')
        try:
            return [int(x.strip()) for x in retry_delays_str.split(',')]
        except:
            return [60, 300, 900]  # 默认值
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(LLMWorkerService, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, 'initialized'):
            self.initialized = True
            self.dashscope_service = None
            self.estimate_service = None
            self._processing_records: Set[int] = set()  # 正在处理的记录ID

    def get_dashscope_service(self):
        """获取 DashScope 服务实例（延迟初始化）"""
        if self.dashscope_service is None:
            self.dashscope_service = DashScopeService()
        return self.dashscope_service

    def get_estimate_service(self):
        """获取预估服务实例（延迟初始化）"""
        if self.estimate_service is None:
            self.estimate_service = EstimateService()
        return self.estimate_service

    def start_worker(self):
        """启动 LLM Worker 线程"""
        # 检查系统级开关
        if not getattr(settings, 'llm_worker_enabled', True):
            raise Exception("LLM Worker is disabled in system configuration")
            
        if self._worker_thread and self._worker_thread.is_alive():
            logger.info("LLM Worker already running")
            return
        
        # 清理可能的残留状态
        self._cleanup_stale_processing_records()
            
        self._stop_worker = False
        self._worker_thread = threading.Thread(
            target=self._worker_loop, 
            daemon=True, 
            name="LLMWorker"
        )
        self._worker_thread.start()
        logger.info("LLM Worker thread started")

    def _cleanup_stale_processing_records(self):
        """清理可能的残留处理记录（内存+数据库）"""
        # 1. 清理内存中的残留
        if not hasattr(self, '_processing_records'):
            self._processing_records = set()
            return
            
        if self._processing_records:
            logger.info(f"清理 {len(self._processing_records)} 个内存残留的处理记录: {list(self._processing_records)}")
            self._processing_records.clear()
        
        # 2. 清理数据库中可能遗留的 processing 状态（仅用于清理历史遗留数据）
        db = SessionLocal()
        try:
            # 查找可能遗留的 processing 记录（新系统不会产生，但可能存在历史数据）
            zombie_records = db.query(VideoRecord).filter(
                VideoRecord.llm_status == 'processing'
            ).all()
            
            if zombie_records:
                logger.warning(f"发现 {len(zombie_records)} 个遗留的 processing 状态记录（历史数据）")
                
                for record in zombie_records:
                    # 重置状态为 None，允许重新处理
                    record.llm_status = None
                    record.llm_error = "系统重启，任务已重置"
                    
                    # 清除重试时间，允许立即重新处理
                    record.llm_next_retry_at = None
                    
                    logger.info(f"清理遗留状态: video_id={record.id}, file={record.file_name}")
                
                db.commit()
                logger.info(f"已清理 {len(zombie_records)} 个遗留的 processing 状态")
                
        except Exception as e:
            logger.error(f"清理遗留状态失败: {e}")
            db.rollback()
        finally:
            db.close()

    def stop_worker(self):
        """停止 LLM Worker 线程"""
        self._stop_worker = True
        if self._worker_thread:
            self._worker_thread.join(timeout=30)
            logger.info("LLM Worker thread stopped")

    def is_running(self) -> bool:
        """检查 Worker 是否在运行"""
        return self._worker_thread and self._worker_thread.is_alive() and not self._stop_worker

    def get_status(self) -> Dict[str, Any]:
        """获取 Worker 状态"""
        db = SessionLocal()
        try:
            from datetime import datetime, timedelta
            
            # 统计各状态的记录数
            stats = db.query(
                VideoRecord.llm_status,
                func.count(VideoRecord.id)
            ).group_by(VideoRecord.llm_status).all()
            
            queue_stats = dict(stats)
            # 将None状态显示为'pending'（前端兼容）
            if None in queue_stats:
                queue_stats['pending'] = queue_stats.pop(None)
            
            # 统计窗口内的未处理任务（真正会被处理的）
            time_threshold = datetime.now() - timedelta(hours=self.TIME_WINDOW_HOURS)
            pending_in_window = db.query(func.count(VideoRecord.id)).filter(
                VideoRecord.llm_status.is_(None),
                VideoRecord.created_at >= time_threshold
            ).scalar() or 0
            
            # 统计窗口外的未处理任务（不会被处理的）
            pending_outside_window = queue_stats.get('pending', 0) - pending_in_window
            
            return {
                'worker_running': self.is_running(),
                'processing_count': len(self._processing_records),
                'queue_stats': queue_stats,
                'pending_in_window': pending_in_window,
                'pending_outside_window': pending_outside_window,
                'time_window_hours': self.TIME_WINDOW_HOURS,
                'config': {
                    'max_concurrent': self.MAX_CONCURRENT_TASKS,
                    'poll_interval': self.POLL_INTERVAL
                }
            }
        finally:
            db.close()

    def _worker_loop(self):
        """Worker 主循环"""
        logger.info("LLM Worker loop started")
        
        while not self._stop_worker:
            try:
                # 1. 获取待处理任务（llm_status为NULL的记录）
                pending_records = self._get_pending_records()
                
                if not pending_records:
                    time.sleep(self.POLL_INTERVAL)
                    continue
                
                # 2. 控制并发数
                available_slots = self.MAX_CONCURRENT_TASKS - len(self._processing_records)
                if available_slots <= 0:
                    time.sleep(self.POLL_INTERVAL)
                    continue
                
                tasks_to_process = pending_records[:available_slots]
                
                # 3. 并发处理任务
                for record in tasks_to_process:
                    self._process_record_async(record)
                    
            except Exception as e:
                logger.error(f"LLM Worker loop error: {e}")
            
            time.sleep(self.POLL_INTERVAL)
        
        logger.info("LLM Worker loop stopped")

    def _get_pending_records(self) -> List[VideoRecord]:
        """获取待处理的记录（llm_status为NULL的记录）"""
        db = SessionLocal()
        try:
            from datetime import datetime, timedelta
            
            # 计算时间窗口的起始时间（最近N小时）
            time_threshold = datetime.now() - timedelta(hours=self.TIME_WINDOW_HOURS)
            current_time = datetime.now()
            
            logger.debug(f"查询待处理记录 - 时间窗口: {time_threshold}, 当前处理中: {len(self._processing_records)} 个: {list(self._processing_records)}")
            
            # 先不加 processing_records 过滤，看看有多少记录
            base_query = db.query(VideoRecord).filter(
                VideoRecord.llm_status.is_(None),  # 只查询NULL状态
                VideoRecord.created_at >= time_threshold
            )
            base_count = base_query.count()
            logger.info(f"基础查询找到 {base_count} 条未处理记录（时间窗口内）")
            
            # 构建查询条件：只处理最近N小时内创建的、未处理的记录
            query = db.query(VideoRecord).filter(
                VideoRecord.llm_status.is_(None),  # 只查询NULL状态
                VideoRecord.created_at >= time_threshold,
                ~VideoRecord.id.in_(self._processing_records)
            )
            
            # 添加重试时间过滤：要么没有设置重试时间，要么重试时间已到
            from sqlalchemy import or_
            
            # 先查看重试时间过滤前的记录数
            before_retry_filter = query.count()
            logger.info(f"排除处理中后: {before_retry_filter} 条记录")
            
            query = query.filter(
                or_(
                    VideoRecord.llm_next_retry_at.is_(None),  # 首次处理
                    VideoRecord.llm_next_retry_at <= current_time  # 重试时间已到
                )
            )
            
            after_retry_filter = query.count()
            logger.info(f"重试时间过滤后: {after_retry_filter} 条记录")
            
            records = query.order_by(VideoRecord.created_at.asc()).limit(10).all()
            logger.info(f"最终获取 {len(records)} 条待处理记录")
            
            # 如果没有记录，检查一下具体的重试时间情况
            if not records and before_retry_filter > 0:
                retry_check = db.query(VideoRecord).filter(
                    VideoRecord.llm_status.is_(None),  # 查询NULL状态的记录
                    VideoRecord.created_at >= time_threshold,
                    ~VideoRecord.id.in_(self._processing_records),
                    VideoRecord.llm_next_retry_at.is_not(None)
                ).limit(3).all()
                
                for record in retry_check:
                    logger.info(f"记录 {record.id}: retry_at={record.llm_next_retry_at}, current={current_time}, can_retry={record.llm_next_retry_at <= current_time if record.llm_next_retry_at else True}")
            
            if records:
                for record in records[:3]:  # 只打印前3条
                    logger.debug(f"  记录 {record.id}: {record.file_name}, 创建时间: {record.created_at}")
            
            return records
        finally:
            db.close()

    def _process_record_async(self, record: VideoRecord):
        """异步处理单个记录"""
        def process_task():
            try:
                self._processing_records.add(record.id)
                logger.info(f"开始处理 LLM 分析任务: {record.id} - {record.file_name}")
                
                # 不写入processing状态，保持NULL直到完成
                # 只记录开始时间用于超时检测（但不持久化到数据库）
                
                # 调用 LLM 分析
                result = self._analyze_video_record(record)
                
                # 更新结果
                self._update_analysis_result(record.id, result)
                
                logger.info(f"LLM 分析完成: {record.id}, 费用: {result.get('cost', 0):.4f}元")
                
            except Exception as e:
                logger.error(f"LLM 分析失败: {record.id}, 错误: {e}")
                self._handle_processing_error(record.id, e)
            finally:
                self._processing_records.discard(record.id)
        
        # 启动后台线程处理
        threading.Thread(target=process_task, daemon=True).start()

    def _analyze_video_record(self, record: VideoRecord) -> Dict[str, Any]:
        """分析视频记录"""
        # 1. 获取分析参数
        params = self._get_analysis_params(record)
        
        # 2. 调用 DashScope API
        ds_service = self.get_dashscope_service()
        api_result = ds_service.analyze_video(
            video_path=record.file_path,
            prompt=params['prompt'],
            fps=params['fps'],
            max_pixels=params['max_pixels'],
            min_pixels=params['min_pixels'],
            vl_high_resolution_images=params['vl_high_resolution_images'],
            model_name=params['model_name']
        )
        
        if not api_result['success']:
            raise Exception(f"API call failed: {api_result.get('error')}")
        
        # 3. 计算成本
        estimate_service = self.get_estimate_service()
        input_cost_breakdown = estimate_service.calculate_cost_with_breakdown(
            api_result['input_tokens'], is_input=True
        )
        output_cost_breakdown = estimate_service.calculate_cost_with_breakdown(
            api_result['output_tokens'], is_input=False
        )
        total_cost = input_cost_breakdown['total_cost'] + output_cost_breakdown['total_cost']
        
        return {
            'input_tokens': api_result['input_tokens'],
            'output_tokens': api_result['output_tokens'],
            'total_tokens': api_result['total_tokens'],
            'cost': total_cost,
            'duration_sec': api_result['duration_sec'],
            'model_response': api_result['model_response'],
            'prompt_id': params.get('prompt_id'),
            'prompt': params.get('prompt'),  # 包含替换后的完整提示词
            'model_name': params.get('model_name')  # 包含使用的模型名称
        }

    def _get_analysis_params(self, record: VideoRecord) -> Dict[str, Any]:
        """获取分析参数"""
        db = SessionLocal()
        try:
            # 1. 获取用户 did
            did = self._get_user_did(record, db)
            
            # 2. 获取提示词
            prompt, prompt_id = self._get_default_prompt(did, db)
            
            # 3. 替换提示词中的变量
            prompt = self._replace_prompt_variables(prompt, did, db)
            
            # 4. 返回分析配置
            return {
                'prompt': prompt,
                'prompt_id': prompt_id,
                'fps': getattr(settings, 'auto_analysis_fps', 1.0),
                'max_pixels': getattr(settings, 'auto_analysis_max_pixels', 640 * 32 * 32),
                'min_pixels': getattr(settings, 'auto_analysis_min_pixels', 4 * 32 * 32),
                'model_name': getattr(settings, 'auto_analysis_model', 'qwen3-vl-plus'),
                'vl_high_resolution_images': getattr(settings, 'auto_analysis_high_res', False)
            }
        finally:
            db.close()

    def _get_user_did(self, record: VideoRecord, db: Session) -> str:
        """获取用户 did"""
        if record.did and record.did != "0":
            return record.did
        
        # 从 source_id 获取 did
        if record.source_id:
            source = db.query(StreamSource).filter(StreamSource.id == record.source_id).first()
            if source and source.did:
                return source.did
        
        return "0"  # 默认用户

    def _replace_prompt_variables(self, prompt: str, did: str, db: Session) -> str:
        """替换提示词中的变量"""
        if not prompt or '{{' not in prompt:
            return prompt
            
        # 替换 {{pets_info_list}} 变量
        if '{{pets_info_list}}' in prompt:
            pets_info = self._get_pets_info(did, db)
            prompt = prompt.replace('{{pets_info_list}}', pets_info)
            
        return prompt

    def _get_pets_info(self, did: str, db: Session) -> str:
        """获取宠物信息JSON字符串"""
        try:
            from models.database import Pet
            
            # 查询用户的宠物信息
            pets = db.query(Pet).filter(Pet.did == did).all()
            
            if not pets:
                return "[]"  # 没有宠物信息时返回空数组
                
            pets_list = []
            for pet in pets:
                pet_info = {
                    "pet_name": pet.pet_name,
                    "pet_type": pet.pet_type,
                    "breed": pet.breed,
                    "gender": pet.gender,
                    "weight": pet.weight,
                    "color": pet.color,
                    "avatar_color": pet.avatar_color,
                    "description": pet.description,
                    "id": pet.id,
                    "age": getattr(pet, 'age', None)  # age字段可能不存在
                }
                pets_list.append(pet_info)
                
            import json
            return json.dumps(pets_list, ensure_ascii=False, indent=2)
            
        except Exception as e:
            logger.error(f"获取宠物信息失败: {e}")
            return "[]"

    def _get_default_prompt(self, did: str, db: Session) -> tuple[str, Optional[int]]:
        """获取默认提示词"""
        # 查找系统默认提示词（暂时忽略用户级别的提示词，因为Prompt模型没有did字段）
        system_prompt = db.query(Prompt).filter(
            Prompt.is_default == True,
            Prompt.is_active == True,
            Prompt.deleted == False
        ).first()
        
        if system_prompt:
            return system_prompt.content, system_prompt.id
        
        # 如果没有默认提示词，返回第一个可用的提示词
        first_prompt = db.query(Prompt).filter(
            Prompt.is_active == True,
            Prompt.deleted == False
        ).first()
        
        if first_prompt:
            return first_prompt.content, first_prompt.id
        
        # 使用固定提示词
        default_prompt = """请分析这个宠物视频，描述宠物的行为和状态。重点关注：
1. 宠物的种类和外观特征
2. 宠物的行为动作（如睡觉、玩耍、进食等）
3. 宠物的情绪状态
4. 环境和背景信息

请用简洁的中文回答。"""
        
        return default_prompt, None

    def _update_status(self, record_id: int, status: str, **kwargs):
        """更新记录状态"""
        db = SessionLocal()
        try:
            record = db.query(VideoRecord).filter(VideoRecord.id == record_id).first()
            if record:
                record.llm_status = status
                for key, value in kwargs.items():
                    if hasattr(record, key):
                        setattr(record, key, value)
                db.commit()
        finally:
            db.close()

    def _update_analysis_result(self, record_id: int, result: Dict[str, Any]):
        """更新分析结果"""
        db = SessionLocal()
        try:
            logger.info(f"开始更新任务 {record_id} 的分析结果")
            record = db.query(VideoRecord).filter(VideoRecord.id == record_id).first()
            if record:
                logger.info(f"找到记录 {record_id}，当前状态: {record.llm_status}")
                record.llm_status = 'completed'
                record.llm_completed_at = datetime.now()
                record.llm_error = None  # 清除错误信息
                record.llm_next_retry_at = None  # 清除重试时间
                record.input_tokens = result['input_tokens']
                record.output_tokens = result['output_tokens']
                record.total_tokens = result['total_tokens']
                record.analysis_cost = result['cost']
                record.analysis_duration_sec = result['duration_sec']
                record.llm_result = result['model_response']
                record.llm_raw_response = result['model_response']
                record.llm_prompt_id = result.get('prompt_id')
                # 存储替换后的完整提示词
                if result.get('prompt'):
                    record.prompt = result['prompt']
                # 存储使用的模型名称
                if result.get('model_name'):
                    record.model_name = result['model_name']
                
                # 解析LLM结果并存储到pet_behaviors表
                self._parse_and_store_pet_behaviors(record_id, result['model_response'], record.did, db)
                
                db.commit()
                logger.info(f"任务 {record_id} 状态已更新为 completed")
                
                # 触发 Push 推送（异步，不阻塞主流程）
                self._trigger_push_notification(record_id, db)
            else:
                logger.error(f"未找到记录 {record_id}")
        except Exception as e:
            logger.error(f"更新任务 {record_id} 结果时发生异常: {str(e)}")
            db.rollback()
            raise
        finally:
            db.close()

    def _handle_processing_error(self, record_id: int, error: Exception):
        """处理分析错误"""
        db = SessionLocal()
        try:
            record = db.query(VideoRecord).filter(VideoRecord.id == record_id).first()
            if record:
                record.llm_retry_count += 1
                record.llm_error = str(error)
                
                # 判断是否需要重试
                if record.llm_retry_count <= self.MAX_RETRIES:
                    # 设置下次重试时间，使用延迟数组中的对应值，如果超出数组长度则使用最后一个值
                    retry_delays = self.get_retry_delays()
                    retry_index = min(record.llm_retry_count - 1, len(retry_delays) - 1)
                    retry_delay = retry_delays[retry_index]
                    record.llm_next_retry_at = datetime.now() + timedelta(seconds=retry_delay)
                    record.llm_status = None  # 重新排队（NULL状态）
                    logger.info(f"任务 {record_id} 将在 {retry_delay} 秒后重试 (第 {record.llm_retry_count}/{self.MAX_RETRIES} 次)")
                else:
                    # 超过重试次数，标记为完成（带错误信息）
                    record.llm_status = 'completed'
                    record.llm_next_retry_at = None  # 清除重试时间
                    logger.error(f"任务 {record_id} 重试次数已达上限 ({self.MAX_RETRIES})，标记为完成（失败）")
                
                db.commit()
        finally:
            db.close()

    def trigger_immediate_processing(self):
        """触发立即处理（用于手动干预）"""
        if not self.is_running():
            raise Exception("LLM Worker 未运行，无法触发处理")
        
        logger.info("手动触发 LLM 队列处理")
        
        try:
            # 立即执行一次处理循环，不等待轮询间隔
            pending_records = self._get_pending_records()
            
            if not pending_records:
                logger.info("队列中没有待处理的记录")
                return
            
            # 检查可用处理槽位
            available_slots = self.MAX_CONCURRENT_TASKS - len(self._processing_records)
            if available_slots <= 0:
                logger.info(f"所有处理槽位已满 ({len(self._processing_records)}/{self.MAX_CONCURRENT_TASKS})")
                return
            
            # 处理可用的任务
            tasks_to_process = pending_records[:available_slots]
            processed_count = 0
            
            for record in tasks_to_process:
                try:
                    self._process_record_async(record)
                    processed_count += 1
                except Exception as e:
                    logger.error(f"启动任务 {record.id} 处理失败: {e}")
            
            logger.info(f"手动触发处理完成，启动了 {processed_count} 个任务")
            
        except Exception as e:
            logger.error(f"手动触发处理失败: {e}")
            raise

    def _parse_and_store_pet_behaviors(self, video_id: int, llm_response: str, did: str, db: Session):
        """解析LLM响应并存储到pet_behaviors表"""
        try:
            logger.info(f"开始解析视频 {video_id} 的LLM响应并存储到pet_behaviors表")
            
            # 清理响应文本，移除可能的markdown代码块标记
            cleaned_response = llm_response.strip()
            if cleaned_response.startswith('```json'):
                cleaned_response = cleaned_response[7:]
            if cleaned_response.endswith('```'):
                cleaned_response = cleaned_response[:-3]
            cleaned_response = cleaned_response.strip()
            
            # 解析JSON
            try:
                behaviors_data = json.loads(cleaned_response)
            except json.JSONDecodeError as e:
                logger.warning(f"视频 {video_id} LLM响应不是有效的JSON格式: {e}")
                logger.debug(f"原始响应: {llm_response[:200]}...")
                return
            
            # 确保是列表格式
            if not isinstance(behaviors_data, list):
                logger.warning(f"视频 {video_id} LLM响应不是列表格式")
                return
            
            # 先删除该视频的旧记录（如果存在）
            deleted_count = db.query(PetBehavior).filter(PetBehavior.video_id == video_id).delete()
            if deleted_count > 0:
                logger.info(f"删除视频 {video_id} 的 {deleted_count} 条旧行为记录")
            
            # 使用集合去重，避免LLM返回重复的宠物名
            processed_pets = set()
            
            # 解析每只宠物的行为数据
            for behavior_item in behaviors_data:
                if not isinstance(behavior_item, dict):
                    continue
                
                pet_name = behavior_item.get('id', '').strip()
                if not pet_name:
                    continue
                
                # 检查是否已处理过该宠物（去重）
                if pet_name in processed_pets:
                    logger.warning(f"视频 {video_id} 的LLM响应中宠物 {pet_name} 重复，跳过")
                    continue
                processed_pets.add(pet_name)
                
                # 处理actions字段（将列表转为逗号分隔的字符串）
                actions_list = behavior_item.get('act', [])
                if isinstance(actions_list, list):
                    actions_str = ','.join(actions_list)
                else:
                    actions_str = str(actions_list) if actions_list else ''
                
                # 创建PetBehavior记录
                pet_behavior = PetBehavior(
                    video_id=video_id,
                    pet_name=pet_name,
                    did=did,
                    actions=actions_str,
                    description=behavior_item.get('desc', ''),
                    status=behavior_item.get('stat', ''),
                    location=behavior_item.get('location', ''),
                    score=behavior_item.get('score'),
                    raw_result=json.dumps(behavior_item, ensure_ascii=False),
                    created_at=datetime.now(),
                    updated_at=datetime.now()
                )
                
                db.add(pet_behavior)
                logger.info(f"为视频 {video_id} 添加宠物 {pet_name} 的行为记录")
            
            logger.info(f"视频 {video_id} 的宠物行为数据解析和存储完成")
            
        except Exception as e:
            logger.error(f"解析和存储视频 {video_id} 的宠物行为数据时发生异常: {e}")
            # 不抛出异常，避免影响主流程
            import traceback
            logger.debug(f"详细错误信息: {traceback.format_exc()}")

    def _trigger_push_notification(self, video_id: int, db: Session):
        """
        触发 Push 推送通知（异步，不阻塞主流程）
        
        Args:
            video_id: 视频 ID
            db:       数据库 Session（未使用，保持签名兼容性）
        """
        try:
            from services.push_notification_service import trigger_push_async
            trigger_push_async(video_id)  # 不传 db，后台线程自己创建 Session
            logger.debug(f"已触发 Push 推送任务: video_id={video_id}")
        except Exception as e:
            # 推送失败不影响分析流程
            logger.error(f"触发 Push 推送失败: video_id={video_id}, error={e}")

# 全局实例
llm_worker_service = LLMWorkerService()