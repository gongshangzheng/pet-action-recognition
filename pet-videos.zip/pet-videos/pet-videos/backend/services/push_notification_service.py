"""
Push 推送通知服务

负责检测宠物行为并触发 App Push 通知，包含：
- 推送总开关：PUSH_ENABLED（默认 False，上线后改为 True）
- 静默时段控制（23:00-06:00 不推送）
- 推送冷却机制（同一宠物 1 小时内只推 1 次）
- 智能选择策略（多只宠物时推 score 最高的）

注意：
  当 PUSH_ENABLED=False 时，推送逻辑会正常执行（冷却检查、智能选择等），
  但不会真正调用消息服务，直接返回成功并更新 push_sent_at，便于测试。
"""

import asyncio
import logging
import sys
import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Optional
from sqlalchemy.orm import Session

# 添加 service 目录到模块搜索路径（用于导入 push_service）
service_dir = Path(__file__).parent.parent.parent / "service"
if str(service_dir) not in sys.path:
    sys.path.insert(0, str(service_dir))

from models.database import PetBehavior

logger = logging.getLogger(__name__)
push_detail_logger = logging.getLogger("push_detail")  # 独立 Push 详细日志

# 推送配置
PUSH_ENABLED = True             # Push 推送总开关
PUSH_COOLDOWN_MINUTES = 60      # 推送冷却：1小时
QUIET_HOURS_START = 23          # 静默时段开始：23:00
QUIET_HOURS_END = 6             # 静默时段结束：06:00


def is_quiet_hours() -> bool:
    """
    判断当前是否在静默时段（23:00-06:00）
    
    Returns:
        True 表示在静默时段，不应推送
    """
    current_hour = datetime.now().hour
    
    # 23:00 - 23:59 或 00:00 - 05:59
    if current_hour >= QUIET_HOURS_START or current_hour < QUIET_HOURS_END:
        return True
    
    return False


def should_send_push(behavior: PetBehavior, db: Session) -> bool:
    """
    判断是否应该发送 Push（检查冷却时间）
    
    Args:
        behavior: 宠物行为记录
        db:       数据库 Session
        
    Returns:
        True 表示可以推送
    """
    # 查询该宠物最近一次推送时间（任意 video_id 的记录）
    last_push = db.query(PetBehavior).filter(
        PetBehavior.did == behavior.did,
        PetBehavior.pet_name == behavior.pet_name,
        PetBehavior.push_sent_at.is_not(None)
    ).order_by(PetBehavior.push_sent_at.desc()).first()
    
    if not last_push:
        return True  # 从未推送过
    
    # 计算距上次推送的时间（分钟）
    elapsed_minutes = (datetime.now() - last_push.push_sent_at).total_seconds() / 60
    
    if elapsed_minutes < PUSH_COOLDOWN_MINUTES:
        logger.debug(
            f"[PushNotification] 跳过推送: {behavior.pet_name} 冷却中 "
            f"({elapsed_minutes:.1f}/{PUSH_COOLDOWN_MINUTES} 分钟)"
        )
        return False
    
    return True


def select_best_behavior(behaviors: List[PetBehavior], db: Session) -> Optional[PetBehavior]:
    """
    从多只宠物中选择最应该推送的那只（按 score 排序）
    
    策略：
    1. 过滤掉冷却中的宠物
    2. 按 score 降序排序，取最高的
    3. score 相同时按 pet_name 字典序
    
    Args:
        behaviors: 本次分析识别到的所有宠物行为
        db:        数据库 Session
        
    Returns:
        应该推送的行为记录，无符合条件的返回 None
    """
    if not behaviors:
        return None
    
    # 过滤：只保留非冷却期的宠物
    eligible = [b for b in behaviors if should_send_push(b, db)]
    
    push_detail_logger.info(
        f"[冷却过滤] 候选 {len(behaviors)} 只 -> 符合条件 {len(eligible)} 只\n"
        f"  过滤掉: {[b.pet_name for b in behaviors if b not in eligible]}"
    )
    
    if not eligible:
        logger.info("[PushNotification] 所有宠物均在冷却期，跳过推送")
        return None
    
    # 排序：score 降序（None 视为 0），相同 score 按 pet_name 字典序
    best = sorted(
        eligible,
        key=lambda b: (b.score if b.score is not None else 0, b.pet_name),
        reverse=True
    )[0]
    
    logger.info(
        f"[PushNotification] 选中推送目标: {best.pet_name} "
        f"(score={best.score}, 共{len(behaviors)}只宠物)"
    )
    push_detail_logger.info(
        f"[选择结果] 选中: {best.pet_name}, score={best.score}, actions={best.actions}\n"
        f"  排序依据: {json.dumps([{'pet_name': b.pet_name, 'score': b.score} for b in eligible], ensure_ascii=False)}"
    )
    
    return best


async def send_push_for_behavior(behavior: PetBehavior, db: Session) -> bool:
    """
    为指定宠物行为发送 Push 通知（异步）
    
    Args:
        behavior: 要推送的宠物行为
        db:       数据库 Session
        
    Returns:
        True 表示推送成功
    """
    try:
        # 检查推送总开关
        if not PUSH_ENABLED:
            logger.info(
                f"[PushNotification] Push 功能未启用，跳过推送: "
                f"did={behavior.did}, pet={behavior.pet_name} "
                f"(PUSH_ENABLED=False)"
            )
            # 仍然更新推送时间（模拟发送成功，防止冷却失效）
            behavior.push_sent_at = datetime.now()
            db.commit()
            return True
        
        # 动态导入 push_service（避免循环依赖）
        from push_service import send_push_by_did
        
        # 提取模板参数
        actions = behavior.actions.split(',') if behavior.actions else []
        action = actions[0] if actions else "活动"
        
        template_params = {
            "PET_NAME":               behavior.pet_name,
            "PET_ACTION":             action,
            "PET_ACTION_DESCRIPTION": behavior.description or f"{behavior.pet_name}正在{action}",
        }
        
        logger.info(
            f"[PushNotification] 发送 Push: did={behavior.did}, "
            f"pet={behavior.pet_name}, action={action}"
        )
        
        push_detail_logger.info(
            f"[开始发送] video_id={behavior.video_id}, did={behavior.did}, pet={behavior.pet_name}\n"
            f"  模板: PET_ACTION_NOTICE\n"
            f"  参数: {json.dumps(template_params, ensure_ascii=False)}"
        )
        
        # 发送 Push（生产环境走 BNS）
        result = await send_push_by_did(
            did=behavior.did,
            template_code="PET_ACTION_NOTICE",
            template_params=template_params,
            verbose=False,
        )
        
        if result["success"]:
            # 更新推送时间（异步写入）
            behavior.push_sent_at = datetime.now()
            db.commit()
            
            logger.info(
                f"[PushNotification] Push 发送成功: {behavior.pet_name} "
                f"(video_id={behavior.video_id})"
            )
            push_detail_logger.info(
                f"[发送成功] video_id={behavior.video_id}, pet={behavior.pet_name}, did={behavior.did}\n"
                f"  push_sent_at={behavior.push_sent_at.strftime('%Y-%m-%d %H:%M:%S')}"
            )
            return True
        else:
            logger.error(
                f"[PushNotification] Push 发送失败: {behavior.pet_name}, "
                f"error={result.get('error')}"
            )
            push_detail_logger.error(
                f"[发送失败] video_id={behavior.video_id}, pet={behavior.pet_name}, did={behavior.did}\n"
                f"  错误: {result.get('error')}\n"
                f"  code={result.get('result_code')}, msg={result.get('result_msg')}"
            )
            return False
            
    except Exception as e:
        logger.error(
            f"[PushNotification] Push 发送异常: {behavior.pet_name}, error={e}",
            exc_info=True
        )
        push_detail_logger.error(
            f"[发送异常] video_id={behavior.video_id}, pet={behavior.pet_name}, did={behavior.did}\n"
            f"  异常: {str(e)}",
            exc_info=True
        )
        return False


async def handle_video_analyzed(video_id: int, db: Session):
    """
    处理视频分析完成事件，决定是否发送 Push
    
    应在 LLM Worker 分析完成后调用（_update_analysis_result 之后）
    
    Args:
        video_id: 完成分析的视频 ID
        db:       数据库 Session
    """
    try:
        # 1. 检查静默时段
        if is_quiet_hours():
            logger.info(
                f"[PushNotification] 当前在静默时段，跳过推送 (video_id={video_id})"
            )
            return
        
        # 2. 查询该视频的所有宠物行为
        behaviors = db.query(PetBehavior).filter(
            PetBehavior.video_id == video_id
        ).all()
        
        if not behaviors:
            logger.debug(f"[PushNotification] 视频无宠物行为记录，跳过推送 (video_id={video_id})")
            return
        
        logger.info(
            f"[PushNotification] 视频分析完成，识别到 {len(behaviors)} 只宠物: "
            f"{[b.pet_name for b in behaviors]} (video_id={video_id})"
        )
        
        push_detail_logger.info(
            f"[视频分析完成] video_id={video_id}, 识别到 {len(behaviors)} 只宠物\n"
            f"  宠物列表: {json.dumps([{'pet_name': b.pet_name, 'score': b.score, 'actions': b.actions} for b in behaviors], ensure_ascii=False, indent=2)}"
        )
        
        # 3. 选择最应该推送的宠物（策略C：score 最高）
        best_behavior = select_best_behavior(behaviors, db)
        
        if not best_behavior:
            push_detail_logger.info(f"[决策结果] video_id={video_id}, 无符合条件的宠物（全在冷却期或静默时段）")
            return  # 无符合条件的宠物
        
        # 4. 发送 Push（异步）
        await send_push_for_behavior(best_behavior, db)
        
    except Exception as e:
        logger.error(
            f"[PushNotification] 处理视频分析事件失败: video_id={video_id}, error={e}",
            exc_info=True
        )
        push_detail_logger.error(
            f"[事件处理异常] video_id={video_id}\n"
            f"  异常: {str(e)}",
            exc_info=True
        )


def trigger_push_async(video_id: int):
    """
    触发异步 Push（同步包装，供非异步上下文调用）
    
    在后台任务中执行推送，不阻塞主流程
    
    Args:
        video_id: 视频 ID
    """
    def run_push():
        from models.db import SessionLocal
        
        # 后台线程中创建独立的 Session（避免跨线程共享）
        push_db = SessionLocal()
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(handle_video_analyzed(video_id, push_db))
        except Exception as e:
            logger.error(f"[PushNotification] 异步推送任务失败: video_id={video_id}, error={e}")
        finally:
            push_db.close()  # 确保 Session 关闭，释放连接
            loop.close()
    
    # 启动后台线程
    import threading
    threading.Thread(target=run_push, daemon=True).start()
