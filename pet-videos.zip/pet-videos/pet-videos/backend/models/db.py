"""数据库会话管理"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from pathlib import Path
from config import settings
import logging

logger = logging.getLogger(__name__)

# 确保数据库目录存在
database_dir = Path(settings.database_path).parent
database_dir.mkdir(parents=True, exist_ok=True)

# 打印数据库配置信息
logger.info(f"[Backend/DB] 数据库路径: {settings.database_path}")
logger.info(f"[Backend/DB] 数据库目录: {database_dir}")
logger.info(f"[Backend/DB] 数据库文件存在: {Path(settings.database_path).exists()}")

# 创建数据库引擎
engine = create_engine(
    f"sqlite:///{settings.database_path}",
    connect_args={"check_same_thread": False},  # SQLite 需要这个
    echo=False,  # 设置为 True 可以看到 SQL 语句
    pool_size=30,          # 核心连接数（默认5 → 30）
    max_overflow=20,       # 额外溢出连接（默认10 → 20）
    pool_timeout=60,       # 获取连接超时时间（默认30s → 60s）
    pool_recycle=3600,     # 连接回收时间：1小时（防止连接僵死）
    pool_pre_ping=True     # 使用前先 ping 检查连接是否存活
)

logger.info(f"[Backend/DB] 数据库引擎已创建: sqlite:///{settings.database_path}")

# 创建会话工厂
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)


def get_db() -> Session:
    """
    FastAPI 依赖函数，用于获取数据库会话
    
    使用方法：
        @app.get("/items")
        def read_items(db: Session = Depends(get_db)):
            return db.query(Item).all()
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """初始化数据库，创建所有表"""
    from database import Base
    Base.metadata.create_all(bind=engine)
