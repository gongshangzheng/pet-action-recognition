"""提示词数据库模型"""
from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()


class Prompt(Base):
    """提示词模板"""
    __tablename__ = "prompts"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    
    # 基本信息
    name = Column(String(100), nullable=False, index=True)  # 提示词名称/版本
    content = Column(Text, nullable=False)  # 提示词内容
    description = Column(String(500), nullable=True)  # 描述
    
    # 状态
    is_active = Column(Boolean, default=True, nullable=False)  # 是否启用
    is_default = Column(Boolean, default=False, nullable=False)  # 是否为默认
    
    # 时间戳
    created_at = Column(DateTime, nullable=False, default=datetime.now, index=True)
    updated_at = Column(DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)
    
    def __repr__(self):
        return f"<Prompt(id={self.id}, name={self.name}, is_default={self.is_default})>"
