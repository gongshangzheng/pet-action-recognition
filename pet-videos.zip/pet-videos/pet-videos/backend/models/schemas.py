"""Pydantic 数据模型"""
from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel, Field, field_validator


class VideoInfo(BaseModel):
    """视频信息模型"""
    id: int  # 唯一标识符（video_records 表的主键）
    filename: str
    dir_alias: str  # 目录别名（用于API请求）
    did: Optional[str] = None  # 关联的用户ID
    path: str  # 服务器本地路径（仅用于后端分析，不暴露给前端）
    stream_token: str  # 安全的流式传输token（用于播放）
    size_mb: float
    duration_sec: float
    duration_formatted: str
    resolution: str
    width: int
    height: int
    fps: float
    codec: str
    bitrate_mbps: float
    created_at: Optional[str] = None  # 视频创建时间（ISO格式）


class VideoListResponse(BaseModel):
    """视频列表响应"""
    videos: List[VideoInfo]
    total: int
    page: int
    page_size: int


class DailyStat(BaseModel):
    """每日统计模型"""
    date: str
    count: int


class DirectoryStat(BaseModel):
    """目录统计模型"""
    alias: str  # 目录别名
    name: str  # 显示名称
    daily_stats: List[DailyStat]


class DirectoryInfo(BaseModel):
    """目录信息模型"""
    alias: str  # 目录别名（用于API请求）
    name: str  # 显示名称
    video_count: int
    exists: bool
    did: Optional[str] = None  # 关联的用户ID


class EstimateRequest(BaseModel):
    """费用预估请求"""
    video_path: str
    fps: float = Field(ge=0.1, le=10.0)
    max_pixels: int
    min_pixels: int = 4 * 32 * 32
    prompt: str = ""
    vl_high_resolution_images: bool = False


class EstimateResponse(BaseModel):
    """费用预估响应"""
    frame_count: int
    tokens_per_frame: float
    video_tokens: int
    prompt_tokens: int
    total_input_tokens: int
    estimated_output_tokens: int
    estimated_total_tokens: int
    estimated_cost: float
    breakdown: Dict
    video_info: Optional[Dict] = None


class AnalysisRequest(BaseModel):
    """视频分析请求"""
    video_path: str
    prompt: str
    prompt_id: Optional[int] = None  # 提示词ID
    prompt_name: Optional[str] = None  # 提示词名称/版本
    model_name: str = 'qwen3-vl-plus'  # 模型名称
    fps: float = Field(ge=0.1, le=10.0)
    max_pixels: int
    min_pixels: int = 4 * 32 * 32
    vl_high_resolution_images: bool = False
    call_type: str = 'manual'  # manual: 手动调用, auto: 自动调用


class AnalysisResponse(BaseModel):
    """视频分析响应"""
    model_config = {
        "protected_namespaces": ()
    }
    id: int
    estimated: Dict
    actual: Dict
    model_response: str
    statistics: Dict


class HistoryRecord(BaseModel):
    """历史记录模型"""
    model_config = {
        "protected_namespaces": ()
    }
    id: int
    video_name: str
    dir_alias: Optional[str] = None  # 目录别名
    video_duration_sec: float
    prompt: str
    prompt_id: Optional[int] = None  # 提示词ID
    prompt_name: Optional[str] = None  # 提示词名称
    model_name: Optional[str] = None  # 模型名称
    call_type: str = 'manual'  # 调用类型
    llm_status: Optional[str] = None  # LLM处理状态（仅自动调用有效）
    fps: float
    max_pixels: int
    min_pixels: int
    vl_high_resolution_images: bool
    input_tokens: int
    output_tokens: int
    total_tokens: int
    cost: float
    duration_sec: float
    model_response: Optional[str] = None
    created_at: datetime


class HistoryDetail(BaseModel):
    """历史记录详情"""
    id: int
    video_name: str
    video_path: str
    dir_alias: Optional[str] = None  # 目录别名
    video_duration_sec: float
    prompt: str
    prompt_id: Optional[int] = None  # 提示词ID
    prompt_name: Optional[str] = None  # 提示词名称
    model_name: Optional[str] = None  # 模型名称
    call_type: str = 'manual'  # 调用类型
    fps: float
    max_pixels: int
    min_pixels: int
    vl_high_resolution_images: bool
    input_tokens: int
    output_tokens: int
    total_tokens: int
    cost: float
    duration_sec: float
    model_response: Optional[str]
    created_at: datetime


class HistoryListResponse(BaseModel):
    """历史记录列表响应"""
    records: List[HistoryRecord]
    total: int
    page: int
    page_size: int


class StreamSourceBase(BaseModel):
    """流配置基础模型"""
    name: str
    alias: str
    stream_url: str
    storage_path: str
    is_active: bool = True
    did: Optional[str] = None  # 用户ID（前端App添加的源有此字段）


class StreamSourceCreate(StreamSourceBase):
    """创建流配置"""
    pass


class StreamSourceUpdate(BaseModel):
    """更新流配置"""
    name: Optional[str] = None
    alias: Optional[str] = None
    stream_url: Optional[str] = None
    storage_path: Optional[str] = None
    is_active: Optional[bool] = None
    did: Optional[str] = None


class StreamSourceResponse(StreamSourceBase):
    """流配置响应"""
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class SlicingTaskBase(BaseModel):
    """切片任务基础模型"""
    source_id: int
    pid: Optional[int] = None
    status: str = 'stopped'
    script_file: str = 'pet_monitor.py'
    last_heartbeat: Optional[datetime] = None
    last_start_time: Optional[datetime] = None
    error_msg: Optional[str] = None
    consecutive_failures: int = 0
    enable_yolo: bool = True


class SlicingTaskResponse(SlicingTaskBase):
    """切片任务响应"""
    id: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class ScriptFileInfo(BaseModel):
    """脚本文件信息"""
    filename: str
    path: str
    description: Optional[str] = None


# ===== 视频记录相关模型 =====

class VideoRecordBase(BaseModel):
    """视频记录基础模型（统一管理手动分析和自动分析）"""
    source_id: int  # 手动调用时为0
    did: str = "0"  # 用户ID，手动调用时为"0"
    call_type: str = 'auto'  # auto: 自动调用, manual: 手动调用
    file_name: str
    file_path: str
    file_size: Optional[int] = None
    duration: Optional[float] = None
    width: Optional[int] = None
    height: Optional[int] = None
    fps: Optional[float] = None  # 视频原始帧率
    codec: Optional[str] = None
    detection_type: Optional[str] = None  # pet/motion
    # LLM 分析参数
    prompt: Optional[str] = None
    model_name: Optional[str] = None
    analysis_fps: Optional[float] = None  # 分析FPS
    max_pixels: Optional[int] = None
    min_pixels: Optional[int] = None
    vl_high_resolution_images: Optional[bool] = None
    # Token 统计和费用
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    total_tokens: Optional[int] = None
    analysis_cost: Optional[float] = None
    analysis_duration_sec: Optional[float] = None
    # LLM 任务队列
    llm_status: Optional[str] = None  # NULL表示待处理，processing表示处理中，completed表示已完成
    llm_prompt_id: Optional[int] = None
    llm_result: Optional[str] = None  # 结构化结果
    llm_raw_response: Optional[str] = None  # 原始返回
    llm_error: Optional[str] = None
    llm_analysis_id: Optional[int] = None
    llm_started_at: Optional[datetime] = None
    llm_completed_at: Optional[datetime] = None
    llm_retry_count: int = 0


class VideoRecordCreate(VideoRecordBase):
    """创建视频记录"""
    pass


class VideoRecordUpdate(BaseModel):
    """更新视频记录（主要用于 LLM 任务状态更新）"""
    did: Optional[str] = None
    call_type: Optional[str] = None
    prompt: Optional[str] = None
    model_name: Optional[str] = None
    analysis_fps: Optional[float] = None
    max_pixels: Optional[int] = None
    min_pixels: Optional[int] = None
    vl_high_resolution_images: Optional[bool] = None
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    total_tokens: Optional[int] = None
    analysis_cost: Optional[float] = None
    analysis_duration_sec: Optional[float] = None
    llm_status: Optional[str] = None
    llm_prompt_id: Optional[int] = None
    llm_result: Optional[str] = None
    llm_raw_response: Optional[str] = None
    llm_error: Optional[str] = None
    llm_analysis_id: Optional[int] = None
    llm_started_at: Optional[datetime] = None
    llm_completed_at: Optional[datetime] = None
    llm_retry_count: Optional[int] = None


class VideoRecordResponse(VideoRecordBase):
    """视频记录响应"""
    id: int
    recorded_at: datetime
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


# ===== 宠物信息相关模型 =====

class PetBase(BaseModel):
    """宠物信息基础模型"""
    pet_name: str = Field(..., min_length=1, max_length=100, description="宠物名称")
    pet_type: Optional[str] = Field(None, max_length=50, description="宠物类型（狗/猫/兔子等）")
    breed: Optional[str] = Field(None, max_length=100, description="品种")
    gender: Optional[str] = Field(None, max_length=10, description="性别（公/母）")
    birth_date: Optional[str] = Field(None, pattern=r'^\d{4}-\d{2}-\d{2}$', description="出生日期 YYYY-MM-DD")
    weight: Optional[float] = Field(None, gt=0, description="体重（单位：kg）")
    color: Optional[str] = Field(None, max_length=100, description="颜色/外观特征")
    avatar_url: Optional[str] = Field(None, max_length=500, description="头像URL")
    avatar_color: Optional[str] = Field(None, max_length=10, description="头像背景色")
    description: Optional[str] = Field(None, description="描述")

    @field_validator('birth_date', 'gender', 'pet_type', 'breed',
                     'color', 'avatar_url', 'avatar_color', 'description', mode='before')
    @classmethod
    def empty_str_to_none(cls, v):
        if v == '':
            return None
        return v


class PetCreate(PetBase):
    """创建宠物"""
    pass


class PetUpdate(BaseModel):
    """更新宠物（宠物名称不可修改）"""
    pet_type: Optional[str] = Field(None, max_length=50)
    breed: Optional[str] = Field(None, max_length=100)
    gender: Optional[str] = Field(None, max_length=10)
    birth_date: Optional[str] = Field(None, pattern=r'^\d{4}-\d{2}-\d{2}$')
    weight: Optional[float] = Field(None, gt=0)
    color: Optional[str] = Field(None, max_length=100)
    avatar_url: Optional[str] = Field(None, max_length=500)
    avatar_color: Optional[str] = Field(None, max_length=10)
    description: Optional[str] = None

    @field_validator('birth_date', 'gender', 'pet_type', 'breed',
                     'color', 'avatar_url', 'avatar_color', 'description', mode='before')
    @classmethod
    def empty_str_to_none(cls, v):
        if v == '':
            return None
        return v


class PetResponse(PetBase):
    """宠物信息响应"""
    id: int  # 自增ID
    did: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class PetListResponse(BaseModel):
    """宠物列表响应"""
    pets: List[PetResponse]
    total: int


# ==================== 日报相关 Schema ====================

class DailyReportBase(BaseModel):
    """日报基础模型"""
    pet_name: str = Field(..., max_length=100, description="宠物名称")
    summary: Optional[str] = Field(None, description="日报汇总内容（Markdown格式）")
    daily_tag: Optional[str] = Field(None, max_length=50, description="日报标签（如：精力过剩、岁月静好、饭桶）")
    insight_text: Optional[str] = Field(None, description="洞察建议")
    analysis_data: Optional[str] = Field(None, description="原始分析数据（JSON格式）")
    video_count: int = Field(default=0, description="分析的视频切片数量")
    total_duration: float = Field(default=0.0, description="总时长（秒）")


class DailyReportCreate(DailyReportBase):
    """创建日报"""
    did: str = Field(..., max_length=50, description="用户ID")
    date: str = Field(..., pattern=r'^\d{4}-\d{2}-\d{2}$', description="日期 YYYY-MM-DD")


class DailyReportUpdate(BaseModel):
    """更新日报（did、date、pet_name不可修改）"""
    summary: Optional[str] = None
    daily_tag: Optional[str] = None
    insight_text: Optional[str] = None
    analysis_data: Optional[str] = None
    video_count: Optional[int] = None
    total_duration: Optional[float] = None


class DailyReportResponse(DailyReportBase):
    """日报信息响应"""
    id: int  # 自增ID
    did: str
    date: str
    llm_request: Optional[str] = None  # LLM请求的原始提示词
    llm_response: Optional[str] = None  # LLM返回的原始JSON
    generation_status: str  # pending/processing/completed/failed
    error_message: Optional[str] = None
    retry_count: int = 0
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class DailyReportListResponse(BaseModel):
    """日报列表响应"""
    reports: List[DailyReportResponse]
    total: int
