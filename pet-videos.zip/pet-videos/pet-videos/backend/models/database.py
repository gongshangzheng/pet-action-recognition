"""SQLAlchemy 数据库模型"""
from sqlalchemy import Column, Integer, String, Float, DateTime, Text, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()


class Prompt(Base):
    """提示词模板"""
    __tablename__ = "prompts"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    
    # 基本信息
    name = Column(String(100), nullable=False, index=True)  # 提示词名称/版本
    content = Column(Text, nullable=False)  # 提示词内容
    description = Column(String(500), nullable=True)  # 描述
    
    # 状态
    is_active = Column(Boolean, default=True, nullable=False)  # 是否启用
    is_default = Column(Boolean, default=False, nullable=False)  # 是否为默认
    deleted = Column(Boolean, default=False, nullable=False, index=True)  # 是否已删除（假删除）
    
    # 时间戳
    created_at = Column(DateTime, nullable=False, default=datetime.now, index=True)
    updated_at = Column(DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)
    
    def __repr__(self):
        return f"<Prompt(id={self.id}, name={self.name}, is_default={self.is_default})>"


class AnalysisHistory(Base):
    """视频分析历史记录"""
    __tablename__ = "analysis_history"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    
    # 视频信息
    video_name = Column(String(500), nullable=False, index=True)
    video_path = Column(String(1000), nullable=False)
    dir_alias = Column(String(100), nullable=True, index=True)  # 目录别名（v1.2.0新增）
    video_duration_sec = Column(Float, nullable=False)
    
    # 调用参数
    prompt = Column(Text, nullable=False)
    prompt_id = Column(Integer, nullable=True, index=True)  # 提示词ID（v1.4.0新增）
    prompt_name = Column(String(100), nullable=True)  # 提示词名称/版本（v1.4.0新增）
    model_name = Column(String(100), nullable=True, index=True, default='qwen3-vl-plus')  # 模型名称
    fps = Column(Float, nullable=False)
    max_pixels = Column(Integer, nullable=False)
    min_pixels = Column(Integer, nullable=False)
    vl_high_resolution_images = Column(Boolean, nullable=False, default=False)
    
    # Token 和费用
    input_tokens = Column(Integer, nullable=False)
    output_tokens = Column(Integer, nullable=False)
    total_tokens = Column(Integer, nullable=False)
    cost = Column(Float, nullable=False)
    
    # 执行信息
    duration_sec = Column(Float, nullable=False)
    model_response = Column(Text, nullable=True)
    
    # 调用类型（v1.3.0新增）
    call_type = Column(String(20), nullable=False, default='manual', index=True)  # manual: 手动调用, auto: 自动调用
    
    # 时间戳
    created_at = Column(DateTime, nullable=False, default=datetime.now, index=True)
    
    def __repr__(self):
        return f"<AnalysisHistory(id={self.id}, video={self.video_name}, cost={self.cost})>"


class StreamSource(Base):
    """用户流配置表"""
    __tablename__ = "stream_sources"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(100), nullable=False, index=True)  # 用户名称
    alias = Column(String(100), nullable=False, unique=True, index=True)  # 唯一别名
    stream_url = Column(String(1000), nullable=False)  # 流地址
    storage_path = Column(String(1000), nullable=False)  # 存储目录
    is_active = Column(Boolean, default=True, nullable=False)  # 是否启用
    did = Column(String(50), nullable=True, index=True)  # 用户ID（前端App添加的源有此字段）
    
    created_at = Column(DateTime, nullable=False, default=datetime.now)
    updated_at = Column(DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)

    def __repr__(self):
        return f"<StreamSource(id={self.id}, name={self.name}, alias={self.alias}, did={self.did})>"


class SlicingTask(Base):
    """切片任务表"""
    __tablename__ = "slicing_tasks"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    source_id = Column(Integer, nullable=False, index=True)  # 关联 stream_sources.id
    pid = Column(Integer, nullable=True)  # 进程 ID
    status = Column(String(20), default='stopped', index=True, nullable=False)  # running, stopped, error
    script_file = Column(String(200), nullable=False, default='pet_monitor.py')  # 脚本文件名
    last_heartbeat = Column(DateTime, nullable=True)  # 最近一次心跳时间
    last_start_time = Column(DateTime, nullable=True)  # 最近启动时间
    error_msg = Column(Text, nullable=True)  # 异常信息
    consecutive_failures = Column(Integer, default=0, nullable=False)  # 连续失败次数
    enable_yolo = Column(Boolean, default=True, nullable=False)  # 是否启用YOLO检测
    
    created_at = Column(DateTime, nullable=False, default=datetime.now)
    updated_at = Column(DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)

    def __repr__(self):
        return f"<SlicingTask(id={self.id}, source_id={self.source_id}, status={self.status})>"


class VideoRecord(Base):
    """视频切片记录表（自动分析）"""
    __tablename__ = "video_records"
    
    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    source_id = Column(Integer, nullable=False, index=True)  # 关联 stream_sources.id，手动调用时为0
    
    # 用户信息（从 stream_sources 获取）
    did = Column(String(50), nullable=False, default="0", index=True)  # 用户ID
    
    # 文件信息（不存储 mp4 文件本身，只存储路径和元信息）
    file_name = Column(String(500), nullable=False, index=True)  # 文件名
    file_path = Column(String(1000), nullable=False)  # 完整路径
    file_size = Column(Integer, nullable=True)  # 文件大小（字节）
    thumbnail_path = Column(String(1000), nullable=True)  # 缩略图文件路径
    
    # 视频元信息
    duration = Column(Float, nullable=True)  # 时长（秒）
    width = Column(Integer, nullable=True)  # 宽度
    height = Column(Integer, nullable=True)  # 高度
    fps = Column(Float, nullable=True)  # 视频原始帧率
    codec = Column(String(50), nullable=True)  # 编码格式
    
    # 检测信息
    detection_type = Column(String(20), nullable=True)  # pet/motion - 检测类型
    
    # LLM 分析参数（v2.0 统一）
    prompt = Column(Text, nullable=True)  # 提示词内容
    model_name = Column(String(100), nullable=True, index=True)  # 模型名称
    analysis_fps = Column(Float, nullable=True)  # 分析FPS（区别于视频原始fps）
    max_pixels = Column(Integer, nullable=True)  # 最大像素
    min_pixels = Column(Integer, nullable=True)  # 最小像素
    vl_high_resolution_images = Column(Boolean, nullable=True)  # 高分辨率模式
    
    # LLM Token 统计和费用（v2.0 统一）
    input_tokens = Column(Integer, nullable=True)  # 输入Token数
    output_tokens = Column(Integer, nullable=True)  # 输出Token数
    total_tokens = Column(Integer, nullable=True)  # 总Token数
    analysis_cost = Column(Float, nullable=True)  # 分析费用（元）
    analysis_duration_sec = Column(Float, nullable=True)  # LLM执行耗时（秒）
    
    # LLM 任务队列字段
    llm_status = Column(String(20), default=None, index=True, nullable=True)  # None(未处理), processing, completed, failed
    llm_prompt_id = Column(Integer, nullable=True, index=True)  # 使用的提示词 ID
    llm_result = Column(Text, nullable=True)  # LLM 结构化分析结果（兼容保留）
    llm_raw_response = Column(Text, nullable=True)  # LLM 完整原始返回（JSON格式）
    llm_error = Column(Text, nullable=True)  # LLM 分析错误信息
    llm_analysis_id = Column(Integer, nullable=True, index=True)  # 关联 analysis_history.id（可废弃）
    llm_started_at = Column(DateTime, nullable=True)  # LLM 开始处理时间
    llm_completed_at = Column(DateTime, nullable=True)  # LLM 处理完成时间
    llm_retry_count = Column(Integer, default=0, nullable=False)  # 重试次数
    llm_next_retry_at = Column(DateTime, nullable=True)  # 下次重试时间
    
    # 时间戳
    recorded_at = Column(DateTime, nullable=False, default=datetime.now, index=True)  # 录制时间
    created_at = Column(DateTime, nullable=False, default=datetime.now)
    updated_at = Column(DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)

    def __repr__(self):
        return f"<VideoRecord(id={self.id}, did={self.did}, call_type={self.call_type}, llm_status={self.llm_status})>"


class Pet(Base):
    """宠物信息表"""
    __tablename__ = "pets"
    
    # 主键
    id = Column(Integer, primary_key=True, autoincrement=True)  # 自增ID
    
    # 用户和宠物信息（did+pet_name保持唯一）
    did = Column(String(50), nullable=False, index=True)  # 用户ID
    pet_name = Column(String(100), nullable=False, index=True)  # 宠物名称
    
    # 宠物信息
    pet_type = Column(String(50), nullable=True)  # 宠物类型（狗/猫/兔子等）
    breed = Column(String(100), nullable=True)  # 品种
    gender = Column(String(10), nullable=True)  # 性别（公/母）
    birth_date = Column(String(10), nullable=True)  # 出生日期 YYYY-MM-DD
    weight = Column(Float, nullable=True)  # 体重（单位：kg）
    color = Column(String(100), nullable=True)  # 颜色/外观特征
    avatar_url = Column(String(500), nullable=True)  # 头像URL
    avatar_color = Column(String(10), nullable=True)  # 头像背景色
    description = Column(Text, nullable=True)  # 描述
    
    # 时间戳
    created_at = Column(DateTime, nullable=False, default=datetime.now)
    updated_at = Column(DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)

    def __repr__(self):
        return f"<Pet(id={self.id}, did={self.did}, pet_name={self.pet_name}, pet_type={self.pet_type})>"


class PetBehavior(Base):
    """宠物行为记录表"""
    __tablename__ = "pet_behaviors"
    
    # 联合主键
    video_id = Column(Integer, ForeignKey("video_records.id"), primary_key=True, nullable=False, index=True)
    pet_name = Column(String(100), primary_key=True, nullable=False, index=True)
    
    # 冗余字段，便于按用户查询
    did = Column(String(50), nullable=False, index=True)
    
    # LLM 分析结果字段
    actions = Column(String(200), nullable=True)  # 逗号分隔: "休息,玩耍"
    description = Column(Text, nullable=True)  # 描述
    status = Column(String(200), nullable=True)  # 状态
    location = Column(String(200), nullable=True)  # 位置
    score = Column(Integer, nullable=True)  # 评分
    
    # 完整原始结果（JSON格式）
    raw_result = Column(Text, nullable=True)
    
    # Push 推送记录
    push_sent_at = Column(DateTime, nullable=True, index=True)  # 最近一次推送时间
    
    # 时间戳
    created_at = Column(DateTime, nullable=False, default=datetime.now)
    updated_at = Column(DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)

    def __repr__(self):
        return f"<PetBehavior(video_id={self.video_id}, pet_name={self.pet_name}, score={self.score})>"


# 向后兼容别名
VideoPetAnalysis = PetBehavior


class BehaviorFeedback(Base):
    """宠物行为反馈表（点赞/点踩）"""
    __tablename__ = "behavior_feedback"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    video_id = Column(Integer, ForeignKey("video_records.id"), nullable=False, index=True)
    pet_name = Column(String(100), nullable=False, index=True)
    did = Column(String(50), nullable=False, index=True)
    action = Column(String(10), nullable=False)  # 'like' 或 'dislike'
    created_at = Column(DateTime, nullable=False, default=datetime.now)
    updated_at = Column(DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)

    def __repr__(self):
        return f"<BehaviorFeedback(id={self.id}, video_id={self.video_id}, pet_name={self.pet_name}, action={self.action})>"


class DailyReport(Base):
    """宠物日报表（每次LLM请求都记录，用于追踪）"""
    __tablename__ = "daily_reports"
    
    # 主键：自增ID
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    
    # 业务标识（did + date + pet_name 不再是主键，允许重复）
    did = Column(String(50), nullable=False, index=True)
    date = Column(String(10), nullable=False, index=True)  # YYYY-MM-DD
    pet_name = Column(String(100), nullable=False, index=True)
    
    # 日报内容（拆分字段）
    summary = Column(Text, nullable=True)  # LLM生成的日报汇总（Markdown格式，包含加粗的关键事件）
    daily_tag = Column(String(50), nullable=True)  # 日报标签（如：精力过剩、岁月静好、饭桶）
    insight_text = Column(Text, nullable=True)  # 洞察建议
    
    # 原始数据（用于追踪问题）
    llm_request = Column(Text, nullable=True)  # LLM请求的原始提示词
    llm_response = Column(Text, nullable=True)  # LLM返回的原始JSON
    analysis_data = Column(Text, nullable=True)  # 输入的分析数据（JSON格式）
    
    # 统计信息
    video_count = Column(Integer, default=0)  # 分析的视频切片数量
    total_duration = Column(Float, default=0.0)  # 总时长（秒）
    
    # 生成状态
    generation_status = Column(String(20), default='completed')  # pending/processing/completed/failed
    error_message = Column(Text, nullable=True)  # 错误信息
    retry_count = Column(Integer, default=0)  # 重试次数
    
    # 时间戳
    created_at = Column(DateTime, nullable=False, default=datetime.now, index=True)
    updated_at = Column(DateTime, nullable=False, default=datetime.now, onupdate=datetime.now)

    def __repr__(self):
        return f"<DailyReport(id={self.id}, did={self.did}, date={self.date}, pet_name={self.pet_name})>"


