"""提示词 Pydantic 模型"""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field


class PromptBase(BaseModel):
    """提示词基础模型"""
    name: str = Field(..., min_length=1, max_length=100, description="提示词名称")
    content: str = Field(..., min_length=1, description="提示词内容")
    description: Optional[str] = Field(None, max_length=500, description="描述")
    is_active: bool = Field(True, description="是否启用")


class PromptCreate(PromptBase):
    """创建提示词"""
    pass


class PromptUpdate(BaseModel):
    """更新提示词"""
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    content: Optional[str] = Field(None, min_length=1)
    description: Optional[str] = Field(None, max_length=500)
    is_active: Optional[bool] = None


class PromptResponse(PromptBase):
    """提示词响应"""
    id: int
    is_default: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class PromptListResponse(BaseModel):
    """提示词列表响应"""
    prompts: List[PromptResponse]
    total: int
