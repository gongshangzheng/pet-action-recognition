"""日报管理 API"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime
import logging

from models.db import get_db
from models.database import DailyReport
from models.schemas import (
    DailyReportCreate,
    DailyReportUpdate,
    DailyReportResponse,
    DailyReportListResponse
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/daily-reports", tags=["daily-reports"])
internal_router = APIRouter(prefix="/api/internal/daily-reports", tags=["daily-reports-internal"])


async def _get_daily_reports_impl(
    did: Optional[str],
    date: Optional[str],
    pet_name: Optional[str],
    db: Session
):
    """
    获取日报列表的内部实现（每只宠物只返回最新的一条）
    - 支持按 did、date、pet_name 过滤
    - 一只宠物一天可能有多条日报记录（用于追踪），但只返回最新的一条
    """
    try:
        # 使用子查询获取每只宠物的最新日报ID
        from sqlalchemy import func
        
        subquery = db.query(
            DailyReport.did,
            DailyReport.date,
            DailyReport.pet_name,
            func.max(DailyReport.id).label('max_id')
        )
        
        # 应用过滤条件到子查询
        if did:
            subquery = subquery.filter(DailyReport.did == did)
        if date:
            subquery = subquery.filter(DailyReport.date == date)
        if pet_name:
            subquery = subquery.filter(DailyReport.pet_name == pet_name)
        
        # 按 (did, date, pet_name) 分组，获取最新的ID
        subquery = subquery.group_by(
            DailyReport.did,
            DailyReport.date,
            DailyReport.pet_name
        ).subquery()
        
        # 主查询：使用 defer 延迟加载大字段
        from sqlalchemy.orm import defer
        
        reports = db.query(DailyReport)\
            .options(
                defer(DailyReport.llm_request),
                defer(DailyReport.llm_response),
                defer(DailyReport.analysis_data)
            )\
            .join(
                subquery,
                DailyReport.id == subquery.c.max_id
            ).order_by(DailyReport.created_at.desc()).all()
        
        return DailyReportListResponse(
            reports=reports,
            total=len(reports)
        )
    except Exception as e:
        logger.error(f"获取日报列表失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取日报列表失败: {str(e)}")


@router.get("/", response_model=DailyReportListResponse)
async def get_daily_reports(
    did: Optional[str] = Query(None, description="用户ID"),
    date: Optional[str] = Query(None, description="日期 YYYY-MM-DD"),
    pet_name: Optional[str] = Query(None, description="宠物名称"),
    db: Session = Depends(get_db)
):
    """获取日报列表（需要JWT认证）"""
    return await _get_daily_reports_impl(did, date, pet_name, db)


@internal_router.get("/", response_model=DailyReportListResponse)
async def get_daily_reports_internal(
    did: Optional[str] = Query(None, description="用户ID"),
    date: Optional[str] = Query(None, description="日期 YYYY-MM-DD"),
    pet_name: Optional[str] = Query(None, description="宠物名称"),
    db: Session = Depends(get_db)
):
    """获取日报列表（内部接口，无需JWT认证，供Service层调用）"""
    return await _get_daily_reports_impl(did, date, pet_name, db)


@router.get("/{did}/{date}/{pet_name}", response_model=DailyReportResponse)
async def get_daily_report(
    did: str,
    date: str,
    pet_name: str,
    db: Session = Depends(get_db)
):
    """获取指定日报"""
    report = db.query(DailyReport).filter(
        DailyReport.did == did,
        DailyReport.date == date,
        DailyReport.pet_name == pet_name
    ).first()
    
    if not report:
        raise HTTPException(
            status_code=404,
            detail=f"日报不存在: did={did}, date={date}, pet_name={pet_name}"
        )
    
    return report


@router.post("/", response_model=DailyReportResponse)
async def create_or_update_daily_report(
    report_data: DailyReportCreate,
    db: Session = Depends(get_db)
):
    """
    创建或更新日报（UPSERT）
    - 如果日报已存在（相同 did+date+pet_name），则更新
    - 否则创建新日报
    """
    try:
        # 查询是否已存在
        existing_report = db.query(DailyReport).filter(
            DailyReport.did == report_data.did,
            DailyReport.date == report_data.date,
            DailyReport.pet_name == report_data.pet_name
        ).first()
        
        if existing_report:
            # 更新现有日报
            existing_report.summary = report_data.summary
            existing_report.analysis_data = report_data.analysis_data
            existing_report.video_count = report_data.video_count
            existing_report.total_duration = report_data.total_duration
            existing_report.updated_at = datetime.now()
            
            db.commit()
            db.refresh(existing_report)
            
            logger.info(f"更新日报: did={report_data.did}, date={report_data.date}, pet_name={report_data.pet_name}")
            return existing_report
        else:
            # 创建新日报
            new_report = DailyReport(
                did=report_data.did,
                date=report_data.date,
                pet_name=report_data.pet_name,
                summary=report_data.summary,
                analysis_data=report_data.analysis_data,
                video_count=report_data.video_count,
                total_duration=report_data.total_duration
            )
            
            db.add(new_report)
            db.commit()
            db.refresh(new_report)
            
            logger.info(f"创建日报: did={report_data.did}, date={report_data.date}, pet_name={report_data.pet_name}")
            return new_report
            
    except Exception as e:
        db.rollback()
        logger.error(f"创建/更新日报失败: {e}")
        raise HTTPException(status_code=500, detail=f"创建/更新日报失败: {str(e)}")


@router.put("/{did}/{date}/{pet_name}", response_model=DailyReportResponse)
async def update_daily_report(
    did: str,
    date: str,
    pet_name: str,
    report_update: DailyReportUpdate,
    db: Session = Depends(get_db)
):
    """更新指定日报"""
    report = db.query(DailyReport).filter(
        DailyReport.did == did,
        DailyReport.date == date,
        DailyReport.pet_name == pet_name
    ).first()
    
    if not report:
        raise HTTPException(
            status_code=404,
            detail=f"日报不存在: did={did}, date={date}, pet_name={pet_name}"
        )
    
    try:
        # 只更新提供的字段
        update_data = report_update.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(report, key, value)
        
        report.updated_at = datetime.now()
        
        db.commit()
        db.refresh(report)
        
        logger.info(f"更新日报: did={did}, date={date}, pet_name={pet_name}")
        return report
        
    except Exception as e:
        db.rollback()
        logger.error(f"更新日报失败: {e}")
        raise HTTPException(status_code=500, detail=f"更新日报失败: {str(e)}")


@router.delete("/{did}/{date}/{pet_name}")
async def delete_daily_report(
    did: str,
    date: str,
    pet_name: str,
    db: Session = Depends(get_db)
):
    """删除指定日报"""
    report = db.query(DailyReport).filter(
        DailyReport.did == did,
        DailyReport.date == date,
        DailyReport.pet_name == pet_name
    ).first()
    
    if not report:
        raise HTTPException(
            status_code=404,
            detail=f"日报不存在: did={did}, date={date}, pet_name={pet_name}"
        )
    
    try:
        db.delete(report)
        db.commit()
        
        logger.info(f"删除日报: did={did}, date={date}, pet_name={pet_name}")
        return {"message": "日报删除成功"}
        
    except Exception as e:
        db.rollback()
        logger.error(f"删除日报失败: {e}")
        raise HTTPException(status_code=500, detail=f"删除日报失败: {str(e)}")
