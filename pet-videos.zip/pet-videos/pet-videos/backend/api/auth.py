from fastapi import APIRouter, HTTPException, Depends, Header, status
from pydantic import BaseModel
from config import settings
import jwt
import time
import logging
from typing import Optional

router = APIRouter(prefix="/api", tags=["auth"])
logger = logging.getLogger(__name__)

class LoginRequest(BaseModel):
    username: str
    password: str

class LoginResponse(BaseModel):
    token: str
    username: str

def create_token(username: str):
    payload = {
        "sub": username,
        "exp": time.time() + 86400 * 7  # 24小时 * 7天 有效期
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")

def verify_token(authorization: Optional[str] = Header(None)):
    if not authorization:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization header missing"
        )
    
    try:
        # 格式为 "Bearer <token>"
        token = authorization.split(" ")[1] if " " in authorization else authorization
        payload = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
        return payload["sub"]
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token"
        )

@router.post("/login", response_model=LoginResponse)
async def login(request: LoginRequest):
    logger.info(f"[Login] Received login request for username: {request.username}")
    logger.info(f"[Login] Expected username: {settings.admin_username}, password length: {len(settings.admin_password)}")
    logger.info(f"[Login] Received password length: {len(request.password)}")
    
    # 精确比较
    username_match = request.username == settings.admin_username
    password_match = request.password == settings.admin_password
    
    logger.info(f"[Login] Username match: {username_match}, Password match: {password_match}")
    
    if username_match and password_match:
        token = create_token(request.username)
        logger.info(f"[Login] Login successful for user: {request.username}")
        return LoginResponse(token=token, username=request.username)
    
    logger.warning(f"[Login] Login failed for username: {request.username}")
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="用户名或密码错误"
    )

@router.get("/auth/check")
async def check_auth(username: str = Depends(verify_token)):
    return {"status": "ok", "username": username}
