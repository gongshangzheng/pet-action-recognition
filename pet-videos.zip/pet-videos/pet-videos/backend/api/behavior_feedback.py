"""
宠物行为反馈 API（点赞/点踩）
"""
from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional, Dict, List, Any
import logging

from models.db import get_db
from services.behavior_feedback_service import BehaviorFeedbackService
from pydantic import BaseModel

router = APIRouter(prefix="/api/internal/behavior-feedback", tags=["behavior-feedback-internal"])
logger = logging.getLogger(__name__)

service = BehaviorFeedbackService()


class FeedbackResponse(BaseModel):
    """反馈响应"""
    user_feedback: Optional[str] = None  # 'like'/'dislike'/None


class BatchFeedbackRequest(BaseModel):
    """批量查询请求"""
    items: List[Dict[str, Any]]  # [{"video_id": 1, "pet_name": "毛毛"}, ...]


@router.post("/", response_model=FeedbackResponse)
async def submit_feedback_internal(
    video_id: int = Query(..., description="视频ID"),
    pet_name: str = Query(..., description="宠物名称"),
    did: str = Query(..., description="用户ID"),
    action: str = Query(..., regex="^(like|dislike)$", description="反馈类型"),
    db: Session = Depends(get_db)
):
    """
    提交反馈（内部接口，供 Service 调用）
    - 幂等操作：重复提交相同反馈返回当前状态
    - 切换操作：从 like 切换到 dislike（或反之）
    """
    try:
        logger.info(f"提交反馈请求: video_id={video_id}, pet_name={pet_name}, did={did}, action={action}")
        current_action = service.submit_feedback(video_id, pet_name, did, action, db)
        return FeedbackResponse(user_feedback=current_action)
    except ValueError as e:
        logger.error(f"提交反馈失败: {e}")
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"提交反馈异常: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"提交失败: {str(e)}")


@router.delete("/", response_model=FeedbackResponse)
async def cancel_feedback_internal(
    video_id: int = Query(..., description="视频ID"),
    pet_name: str = Query(..., description="宠物名称"),
    did: str = Query(..., description="用户ID"),
    db: Session = Depends(get_db)
):
    """
    取消反馈（内部接口，供 Service 调用）
    - 删除用户对该行为的反馈记录
    """
    try:
        logger.info(f"取消反馈请求: video_id={video_id}, pet_name={pet_name}, did={did}")
        service.cancel_feedback(video_id, pet_name, did, db)
        return FeedbackResponse(user_feedback=None)
    except Exception as e:
        logger.error(f"取消反馈异常: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"取消失败: {str(e)}")


@router.post("/batch")
async def batch_query_feedback(
    request: BatchFeedbackRequest,
    did: str = Query(..., description="用户ID"),
    db: Session = Depends(get_db)
):
    """
    批量查询用户反馈状态（内部接口，供 Service 调用）
    
    请求体:
        {
            "items": [
                {"video_id": 1, "pet_name": "毛毛"},
                {"video_id": 2, "pet_name": "旺财"}
            ]
        }
    
    返回:
        {
            "1_毛毛": "like",
            "2_旺财": null
        }
    """
    try:
        logger.info(f"批量查询反馈: did={did}, items_count={len(request.items)}")
        
        # 转换为 tuple 列表
        item_tuples = [(item["video_id"], item["pet_name"]) for item in request.items]
        
        # 批量查询
        feedback_map = service.batch_get_user_feedback(item_tuples, did, db)
        
        # 转为前端友好格式: "video_id_pet_name" -> action
        result = {}
        for (vid, pname), action in feedback_map.items():
            key = f"{vid}_{pname}"
            result[key] = action
        
        return result
    except Exception as e:
        logger.error(f"批量查询反馈异常: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"查询失败: {str(e)}")
