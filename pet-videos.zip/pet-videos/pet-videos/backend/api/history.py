"""历史记录 API（分别从 video_records 和 manual_analysis 表读取）"""
from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Union
from pathlib import Path
from datetime import datetime, timedelta

from models.schemas import HistoryRecord, HistoryDetail, HistoryListResponse
from models.database import VideoRecord, AnalysisHistory
from models.db import get_db
from config import settings
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["history"])


def _get_dir_alias_from_path(video_path: str) -> str:
    """从视频路径反推目录别名（用于兼容旧记录）"""
    try:
        parent_path = str(Path(video_path).parent)
        return settings.get_alias_by_path(parent_path)
    except:
        return None


@router.get("/history", response_model=HistoryListResponse)
async def get_history(
    call_type: str = Query("manual", description="记录类型: auto, manual"),
    limit: int = Query(10, ge=1, le=100),
    offset: int = Query(0, ge=0),
    query_all: str = Query(None, description="查询所有记录（不限时间窗口）"),
    did: str = Query(None, description="按DID筛选"),
    filename: str = Query(None, description="按文件名筛选（模糊匹配）"),
    date_from: str = Query(None, description="开始日期 YYYY-MM-DD"),
    date_to: str = Query(None, description="结束日期 YYYY-MM-DD"),
    db: Session = Depends(get_db)
):
    """获取历史记录列表（分页）- 分别查询手动或自动分析记录，默认显示手动"""
    try:
        from models.database import StreamSource, Prompt
        
        if call_type == "manual":
            # 查询手动分析记录
            total = db.query(AnalysisHistory).filter(AnalysisHistory.call_type == 'manual').count()
            logger.info(f"[History API] 查询到 {total} 条手动分析记录")
            
            records = db.query(AnalysisHistory)\
                .filter(AnalysisHistory.call_type == 'manual')\
                .order_by(AnalysisHistory.created_at.desc())\
                .limit(limit)\
                .offset(offset)\
                .all()
                
        elif call_type == "auto":
            # 构建基础查询
            query = db.query(VideoRecord)
            
            # 判断是否查询所有记录（auto-all模式）
            is_query_all = query_all == 'true'
            
            if not is_query_all:
                # "窗口"模式：只显示时间窗口内的任务
                time_window_hours = settings.llm_worker_time_window_hours
                cutoff_time = datetime.now() - timedelta(hours=time_window_hours)
                query = query.filter(VideoRecord.created_at >= cutoff_time)
                logger.info(f"[History API] 窗口模式：使用时间窗口过滤（{time_window_hours}小时）")
            else:
                # "自动"模式：查询所有记录，应用用户指定的过滤条件
                logger.info(f"[History API] 查询所有自动记录模式")
                
                if did:
                    query = query.filter(VideoRecord.did == did)
                    logger.info(f"[History API] 按DID过滤: {did}")
                
                if filename:
                    query = query.filter(VideoRecord.file_name.like(f"%{filename}%"))
                    logger.info(f"[History API] 按文件名过滤: {filename}")
                
                if date_from:
                    try:
                        date_from_obj = datetime.strptime(date_from, '%Y-%m-%d')
                        query = query.filter(VideoRecord.created_at >= date_from_obj)
                        logger.info(f"[History API] 按开始日期过滤: {date_from}")
                    except ValueError:
                        logger.warning(f"[History API] 无效的开始日期格式: {date_from}")
                
                if date_to:
                    try:
                        date_to_obj = datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1)  # 包含当天
                        query = query.filter(VideoRecord.created_at < date_to_obj)
                        logger.info(f"[History API] 按结束日期过滤: {date_to}")
                    except ValueError:
                        logger.warning(f"[History API] 无效的结束日期格式: {date_to}")
            
            # 获取总数
            total = query.count()
            logger.info(f"[History API] 查询到 {total} 条自动分析记录")
            
            # 按视频录制时间倒序排列（最新录制的在前）
            records = query\
                .order_by(VideoRecord.recorded_at.desc())\
                .limit(limit)\
                .offset(offset)\
                .all()
        else:
            raise HTTPException(status_code=400, detail="Invalid call_type. Must be 'auto' or 'manual'")
        
        logger.info(f"[History API] 实际返回 {len(records)} 条{call_type}记录")
        
        # 转换为响应模型
        history_records = []
        
        if call_type == "manual":
            # 处理手动分析记录
            for r in records:
                dir_alias = _get_dir_alias_from_path(r.video_path)
                
                history_records.append(HistoryRecord(
                    id=r.id,
                    video_name=r.video_name,
                    dir_alias=dir_alias,
                    video_duration_sec=r.video_duration_sec or 0,
                    prompt=r.prompt or '',
                    prompt_id=None,  # 手动分析没有prompt_id
                    prompt_name=None,
                    model_name=r.model_name,
                    call_type='manual',
                    fps=r.fps or getattr(r, 'fps', 0) or 0,
                    max_pixels=r.max_pixels or 0,
                    min_pixels=r.min_pixels or 0,
                    vl_high_resolution_images=r.vl_high_resolution_images or False,
                    input_tokens=r.input_tokens or 0,
                    output_tokens=r.output_tokens or 0,
                    total_tokens=r.total_tokens or 0,
                    cost=r.cost or 0,
                    duration_sec=r.duration_sec or 0,
                    model_response=(r.model_response[:100] + '...') if (r.model_response and len(r.model_response) > 100) else (r.model_response or ''),
                    created_at=r.created_at
                ))
        
        else:  # auto
            # 处理自动分析记录
            for r in records:
                # 获取视频源别名
                dir_alias = None
                if r.source_id and r.source_id > 0:
                    source = db.query(StreamSource).filter(StreamSource.id == r.source_id).first()
                    dir_alias = source.alias if source else None
                
                # 获取提示词名称
                prompt_name = None
                if r.llm_prompt_id:
                    prompt = db.query(Prompt).filter(Prompt.id == r.llm_prompt_id).first()
                    prompt_name = prompt.name if prompt else None
                
                history_records.append(HistoryRecord(
                    id=r.id,
                    video_name=r.file_name,  # VideoRecord uses file_name
                    dir_alias=dir_alias,
                    video_duration_sec=r.duration or 0,  # VideoRecord uses duration
                    prompt=r.prompt or '',
                    prompt_id=r.llm_prompt_id,
                    prompt_name=prompt_name,
                    model_name=r.model_name,
                    call_type='auto',
                    llm_status=r.llm_status,
                    fps=r.analysis_fps or r.fps or 0,  # VideoRecord has analysis_fps and fps
                    max_pixels=r.max_pixels or 0,
                    min_pixels=r.min_pixels or 0,
                    vl_high_resolution_images=r.vl_high_resolution_images or False,
                    input_tokens=r.input_tokens or 0,
                    output_tokens=r.output_tokens or 0,
                    total_tokens=r.total_tokens or 0,
                    cost=r.analysis_cost or 0,  # VideoRecord uses analysis_cost
                    duration_sec=r.analysis_duration_sec or 0,  # VideoRecord uses analysis_duration_sec
                    model_response=(r.llm_raw_response[:100] + '...') if (r.llm_raw_response and len(r.llm_raw_response) > 100) else (r.llm_raw_response or ''),  # VideoRecord uses llm_raw_response
                    created_at=r.llm_completed_at or r.created_at
                ))
        
        return HistoryListResponse(
            records=history_records,
            total=total,
            page=offset // limit + 1,
            page_size=limit
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get history: {str(e)}")


@router.get("/history/{record_id}", response_model=HistoryDetail)
async def get_history_detail(record_id: int, call_type: str = Query(..., description="记录类型: auto 或 manual"), db: Session = Depends(get_db)):
    """获取历史记录详情 - 分别查询 video_records 和 manual_analysis 表"""
    try:
        from models.database import StreamSource, Prompt
        
        if call_type == 'auto':
            # 查询自动分析记录（包含所有状态）
            record = db.query(VideoRecord)\
                .filter(VideoRecord.id == record_id)\
                .first()
        elif call_type == 'manual':
            # 查询手动分析记录
            record = db.query(AnalysisHistory)\
                .filter(AnalysisHistory.id == record_id)\
                .filter(AnalysisHistory.call_type == 'manual')\
                .first()
        else:
            raise HTTPException(status_code=400, detail="Invalid call_type. Must be 'auto' or 'manual'")
        
        if not record:
            raise HTTPException(status_code=404, detail="Record not found")
        
        # 根据记录类型处理不同字段
        if call_type == 'auto':
            # 自动分析记录
            # 获取视频源别名
            dir_alias = None
            if record.source_id and record.source_id > 0:
                source = db.query(StreamSource).filter(StreamSource.id == record.source_id).first()
                dir_alias = source.alias if source else None
            
            # 获取提示词名称和内容
            prompt_name = None
            prompt_content = record.prompt or ''
            if record.llm_prompt_id:
                prompt = db.query(Prompt).filter(Prompt.id == record.llm_prompt_id).first()
                if prompt:
                    prompt_name = prompt.name
                    # 如果record.prompt为空，使用提示词模板的内容
                    if not prompt_content:
                        prompt_content = prompt.content or ''
        else:
            # 手动分析记录
            dir_alias = _get_dir_alias_from_path(record.video_path)
            prompt_name = None
            prompt_content = record.prompt or ''
        
        # 根据call_type使用不同的字段映射
        if call_type == 'auto':
            # VideoRecord字段映射
            return HistoryDetail(
                id=record.id,
                video_name=record.file_name,  # VideoRecord uses file_name
                dir_alias=dir_alias,
                video_path=record.file_path,  # VideoRecord uses file_path
                video_duration_sec=record.duration or 0,  # VideoRecord uses duration
                prompt=prompt_content,
                prompt_id=getattr(record, 'llm_prompt_id', None),
                prompt_name=prompt_name,
                model_name=record.model_name,
                call_type=call_type,
                fps=getattr(record, 'analysis_fps', 0) or getattr(record, 'fps', 0) or 0,
                max_pixels=record.max_pixels or 0,
                min_pixels=record.min_pixels or 0,
                vl_high_resolution_images=record.vl_high_resolution_images or False,
                input_tokens=record.input_tokens or 0,
                output_tokens=record.output_tokens or 0,
                total_tokens=record.total_tokens or 0,
                cost=getattr(record, 'analysis_cost', 0) or 0,  # VideoRecord uses analysis_cost
                duration_sec=getattr(record, 'analysis_duration_sec', 0) or 0,  # VideoRecord uses analysis_duration_sec
                model_response=getattr(record, 'llm_raw_response', '') or getattr(record, 'llm_result', '') or '',
                created_at=record.created_at
            )
        else:
            # AnalysisHistory字段映射
            return HistoryDetail(
                id=record.id,
                video_name=record.video_name,  # AnalysisHistory uses video_name
                dir_alias=dir_alias,
                video_path=record.video_path,  # AnalysisHistory uses video_path
                video_duration_sec=record.video_duration_sec or 0,  # AnalysisHistory uses video_duration_sec
                prompt=prompt_content,
                prompt_id=None,  # 手动分析没有prompt_id
                prompt_name=prompt_name,
                model_name=record.model_name,
                call_type=call_type,
                fps=record.fps or 0,
                max_pixels=record.max_pixels or 0,
                min_pixels=record.min_pixels or 0,
                vl_high_resolution_images=record.vl_high_resolution_images or False,
                input_tokens=record.input_tokens or 0,
                output_tokens=record.output_tokens or 0,
                total_tokens=record.total_tokens or 0,
                cost=record.cost or 0,  # AnalysisHistory uses cost
                duration_sec=record.duration_sec or 0,  # AnalysisHistory uses duration_sec
                model_response=record.model_response or '',  # AnalysisHistory uses model_response
                created_at=record.created_at
            )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get history detail: {str(e)}")


@router.delete("/history/{record_id}")
async def delete_history(record_id: int, call_type: str = Query(..., description="记录类型: auto 或 manual"), db: Session = Depends(get_db)):
    """删除历史记录 - 分别删除 video_records 和 manual_analysis 表的记录"""
    try:
        if call_type == 'auto':
            # 删除自动分析记录（注意：通常不应该删除自动记录）
            record = db.query(VideoRecord)\
                .filter(VideoRecord.id == record_id)\
                .first()
        elif call_type == 'manual':
            # 删除手动分析记录
            record = db.query(AnalysisHistory)\
                .filter(AnalysisHistory.id == record_id)\
                .filter(AnalysisHistory.call_type == 'manual')\
                .first()
        else:
            raise HTTPException(status_code=400, detail="Invalid call_type. Must be 'auto' or 'manual'")
        
        if not record:
            raise HTTPException(status_code=404, detail="Record not found")
        
        db.delete(record)
        db.commit()
        
        return {"success": True, "message": "Record deleted"}
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to delete record: {str(e)}")


@router.delete("/history")
async def clear_history(call_type: str = Query(..., description="记录类型: auto, manual 或 all"), db: Session = Depends(get_db)):
    """清空历史记录 - 分别删除不同类型的记录"""
    try:
        if call_type == 'manual':
            # 只删除手动分析记录
            count = db.query(AnalysisHistory).filter(AnalysisHistory.call_type == 'manual').count()
            db.query(AnalysisHistory).filter(AnalysisHistory.call_type == 'manual').delete()
        elif call_type == 'auto':
            # 删除自动分析记录（注意：通常不应该删除自动记录）
            count = db.query(VideoRecord).count()
            db.query(VideoRecord).delete()
        elif call_type == 'all':
            # 删除所有记录
            manual_count = db.query(AnalysisHistory).filter(AnalysisHistory.call_type == 'manual').count()
            auto_count = db.query(VideoRecord).count()
            db.query(AnalysisHistory).filter(AnalysisHistory.call_type == 'manual').delete()
            db.query(VideoRecord).delete()
            count = manual_count + auto_count
        else:
            raise HTTPException(status_code=400, detail="Invalid call_type. Must be 'auto', 'manual' or 'all'")
        
        db.commit()
        
        return {"success": True, "message": f"Deleted {count} records"}
        
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to clear history: {str(e)}")

