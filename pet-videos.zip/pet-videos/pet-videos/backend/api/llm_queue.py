"""LLM 队列管理 API - 仅供内部管理使用"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Dict, Any
import logging

from models.db import get_db
from models.database import VideoRecord
from services.llm_worker_service import llm_worker_service

router = APIRouter(prefix="/api/llm", tags=["llm-queue"])
internal_router = APIRouter(prefix="/api/internal/llm", tags=["llm-queue-internal"])
logger = logging.getLogger(__name__)


@internal_router.get("/status")
async def get_llm_queue_status() -> Dict[str, Any]:
    """获取 LLM 队列状态（内部接口）"""
    try:
        status = llm_worker_service.get_status()
        return {
            "success": True,
            "data": status
        }
    except Exception as e:
        logger.error(f"Failed to get LLM queue status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@internal_router.post("/worker/start")
async def start_llm_worker():
    """启动 LLM Worker（内部接口）"""
    try:
        llm_worker_service.start_worker()
        return {"success": True, "message": "LLM Worker started"}
    except Exception as e:
        logger.error(f"Failed to start LLM Worker: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@internal_router.post("/worker/stop")
async def stop_llm_worker():
    """停止 LLM Worker（内部接口）"""
    try:
        llm_worker_service.stop_worker()
        return {"success": True, "message": "LLM Worker stopped"}
    except Exception as e:
        logger.error(f"Failed to stop LLM Worker: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@internal_router.post("/process")
async def trigger_processing():
    """手动触发队列处理（内部接口）"""
    try:
        llm_worker_service.trigger_immediate_processing()
        return {"success": True, "message": "Processing triggered"}
    except Exception as e:
        logger.error(f"Failed to trigger processing: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@internal_router.post("/retry/{record_id}")
async def retry_failed_record(record_id: int, db: Session = Depends(get_db)):
    """重试失败的记录（内部接口）"""
    try:
        record = db.query(VideoRecord).filter(VideoRecord.id == record_id).first()
        if not record:
            raise HTTPException(status_code=404, detail="Record not found")
        
        if record.llm_status not in ['failed', 'error', 'completed']:
            raise HTTPException(status_code=400, detail="Record is not in failed/error/completed state")
        
        # 重置状态（NULL状态表示待处理）
        record.llm_status = None
        record.llm_retry_count = 0
        record.llm_error = None
        record.llm_started_at = None
        record.llm_completed_at = None
        record.llm_next_retry_at = None  # 清除重试时间，立即处理
        db.commit()
        
        logger.info(f"Reset record {record_id} for retry")
        return {"success": True, "message": "Record reset for retry"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to retry record {record_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@internal_router.delete("/record/{record_id}")
async def delete_queue_record(record_id: int, db: Session = Depends(get_db)):
    """删除队列记录（内部接口）"""
    try:
        record = db.query(VideoRecord).filter(VideoRecord.id == record_id).first()
        if not record:
            raise HTTPException(status_code=404, detail="Record not found")
        
        # 只能删除非处理中的记录
        if record.llm_status == 'processing':
            raise HTTPException(status_code=400, detail="Cannot delete processing record")
        
        db.delete(record)
        db.commit()
        
        logger.info(f"Deleted queue record {record_id}")
        return {"success": True, "message": "Record deleted"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete record {record_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/queue/stats")
async def get_public_queue_stats(db: Session = Depends(get_db)):
    """获取队列统计信息（公开接口，仅统计数据）"""
    try:
        from sqlalchemy import func
        
        # 统计各状态的记录数（现在video_records表只包含自动分析记录）
        stats = db.query(
            VideoRecord.llm_status,
            func.count(VideoRecord.id)
        ).group_by(VideoRecord.llm_status).all()
        
        queue_stats = dict(stats)
        
        # 添加系统配置信息
        from config import settings
        
        return {
            "success": True,
            "data": {
                "queue_stats": queue_stats,
                "worker_running": llm_worker_service.is_running(),
                "processing_count": len(llm_worker_service._processing_records),
                "system_enabled": getattr(settings, 'llm_worker_enabled', True),
                "config": {
                    "max_concurrent": getattr(settings, 'llm_worker_max_concurrent', 2),
                    "poll_interval": getattr(settings, 'llm_worker_poll_interval', 10),
                    "max_retries": getattr(settings, 'llm_worker_max_retries', 3),
                    "time_window_hours": getattr(settings, 'llm_worker_time_window_hours', 25),
                    "auto_start": getattr(settings, 'llm_worker_auto_start', True),
                    "retry_delays": getattr(settings, 'llm_worker_retry_delays', '60,300,900')
                }
            }
        }
    except Exception as e:
        logger.error(f"Failed to get queue stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))