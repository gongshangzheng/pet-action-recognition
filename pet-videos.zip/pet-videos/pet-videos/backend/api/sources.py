from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
import logging

from models.db import get_db
from models.database import StreamSource, SlicingTask
from models.schemas import StreamSourceCreate, StreamSourceUpdate, StreamSourceResponse
from services.task_service import TaskService

# 需要 JWT 认证的路由（外部调用）
router = APIRouter(prefix="/api/sources", tags=["sources"])

# 内部路由（Service 调用，不需要 JWT）
internal_router = APIRouter(prefix="/api/internal/sources", tags=["sources-internal"])

logger = logging.getLogger(__name__)
task_service = TaskService()

@router.get("/", response_model=List[StreamSourceResponse])
async def get_sources(
    did: Optional[str] = Query(None, description="用户DID，传入则只返回该用户的源"),
    db: Session = Depends(get_db)
):
    """获取流配置列表（支持按用户DID过滤）"""
    query = db.query(StreamSource)
    if did is not None:
        query = query.filter(StreamSource.did == did)
    return query.all()

@router.post("/", response_model=StreamSourceResponse)
async def create_source(source: StreamSourceCreate, db: Session = Depends(get_db)):
    """创建新的流配置"""
    # 检查别名是否唯一
    db_source = db.query(StreamSource).filter(StreamSource.alias == source.alias).first()
    if db_source:
        raise HTTPException(status_code=400, detail="Alias already registered")
    
    new_source = StreamSource(**source.model_dump())
    db.add(new_source)
    try:
        db.commit()
        db.refresh(new_source)
        return new_source
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to create source: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{source_id}", response_model=StreamSourceResponse)
async def get_source(source_id: int, db: Session = Depends(get_db)):
    """获取单个流配置详情"""
    source = db.query(StreamSource).filter(StreamSource.id == source_id).first()
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")
    return source

@router.put("/{source_id}", response_model=StreamSourceResponse)
async def update_source(
    source_id: int, 
    source_update: StreamSourceUpdate,
    requesting_did: Optional[str] = Query(None, description="请求用户的DID，用于权限校验"),
    db: Session = Depends(get_db)
):
    """更新流配置（支持权限校验）"""
    db_source = db.query(StreamSource).filter(StreamSource.id == source_id).first()
    if not db_source:
        raise HTTPException(status_code=404, detail="Source not found")
    
    # 权限校验：如果传入了 requesting_did，检查是否有权限操作
    if requesting_did is not None:
        if db_source.did != requesting_did:
            raise HTTPException(status_code=403, detail="No permission to update this source")
    
    update_data = source_update.model_dump(exclude_unset=True)
    
    # 如果修改了别名，检查唯一性
    if 'alias' in update_data and update_data['alias'] != db_source.alias:
        alias_exists = db.query(StreamSource).filter(StreamSource.alias == update_data['alias']).first()
        if alias_exists:
            raise HTTPException(status_code=400, detail="Alias already registered")
    
    # 如果要停用源（is_active: true -> false），自动停止关联的运行中任务
    if 'is_active' in update_data and not update_data['is_active'] and db_source.is_active:
        running_tasks = db.query(SlicingTask).filter(
            SlicingTask.source_id == source_id,
            SlicingTask.status == 'running'
        ).all()
        
        if running_tasks:
            logger.info(f"停用源 {source_id}，自动停止 {len(running_tasks)} 个运行中的任务")
            for task in running_tasks:
                task_service.stop_task(source_id, db)
                logger.info(f"已停止任务 {task.id} (source_id={source_id})")
            
    for key, value in update_data.items():
        setattr(db_source, key, value)
        
    try:
        db.commit()
        db.refresh(db_source)
        return db_source
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to update source: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{source_id}/disable")
async def disable_source(source_id: int, db: Session = Depends(get_db)):
    """停用源并停止关联任务"""
    db_source = db.query(StreamSource).filter(StreamSource.id == source_id).first()
    if not db_source:
        raise HTTPException(status_code=404, detail="Source not found")
    
    if not db_source.is_active:
        return {"message": "Source already disabled", "stopped_tasks": 0}
    
    # 查找并停止所有运行中的任务
    running_tasks = db.query(SlicingTask).filter(
        SlicingTask.source_id == source_id,
        SlicingTask.status == 'running'
    ).all()
    
    stopped_count = 0
    for task in running_tasks:
        task_service.stop_task(source_id, db)
        stopped_count += 1
        logger.info(f"停止任务 {task.id} (source_id={source_id})")
    
    # 停用源
    db_source.is_active = False
    db.commit()
    
    logger.info(f"源 {source_id} 已停用，停止了 {stopped_count} 个任务")
    return {"message": "Source disabled successfully", "stopped_tasks": stopped_count}

@router.post("/{source_id}/enable")
async def enable_source(source_id: int, db: Session = Depends(get_db)):
    """启用源"""
    db_source = db.query(StreamSource).filter(StreamSource.id == source_id).first()
    if not db_source:
        raise HTTPException(status_code=404, detail="Source not found")
    
    if db_source.is_active:
        return {"message": "Source already enabled"}
    
    db_source.is_active = True
    db.commit()
    
    logger.info(f"源 {source_id} 已启用")
    return {"message": "Source enabled successfully"}

@router.delete("/{source_id}")
async def delete_source(
    source_id: int,
    requesting_did: Optional[str] = Query(None, description="请求用户的DID，用于权限校验"),
    db: Session = Depends(get_db)
):
    """删除流配置（严格保护：有任何关联任务都不允许删除）"""
    db_source = db.query(StreamSource).filter(StreamSource.id == source_id).first()
    if not db_source:
        raise HTTPException(status_code=404, detail="Source not found")
    
    # 权限校验：如果传入了 requesting_did，检查是否有权限操作
    if requesting_did is not None:
        if db_source.did != requesting_did:
            raise HTTPException(status_code=403, detail="No permission to delete this source")
    
    # 检查是否有任何关联的任务（无论状态）
    related_tasks = db.query(SlicingTask).filter(
        SlicingTask.source_id == source_id
    ).all()
    
    if related_tasks:
        task_count = len(related_tasks)
        running_count = sum(1 for t in related_tasks if t.status == 'running')
        
        if running_count > 0:
            raise HTTPException(
                status_code=400,
                detail=f"Cannot delete source. It has {task_count} associated task(s), {running_count} of which are running. Please delete all tasks first."
            )
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Cannot delete source. It has {task_count} associated task(s). Please delete all tasks first."
            )

    try:
        db.delete(db_source)
        db.commit()
        logger.info(f"源 {source_id} 已删除（无关联任务）")
        return {"message": "Source deleted successfully"}
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to delete source: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== 内部 API（供 Service 调用，不需要 JWT） ====================

@internal_router.get("/", response_model=List[StreamSourceResponse])
async def internal_get_sources(
    did: Optional[str] = Query(None, description="用户DID，传入则只返回该用户的源"),
    db: Session = Depends(get_db)
):
    """获取流配置列表（内部调用，不需要JWT）"""
    query = db.query(StreamSource)
    if did is not None:
        query = query.filter(StreamSource.did == did)
    
    sources = query.all()
    logger.info(f"[Backend] 查询设备 - did={did}, 返回数量: {len(sources)}")
    if sources:
        logger.info(f"[Backend] 返回的设备列表: {[(s.id, s.name, s.did) for s in sources]}")
    
    return sources


@internal_router.post("/", response_model=StreamSourceResponse)
async def internal_create_source(source: StreamSourceCreate, db: Session = Depends(get_db)):
    """创建新的流配置（内部调用，不需要JWT）"""
    # 检查别名是否唯一
    db_source = db.query(StreamSource).filter(StreamSource.alias == source.alias).first()
    if db_source:
        raise HTTPException(status_code=400, detail="Alias already registered")
    
    new_source = StreamSource(**source.model_dump())
    db.add(new_source)
    try:
        db.commit()
        db.refresh(new_source)
        return new_source
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to create source: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@internal_router.get("/{source_id}", response_model=StreamSourceResponse)
async def internal_get_source(source_id: int, db: Session = Depends(get_db)):
    """获取单个流配置详情（内部调用，不需要JWT）"""
    source = db.query(StreamSource).filter(StreamSource.id == source_id).first()
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")
    return source


@internal_router.put("/{source_id}", response_model=StreamSourceResponse)
async def internal_update_source(
    source_id: int, 
    source_update: StreamSourceUpdate,
    requesting_did: Optional[str] = Query(None, description="请求用户的DID，用于权限校验"),
    db: Session = Depends(get_db)
):
    """更新流配置（内部调用，不需要JWT，支持权限校验）"""
    db_source = db.query(StreamSource).filter(StreamSource.id == source_id).first()
    if not db_source:
        raise HTTPException(status_code=404, detail="Source not found")
    
    # 权限校验：如果传入了 requesting_did，检查是否有权限操作
    if requesting_did is not None:
        if db_source.did != requesting_did:
            raise HTTPException(status_code=403, detail="No permission to update this source")
    
    update_data = source_update.model_dump(exclude_unset=True)
    
    # 如果修改了别名，检查唯一性
    if 'alias' in update_data and update_data['alias'] != db_source.alias:
        alias_exists = db.query(StreamSource).filter(StreamSource.alias == update_data['alias']).first()
        if alias_exists:
            raise HTTPException(status_code=400, detail="Alias already registered")
    
    # 如果要停用源，自动停止关联的运行中任务
    if 'is_active' in update_data and not update_data['is_active'] and db_source.is_active:
        running_tasks = db.query(SlicingTask).filter(
            SlicingTask.source_id == source_id,
            SlicingTask.status == 'running'
        ).all()
        
        if running_tasks:
            logger.info(f"停用源 {source_id}，自动停止 {len(running_tasks)} 个运行中的任务")
            for task in running_tasks:
                task_service.stop_task(source_id, db)
                logger.info(f"已停止任务 {task.id} (source_id={source_id})")
            
    for key, value in update_data.items():
        setattr(db_source, key, value)
        
    try:
        db.commit()
        db.refresh(db_source)
        return db_source
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to update source: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@internal_router.delete("/{source_id}")
async def internal_delete_source(
    source_id: int,
    requesting_did: Optional[str] = Query(None, description="请求用户的DID，用于权限校验"),
    db: Session = Depends(get_db)
):
    """删除流配置（内部调用，不需要JWT，支持权限校验）"""
    db_source = db.query(StreamSource).filter(StreamSource.id == source_id).first()
    if not db_source:
        raise HTTPException(status_code=404, detail="Source not found")
    
    # 权限校验：如果传入了 requesting_did，检查是否有权限操作
    if requesting_did is not None:
        if db_source.did != requesting_did:
            raise HTTPException(status_code=403, detail="No permission to delete this source")
    
    # 检查是否有任何关联的任务
    related_tasks = db.query(SlicingTask).filter(
        SlicingTask.source_id == source_id
    ).all()
    
    if related_tasks:
        task_count = len(related_tasks)
        running_count = sum(1 for t in related_tasks if t.status == 'running')
        
        if running_count > 0:
            raise HTTPException(
                status_code=400,
                detail=f"Cannot delete source. It has {task_count} associated task(s), {running_count} of which are running. Please delete all tasks first."
            )
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Cannot delete source. It has {task_count} associated task(s). Please delete all tasks first."
            )

    try:
        db.delete(db_source)
        db.commit()
        logger.info(f"源 {source_id} 已删除（无关联任务）")
        return {"message": "Source deleted successfully"}
    except Exception as e:
        db.rollback()
        logger.error(f"Failed to delete source: {e}")
        raise HTTPException(status_code=500, detail=str(e))
