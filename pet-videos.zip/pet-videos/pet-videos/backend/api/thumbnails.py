"""
缩略图 API

提供视频缩略图的访问接口
"""

import logging
from pathlib import Path
from fastapi import APIRouter, Query, HTTPException
from fastapi.responses import FileResponse
from fastapi.concurrency import run_in_threadpool

from utils.security import decode_video_token
from services.thumbnail_service import ThumbnailService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/thumbnail", tags=["Thumbnail"])
internal_router = APIRouter(prefix="/api/internal/thumbnail", tags=["Internal Thumbnail"])

# 初始化缩略图服务
thumbnail_service = ThumbnailService()


@router.get("/")
async def get_thumbnail(
    token: str = Query(..., description="视频token（与视频流相同）")
):
    """
    获取视频缩略图（公开接口，使用token验证）
    
    通过与视频流相同的 token 访问缩略图
    缩略图路径自动从视频路径推导
    """
    try:
        # 解码 token 获取视频信息
        try:
            alias, filename = decode_video_token(token)
        except Exception as e:
            logger.warning(f"Token 解码失败: {e}")
            raise HTTPException(status_code=403, detail="Token 无效或已过期")
        
        logger.info(f"请求缩略图: alias={alias}, filename={filename}")
        
        # 从数据库获取视频记录（包含缩略图路径）
        from models.database import StreamSource, VideoRecord
        from models.db import SessionLocal
        
        db = SessionLocal()
        try:
            # 1. 根据 alias 获取 source
            source = db.query(StreamSource).filter(StreamSource.alias == alias).first()
            if not source:
                logger.warning(f"Source not found: alias={alias}")
                raise HTTPException(status_code=404, detail="视频源不存在")
            
            # 2. 查询视频记录
            video_record = db.query(VideoRecord).filter(
                VideoRecord.source_id == source.id,
                VideoRecord.file_name == filename
            ).first()
            
            if not video_record:
                logger.warning(f"Video record not found: source_id={source.id}, filename={filename}")
                raise HTTPException(status_code=404, detail="视频记录不存在")
            
            # 3. 获取缩略图路径
            thumbnail_path = video_record.thumbnail_path
            
            # 如果数据库中没有缩略图路径，尝试自动生成
            if not thumbnail_path or not Path(thumbnail_path).exists():
                logger.info(f"缩略图不存在，尝试自动生成: {video_record.file_path}")
                try:
                    # 在线程池中生成缩略图，避免阻塞事件循环
                    thumbnail_path = await run_in_threadpool(
                        thumbnail_service.generate_thumbnail,
                        video_record.file_path,
                        video_record.id,
                        None,  # timestamp: None = 智能模式，自动选择最佳帧
                        320    # width
                    )
                    
                    if not thumbnail_path:
                        raise Exception("缩略图生成返回空路径")
                    
                    # 更新数据库
                    video_record.thumbnail_path = thumbnail_path
                    db.commit()
                    logger.info(f"缩略图生成成功并已保存到数据库: {thumbnail_path}")
                    
                except Exception as gen_error:
                    logger.error(f"缩略图生成失败: {gen_error}")
                    raise HTTPException(status_code=500, detail="缩略图生成失败")
            
            # 验证缩略图文件
            thumbnail_path_obj = Path(thumbnail_path)
            if not thumbnail_path_obj.exists():
                logger.error(f"缩略图文件不存在: {thumbnail_path}")
                raise HTTPException(status_code=404, detail="缩略图文件不存在")
            
            # 返回缩略图文件
            logger.info(f"返回缩略图: {thumbnail_path}")
            return FileResponse(
                path=str(thumbnail_path_obj),
                media_type="image/jpeg",
                headers={
                    "Cache-Control": "public, max-age=86400",  # 缓存1天
                    "Accept-Ranges": "bytes"
                }
            )
            
        finally:
            db.close()
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"获取缩略图失败: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"获取缩略图失败: {str(e)}")


@internal_router.get("/")
async def get_thumbnail_internal(
    token: str = Query(..., description="视频token")
):
    """
    获取视频缩略图（内部接口，无需JWT认证）
    
    用于 Service 层调用
    """
    return await get_thumbnail(token=token)
