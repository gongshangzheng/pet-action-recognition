"""视频和目录管理 API"""
from fastapi import APIRouter, HTTPException, Query, Request, Depends
from fastapi.responses import FileResponse, StreamingResponse
from typing import List, Optional
from pathlib import Path
from pydantic import BaseModel
from datetime import datetime
import logging
import aiofiles

from models.schemas import VideoInfo, DirectoryInfo, VideoListResponse, DirectoryStat
from services.video_service import VideoService
from utils.security import decode_video_token, validate_video_token
from models.db import get_db, SessionLocal
from sqlalchemy.orm import Session

# 需要JWT认证的视频API
router = APIRouter(prefix="/api", tags=["videos"])
# 公开的视频流API（不需要JWT，stream_token本身已有HMAC签名）
public_router = APIRouter(prefix="/api", tags=["videos-public"])

logger = logging.getLogger(__name__)

# 服务实例
video_service = VideoService()


def validate_alias(alias: str) -> Path:
    """验证目录别名并返回对应路径
    
    Args:
        alias: 目录别名
        
    Returns:
        验证后的目录Path对象
        
    Raises:
        HTTPException: 别名无效或目录不存在
    """
    # 1. 验证别名格式（只允许字母、数字、下划线、连字符）
    import re
    if not re.match(r'^[a-zA-Z0-9_-]+$', alias):
        logger.warning(f"Invalid alias format: {alias}")
        raise HTTPException(status_code=400, detail="Invalid alias format")
    
    # 2. 从数据库获取别名对应的路径
    from models.db import SessionLocal
    from models.database import StreamSource
    db = SessionLocal()
    try:
        source = db.query(StreamSource).filter(StreamSource.alias == alias, StreamSource.is_active == True).first()
        if not source:
            logger.warning(f"Unknown alias: {alias}")
            raise HTTPException(status_code=404, detail=f"Directory alias not found: {alias}")
        dir_path_str = source.storage_path
    finally:
        db.close()
    
    # 3. 检查目录是否存在
    dir_path = Path(dir_path_str).resolve()
    if not dir_path.exists():
        raise HTTPException(status_code=404, detail=f"Directory not found for alias: {alias}")
    
    if not dir_path.is_dir():
        raise HTTPException(status_code=400, detail=f"Not a directory: {alias}")
    
    return dir_path


@router.get("/directories", response_model=List[DirectoryInfo])
async def get_directories(db: Session = Depends(get_db)):
    """获取所有配置的视频目录列表（从数据库读取）"""
    try:
        from models.database import VideoRecord, StreamSource
        
        directories = []
        sources = db.query(StreamSource).filter(StreamSource.is_active == True).all()
        
        for source in sources:
            # 从数据库统计视频数量
            video_count = db.query(VideoRecord).filter(VideoRecord.source_id == source.id).count()
            
            # 检查存储目录是否存在
            dir_path = Path(source.storage_path)
            exists = dir_path.exists() and dir_path.is_dir()
            
            directories.append({
                'alias': source.alias,
                'name': source.name,
                'video_count': video_count,
                'exists': exists,
                'did': source.did
            })
        
        return directories
    except Exception as e:
        logger.error(f"Failed to get directories: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get directories: {str(e)}")


@router.get("/videos", response_model=VideoListResponse)
async def get_videos(
    alias: str = Query(..., description="目录别名"),
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(10, ge=1, le=100, description="每页数量"),
    db: Session = Depends(get_db)
):
    """获取指定目录下的视频列表（从数据库读取）"""
    try:
        from models.database import VideoRecord, StreamSource
        
        # 1. 通过别名获取 source
        source = db.query(StreamSource).filter(
            StreamSource.alias == alias,
            StreamSource.is_active == True
        ).first()
        
        if not source:
            raise HTTPException(status_code=404, detail=f"Source not found for alias: {alias}")
        
        # 2. 从数据库查询视频记录（按录制时间倒序）
        total = db.query(VideoRecord).filter(VideoRecord.source_id == source.id).count()
        
        offset = (page - 1) * page_size
        records = db.query(VideoRecord)\
            .filter(VideoRecord.source_id == source.id)\
            .order_by(VideoRecord.recorded_at.desc())\
            .offset(offset)\
            .limit(page_size)\
            .all()
        
        # 3. 转换为前端所需格式
        videos = []
        for record in records:
            # 生成 stream_token
            stream_token = video_service.generate_stream_token(alias, record.file_name)
            
            videos.append({
                'id': record.id,  # 添加唯一标识符
                'filename': record.file_name,
                'dir_alias': alias,
                'did': source.did,  # 添加用户ID
                'path': record.file_path,
                'stream_token': stream_token,
                'size_mb': record.file_size / (1024 * 1024) if record.file_size else 0,
                'duration_sec': record.duration if record.duration else 0,
                'duration_formatted': video_service._format_duration(record.duration) if record.duration else '-',
                'resolution': f"{record.width}x{record.height}" if record.width and record.height else '-',
                'width': record.width if record.width else 0,
                'height': record.height if record.height else 0,
                'fps': record.fps if record.fps else 0,
                'codec': record.codec if record.codec else '-',
                'bitrate_mbps': 0,  # 暂不计算
                'created_at': record.recorded_at.isoformat() if record.recorded_at else None
            })
        
        return {
            'videos': videos,
            'total': total,
            'page': page,
            'page_size': page_size
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get videos from alias {alias}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get videos: {str(e)}")


@router.get("/videos/stats", response_model=List[DirectoryStat])
async def get_video_stats():
    """获取所有目录的视频统计数据"""
    try:
        stats = video_service.get_video_stats()
        return stats
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get video stats: {str(e)}")


@router.get("/videos/by_date", response_model=VideoListResponse)
async def get_videos_by_date(
    date: str = Query(..., description="日期 (YYYY-MM-DD)"),
    alias: Optional[str] = Query(None, description="目录别名（可选）"),
    did: Optional[str] = Query(None, description="用户ID（可选，查询用户所有摄像头）"),
    pet_name: Optional[str] = Query(None, description="宠物名称（可选，过滤包含该宠物的视频）"),
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(20, ge=1, le=200, description="每页数量"),
    db: Session = Depends(get_db)
):
    """获取指定日期的视频列表（支持按别名/用户/宠物过滤，支持分页）"""
    try:
        from models.database import StreamSource, PetBehavior
        from sqlalchemy import func
        
        # 获取源ID列表
        source_ids = []
        if alias:
            # 通过别名获取源
            source = db.query(StreamSource).filter(
                StreamSource.alias == alias,
                StreamSource.is_active == True
            ).first()
            if not source:
                raise HTTPException(status_code=404, detail=f"Source not found for alias: {alias}")
            source_ids = [source.id]
        elif did:
            # 通过 did 获取用户所有活跃的摄像头
            sources = db.query(StreamSource).filter(
                StreamSource.did == did,
                StreamSource.is_active == True
            ).all()
            if not sources:
                # 用户没有摄像头，返回空列表
                return {
                    "videos": [],
                    "total": 0,
                    "page": page,
                    "page_size": page_size
                }
            source_ids = [s.id for s in sources]
        else:
            raise HTTPException(status_code=400, detail="Either 'alias' or 'did' must be provided")
        
        # 调用 service 层查询
        result = video_service.get_videos_by_date_multi_source(
            source_ids=source_ids,
            date_str=date,
            pet_name=pet_name,
            page=page,
            page_size=page_size,
            db=db
        )
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get videos by date: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get videos by date: {str(e)}")


# ==================== 公开API（不需要JWT认证）====================
# 视频流API使用public_router，因为<video>标签无法携带Authorization header
# stream_token本身已包含HMAC签名，足够安全

@public_router.api_route("/video/stream", methods=["GET", "HEAD"])
async def stream_video(
    token: str = Query(..., description="视频文件token（别名:文件名）"),
    request: Request = None
):
    """流式传输视频文件（支持Range请求和HEAD请求，公开API）
    
    注意：此API不需要JWT认证，因为：
    1. HTML <video> 标签无法携带 Authorization header
    2. stream_token 本身包含 HMAC 签名，已有足够安全性
    3. stream_token 格式: base64(alias:filename).signature
    
    支持HTTP Range请求，用于：
    - 视频预加载和元数据获取
    - 视频拖动/seek操作
    - 减少带宽消耗
    """
    try:
        # 1. 解码token获取别名和文件名
        try:
            dir_alias, filename = decode_video_token(token)
        except ValueError as e:
            raise HTTPException(status_code=400, detail="Invalid video token")
        
        # 2. 验证别名和文件名的安全性（包含HMAC签名验证）
        validated_path = validate_video_token(dir_alias, filename)
        
        # 3. 获取文件大小
        file_size = validated_path.stat().st_size
        
        # 3.5 处理 HEAD 请求（返回元数据，不返回内容）
        if request and request.method == "HEAD":
            from fastapi.responses import Response
            return Response(
                status_code=200,
                headers={
                    "Content-Type": "video/mp4",
                    "Content-Length": str(file_size),
                    "Accept-Ranges": "bytes",
                },
                media_type="video/mp4"
            )
        
        # 4. 检查Range请求
        range_header = request.headers.get("range") if request else None
        
        if range_header:
            # 解析Range头: bytes=start-end
            range_match = range_header.replace("bytes=", "").split("-")
            start = int(range_match[0]) if range_match[0] else 0
            end = int(range_match[1]) if len(range_match) > 1 and range_match[1] else file_size - 1
            
            # 确保范围有效
            start = max(0, start)
            end = min(end, file_size - 1)
            content_length = end - start + 1
            
            # 异步读取指定范围的文件内容
            async def iterfile():
                async with aiofiles.open(validated_path, "rb") as f:
                    await f.seek(start)
                    remaining = content_length
                    while remaining > 0:
                        chunk_size = min(65536, remaining)  # 64KB chunks for better performance
                        data = await f.read(chunk_size)
                        if not data:
                            break
                        remaining -= len(data)
                        yield data
            
            # 返回206 Partial Content
            return StreamingResponse(
                iterfile(),
                status_code=206,
                headers={
                    "Content-Type": "video/mp4",
                    "Content-Length": str(content_length),
                    "Content-Range": f"bytes {start}-{end}/{file_size}",
                    "Accept-Ranges": "bytes",
                },
                media_type="video/mp4"
            )
        else:
            # 无Range请求，返回完整文件
            logger.info(f"Streaming video (full): {dir_alias}/{filename}")
            return FileResponse(
                path=str(validated_path),
                media_type='video/mp4',
                filename=validated_path.name,
                headers={"Accept-Ranges": "bytes"}
            )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to stream video: {e}")
        raise HTTPException(status_code=500, detail="Failed to stream video")


# ==================== 需要JWT认证的API ====================


@router.get("/video/{video_path:path}", response_model=VideoInfo)
async def get_video_info(video_path: str):
    """获取单个视频的详细信息"""
    try:
        # 检查文件是否存在
        if not Path(video_path).exists():
            raise HTTPException(status_code=404, detail="Video file not found")
        
        # 提取视频信息
        info = video_service.extract_info(video_path)
        return info
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to extract video info: {str(e)}")


class VideoRecordRequest(BaseModel):
    """视频切片记录请求"""
    source_id: int
    file_path: str
    file_name: str
    duration: Optional[float] = None
    file_size: Optional[int] = None
    detection_type: Optional[str] = None  # 'pet' 或 'motion'


@public_router.post("/videos/record")
async def record_video_slice(request: VideoRecordRequest):
    """记录视频切片到数据库（由切片脚本调用，无需认证）"""
    from models.database import VideoRecord
    
    logger.info(
        f"视频切片已完成 - Source: {request.source_id}, "
        f"File: {request.file_name}, "
        f"Duration: {request.duration}s, "
        f"Size: {request.file_size} bytes"
    )
    
    # 验证文件是否存在
    file_path = Path(request.file_path)
    if not file_path.exists():
        logger.warning(f"视频文件不存在: {request.file_path}")
        raise HTTPException(status_code=404, detail="Video file not found")
    
    # 提取视频元数据（使用 ffprobe）
    width, height, fps_val, codec = None, None, None, None
    try:
        info = video_service.extract_info(request.file_path)
        width = info.get('width')
        height = info.get('height')
        fps_val = info.get('fps')
        codec = info.get('codec')
    except Exception as e:
        logger.warning(f"提取视频元数据失败: {e}")
    
    # 写入数据库
    db = SessionLocal()
    try:
        # 从 stream_sources 获取 did
        from models.database import StreamSource
        source = db.query(StreamSource).filter(StreamSource.id == request.source_id).first()
        source_did = source.did if source and source.did else "0"
        
        video_record = VideoRecord(
            source_id=request.source_id,
            did=source_did,  # 从源获取did
            file_name=request.file_name,
            file_path=request.file_path,
            file_size=request.file_size,
            duration=request.duration,
            width=width,
            height=height,
            fps=fps_val,
            codec=codec,
            detection_type=request.detection_type,
            llm_status=None,  # 默认NULL，由Worker自动处理
            recorded_at=datetime.now()
        )
        db.add(video_record)
        db.commit()
        db.refresh(video_record)
        
        logger.info(f"视频记录已保存到数据库: ID={video_record.id}, File={request.file_name}")
        
        return {
            "message": "Video recorded successfully",
            "file_name": request.file_name,
            "record_id": video_record.id
        }
    except Exception as e:
        db.rollback()
        logger.error(f"保存视频记录失败: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to save video record: {str(e)}")
    finally:
        db.close()
