"""提示词管理 API"""
from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.orm import Session
from typing import List

from models.prompt_schemas import PromptCreate, PromptUpdate, PromptResponse, PromptListResponse
from models.database import Prompt
from models.db import get_db

router = APIRouter(prefix="/api", tags=["prompts"])


@router.get("/prompts", response_model=PromptListResponse)
async def get_prompts(
    active_only: bool = Query(False, description="只返回启用的提示词"),
    db: Session = Depends(get_db)
):
    """获取提示词列表"""
    try:
        # 只查询未删除的提示词
        query = db.query(Prompt).filter(Prompt.deleted == False)
        
        if active_only:
            query = query.filter(Prompt.is_active == True)
        
        prompts = query.order_by(Prompt.created_at.desc()).all()
        
        return PromptListResponse(
            prompts=[PromptResponse.from_orm(p) for p in prompts],
            total=len(prompts)
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get prompts: {str(e)}")


@router.get("/prompts/default", response_model=PromptResponse)
async def get_default_prompt(db: Session = Depends(get_db)):
    """获取默认提示词"""
    try:
        # 查找标记为默认的提示词（未删除）
        prompt = db.query(Prompt)\
            .filter(Prompt.is_default == True, Prompt.is_active == True, Prompt.deleted == False)\
            .first()
        
        # 如果没有默认提示词，返回最新的启用提示词（未删除）
        if not prompt:
            prompt = db.query(Prompt)\
                .filter(Prompt.is_active == True, Prompt.deleted == False)\
                .order_by(Prompt.created_at.desc())\
                .first()
        
        if not prompt:
            raise HTTPException(status_code=404, detail="No active prompt found")
        
        return PromptResponse.from_orm(prompt)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get default prompt: {str(e)}")


@router.get("/prompts/{prompt_id}", response_model=PromptResponse)
async def get_prompt(prompt_id: int, db: Session = Depends(get_db)):
    """获取指定提示词"""
    try:
        prompt = db.query(Prompt).filter(Prompt.id == prompt_id, Prompt.deleted == False).first()
        
        if not prompt:
            raise HTTPException(status_code=404, detail="Prompt not found")
        
        return PromptResponse.from_orm(prompt)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get prompt: {str(e)}")


@router.post("/prompts", response_model=PromptResponse, status_code=201)
async def create_prompt(prompt: PromptCreate, db: Session = Depends(get_db)):
    """创建新提示词"""
    try:
        # 创建新提示词
        db_prompt = Prompt(
            name=prompt.name,
            content=prompt.content,
            description=prompt.description,
            is_active=prompt.is_active,
            is_default=False  # 新创建的默认不设为默认
        )
        
        db.add(db_prompt)
        db.commit()
        db.refresh(db_prompt)
        
        return PromptResponse.from_orm(db_prompt)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to create prompt: {str(e)}")


@router.put("/prompts/{prompt_id}", response_model=PromptResponse)
async def update_prompt(prompt_id: int, prompt: PromptUpdate, db: Session = Depends(get_db)):
    """更新提示词"""
    try:
        db_prompt = db.query(Prompt).filter(Prompt.id == prompt_id, Prompt.deleted == False).first()
        
        if not db_prompt:
            raise HTTPException(status_code=404, detail="Prompt not found")
        
        # 更新字段
        update_data = prompt.dict(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_prompt, key, value)
        
        db.commit()
        db.refresh(db_prompt)
        
        return PromptResponse.from_orm(db_prompt)
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to update prompt: {str(e)}")


@router.put("/prompts/{prompt_id}/set-default")
async def set_default_prompt(prompt_id: int, db: Session = Depends(get_db)):
    """设置为默认提示词"""
    try:
        prompt = db.query(Prompt).filter(Prompt.id == prompt_id, Prompt.deleted == False).first()
        
        if not prompt:
            raise HTTPException(status_code=404, detail="Prompt not found")
        
        # 取消其他提示词的默认状态（只在未删除的提示词中）
        db.query(Prompt).filter(Prompt.deleted == False).update({"is_default": False})
        
        # 设置当前提示词为默认
        prompt.is_default = True
        prompt.is_active = True  # 默认提示词必须启用
        
        db.commit()
        
        return {"success": True, "message": f"Prompt {prompt_id} set as default"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to set default prompt: {str(e)}")


@router.delete("/prompts/{prompt_id}")
async def delete_prompt(prompt_id: int, db: Session = Depends(get_db)):
    """删除提示词（假删除）"""
    try:
        prompt = db.query(Prompt).filter(Prompt.id == prompt_id, Prompt.deleted == False).first()
        
        if not prompt:
            raise HTTPException(status_code=404, detail="Prompt not found")
        
        # 如果是默认提示词，不允许删除
        if prompt.is_default:
            raise HTTPException(status_code=400, detail="Cannot delete default prompt")
        
        # 假删除：只标记为已删除
        prompt.deleted = True
        db.commit()
        
        return {"success": True, "message": "Prompt deleted"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to delete prompt: {str(e)}")
