"""宠物信息管理 API"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List
import logging
from datetime import datetime

from models.db import get_db
from models.database import Pet
from models.schemas import PetCreate, PetUpdate, PetResponse, PetListResponse

# 需要 JWT 认证的路由（外部调用）
router = APIRouter(prefix="/api/pets", tags=["pets"])

# 内部路由（Service 调用，不需要 JWT）
internal_router = APIRouter(prefix="/api/internal/pets", tags=["pets-internal"])

logger = logging.getLogger(__name__)


@router.get("/", response_model=PetListResponse)
async def get_pets(
    did: str = Query(None, description="用户DID，不传则返回所有"),
    db: Session = Depends(get_db)
):
    """获取宠物列表（按创建时间排序，不传did则返回所有宠物）"""
    if did:
        pets = db.query(Pet).filter(Pet.did == did).order_by(Pet.created_at).all()
    else:
        pets = db.query(Pet).order_by(Pet.created_at).all()
    return PetListResponse(pets=pets, total=len(pets))


@router.get("/{pet_name}", response_model=PetResponse)
async def get_pet(
    pet_name: str,
    did: str = Query(..., description="用户DID"),
    db: Session = Depends(get_db)
):
    """获取单个宠物详情"""
    pet = db.query(Pet).filter(
        Pet.did == did,
        Pet.pet_name == pet_name
    ).first()
    
    if not pet:
        raise HTTPException(status_code=404, detail="Pet not found")
    
    return pet


@router.post("/", response_model=PetResponse)
async def create_pet(
    pet: PetCreate,
    did: str = Query(..., description="用户DID"),
    db: Session = Depends(get_db)
):
    """创建宠物"""
    # 检查是否已存在同名宠物
    existing_pet = db.query(Pet).filter(
        Pet.did == did,
        Pet.pet_name == pet.pet_name
    ).first()
    
    if existing_pet:
        raise HTTPException(
            status_code=400,
            detail=f"Pet with name '{pet.pet_name}' already exists"
        )
    
    # 创建新宠物
    pet_data = pet.model_dump()
    new_pet = Pet(
        did=did,
        **pet_data,
        created_at=datetime.now(),
        updated_at=datetime.now()
    )
    
    db.add(new_pet)
    
    try:
        db.commit()
        db.refresh(new_pet)
        logger.info(f"创建宠物成功: did={did}, pet_name={pet.pet_name}")
        return new_pet
    except Exception as e:
        db.rollback()
        logger.error(f"创建宠物失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{pet_name}", response_model=PetResponse)
async def update_pet(
    pet_name: str,
    pet_update: PetUpdate,
    did: str = Query(..., description="用户DID"),
    db: Session = Depends(get_db)
):
    """更新宠物信息（宠物名称不可修改）"""
    # 查找宠物
    db_pet = db.query(Pet).filter(
        Pet.did == did,
        Pet.pet_name == pet_name
    ).first()
    
    if not db_pet:
        raise HTTPException(status_code=404, detail="Pet not found")
    
    # 更新字段
    update_data = pet_update.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_pet, key, value)
    
    db_pet.updated_at = datetime.now()
    
    try:
        db.commit()
        db.refresh(db_pet)
        logger.info(f"更新宠物成功: did={did}, pet_name={pet_name}")
        return db_pet
    except Exception as e:
        db.rollback()
        logger.error(f"更新宠物失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{pet_name}")
async def delete_pet(
    pet_name: str,
    did: str = Query(..., description="用户DID"),
    db: Session = Depends(get_db)
):
    """删除宠物"""
    # 查找宠物
    db_pet = db.query(Pet).filter(
        Pet.did == did,
        Pet.pet_name == pet_name
    ).first()
    
    if not db_pet:
        raise HTTPException(status_code=404, detail="Pet not found")
    
    try:
        db.delete(db_pet)
        db.commit()
        logger.info(f"删除宠物成功: did={did}, pet_name={pet_name}")
        return {"message": "Pet deleted successfully"}
    except Exception as e:
        db.rollback()
        logger.error(f"删除宠物失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== 内部 API（供 Service 调用，不需要 JWT） ====================

@internal_router.get("/", response_model=PetListResponse)
async def internal_get_pets(
    did: str = Query(None, description="用户DID，不传则返回所有"),
    db: Session = Depends(get_db)
):
    """获取宠物列表（内部调用，不需要JWT）"""
    import time
    start_time = time.time()
    
    try:
        query_start = time.time()
        if did:
            pets = db.query(Pet).filter(Pet.did == did).order_by(Pet.created_at).all()
        else:
            pets = db.query(Pet).order_by(Pet.created_at).all()
        query_time = (time.time() - query_start) * 1000
        
        serialize_start = time.time()
        result = PetListResponse(pets=pets, total=len(pets))
        serialize_time = (time.time() - serialize_start) * 1000
        
        total_time = (time.time() - start_time) * 1000
        logger.info(f"[Backend/Pets] 性能统计 - 总耗时: {total_time:.0f}ms | DB查询: {query_time:.0f}ms | 序列化: {serialize_time:.0f}ms | 记录数: {len(pets)}")
        return result
        
    except Exception as e:
        logger.error(f"[Backend/Pets] 查询失败: {type(e).__name__}: {e}")
        raise HTTPException(status_code=500, detail=f"查询宠物列表失败: {str(e)}")


@internal_router.get("/{pet_name}", response_model=PetResponse)
async def internal_get_pet(
    pet_name: str,
    did: str = Query(..., description="用户DID"),
    db: Session = Depends(get_db)
):
    """获取单个宠物详情（内部调用，不需要JWT）"""
    pet = db.query(Pet).filter(
        Pet.did == did,
        Pet.pet_name == pet_name
    ).first()
    
    if not pet:
        raise HTTPException(status_code=404, detail="Pet not found")
    
    return pet


@internal_router.post("/", response_model=PetResponse)
async def internal_create_pet(
    pet: PetCreate,
    did: str = Query(..., description="用户DID"),
    db: Session = Depends(get_db)
):
    """创建宠物（内部调用，不需要JWT）"""
    logger.info(f"[Backend/Pets] 创建宠物请求: did={did}, pet_name={pet.pet_name}")
    logger.info(f"[Backend/Pets] 请求数据: {pet.model_dump()}")
    
    try:
        # 检查是否已存在同名宠物
        existing_pet = db.query(Pet).filter(
            Pet.did == did,
            Pet.pet_name == pet.pet_name
        ).first()
        
        if existing_pet:
            logger.warning(f"[Backend/Pets] 宠物已存在: did={did}, pet_name={pet.pet_name}")
            raise HTTPException(
                status_code=400,
                detail=f"Pet with name '{pet.pet_name}' already exists"
            )
        
        # 创建新宠物
        pet_data = pet.model_dump()
        logger.info(f"[Backend/Pets] 准备插入数据: {pet_data}")
        
        new_pet = Pet(
            did=did,
            **pet_data,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        
        db.add(new_pet)
        db.commit()
        db.refresh(new_pet)
        
        logger.info(f"[Backend/Pets] 创建成功: id={new_pet.id}, did={did}, pet_name={pet.pet_name}, avatar_color={new_pet.avatar_color}")
        return new_pet
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"[Backend/Pets] 创建失败: {type(e).__name__}: {e}")
        import traceback
        logger.error(f"[Backend/Pets] 堆栈:\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"创建宠物失败: {str(e)}")


@internal_router.put("/{pet_name}", response_model=PetResponse)
async def internal_update_pet(
    pet_name: str,
    pet_update: PetUpdate,
    did: str = Query(..., description="用户DID"),
    db: Session = Depends(get_db)
):
    """更新宠物信息（内部调用，不需要JWT）"""
    # 查找宠物
    db_pet = db.query(Pet).filter(
        Pet.did == did,
        Pet.pet_name == pet_name
    ).first()
    
    if not db_pet:
        raise HTTPException(status_code=404, detail="Pet not found")
    
    # 更新字段
    update_data = pet_update.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_pet, key, value)
    
    db_pet.updated_at = datetime.now()
    
    try:
        db.commit()
        db.refresh(db_pet)
        logger.info(f"更新宠物成功: did={did}, pet_name={pet_name}")
        return db_pet
    except Exception as e:
        db.rollback()
        logger.error(f"更新宠物失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@internal_router.delete("/{pet_name}")
async def internal_delete_pet(
    pet_name: str,
    did: str = Query(..., description="用户DID"),
    db: Session = Depends(get_db)
):
    """删除宠物（内部调用，不需要JWT）"""
    # 查找宠物
    db_pet = db.query(Pet).filter(
        Pet.did == did,
        Pet.pet_name == pet_name
    ).first()
    
    if not db_pet:
        raise HTTPException(status_code=404, detail="Pet not found")
    
    try:
        db.delete(db_pet)
        db.commit()
        logger.info(f"删除宠物成功: did={did}, pet_name={pet_name}")
        return {"message": "Pet deleted successfully"}
    except Exception as e:
        db.rollback()
        logger.error(f"删除宠物失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ==================== 通过ID操作的接口（Service 调用） ====================

@internal_router.get("/by-id/{pet_id}", response_model=PetResponse)
async def internal_get_pet_by_id(
    pet_id: int,
    did: str = Query(..., description="用户DID"),
    db: Session = Depends(get_db)
):
    """通过ID获取宠物详情（内部调用，不需要JWT）"""
    logger.info(f"[Backend/Pets] 通过ID获取宠物: pet_id={pet_id}, did={did}")
    
    try:
        pet = db.query(Pet).filter(
            Pet.id == pet_id,
            Pet.did == did
        ).first()
        
        if not pet:
            logger.warning(f"[Backend/Pets] 宠物未找到: pet_id={pet_id}, did={did}")
            raise HTTPException(status_code=404, detail="Pet not found")
        
        logger.info(f"[Backend/Pets] 查询成功: id={pet.id}, name={pet.pet_name}, avatar_color={pet.avatar_color}")
        return pet
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[Backend/Pets] 查询失败: {type(e).__name__}: {e}")
        import traceback
        logger.error(f"[Backend/Pets] 堆栈:\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"查询宠物失败: {str(e)}")


@internal_router.put("/by-id/{pet_id}", response_model=PetResponse)
async def internal_update_pet_by_id(
    pet_id: int,
    pet_update: PetUpdate,
    did: str = Query(..., description="用户DID"),
    db: Session = Depends(get_db)
):
    """通过ID更新宠物信息（内部调用，不需要JWT）"""
    logger.info(f"[Backend/Pets] 更新宠物请求: pet_id={pet_id}, did={did}")
    logger.info(f"[Backend/Pets] 更新数据: {pet_update.model_dump(exclude_unset=True)}")
    
    try:
        # 查找宠物
        db_pet = db.query(Pet).filter(
            Pet.id == pet_id,
            Pet.did == did
        ).first()
        
        if not db_pet:
            logger.warning(f"[Backend/Pets] 宠物未找到: pet_id={pet_id}, did={did}")
            raise HTTPException(status_code=404, detail="Pet not found")
        
        # 更新字段
        update_data = pet_update.model_dump(exclude_unset=True)
        logger.info(f"[Backend/Pets] 更新前: id={db_pet.id}, name={db_pet.pet_name}, avatar_color={db_pet.avatar_color}")
        
        for key, value in update_data.items():
            setattr(db_pet, key, value)
        
        db_pet.updated_at = datetime.now()
        
        db.commit()
        db.refresh(db_pet)
        
        logger.info(f"[Backend/Pets] 更新成功: id={db_pet.id}, name={db_pet.pet_name}, avatar_color={db_pet.avatar_color}")
        return db_pet
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"[Backend/Pets] 更新失败: {type(e).__name__}: {e}")
        import traceback
        logger.error(f"[Backend/Pets] 堆栈:\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"更新宠物失败: {str(e)}")


@internal_router.delete("/by-id/{pet_id}")
async def internal_delete_pet_by_id(
    pet_id: int,
    did: str = Query(..., description="用户DID"),
    db: Session = Depends(get_db)
):
    """通过ID删除宠物（内部调用，不需要JWT）"""
    logger.info(f"[Backend/Pets] 删除宠物请求: pet_id={pet_id}, did={did}")
    
    try:
        # 查找宠物
        db_pet = db.query(Pet).filter(
            Pet.id == pet_id,
            Pet.did == did
        ).first()
        
        if not db_pet:
            logger.warning(f"[Backend/Pets] 宠物未找到: pet_id={pet_id}, did={did}")
            raise HTTPException(status_code=404, detail="Pet not found")
        
        logger.info(f"[Backend/Pets] 删除前: id={db_pet.id}, name={db_pet.pet_name}")
        
        db.delete(db_pet)
        db.commit()
        
        logger.info(f"[Backend/Pets] 删除成功: pet_id={pet_id}, did={did}")
        return {"message": "Pet deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"[Backend/Pets] 删除失败: {type(e).__name__}: {e}")
        import traceback
        logger.error(f"[Backend/Pets] 堆栈:\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"删除宠物失败: {str(e)}")
