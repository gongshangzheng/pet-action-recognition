"""视频记录 API - 提供视频切片和AI分析结果查询"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from typing import List, Optional
from datetime import datetime, timedelta
import logging

from models.db import get_db
from models.database import VideoRecord, PetBehavior, StreamSource
from config import settings
from services.video_service import VideoService
from services.behavior_feedback_service import BehaviorFeedbackService

router = APIRouter(prefix="/api/video-records", tags=["video-records"])
internal_router = APIRouter(prefix="/api/internal/video-records", tags=["internal-video-records"])
logger = logging.getLogger(__name__)

# 视频服务实例
video_service = VideoService()


async def _get_video_dates_impl(
    did: str,
    start_date: Optional[str],
    end_date: Optional[str],
    db: Session
):
    """获取有视频记录的日期列表（内部实现）"""
    import time
    start_time = time.time()
    
    try:
        # logger.info(f"[DEBUG] ========== Backend Calendar 查询开始 ==========")
        # logger.info(f"[DEBUG] 参数: did={did}, start_date={start_date}, end_date={end_date}")
        
        # 获取用户的所有摄像头 source_id（使用 did 字段）
        step_start = time.time()
        sources = db.query(StreamSource).filter(
            StreamSource.did == did,
            StreamSource.is_active == 1
        ).all()
        source_ids = [s.id for s in sources]
        # logger.info(f"[DEBUG] 步骤1: 查询摄像头耗时 {(time.time()-step_start)*1000:.2f}ms")
        # logger.info(f"[DEBUG] 找到 {len(source_ids)} 个活跃摄像头: {source_ids}")
        
        if not source_ids:
            # logger.info(f"[DEBUG] 没有摄像头，返回空列表")
            # logger.info(f"[DEBUG] ========== Backend Calendar 查询完成 (总耗时 {(time.time()-start_time)*1000:.2f}ms) ==========")
            return {"dates": []}
        
        # 查询 video_records 表，获取不同的日期
        # 只返回有宠物行为数据的日期（使用 EXISTS 子查询代替 JOIN）
        step_start = time.time()
        from models.database import PetBehavior
        from sqlalchemy import exists
        
        # 使用 EXISTS 子查询，性能优于 JOIN
        has_behavior = exists().where(PetBehavior.video_id == VideoRecord.id)
        
        query = db.query(func.date(VideoRecord.recorded_at).label('date'))\
            .filter(
                VideoRecord.source_id.in_(source_ids),
                has_behavior
            )
        
        # 添加日期范围过滤
        if start_date:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
            query = query.filter(VideoRecord.recorded_at >= start_dt)
        if end_date:
            end_dt = datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)
            query = query.filter(VideoRecord.recorded_at < end_dt)
        
        # 去重并排序
        dates = query.distinct().order_by('date').all()
        # logger.info(f"[DEBUG] 步骤2: 查询日期耗时 {(time.time()-step_start)*1000:.2f}ms")
        # logger.info(f"[DEBUG] 查询到 {len(dates)} 条日期记录")
        
        # SQLite的func.date()返回字符串，不需要strftime
        step_start = time.time()
        date_list = []
        for d in dates:
            date_val = d[0]
            if isinstance(date_val, str):
                # 已经是字符串格式
                date_list.append(date_val)
            else:
                # 是date对象，需要格式化
                date_list.append(date_val.strftime('%Y-%m-%d'))
        
        # logger.info(f"[DEBUG] 步骤3: 格式化日期耗时 {(time.time()-step_start)*1000:.2f}ms")
        # logger.info(f"[DEBUG] 日期列表: {date_list}")
        # logger.info(f"[DEBUG] ========== Backend Calendar 查询完成 (总耗时 {(time.time()-start_time)*1000:.2f}ms) ==========")
        return {"dates": date_list}
        
    except Exception as e:
        logger.error(f"Backend Calendar 查询异常: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"获取视频日期失败: {str(e)}")


@router.get("/dates")
async def get_video_dates(
    did: str = Query(..., description="用户DID"),
    start_date: Optional[str] = Query(None, description="起始日期 YYYY-MM-DD"),
    end_date: Optional[str] = Query(None, description="结束日期 YYYY-MM-DD"),
    db: Session = Depends(get_db)
):
    """获取有视频记录的日期列表（用于日历接口）"""
    return await _get_video_dates_impl(did, start_date, end_date, db)


@internal_router.get("/dates")
async def get_video_dates_internal(
    did: str = Query(..., description="用户DID"),
    start_date: Optional[str] = Query(None, description="起始日期 YYYY-MM-DD"),
    end_date: Optional[str] = Query(None, description="结束日期 YYYY-MM-DD"),
    db: Session = Depends(get_db)
):
    """获取有视频记录的日期列表（内部接口，无需JWT认证）"""
    return await _get_video_dates_impl(did, start_date, end_date, db)


@internal_router.get("/")
async def get_video_records_internal(
    did: str = Query(..., description="用户DID"),
    date: str = Query(..., description="日期 YYYY-MM-DD"),
    pet_name: Optional[str] = Query(None, description="宠物名称（可选）"),
    db: Session = Depends(get_db)
):
    """获取视频记录列表（内部接口，无需JWT认证，用于Service层调用）"""
    return await get_video_records(did, date, pet_name, db)


@router.get("/")
async def get_video_records(
    did: str = Query(..., description="用户DID"),
    date: str = Query(..., description="日期 YYYY-MM-DD"),
    pet_name: Optional[str] = Query(None, description="宠物名称（可选）"),
    db: Session = Depends(get_db)
):
    """获取视频记录列表（包含AI分析结果，用于日报events）"""
    # logger.info(f"[video_records] API被调用！参数: did={did}, date={date}, pet_name={pet_name}")
    try:
        # logger.info(f"[video_records] 开始查询: did={did}, date={date}, pet_name={pet_name}")
        
        # 获取用户的所有摄像头 source_id（使用 did 字段）
        sources = db.query(StreamSource).filter(
            StreamSource.did == did,
            StreamSource.is_active == 1
        ).all()
        source_ids = [s.id for s in sources]
        
        # logger.info(f"[video_records] 用户 {did} 找到 {len(source_ids)} 个摄像头: {source_ids}")
        
        if not source_ids:
            # logger.warning(f"[video_records] 用户 {did} 没有找到对应的摄像头")
            return {"records": []}
        
        # 解析日期
        date_obj = datetime.strptime(date, '%Y-%m-%d').date()
        start_dt = datetime.combine(date_obj, datetime.min.time())
        end_dt = start_dt + timedelta(days=1)
        
        # 查询 video_records
        query = db.query(VideoRecord).filter(
            VideoRecord.source_id.in_(source_ids),
            VideoRecord.recorded_at >= start_dt,
            VideoRecord.recorded_at < end_dt
        )
        
        # 按录制时间排序
        records = query.order_by(VideoRecord.recorded_at).all()
        
        if not records:
            logger.info(f"查询用户 {did} 日期 {date} 的视频记录，共 0 条")
            return {"records": []}
        
        # 批量查询所有相关数据，消除 N+1 查询问题
        video_ids = [r.id for r in records]
        source_ids_set = {r.source_id for r in records}
        
        # 1. 批量查询所有 pet_behaviors
        all_pet_behaviors = db.query(PetBehavior).filter(
            PetBehavior.video_id.in_(video_ids)
        ).all()
        
        # 构建 video_id -> [pet_behaviors] 映射
        behaviors_map = {}
        for behavior in all_pet_behaviors:
            if behavior.video_id not in behaviors_map:
                behaviors_map[behavior.video_id] = []
            behaviors_map[behavior.video_id].append(behavior)
        
        # 2. 批量查询所有 stream_sources
        sources = db.query(StreamSource).filter(
            StreamSource.id.in_(source_ids_set)
        ).all()
        sources_map = {s.id: s for s in sources}
        
        # 3. 批量查询所有反馈状态
        feedback_service = BehaviorFeedbackService()
        all_items = []
        for vid in video_ids:
            behaviors = behaviors_map.get(vid, [])
            for behavior in behaviors:
                all_items.append((vid, behavior.pet_name))
        feedback_map = feedback_service.batch_get_user_feedback(all_items, did, db)
        
        # 构建返回数据
        result_records = []
        for record in records:
            # 获取该视频的宠物行为记录
            pet_behaviors = behaviors_map.get(record.id, [])
            
            # 如果该视频完全没有行为记录，跳过
            if not pet_behaviors:
                continue
            
            # 如果指定了 pet_name，过滤宠物行为记录
            filtered_pet_behaviors = pet_behaviors
            if pet_name:
                filtered_pet_behaviors = [p for p in pet_behaviors if p.pet_name == pet_name]
                # 如果指定了宠物名称但没有找到对应的行为记录，跳过这个视频记录
                if not filtered_pet_behaviors:
                    continue
            
            # 合并宠物行为结果
            pets_info = []
            all_actions = []
            for pet in filtered_pet_behaviors:
                key = (record.id, pet.pet_name)
                user_feedback = feedback_map.get(key)  # 'like'/'dislike'/None
                
                pets_info.append({
                    "video_id": record.id,
                    "pet_name": pet.pet_name,
                    "actions": pet.actions.split(',') if pet.actions else [],
                    "description": pet.description,
                    "status": pet.status,
                    "score": pet.score,
                    "user_feedback": user_feedback
                })
                if pet.actions:
                    all_actions.extend(pet.actions.split(','))
            
            # 生成视频播放token和URL
            video_url = None
            if record.file_name:
                source = sources_map.get(record.source_id)
                if source:
                    try:
                        stream_token = video_service.generate_stream_token(source.alias, record.file_name)
                        video_url = f"/api/video/stream?token={stream_token}"
                    except Exception as e:
                        logger.warning(f"生成stream_token失败: {e}")
            
            # 构建记录对象
            record_data = {
                "id": record.id,
                "duration": record.duration,
                "recorded_at": record.recorded_at.isoformat() if record.recorded_at else None,
                
                # 视频播放URL
                "video_url": video_url,
                
                # 宠物相关信息（如果只有一只宠物，直接返回其名称和动作）
                "pet_name": pets_info[0]["pet_name"] if len(pets_info) == 1 else None,
                "actions": list(set(all_actions)) if all_actions else [],  # 去重，没有则返回空列表
                
                # 完整的宠物分析列表（可能为空）
                "pets": pets_info
            }
            
            result_records.append(record_data)
        
        # logger.info(f"查询用户 {did} 日期 {date} 的视频记录，共 {len(result_records)} 条")
        return {"records": result_records}
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"日期格式错误: {str(e)}")
    except Exception as e:
        logger.error(f"获取视频记录失败: {e}")
        raise HTTPException(status_code=500, detail=f"获取视频记录失败: {str(e)}")
