"""视频分析 API"""
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from pathlib import Path
import os
from typing import List, Dict

from models.schemas import EstimateRequest, EstimateResponse, AnalysisRequest, AnalysisResponse
from models.database import VideoRecord
from datetime import datetime
from services.video_service import VideoService
from services.estimate_service import EstimateService
from services.dashscope_service import DashScopeService
from models.db import get_db
from config import settings, AVAILABLE_MODELS

router = APIRouter(prefix="/api", tags=["analysis"])
public_router = APIRouter(prefix="/api", tags=["analysis-public"])

# 服务实例
video_service = VideoService()
estimate_service = EstimateService()
dashscope_service = None  # 延迟初始化


def get_dashscope_service():
    """获取 DashScope 服务实例"""
    global dashscope_service
    if dashscope_service is None:
        dashscope_service = DashScopeService()
    return dashscope_service


@public_router.get("/models", response_model=List[Dict])
async def get_available_models():
    """获取可用模型列表（公开API，无需认证）"""
    return AVAILABLE_MODELS


@router.post("/estimate", response_model=EstimateResponse)
async def estimate_cost(request: EstimateRequest):
    """预估视频分析的费用"""
    try:
        # 检查文件是否存在
        if not Path(request.video_path).exists():
            raise HTTPException(status_code=404, detail="Video file not found")
        
        # 计算预估
        result = estimate_service.estimate(
            video_path=request.video_path,
            fps=request.fps,
            max_pixels=request.max_pixels,
            min_pixels=request.min_pixels,
            prompt_length=len(request.prompt) if request.prompt else 50,
            vl_high_resolution_images=request.vl_high_resolution_images
        )
        
        return EstimateResponse(**result)
        
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Video file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to estimate: {str(e)}")


@router.post("/analyze", response_model=AnalysisResponse)
async def analyze_video(request: AnalysisRequest, db: Session = Depends(get_db)):
    """执行视频分析"""
    try:
        # 1. 检查文件是否存在
        if not Path(request.video_path).exists():
            raise HTTPException(status_code=404, detail="Video file not found")
        
        # 2. 检查文件大小
        file_size_mb = Path(request.video_path).stat().st_size / 1024 / 1024
        if file_size_mb > settings.max_video_size_mb:
            raise HTTPException(
                status_code=400, 
                detail=f"Video file too large ({file_size_mb:.2f}MB > {settings.max_video_size_mb}MB)"
            )
        
        # 3. 获取视频信息
        try:
            video_info = video_service.extract_info(request.video_path)
        except Exception as e:
            # 如果无法提取视频信息，使用基本信息
            video_info = {
                'filename': os.path.basename(request.video_path),
                'duration_sec': 0
            }
            print(f"Warning: Failed to extract video info: {e}")
        
        # 4. 计算预估
        estimated = estimate_service.estimate(
            video_path=request.video_path,
            fps=request.fps,
            max_pixels=request.max_pixels,
            min_pixels=request.min_pixels,
            prompt_length=len(request.prompt)
        )
        
        # 5. 调用 DashScope API
        ds_service = get_dashscope_service()
        api_result = ds_service.analyze_video(
            video_path=request.video_path,
            prompt=request.prompt,
            fps=request.fps,
            max_pixels=request.max_pixels,
            min_pixels=request.min_pixels,
            vl_high_resolution_images=request.vl_high_resolution_images,
            model_name=request.model_name
        )
        
        if not api_result['success']:
            raise HTTPException(status_code=500, detail=f"API call failed: {api_result.get('error')}")
        
        # 6. 计算实际成本（不四舍五入）
        actual_input_tokens = api_result['input_tokens']
        actual_output_tokens = api_result['output_tokens']
        actual_total_tokens = api_result['total_tokens']
        
        actual_input_cost_breakdown = estimate_service.calculate_cost_with_breakdown(actual_input_tokens, is_input=True)
        actual_output_cost_breakdown = estimate_service.calculate_cost_with_breakdown(actual_output_tokens, is_input=False)
        actual_cost = actual_input_cost_breakdown['total_cost'] + actual_output_cost_breakdown['total_cost']
        
        # 7. 计算统计信息
        accuracy_rate = estimate_service.calculate_accuracy(
            estimated['total_input_tokens'],
            actual_input_tokens
        )
        
        tokens_per_frame = actual_input_tokens / estimated['frame_count'] if estimated['frame_count'] > 0 else 0
        cost_per_frame = actual_cost / estimated['frame_count'] if estimated['frame_count'] > 0 else 0
        cost_per_second = actual_cost / video_info['duration_sec'] if video_info['duration_sec'] > 0 else 0
        processing_speed = actual_total_tokens / api_result['duration_sec'] if api_result['duration_sec'] > 0 else 0
        
        # 8. 保存到数据库（使用 manual_analysis 表）
        from models.database import AnalysisHistory
        
        manual_analysis = AnalysisHistory(
            # 视频信息 - 使用AnalysisHistory的字段名
            video_name=video_info['filename'],
            video_path=request.video_path,
            video_duration_sec=video_info['duration_sec'],
            
            # 分析参数
            prompt=request.prompt,
            model_name=request.model_name,
            fps=request.fps,  # AnalysisHistory使用fps字段
            max_pixels=request.max_pixels,
            min_pixels=request.min_pixels,
            vl_high_resolution_images=request.vl_high_resolution_images,
            
            # Token统计和费用 - 使用AnalysisHistory的字段名
            input_tokens=actual_input_tokens,
            output_tokens=actual_output_tokens,
            total_tokens=actual_total_tokens,
            cost=actual_cost,  # AnalysisHistory使用cost字段
            duration_sec=api_result['duration_sec'],  # AnalysisHistory使用duration_sec字段
            
            # LLM结果 - 使用AnalysisHistory的字段名
            model_response=api_result['model_response'],  # AnalysisHistory使用model_response字段
        )
        
        db.add(manual_analysis)
        db.commit()
        db.refresh(manual_analysis)
        
        # 9. 返回结果
        return AnalysisResponse(
            id=manual_analysis.id,
            estimated={
                'frames': estimated['frame_count'],
                'video_tokens': estimated['video_tokens'],
                'prompt_tokens': estimated['prompt_tokens'],
                'total_input_tokens': estimated['total_input_tokens'],
                'estimated_output_tokens': estimated['estimated_output_tokens'],
                'cost': estimated['estimated_cost'],
                'breakdown': estimated['breakdown']
            },
            actual={
                'input_tokens': actual_input_tokens,
                'output_tokens': actual_output_tokens,
                'total_tokens': actual_total_tokens,
                'cost': actual_cost,
                'breakdown': {
                    'input_cost': actual_input_cost_breakdown['total_cost'],
                    'output_cost': actual_output_cost_breakdown['total_cost'],
                    'input_details': actual_input_cost_breakdown['breakdown'],
                    'output_details': actual_output_cost_breakdown['breakdown']
                }
            },
            model_response=api_result['model_response'],
            statistics={
                'duration_sec': api_result['duration_sec'],
                'accuracy_rate': accuracy_rate,
                'tokens_per_frame': round(tokens_per_frame, 1),
                'cost_per_frame': cost_per_frame,
                'cost_per_second': cost_per_second,
                'processing_speed': round(processing_speed, 0)
            }
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")
