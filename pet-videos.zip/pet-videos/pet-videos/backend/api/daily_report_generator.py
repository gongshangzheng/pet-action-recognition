"""日报生成器管理 API"""
from fastapi import APIRouter, HTTPException, Query
from typing import Optional

from services.daily_report_generator import daily_report_generator
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/daily-report-generator", tags=["daily-report-generator"])


@router.post("/start")
async def start_generator():
    """启动日报生成服务"""
    try:
        if daily_report_generator.is_running():
            return {
                "message": "日报生成服务已在运行",
                "status": "running"
            }
        
        daily_report_generator.start_worker()
        logger.info("日报生成服务已启动")
        
        return {
            "message": "日报生成服务启动成功",
            "status": "started"
        }
    except Exception as e:
        logger.error(f"启动日报生成服务失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stop")
async def stop_generator():
    """停止日报生成服务"""
    try:
        if not daily_report_generator.is_running():
            return {
                "message": "日报生成服务未运行",
                "status": "stopped"
            }
        
        daily_report_generator.stop_worker()
        logger.info("日报生成服务已停止")
        
        return {
            "message": "日报生成服务停止成功",
            "status": "stopped"
        }
    except Exception as e:
        logger.error(f"停止日报生成服务失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status")
async def get_generator_status():
    """获取日报生成服务状态"""
    try:
        status = daily_report_generator.get_status()
        return status
    except Exception as e:
        logger.error(f"获取日报生成服务状态失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate")
async def trigger_generation(
    did: Optional[str] = Query(None, description="用户ID（可选，不传则生成所有）"),
    pet_name: Optional[str] = Query(None, description="宠物名称（可选，需要与did一起传）")
):
    """手动触发生成日报"""
    try:
        if did and not pet_name:
            raise HTTPException(
                status_code=400,
                detail="如果指定了did，必须同时指定pet_name"
            )
        
        daily_report_generator.trigger_immediate_generation(did, pet_name)
        
        if did and pet_name:
            message = f"已触发生成日报: {did} / {pet_name}"
        else:
            message = "已触发生成所有日报"
        
        return {
            "message": message,
            "success": True
        }
    except Exception as e:
        logger.error(f"手动触发生成日报失败: {e}")
        raise HTTPException(status_code=500, detail=str(e))
