from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel
import logging
import os
from pathlib import Path

from models.db import get_db
from models.database import SlicingTask, StreamSource
from models.schemas import SlicingTaskResponse, ScriptFileInfo
from services.task_service import TaskService
from config import settings

router = APIRouter(prefix="/api/tasks", tags=["tasks"])
internal_router = APIRouter(prefix="/api/tasks", tags=["tasks-internal"])
logger = logging.getLogger(__name__)
task_service = TaskService()

class StartTaskRequest(BaseModel):
    enable_yolo: Optional[bool] = True
    script_file: Optional[str] = 'pet_monitor.py'

@router.get("/", response_model=List[SlicingTaskResponse])
async def get_tasks(db: Session = Depends(get_db)):
    """获取所有任务状态"""
    return db.query(SlicingTask).all()

@router.get("/scripts", response_model=List[ScriptFileInfo])
async def get_available_scripts():
    """获取 scripts 目录下所有可用的 Python 脚本"""
    scripts_dir = Path(settings.BASE_DIR) / "scripts"
    
    if not scripts_dir.exists():
        logger.warning(f"Scripts directory not found: {scripts_dir}")
        return []
    
    scripts = []
    for py_file in scripts_dir.glob("*.py"):
        # 读取文件头部所有连续的注释行作为描述（最多10行）
        description = None
        try:
            with open(py_file, 'r', encoding='utf-8') as f:
                comment_lines = []
                for i, line in enumerate(f):
                    if i >= 10:  # 最多读取前10行
                        break
                    stripped = line.strip()
                    if stripped.startswith('#'):
                        # 去掉 # 号和空格
                        comment_text = stripped[1:].strip()
                        if comment_text:  # 只添加非空注释
                            comment_lines.append(comment_text)
                    elif stripped:  # 遇到第一个非注释非空行，停止读取
                        break
                
                if comment_lines:
                    description = '\n'.join(comment_lines)
        except Exception as e:
            logger.warning(f"Failed to read description from {py_file.name}: {e}")
        
        scripts.append(ScriptFileInfo(
            filename=py_file.name,
            path=str(py_file),
            description=description
        ))
    
    # 按文件名排序
    scripts.sort(key=lambda x: x.filename)
    
    logger.info(f"Found {len(scripts)} Python scripts in {scripts_dir}")
    return scripts

@router.post("/{source_id}/start")
async def start_task(
    source_id: int, 
    request: StartTaskRequest = Body(default=StartTaskRequest()),
    db: Session = Depends(get_db)
):
    """启动指定源的切片任务"""
    # 验证脚本文件是否存在
    scripts_dir = Path(settings.BASE_DIR) / "scripts"
    script_path = scripts_dir / request.script_file
    if not script_path.exists():
        raise HTTPException(status_code=400, detail=f"Script file not found: {request.script_file}")
    
    # 查找或创建任务
    task = db.query(SlicingTask).filter(SlicingTask.source_id == source_id).first()
    if not task:
        # 新建任务，设置 enable_yolo 和 script_file
        task = SlicingTask(
            source_id=source_id, 
            enable_yolo=request.enable_yolo,
            script_file=request.script_file
        )
        db.add(task)
        db.commit()
    else:
        # 更新已有任务的配置
        task.enable_yolo = request.enable_yolo
        task.script_file = request.script_file
        # 手动启动时，清零失败计数和错误信息
        task.consecutive_failures = 0
        task.error_msg = None
        db.commit()
        logger.info(f"Reset failure count for task {source_id} on manual start")
    
    success = task_service.start_task(source_id, db)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to start task")
    return {"message": "Task started successfully"}

@router.post("/{source_id}/stop")
async def stop_task(source_id: int, db: Session = Depends(get_db)):
    """停止指定源的切片任务"""
    success = task_service.stop_task(source_id, db)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to stop task")
    return {"message": "Task stopped successfully"}

@router.delete("/{task_id}")
async def delete_task(task_id: int, db: Session = Depends(get_db)):
    """删除任务（先停止再删除）"""
    # 查找任务
    task = db.query(SlicingTask).filter(SlicingTask.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # 如果任务正在运行，先停止
    if task.status == 'running':
        logger.info(f"停止任务 {task_id} (source_id={task.source_id})")
        task_service.stop_task(task.source_id, db)
    
    # 删除数据库记录
    db.delete(task)
    db.commit()
    
    logger.info(f"任务 {task_id} 已删除")
    return {"message": "Task deleted successfully"}

@internal_router.post("/{source_id}/heartbeat")
async def task_heartbeat(source_id: int, db: Session = Depends(get_db)):
    """任务心跳接口（由切片脚本调用，无需认证）"""
    task = db.query(SlicingTask).filter(SlicingTask.source_id == source_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    from datetime import datetime
    task.last_heartbeat = datetime.now()
    task.status = 'running'
    db.commit()
    
    return {"message": "Heartbeat updated"}

@router.get("/available_sources")
async def get_available_sources(db: Session = Depends(get_db)):
    """获取尚未运行任务的源"""
    # 查找没有关联 running 任务的所有源
    running_source_ids = db.query(SlicingTask.source_id).filter(SlicingTask.status == 'running').all()
    running_ids = [r[0] for r in running_source_ids]
    
    available = db.query(StreamSource).filter(
        StreamSource.is_active == True,
        ~StreamSource.id.in_(running_ids) if running_ids else True
    ).all()
    
    return available

@router.get("/{source_id}/logs")
async def get_task_logs(
    source_id: int, 
    db: Session = Depends(get_db)
):
    """获取任务日志（倒序，最新的在前，最多5000行）"""
    MAX_LINES = 5000
    
    # 查找任务
    task = db.query(SlicingTask).filter(SlicingTask.source_id == source_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # 构建日志文件路径
    log_dir = Path(settings.BASE_DIR) / "logs" / "tasks"
    log_file = log_dir / f"task_{source_id}.log"
    
    if not log_file.exists():
        return {
            "source_id": source_id,
            "exists": False,
            "lines": [],
            "total_lines": 0
        }
    
    try:
        # 读取全部日志文件
        with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
            all_lines = f.readlines()
        
        total_lines = len(all_lines)
        
        # 只取最后5000行（最新的）
        recent_lines = all_lines[-MAX_LINES:] if total_lines > MAX_LINES else all_lines
        
        # 倒序（最新的在前）
        recent_lines.reverse()
        
        # 清理空行
        log_lines = [line.rstrip() for line in recent_lines if line.strip()]
        
        return {
            "source_id": source_id,
            "exists": True,
            "lines": log_lines,
            "total_lines": total_lines
        }
    except Exception as e:
        logger.error(f"Failed to read log file {log_file}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to read log file: {str(e)}")
