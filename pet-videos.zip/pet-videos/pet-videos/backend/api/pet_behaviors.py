"""宠物行为 API"""
from fastapi import APIRouter, HTTPException, Depends, Query
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, desc
from typing import List, Optional, Dict, Any
from datetime import datetime, date
import json
import logging

from models.db import get_db
from models.database import PetBehavior, VideoRecord, Pet
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/pet-behaviors", tags=["pet-behaviors"])
logger = logging.getLogger(__name__)


# Pydantic 模型
class PetBehaviorResponse(BaseModel):
    """宠物行为响应模型"""
    video_id: int
    pet_name: str
    did: str
    actions: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    location: Optional[str] = None
    score: Optional[int] = None
    created_at: datetime
    
    # 关联的视频信息
    video_file_name: Optional[str] = None
    video_duration: Optional[float] = None
    video_recorded_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class PetBehaviorListResponse(BaseModel):
    """宠物行为列表响应"""
    behaviors: List[PetBehaviorResponse]
    total: int
    page: int
    page_size: int


class PetBehaviorDetailResponse(BaseModel):
    """宠物行为详情响应"""
    video_id: int
    pet_name: str
    did: str
    actions: Optional[str] = None
    actions_list: List[str] = Field(default_factory=list)  # 解析后的行为列表
    description: Optional[str] = None
    status: Optional[str] = None
    location: Optional[str] = None
    score: Optional[int] = None
    raw_result: Optional[Dict[str, Any]] = None  # 解析后的原始JSON
    created_at: datetime
    
    # 关联的视频信息
    video_file_name: Optional[str] = None
    video_file_path: Optional[str] = None
    video_duration: Optional[float] = None
    video_recorded_at: Optional[datetime] = None
    video_llm_status: Optional[str] = None
    
    class Config:
        from_attributes = True


@router.get("/statistics/summary")
async def get_behavior_stats(
    did: Optional[str] = Query(None, description="用户DID（可选）"),
    start_date: Optional[str] = Query(None, description="开始日期 YYYY-MM-DD（可选）"),
    end_date: Optional[str] = Query(None, description="结束日期 YYYY-MM-DD（可选）"),
    db: Session = Depends(get_db)
):
    """获取宠物行为统计信息"""
    try:
        logger.info(f"查询宠物行为统计: did={did}, start_date={start_date}, end_date={end_date}")
        
        # 构建基础查询
        query = db.query(PetBehavior).join(
            VideoRecord, PetBehavior.video_id == VideoRecord.id
        )
        
        # 添加过滤条件
        if did:
            query = query.filter(PetBehavior.did == did)
        
        if start_date:
            try:
                start_dt = datetime.strptime(start_date, '%Y-%m-%d')
                query = query.filter(VideoRecord.recorded_at >= start_dt)
            except ValueError:
                raise HTTPException(status_code=400, detail="开始日期格式错误")
        
        if end_date:
            try:
                end_dt = datetime.strptime(end_date, '%Y-%m-%d')
                query = query.filter(VideoRecord.recorded_at <= end_dt)
            except ValueError:
                raise HTTPException(status_code=400, detail="结束日期格式错误")
        
        # 获取所有记录
        behaviors = query.all()
        
        # 统计信息
        total_behaviors = len(behaviors)
        pet_names = set(b.pet_name for b in behaviors)
        total_pets = len(pet_names)
        
        # 行为类型统计
        action_stats = {}
        for behavior in behaviors:
            if behavior.actions:
                actions = [action.strip() for action in behavior.actions.split(',') if action.strip()]
                for action in actions:
                    action_stats[action] = action_stats.get(action, 0) + 1
        
        # 评分统计
        scores = [b.score for b in behaviors if b.score is not None]
        avg_score = sum(scores) / len(scores) if scores else 0
        
        # 按宠物统计
        pet_stats = {}
        for pet_name in pet_names:
            pet_behaviors = [b for b in behaviors if b.pet_name == pet_name]
            pet_scores = [b.score for b in pet_behaviors if b.score is not None]
            pet_stats[pet_name] = {
                'behavior_count': len(pet_behaviors),
                'avg_score': sum(pet_scores) / len(pet_scores) if pet_scores else 0,
                'latest_behavior': max(pet_behaviors, key=lambda x: x.created_at).created_at if pet_behaviors else None
            }
        
        result = {
            'total_behaviors': total_behaviors,
            'total_pets': total_pets,
            'avg_score': round(avg_score, 2),
            'action_stats': action_stats,
            'pet_stats': pet_stats,
            'date_range': {
                'start_date': start_date,
                'end_date': end_date
            }
        }
        
        logger.info(f"统计完成: {total_behaviors} 条行为记录, {total_pets} 只宠物")
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"查询宠物行为统计失败: {e}")
        raise HTTPException(status_code=500, detail=f"统计失败: {str(e)}")


@router.get("/", response_model=PetBehaviorListResponse)
async def get_pet_behaviors(
    did: Optional[str] = Query(None, description="用户DID（可选）"),
    pet_name: Optional[str] = Query(None, description="宠物名称（可选）"),
    date: Optional[str] = Query(None, description="日期 YYYY-MM-DD（可选）"),
    page: int = Query(1, ge=1, description="页码"),
    page_size: int = Query(20, ge=1, le=100, description="每页数量"),
    db: Session = Depends(get_db)
):
    """获取宠物行为列表"""
    try:
        logger.info(f"查询宠物行为列表: did={did}, pet_name={pet_name}, date={date}")
        
        # 构建查询
        query = db.query(PetBehavior).join(
            VideoRecord, PetBehavior.video_id == VideoRecord.id
        )
        
        # 添加过滤条件
        if did:
            query = query.filter(PetBehavior.did == did)
        
        if pet_name:
            query = query.filter(PetBehavior.pet_name == pet_name)
        
        if date:
            # 按日期过滤视频记录
            try:
                date_obj = datetime.strptime(date, '%Y-%m-%d').date()
                start_dt = datetime.combine(date_obj, datetime.min.time())
                end_dt = datetime.combine(date_obj, datetime.max.time())
                query = query.filter(
                    and_(
                        VideoRecord.recorded_at >= start_dt,
                        VideoRecord.recorded_at <= end_dt
                    )
                )
            except ValueError:
                raise HTTPException(status_code=400, detail="日期格式错误，请使用 YYYY-MM-DD")
        
        # 获取总数
        total = query.count()
        
        # 分页和排序
        behaviors = query.order_by(desc(PetBehavior.created_at)).offset(
            (page - 1) * page_size
        ).limit(page_size).all()
        
        # 构建响应数据
        behavior_responses = []
        for behavior in behaviors:
            # 获取关联的视频记录
            video_record = db.query(VideoRecord).filter(
                VideoRecord.id == behavior.video_id
            ).first()
            
            behavior_data = PetBehaviorResponse(
                video_id=behavior.video_id,
                pet_name=behavior.pet_name,
                did=behavior.did,
                actions=behavior.actions,
                description=behavior.description,
                status=behavior.status,
                location=behavior.location,
                score=behavior.score,
                created_at=behavior.created_at,
                video_file_name=video_record.file_name if video_record else None,
                video_duration=video_record.duration if video_record else None,
                video_recorded_at=video_record.recorded_at if video_record else None
            )
            behavior_responses.append(behavior_data)
        
        logger.info(f"查询到 {len(behavior_responses)} 条宠物行为记录")
        
        return PetBehaviorListResponse(
            behaviors=behavior_responses,
            total=total,
            page=page,
            page_size=page_size
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"查询宠物行为列表失败: {e}")
        raise HTTPException(status_code=500, detail=f"查询失败: {str(e)}")


@router.get("/{video_id}/{pet_name}", response_model=PetBehaviorDetailResponse)
async def get_pet_behavior_detail(
    video_id: int,
    pet_name: str,
    db: Session = Depends(get_db)
):
    """获取宠物行为详情"""
    try:
        logger.info(f"查询宠物行为详情: video_id={video_id}, pet_name={pet_name}")
        
        # 查询宠物行为记录
        behavior = db.query(PetBehavior).filter(
            and_(
                PetBehavior.video_id == video_id,
                PetBehavior.pet_name == pet_name
            )
        ).first()
        
        if not behavior:
            raise HTTPException(
                status_code=404, 
                detail=f"未找到视频 {video_id} 中宠物 {pet_name} 的行为记录"
            )
        
        # 获取关联的视频记录
        video_record = db.query(VideoRecord).filter(
            VideoRecord.id == video_id
        ).first()
        
        # 解析actions为列表
        actions_list = []
        if behavior.actions:
            actions_list = [action.strip() for action in behavior.actions.split(',') if action.strip()]
        
        # 解析raw_result为JSON
        raw_result_dict = None
        if behavior.raw_result:
            try:
                raw_result_dict = json.loads(behavior.raw_result)
            except json.JSONDecodeError:
                logger.warning(f"无法解析raw_result为JSON: {behavior.raw_result}")
        
        # 构建响应数据
        response_data = PetBehaviorDetailResponse(
            video_id=behavior.video_id,
            pet_name=behavior.pet_name,
            did=behavior.did,
            actions=behavior.actions,
            actions_list=actions_list,
            description=behavior.description,
            status=behavior.status,
            location=behavior.location,
            score=behavior.score,
            raw_result=raw_result_dict,
            created_at=behavior.created_at,
            video_file_name=video_record.file_name if video_record else None,
            video_file_path=video_record.file_path if video_record else None,
            video_duration=video_record.duration if video_record else None,
            video_recorded_at=video_record.recorded_at if video_record else None,
            video_llm_status=video_record.llm_status if video_record else None
        )
        
        logger.info(f"查询到宠物行为详情: {pet_name} 在视频 {video_id} 中的行为")
        
        return response_data
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"查询宠物行为详情失败: {e}")
        raise HTTPException(status_code=500, detail=f"查询失败: {str(e)}")