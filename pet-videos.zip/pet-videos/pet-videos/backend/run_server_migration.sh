#!/bin/bash
# 服务器数据库迁移执行脚本
# 用途：按正确顺序执行所有迁移脚本

set -e  # 遇到错误立即退出

echo "======================================================================"
echo "🚀 服务器数据库迁移执行脚本"
echo "======================================================================"
echo ""

# 数据库路径（可通过环境变量指定）
DB_PATH="${DATABASE_PATH:-database/server_history.db}"

echo "📂 数据库路径: $DB_PATH"
echo ""

# 检查数据库文件是否存在
if [ ! -f "$DB_PATH" ]; then
    echo "❌ 数据库文件不存在: $DB_PATH"
    echo "请先将服务器数据库下载到该位置"
    exit 1
fi

# 备份数据库
BACKUP_PATH="${DB_PATH}.backup.$(date +%Y%m%d_%H%M%S)"
echo "📝 步骤 1: 备份数据库"
echo "----------------------------------------------------------------------"
cp "$DB_PATH" "$BACKUP_PATH"
echo "✅ 备份完成: $BACKUP_PATH"
echo ""

# 迁移脚本列表（按顺序执行）
MIGRATIONS=(
    "migrate_add_did_to_stream_sources.py:添加 did 字段到 stream_sources"
    "migrate_unify_video_records.py:统一视频记录表"
    "migrate_add_pets_table.py:创建 pets 表"
    "migrate_add_weight_to_pets.py:添加 weight 字段到 pets"
    "migrate_add_avatar_color_to_pets.py:添加 avatar_color 字段到 pets"
    "migrate_add_video_pet_analysis_table.py:创建 video_pet_analysis 表"
    "migrate_rename_video_pet_analysis_to_pet_behaviors.py:重命名为 pet_behaviors 表"
    "migrate_add_daily_reports_table.py:创建 daily_reports 表"
)

echo "📝 步骤 2: 执行迁移脚本"
echo "----------------------------------------------------------------------"
echo ""

SUCCESS_COUNT=0
FAIL_COUNT=0

for migration in "${MIGRATIONS[@]}"; do
    IFS=':' read -r script description <<< "$migration"
    script_path="migrations/$script"
    
    if [ ! -f "$script_path" ]; then
        echo "  ⚠️  脚本不存在: $script"
        ((FAIL_COUNT++))
        continue
    fi
    
    echo "  🔄 执行: $description"
    echo "     脚本: $script"
    
    if DATABASE_PATH="$DB_PATH" python3 "$script_path"; then
        echo "  ✅ 成功"
        ((SUCCESS_COUNT++))
    else
        echo "  ❌ 失败"
        ((FAIL_COUNT++))
        echo ""
        echo "迁移失败！已回滚到备份："
        echo "  cp $BACKUP_PATH $DB_PATH"
        exit 1
    fi
    echo ""
done

echo "======================================================================"
echo "📊 迁移执行总结"
echo "======================================================================"
echo ""
echo "执行的迁移脚本: $((SUCCESS_COUNT + FAIL_COUNT))"
echo "成功: $SUCCESS_COUNT"
echo "失败: $FAIL_COUNT"
echo ""

if [ $FAIL_COUNT -eq 0 ]; then
    echo "✅ 所有迁移脚本执行成功！"
    echo ""
    echo "📝 后续操作:"
    echo "  1. 验证数据库结构和数据完整性"
    echo "  2. 将迁移后的数据库上传回服务器"
    echo "  3. 重启服务器上的应用服务"
    echo ""
    echo "备份文件: $BACKUP_PATH"
    exit 0
else
    echo "❌ 部分迁移失败"
    echo ""
    echo "备份文件: $BACKUP_PATH"
    exit 1
fi
