@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ======================================================================
echo Pet-Videos Database Migration Script
echo ======================================================================
echo.

if "%DATABASE_PATH%"=="" (
    set "DB_PATH=database\server_history.db"
) else (
    set "DB_PATH=%DATABASE_PATH%"
)

echo Database: %DB_PATH%
echo.

if not exist "%DB_PATH%" (
    echo ERROR: Database file not found: %DB_PATH%
    exit /b 1
)

set "TIMESTAMP=%date:~0,4%%date:~5,2%%date:~8,2%_%time:~0,2%%time:~3,2%%time:~6,2%"
set "TIMESTAMP=%TIMESTAMP: =0%"
set "BACKUP_PATH=%DB_PATH%.backup.%TIMESTAMP%"

echo Step 1: Backup database
echo ----------------------------------------------------------------------
copy "%DB_PATH%" "%BACKUP_PATH%" >nul
if errorlevel 1 (
    echo ERROR: Backup failed
    exit /b 1
)
echo OK: Backup completed: %BACKUP_PATH%
echo.

echo Step 2: Run migration scripts
echo ----------------------------------------------------------------------
echo.

set SUCCESS_COUNT=0
set FAIL_COUNT=0

echo [1/8] migrate_add_did_to_stream_sources.py
if exist "migrations\migrate_add_did_to_stream_sources.py" (
    set "DATABASE_PATH=%DB_PATH%"
    python migrations\migrate_add_did_to_stream_sources.py
    if errorlevel 1 (
        echo ERROR: Migration failed
        echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
        exit /b 1
    )
    set /a SUCCESS_COUNT+=1
    echo OK
) else (
    echo SKIP: File not found
)
echo.

echo [2/8] migrate_unify_video_records.py
if exist "migrations\migrate_unify_video_records.py" (
    set "DATABASE_PATH=%DB_PATH%"
    python migrations\migrate_unify_video_records.py
    if errorlevel 1 (
        echo ERROR: Migration failed
        echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
        exit /b 1
    )
    set /a SUCCESS_COUNT+=1
    echo OK
) else (
    echo SKIP: File not found
)
echo.

echo [3/8] migrate_add_pets_table.py
if exist "migrations\migrate_add_pets_table.py" (
    set "DATABASE_PATH=%DB_PATH%"
    python migrations\migrate_add_pets_table.py
    if errorlevel 1 (
        echo ERROR: Migration failed
        echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
        exit /b 1
    )
    set /a SUCCESS_COUNT+=1
    echo OK
) else (
    echo SKIP: File not found
)
echo.

echo [4/8] migrate_add_weight_to_pets.py
if exist "migrations\migrate_add_weight_to_pets.py" (
    set "DATABASE_PATH=%DB_PATH%"
    python migrations\migrate_add_weight_to_pets.py
    if errorlevel 1 (
        echo ERROR: Migration failed
        echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
        exit /b 1
    )
    set /a SUCCESS_COUNT+=1
    echo OK
) else (
    echo SKIP: File not found
)
echo.

echo [5/8] migrate_add_avatar_color_to_pets.py
if exist "migrations\migrate_add_avatar_color_to_pets.py" (
    set "DATABASE_PATH=%DB_PATH%"
    python migrations\migrate_add_avatar_color_to_pets.py
    if errorlevel 1 (
        echo ERROR: Migration failed
        echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
        exit /b 1
    )
    set /a SUCCESS_COUNT+=1
    echo OK
) else (
    echo SKIP: File not found
)
echo.

echo [6/8] migrate_add_video_pet_analysis_table.py
if exist "migrations\migrate_add_video_pet_analysis_table.py" (
    set "DATABASE_PATH=%DB_PATH%"
    python migrations\migrate_add_video_pet_analysis_table.py
    if errorlevel 1 (
        echo ERROR: Migration failed
        echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
        exit /b 1
    )
    set /a SUCCESS_COUNT+=1
    echo OK
) else (
    echo SKIP: File not found
)
echo.

echo [7/8] migrate_rename_video_pet_analysis_to_pet_behaviors.py
if exist "migrations\migrate_rename_video_pet_analysis_to_pet_behaviors.py" (
    set "DATABASE_PATH=%DB_PATH%"
    python migrations\migrate_rename_video_pet_analysis_to_pet_behaviors.py
    if errorlevel 1 (
        echo ERROR: Migration failed
        echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
        exit /b 1
    )
    set /a SUCCESS_COUNT+=1
    echo OK
) else (
    echo SKIP: File not found
)
echo.

echo [8/8] migrate_add_daily_reports_table.py
if exist "migrations\migrate_add_daily_reports_table.py" (
    set "DATABASE_PATH=%DB_PATH%"
    python migrations\migrate_add_daily_reports_table.py
    if errorlevel 1 (
        echo ERROR: Migration failed
        echo Rollback: copy "%BACKUP_PATH%" "%DB_PATH%"
        exit /b 1
    )
    set /a SUCCESS_COUNT+=1
    echo OK
) else (
    echo SKIP: File not found
)
echo.

echo ======================================================================
echo Migration Summary
echo ======================================================================
echo.
echo Success: %SUCCESS_COUNT%
echo Backup: %BACKUP_PATH%
echo.
echo All migrations completed successfully!
echo.
echo Next steps:
echo   1. Verify database structure
echo   2. Upload database to server
echo   3. Restart application services
echo.
echo ======================================================================

exit /b 0
