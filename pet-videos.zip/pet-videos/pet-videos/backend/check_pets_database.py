"""
快速检查pets数据库状态

用于排查宠物列表加载问题
"""
import sqlite3
import sys
from pathlib import Path

def check_database(db_path=None):
    """检查数据库状态"""
    if not db_path:
        # 尝试从config读取
        try:
            sys.path.insert(0, str(Path(__file__).parent))
            from config import settings
            db_path = settings.database_path
        except Exception as e:
            print(f"❌ 无法读取配置: {e}")
            print("请手动指定数据库路径:")
            print(f"  python {Path(__file__).name} <数据库路径>")
            return False
    
    db_path = Path(db_path)
    
    print("=" * 60)
    print("Pets 数据库诊断工具")
    print("=" * 60)
    print(f"\n数据库路径: {db_path}")
    print(f"文件存在: {db_path.exists()}")
    
    if not db_path.exists():
        print("\n❌ 数据库文件不存在！")
        return False
    
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # 检查表
        print("\n--- 检查表 ---")
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name IN ('pets', 'pets_new')
            ORDER BY name
        """)
        tables = [row[0] for row in cursor.fetchall()]
        print(f"找到的表: {', '.join(tables) if tables else '无'}")
        
        if 'pets' not in tables:
            print("\n❌ pets表不存在！")
            if 'pets_new' in tables:
                print("⚠️  发现pets_new表，迁移未完成")
                print("请执行: python backend/migrations/migrate_fix_server_database.py")
            else:
                print("请执行: python backend/migrations/migrate_init_all.py")
            return False
        
        # 检查表结构
        print("\n--- 检查表结构 ---")
        cursor.execute("PRAGMA table_info(pets)")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]
        print(f"字段数量: {len(columns)}")
        print(f"字段列表: {', '.join(column_names)}")
        
        # 检查关键字段
        print("\n--- 检查关键字段 ---")
        required_fields = {
            'id': False,
            'did': False,
            'pet_name': False,
            'avatar_color': False
        }
        
        pk_column = None
        for col in columns:
            col_id, name, type_, notnull, default, pk = col
            if name in required_fields:
                required_fields[name] = True
            if pk == 1:
                pk_column = name
        
        for field, exists in required_fields.items():
            status = "✓" if exists else "✗"
            print(f"{status} {field}: {exists}")
        
        if pk_column:
            print(f"✓ 主键: {pk_column}")
        else:
            print("✗ 无主键")
        
        missing = [f for f, exists in required_fields.items() if not exists]
        if missing:
            print(f"\n❌ 缺少字段: {', '.join(missing)}")
            print("请执行: python backend/migrations/migrate_pets_upgrade.py")
            return False
        
        # 检查数据
        print("\n--- 检查数据 ---")
        cursor.execute("SELECT COUNT(*) FROM pets")
        total = cursor.fetchone()[0]
        print(f"总记录数: {total}")
        
        if total > 0:
            cursor.execute("""
                SELECT COUNT(DISTINCT did) FROM pets
            """)
            users = cursor.fetchone()[0]
            print(f"用户数: {users}")
            
            # 显示示例数据
            print("\n示例数据（最多3条）:")
            cursor.execute("""
                SELECT id, did, pet_name, pet_type, breed, avatar_color 
                FROM pets 
                LIMIT 3
            """)
            rows = cursor.fetchall()
            
            for row in rows:
                pet_id, did, name, pet_type, breed, color = row
                print(f"  ID={pet_id}, DID={did}, 名称={name}, 物种={pet_type}, 品种={breed}, 颜色={color}")
            
            # 检查空值
            print("\n空值检查:")
            cursor.execute("SELECT COUNT(*) FROM pets WHERE id IS NULL")
            null_id = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM pets WHERE avatar_color IS NULL")
            null_color = cursor.fetchone()[0]
            
            if null_id > 0:
                print(f"  ⚠️  {null_id} 条记录的id为空")
            if null_color > 0:
                print(f"  ⚠️  {null_color} 条记录的avatar_color为空")
        else:
            print("⚠️  数据库为空，无宠物记录")
        
        # 检查索引
        print("\n--- 检查索引 ---")
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='index' AND tbl_name='pets'
        """)
        indexes = [row[0] for row in cursor.fetchall()]
        print(f"索引数量: {len(indexes)}")
        for idx in indexes:
            print(f"  - {idx}")
        
        conn.close()
        
        print("\n" + "=" * 60)
        print("✅ 数据库结构正常")
        print("=" * 60)
        
        return True
        
    except Exception as e:
        print(f"\n❌ 检查失败: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    if len(sys.argv) > 1:
        db_path = sys.argv[1]
    else:
        db_path = None
    
    success = check_database(db_path)
    sys.exit(0 if success else 1)
