#!/usr/bin/env python3
"""
测试服务器数据库迁移脚本
验证所有迁移脚本能否正确应用到服务器下载的数据库
"""

import sqlite3
import sys
import shutil
from pathlib import Path
from datetime import datetime

# 数据库路径
SERVER_DB = Path(__file__).parent.parent / "database" / "server_history.db"
TEST_DB = Path(__file__).parent.parent / "database" / "test_migration.db"

def backup_database():
    """备份数据库"""
    if not SERVER_DB.exists():
        print(f"❌ 服务器数据库不存在: {SERVER_DB}")
        return False
    
    # 复制到测试数据库
    shutil.copy2(SERVER_DB, TEST_DB)
    print(f"✅ 已创建测试数据库: {TEST_DB}\n")
    return True

def check_table_structure(db_path, table_name):
    """检查表结构"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        cursor.execute(f"PRAGMA table_info({table_name})")
        columns = cursor.fetchall()
        return {col[1]: col[2] for col in columns}
    except:
        return None
    finally:
        conn.close()

def check_table_exists(db_path, table_name):
    """检查表是否存在"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name=?
    """, (table_name,))
    
    exists = cursor.fetchone() is not None
    conn.close()
    return exists

def run_migration_script(script_path, db_path):
    """运行迁移脚本"""
    import subprocess
    import os
    
    env = os.environ.copy()
    env['DATABASE_PATH'] = str(db_path)
    
    result = subprocess.run(
        [sys.executable, str(script_path)],
        env=env,
        capture_output=True,
        text=True
    )
    
    return result.returncode == 0, result.stdout, result.stderr

def main():
    print("="*70)
    print("🧪 服务器数据库迁移测试")
    print("="*70)
    print()
    
    # 1. 备份数据库
    print("📝 步骤 1: 备份服务器数据库")
    print("-"*70)
    if not backup_database():
        return False
    
    # 2. 检查初始状态
    print("📝 步骤 2: 检查初始数据库状态")
    print("-"*70)
    
    initial_tables = {
        "stream_sources": check_table_structure(TEST_DB, "stream_sources"),
        "video_records": check_table_structure(TEST_DB, "video_records"),
        "analysis_history": check_table_structure(TEST_DB, "analysis_history"),
    }
    
    print("现有表:")
    for table, columns in initial_tables.items():
        if columns:
            print(f"  ✓ {table}: {len(columns)} 个字段")
        else:
            print(f"  ✗ {table}: 不存在")
    
    print("\n缺失的表:")
    missing_tables = ["pets", "daily_reports", "video_pet_analysis"]
    for table in missing_tables:
        exists = check_table_exists(TEST_DB, table)
        if not exists:
            print(f"  ✗ {table}")
    
    print()
    
    # 3. 执行迁移脚本
    print("📝 步骤 3: 执行迁移脚本")
    print("-"*70)
    
    migrations_dir = Path(__file__).parent / "migrations"
    
    # 按顺序执行关键迁移
    migration_scripts = [
        ("migrate_add_did_to_stream_sources.py", "添加 did 字段到 stream_sources"),
        ("migrate_unify_video_records.py", "统一视频记录表"),
        ("migrate_add_pets_table.py", "创建 pets 表"),
        ("migrate_add_weight_to_pets.py", "添加 weight 字段到 pets"),
        ("migrate_add_avatar_color_to_pets.py", "添加 avatar_color 字段到 pets"),
        ("migrate_add_video_pet_analysis_table.py", "创建 video_pet_analysis 表"),
        ("migrate_rename_video_pet_analysis_to_pet_behaviors.py", "重命名为 pet_behaviors 表"),
        ("migrate_add_daily_reports_table.py", "创建 daily_reports 表"),
    ]
    
    results = []
    for script_name, description in migration_scripts:
        script_path = migrations_dir / script_name
        
        if not script_path.exists():
            print(f"  ⚠️  脚本不存在: {script_name}")
            results.append((script_name, False, "脚本不存在"))
            continue
        
        print(f"\n  🔄 执行: {description}")
        print(f"     脚本: {script_name}")
        
        success, stdout, stderr = run_migration_script(script_path, TEST_DB)
        
        if success:
            print(f"  ✅ 成功")
            results.append((script_name, True, "成功"))
        else:
            print(f"  ❌ 失败")
            if stderr:
                print(f"     错误: {stderr[:200]}")
            results.append((script_name, False, stderr[:200] if stderr else "未知错误"))
    
    print()
    
    # 4. 检查迁移后状态
    print("📝 步骤 4: 检查迁移后数据库状态")
    print("-"*70)
    
    final_tables = {
        "stream_sources": check_table_structure(TEST_DB, "stream_sources"),
        "video_records": check_table_structure(TEST_DB, "video_records"),
        "pets": check_table_structure(TEST_DB, "pets"),
        "daily_reports": check_table_structure(TEST_DB, "daily_reports"),
        "pet_behaviors": check_table_structure(TEST_DB, "pet_behaviors"),
    }
    
    print("\n迁移后的表:")
    for table, columns in final_tables.items():
        if columns:
            print(f"  ✓ {table}: {len(columns)} 个字段")
        else:
            print(f"  ✗ {table}: 不存在")
    
    # 检查关键字段
    print("\n关键字段检查:")
    
    checks = [
        ("stream_sources", "did", "用户ID字段"),
        ("video_records", "did", "用户ID字段"),
        ("video_records", "call_type", "调用类型字段"),
        ("video_records", "model_name", "模型名称字段"),
        ("pets", "weight", "宠物体重字段"),
        ("pets", "avatar_color", "头像颜色字段"),
    ]
    
    all_passed = True
    for table, field, desc in checks:
        columns = final_tables.get(table)
        if columns and field in columns:
            print(f"  ✓ {table}.{field} - {desc}")
        else:
            print(f"  ✗ {table}.{field} - {desc} (缺失)")
            all_passed = False
    
    print()
    
    # 5. 总结
    print("="*70)
    print("📊 迁移测试总结")
    print("="*70)
    print()
    
    success_count = sum(1 for _, success, _ in results if success)
    total_count = len(results)
    
    print(f"执行的迁移脚本: {total_count}")
    print(f"成功: {success_count}")
    print(f"失败: {total_count - success_count}")
    print()
    
    if all_passed and success_count == total_count:
        print("✅ 所有迁移脚本执行成功，数据库结构符合预期！")
        print()
        print("📝 下一步:")
        print("  1. 确认测试数据库无误后，可以在服务器上执行迁移")
        print("  2. 建议先备份服务器数据库")
        print("  3. 按顺序执行迁移脚本")
        print()
        print(f"测试数据库位置: {TEST_DB}")
        return True
    else:
        print("❌ 部分迁移失败或数据库结构不完整")
        print()
        print("失败的迁移:")
        for script_name, success, error in results:
            if not success:
                print(f"  - {script_name}: {error}")
        print()
        print(f"测试数据库位置: {TEST_DB}")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
