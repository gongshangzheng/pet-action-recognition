# Pet Videos Analysis

视频分析工具，使用 Qwen3-VL-Plus 模型分析视频内容，支持多目录管理、费用预估和历史记录。

## 功能特性

- ✅ **多目录管理** - 配置多个视频目录，可在界面中切换
- ✅ **视频列表展示** - 自动扫描并展示目录下的所有视频文件
- ✅ **参数可调** - fps、max_pixels、min_pixels、vl_high_resolution_images 全部可调
- ✅ **费用预估** - 发送前实时显示预估费用（精确值，不四舍五入）
- ✅ **模型调用** - 调用 qwen3-vl-plus 模型分析视频
- ✅ **实际费用展示** - 返回后显示实际费用（精确值，不四舍五入）
- ✅ **历史记录** - 完整的调用历史，支持查看详情和删除
- ✅ **梯度定价** - 支持 qwen3-vl-plus 梯度定价计算

## 项目结构

```
pet-videos/
├── backend/              # FastAPI 后端
│   ├── main.py          # 入口文件
│   ├── config.py        # 配置管理
│   ├── api/             # API 路由
│   │   ├── videos.py    # 视频和目录 API
│   │   ├── analysis.py  # 分析 API
│   │   └── history.py   # 历史记录 API
│   ├── services/        # 业务服务
│   │   ├── video_service.py        # 视频服务
│   │   ├── token_calculator.py     # Token 计算
│   │   ├── estimate_service.py     # 费用估算
│   │   └── dashscope_service.py    # DashScope API
│   ├── models/          # 数据模型
│   │   ├── schemas.py   # Pydantic 模型
│   │   └── database.py  # SQLAlchemy 模型
│   └── database/        # SQLite 数据库
├── frontend/            # React 前端
│   ├── src/
│   │   ├── App.tsx      # 主应用
│   │   ├── components/  # 组件
│   │   ├── services/    # API 服务
│   │   └── types/       # TypeScript 类型
│   └── package.json
├── .env                 # 环境变量配置
└── README.md
```

## 快速开始

### 1. 环境准备

确保已安装：
- Python 3.10+
- Node.js 18+
- ffmpeg (用于视频信息提取)

```bash
# macOS
brew install ffmpeg

# Ubuntu/Debian
sudo apt install ffmpeg

# Windows
# 下载 ffmpeg 并添加到 PATH
```

### 2. 后端设置

```bash
# 进入后端目录
cd backend

# 创建虚拟环境
python3 -m venv venv

# 激活虚拟环境
source venv/bin/activate  # macOS/Linux
# 或 venv\Scripts\activate  # Windows

# 安装依赖
pip install -r requirements.txt
```

### 3. 配置环境变量

```bash
# 复制环境变量示例文件
cp env.example .env

# 编辑 .env 文件
# 必须配置：
# - DASHSCOPE_API_KEY: 你的阿里云 DashScope API Key
# - VIDEO_DIRS: 视频目录路径（逗号分隔多个）

# 示例：
# DASHSCOPE_API_KEY=sk-xxxxx
# VIDEO_DIRS=/Users/xxx/videos1,/Users/xxx/videos2
```

### 4. 启动后端

```bash
cd backend
source venv/bin/activate
python main.py

# 或使用 uvicorn
uvicorn main:app --reload --port 8000
```

后端 API 文档：http://localhost:8000/docs

### 5. 启动前端

```bash
# 新开一个终端
cd frontend

# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

前端界面：http://localhost:5173

## 使用说明

### 1. 选择视频目录

在界面顶部的下拉框中选择一个配置好的视频目录，系统会自动扫描并显示该目录下的所有视频文件。

### 2. 选择视频

在左侧视频列表中点击选择要分析的视频。

### 3. 配置参数

- **FPS**: 抽帧频率（0.1-10），默认 2.0
- **Max Pixels**: 最大像素数，可选 Low/Medium/High/Ultra
- **Min Pixels**: 最小像素数
- **高分辨率模式**: 开启后 max_pixels 参数无效

### 4. 输入提示词

在提示词输入框中输入你想问视频的问题。

### 5. 查看预估费用

系统会自动计算并显示预估费用（精确值，不四舍五入）。

### 6. 发送分析

点击"发送分析"按钮，调用模型分析视频。

### 7. 查看结果

分析完成后，界面会显示：
- 实际消耗的 Token 数量
- 实际费用（精确值，不四舍五入）
- 模型返回的分析内容
- 统计信息（准确率、处理速度等）

### 8. 查看历史

切换到"调用历史"标签页，可以查看所有调用记录、详情和删除记录。

## API 端点

### 视频和目录

- `GET /api/directories` - 获取目录列表
- `GET /api/videos?directory=xxx` - 获取指定目录的视频列表
- `GET /api/video/{path}` - 获取单个视频信息

### 分析

- `POST /api/estimate` - 预估费用
- `POST /api/analyze` - 分析视频

### 历史记录

- `GET /api/history` - 获取历史记录列表（分页）
- `GET /api/history/{id}` - 获取历史记录详情
- `DELETE /api/history/{id}` - 删除历史记录
- `DELETE /api/history` - 清空历史记录

### 配置

- `GET /api/config` - 获取配置信息
- `GET /health` - 健康检查

## 定价说明

qwen3-vl-plus 使用梯度定价：

| 区间 | 输入价格（元/1K tokens） | 输出价格（元/1K tokens） |
|------|-------------------------|-------------------------|
| 0-32K | 0.001 | 0.01 |
| 32K-128K | 0.0015 | 0.015 |
| 128K-256K | 0.003 | 0.03 |

**注意**: 费用计算精确到小数点后多位，界面显示不进行四舍五入。

## 技术栈

### 后端

- FastAPI - Web 框架
- SQLAlchemy - ORM
- DashScope - 阿里云 AI 服务
- OpenCV - 视频处理
- SQLite - 数据库

### 前端

- React 18
- TypeScript
- Ant Design 5
- Vite
- Axios

## 开发计划

- [ ] 支持批量视频分析
- [ ] 导出分析报告
- [ ] 视频预览功能
- [ ] 更多模型支持

## 许可证

MIT

## 参考项目

本项目参考了 pet 项目的架构和实现。
