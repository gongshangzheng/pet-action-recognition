#!/bin/bash
# 停止所有服务

echo "停止 Pet Videos Analysis 服务..."

# 停止后端
echo "停止后端..."
pkill -f "python.*main.py" || echo "后端未运行"
pkill -f "uvicorn.*main:app" || echo "后端未运行"

# 停止前端
echo "停止前端..."
pkill -f "vite" || echo "前端未运行"

echo "服务已停止"
