# 迁移脚本改进：从 SQL+Shell 到 Python

## 变更日期
2026-02-06

## 变更原因

项目中已有的迁移脚本都是Python格式（如 `migrate_add_pets_table.py`、`migrate_add_avatar_color_to_pets.py` 等），新的迁移脚本应该遵循相同的模式。

**变更前**：使用 SQL + Shell/Batch 脚本
- `002_add_pets_id.sql` - SQL迁移脚本
- `run_migration_002.sh` - macOS/Linux Shell脚本
- `run_migration_002.bat` - Windows Batch脚本

**变更后**：统一使用 Python 脚本
- `migrate_add_pets_id.py` - Python迁移脚本（跨平台）
- `migrate_unify_database_location.py` - Python迁移脚本（跨平台）

## Python 迁移脚本优势

### 1. 跨平台一致性

**Shell/Batch方式**（旧）:
```bash
# macOS/Linux
./run_migration_002.sh

# Windows
run_migration_002.bat
```

需要维护2套脚本，语法不同，行为可能不一致。

**Python方式**（新）:
```bash
# 所有平台统一
python3 backend/migrations/migrate_add_pets_id.py
```

一套脚本，所有平台统一使用。

### 2. 更好的错误处理

**SQL方式**（旧）:
```sql
-- 如果出错，SQLite只返回错误码
-- 难以提供友好的错误信息和恢复指引
```

**Python方式**（新）:
```python
try:
    # 迁移逻辑
    conn.commit()
except Exception as e:
    print(f"❌ 迁移失败: {e}")
    conn.rollback()
    print(f"可以从备份恢复: {backup_path}")
    return False
```

详细的错误信息和恢复指引。

### 3. 自动备份

**Shell方式**（旧）:
```bash
# 需要在Shell脚本中手动处理备份逻辑
BACKUP_PATH="$DB_PATH.backup_$(date +%Y%m%d_%H%M%S)"
cp "$DB_PATH" "$BACKUP_PATH"
```

**Python方式**（新）:
```python
def backup_database(db_path):
    """自动备份数据库"""
    import shutil
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = f"{db_path}.backup_{timestamp}"
    shutil.copy2(db_path, backup_path)
    return backup_path
```

封装为函数，所有迁移脚本统一使用。

### 4. 幂等性检测

**SQL方式**（旧）:
```sql
-- SQL脚本每次都会执行，需要手动检查
-- 容易出现重复迁移的问题
```

**Python方式**（新）:
```python
# 检查是否已经有id字段
cursor.execute("PRAGMA table_info(pets)")
columns = cursor.fetchall()
if 'id' in [col[1] for col in columns]:
    print("✓ pets 表已经有 id 字段，无需迁移")
    return True
```

自动检测，可以安全地重复执行。

### 5. 详细的进度输出

**Shell方式**（旧）:
```bash
echo "Running migration..."
sqlite3 "$DB_PATH" < migration.sql
echo "Done"
```

输出信息有限。

**Python方式**（新）:
```python
print("正在为 pets 表添加自增ID主键...")
print("  [1/6] 创建新表 pets_new...")
print("  [2/6] 复制数据...")
print(f"     已复制 {copied_rows} 条记录")
print("  [3/6] 删除旧表...")
# ... 更多详细步骤
```

清晰的步骤和进度反馈。

### 6. 灵活的配置

**Shell方式**（旧）:
```bash
# 硬编码路径或依赖环境变量
DB_PATH="${DATABASE_PATH:-backend/database/history.db}"
```

**Python方式**（新）:
```python
def get_db_path():
    """动态获取数据库路径，支持多种方式"""
    # 1. 环境变量
    if os.environ.get('DATABASE_PATH'):
        return os.environ['DATABASE_PATH']
    # 2. 配置文件
    from config import settings
    return settings.database_path
    # 3. 默认路径
    return "database/history.db"
```

支持多种配置方式，更灵活。

## 迁移脚本对比

### 创建的迁移脚本

| 功能 | SQL+Shell (旧) | Python (新) |
|------|---------------|------------|
| pets表ID迁移 | `002_add_pets_id.sql`<br>`run_migration_002.sh`<br>`run_migration_002.bat` | `migrate_add_pets_id.py` |
| 数据库位置统一 | `migrate_database_location.sh`<br>`migrate_database_location.bat` | `migrate_unify_database_location.py` |

### 代码行数对比

**SQL+Shell方式**:
- `002_add_pets_id.sql`: ~50行
- `run_migration_002.sh`: ~80行
- `run_migration_002.bat`: ~100行
- **总计**: ~230行（3个文件）

**Python方式**:
- `migrate_add_pets_id.py`: ~180行（1个文件）
- 功能更完善，代码更少

## 文件清理

### 保留的文件（作为参考）

```
backend/migrations/
├── 002_add_pets_id.sql           # 保留作为SQL参考
├── run_migration_002.sh          # 保留作为Shell参考
└── run_migration_002.bat         # 保留作为Batch参考

migrate_database_location.sh      # 保留作为Shell参考
migrate_database_location.bat     # 保留作为Batch参考
```

这些文件不会被删除，但文档中标记为"已弃用"。

### 推荐使用的文件

```
backend/migrations/
├── migrate_add_pets_id.py                 # ✅ 推荐
└── migrate_unify_database_location.py     # ✅ 推荐
```

## 使用指南

### 执行迁移

所有平台统一：

```bash
# 在项目根目录执行
python3 backend/migrations/migrate_add_pets_id.py
python3 backend/migrations/migrate_unify_database_location.py
```

### 指定数据库路径

```bash
# 方式1：环境变量
DATABASE_PATH=database/history.db python3 backend/migrations/migrate_xxx.py

# 方式2：.env文件
# DATABASE_PATH=database/history.db
python3 backend/migrations/migrate_xxx.py
```

### 验证迁移

```bash
# 所有Python脚本都会输出详细信息
python3 backend/migrations/migrate_add_pets_id.py
```

输出示例：

```
==================================================
Pets 表自增ID迁移
==================================================

数据库路径: database/history.db
✓ 数据库已备份: database/history.db.backup_20260206_170813
✓ pets 表已经有 id 字段，无需迁移
```

## 项目中已有的Python迁移脚本

为了保持一致性，查看了项目中现有的迁移脚本：

```bash
backend/migrations/
├── migrate_add_pets_table.py                           # 创建pets表
├── migrate_add_avatar_color_to_pets.py                # 添加avatar_color字段
├── migrate_add_daily_reports_table.py                 # 创建daily_reports表
├── migrate_add_did_to_stream_sources.py               # 添加did字段
├── migrate_add_video_pet_analysis_table.py            # 创建video_pet_analysis表
├── migrate_rename_video_pet_analysis_to_pet_behaviors.py  # 重命名表
└── ... 更多Python迁移脚本
```

所有现有迁移都是Python格式，新增的迁移应该遵循相同模式。

## 测试结果

### macOS环境测试

```bash
$ python3 backend/migrations/migrate_add_pets_id.py
✓ 成功（检测到已迁移，自动跳过）

$ python3 backend/migrations/migrate_unify_database_location.py
✓ 成功（检测到已统一，自动跳过）
```

### Windows环境待测试

```cmd
python backend\migrations\migrate_add_pets_id.py
python backend\migrations\migrate_unify_database_location.py
```

## 更新的文档

1. `backend/migrations/README.md` - 更新为Python脚本说明
2. `MIGRATION_SUMMARY.md` - 更新迁移方式
3. `MIGRATION_QUICKSTART.md` - 新增Python快速开始指南
4. `MIGRATION_PYTHON_UPGRADE.md` - 本文档

## 总结

### 优势

✅ **跨平台统一** - 一套脚本适用所有平台  
✅ **更好的错误处理** - 详细的错误信息和恢复指引  
✅ **自动备份** - 每次迁移前自动备份  
✅ **幂等性** - 可以安全地重复执行  
✅ **详细输出** - 清晰的步骤和进度反馈  
✅ **灵活配置** - 支持多种配置方式  
✅ **项目一致性** - 与现有迁移脚本保持一致  

### 迁移建议

1. **新环境**: 直接使用Python脚本
2. **已有SQL脚本**: 保留作为参考，使用Python脚本
3. **生产环境**: 使用Python脚本（更可靠）

## 反馈

如有问题或建议，请提供：
- Python版本
- 操作系统
- 完整的错误输出
- 数据库文件信息
