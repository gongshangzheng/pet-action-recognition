# 服务器部署指南

## 快速开始

### 一键迁移（推荐）

```bash
# 在项目根目录执行
python3 backend/migrations/migrate_pets_upgrade.py
```

这个脚本会自动完成：
- ✅ 添加pets表自增ID主键
- ✅ 添加avatar_color字段
- ✅ 自动备份数据库
- ✅ 验证迁移结果
- ✅ 幂等性（可重复执行）

---

## 完整部署流程

### 1. 拉取最新代码

```bash
cd /path/to/pet-videos
git pull
```

### 2. 执行数据库迁移

```bash
# 执行合并的迁移脚本
python3 backend/migrations/migrate_pets_upgrade.py
```

**预期输出**：
```
============================================================
Pets表升级迁移（合并版本）
============================================================

数据库路径: database/history.db
✓ 数据库已备份: database/history.db.backup_20260206_171957

[1/2] 检查并添加自增ID主键...
    开始添加ID字段...
      [1.1] 创建新表 pets_new...
      [1.2] 复制数据...
           已复制 N 条记录
      [1.3] 删除旧表...
      [1.4] 重命名新表...
      [1.5] 创建索引...
    ✓ ID字段添加成功

[2/2] 检查并添加avatar_color字段...
    开始添加avatar_color字段...
      [2.1] 添加字段...
      [2.2] 设置默认值 #E5E7EB...
    ✓ avatar_color字段添加成功

验证迁移结果...
  ✓ id字段已创建（主键，自增）
  ✓ avatar_color字段已创建
  ✓ 数据记录数: N
  ✓ 索引数量: 3

============================================================
✅ 迁移成功完成！
============================================================
```

### 3. 重启服务

```bash
# 停止服务
pkill -f "python.*backend/main.py"
pkill -f "python.*service.app"

# 启动Backend
nohup python3 backend/main.py > logs/backend.log 2>&1 &

# 启动Service
nohup python3 -m service.app > logs/service.log 2>&1 &
```

或使用systemd（如果配置了）：
```bash
sudo systemctl restart pet-videos-backend
sudo systemctl restart pet-videos-service
```

### 4. 验证部署

```bash
# 检查数据库结构
sqlite3 database/history.db "PRAGMA table_info(pets);" | grep -E "^0\||avatar_color"

# 预期输出：
# 0|id|INTEGER|0||1
# 13|avatar_color|VARCHAR(10)|0||0

# 测试Backend API
curl "http://localhost:8002/api/internal/pets/" | python3 -m json.tool

# 测试Service API（需要认证token）
curl "http://localhost:8006/api/pet/list" \
  -H "Cookie: openbduss=xxx; stoken=xxx"
```

---

## 迁移内容说明

### 变更1: 添加自增ID主键

**变更前**：
```sql
PRIMARY KEY (did, pet_name)
```

**变更后**：
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
UNIQUE INDEX (did, pet_name)
```

**影响**：
- Service API的 `petId` 字段从宠物名称改为数据库自增ID
- Backend新增通过ID操作的接口：
  - `GET /api/internal/pets/by-id/{pet_id}`
  - `PUT /api/internal/pets/by-id/{pet_id}`
  - `DELETE /api/internal/pets/by-id/{pet_id}`

### 变更2: 添加avatar_color字段

**新增字段**：
```sql
avatar_color VARCHAR(10)
```

**默认值**：`#E5E7EB`（灰色）

**影响**：
- Service API的宠物相关接口支持 `avatarColor` 字段
- 用于App端显示宠物头像背景色

---

## 故障排查

### 问题1: 迁移脚本找不到数据库

**错误信息**：
```
❌ 数据库文件不存在: database/history.db
```

**解决方案**：
```bash
# 检查数据库路径
ls -la database/history.db

# 如果在其他位置，设置环境变量
export DATABASE_PATH=/path/to/history.db
python3 backend/migrations/migrate_pets_upgrade.py
```

### 问题2: 权限错误

**错误信息**：
```
PermissionError: [Errno 13] Permission denied
```

**解决方案**：
```bash
# 检查文件权限
ls -la database/history.db

# 修改权限
chmod 664 database/history.db
chown $USER:$USER database/history.db
```

### 问题3: 迁移失败

**解决方案**：
```bash
# 查看最新备份
ls -lt database/history.db.backup_*

# 从备份恢复
cp database/history.db.backup_YYYYMMDD_HHMMSS database/history.db

# 再次尝试迁移
python3 backend/migrations/migrate_pets_upgrade.py
```

---

## 回滚方案

如果部署后发现问题，可以回滚：

```bash
# 1. 停止服务
pkill -f "python.*backend/main.py"
pkill -f "python.*service.app"

# 2. 恢复数据库（使用最新备份）
cp database/history.db.backup_YYYYMMDD_HHMMSS database/history.db

# 3. 回退代码
git checkout <previous-commit>

# 4. 重启服务
python3 backend/main.py &
python3 -m service.app &
```

---

## 注意事项

1. **备份数据**：迁移脚本会自动备份，但建议额外手动备份
2. **停服时间**：迁移通常在1秒内完成
3. **幂等性**：脚本可以重复执行，已迁移的会自动跳过
4. **数据完整性**：脚本会保留所有现有数据
5. **验证测试**：部署后务必验证API功能

---

## 监控检查

部署完成后，检查以下指标：

```bash
# 1. 服务状态
ps aux | grep -E "backend/main.py|service.app"

# 2. 端口监听
netstat -tlnp | grep -E "8002|8006"

# 3. 错误日志
tail -f logs/backend.log
tail -f logs/service.log

# 4. API响应
curl -I http://localhost:8002/health
curl -I http://localhost:8006/health
```

---

## 相关文档

- `backend/migrations/README.md` - 迁移脚本详细说明
- `MIGRATION_SUMMARY.md` - 迁移操作总结
- `MIGRATION_QUICKSTART.md` - 迁移快速开始
- `MIGRATION_PYTHON_UPGRADE.md` - Python迁移脚本改进说明

---

## 技术支持

如遇问题，提供以下信息：
1. 执行的完整命令
2. 完整的错误输出
3. 数据库路径和文件大小
4. Python版本：`python3 --version`
5. 系统信息：`uname -a`
