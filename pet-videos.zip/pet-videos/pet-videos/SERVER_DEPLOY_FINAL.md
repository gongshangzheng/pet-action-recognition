# 🚀 服务器部署最终方案

## 数据库路径确认

**使用路径**: `backend/database/history.db` ✅

**配置**:
- `.env`: `DATABASE_PATH=backend/database/history.db`
- `backend/config.py`: 默认路径指向 `backend/database/history.db`

---

## 🎯 服务器执行命令（一条）

```bash
# Windows
python backend\migrations\migrate_init_all.py

# Linux/macOS  
python3 backend/migrations/migrate_init_all.py
```

**说明**:
- ✅ 自动检测pets表是否存在
- ✅ 不存在则创建最新结构的表（包含id和avatar_color）
- ✅ 已存在则跳过创建
- ✅ 自动备份数据库
- ✅ 幂等性，可重复执行

---

## 📋 完整部署流程

### Windows服务器

```cmd
REM 1. 拉取最新代码
git pull

REM 2. 进入项目目录
cd D:\pet-videos

REM 3. 执行迁移
python backend\migrations\migrate_init_all.py

REM 4. 重启Backend（停止后重启）
python backend\main.py

REM 5. 重启Service（新窗口）
python -m service.app
```

### Linux服务器

```bash
# 1. 拉取最新代码
git pull

# 2. 进入项目目录
cd /path/to/pet-videos

# 3. 执行迁移
python3 backend/migrations/migrate_init_all.py

# 4. 重启Backend
pkill -f "python.*backend/main.py"
nohup python3 backend/main.py > logs/backend.log 2>&1 &

# 5. 重启Service
pkill -f "python.*service.app"
nohup python3 -m service.app > logs/service.log 2>&1 &
```

---

## ✅ 预期输出

```
============================================================
完整初始化迁移
============================================================

数据库路径: backend/database/history.db
✓ 数据库已备份: backend/database/history.db.backup_20260206_172557

[1/1] 创建pets表...
    正在创建pets表...
    正在创建索引...
    ✓ pets表创建成功

验证数据库结构...
  ✓ pets表存在
  ✓ id字段正确（主键，自增）
  ✓ avatar_color字段存在
  ✓ 索引数量: 3

============================================================
✅ 初始化成功完成！
============================================================

创建的表:
  ✓ pets表（包含id主键和avatar_color字段）

下一步:
  1. 重启 Backend 服务
  2. 重启 Service 服务
  3. 验证 API 接口
```

---

## 🔍 验证部署

### 1. 检查数据库

```bash
# Windows
sqlite3 backend\database\history.db "PRAGMA table_info(pets);"

# Linux/macOS
sqlite3 backend/database/history.db "PRAGMA table_info(pets);"
```

**预期输出**（包含这两个关键字段）:
```
0|id|INTEGER|0||1              ← 自增主键
...
13|avatar_color|VARCHAR(10)|0||0  ← 头像背景色
```

### 2. 测试Backend API

```bash
# 查询宠物列表
curl "http://localhost:8002/api/internal/pets/"

# 通过ID查询
curl "http://localhost:8002/api/internal/pets/by-id/1?did=YOUR_DID"
```

**预期返回**包含字段:
```json
{
  "id": 1,
  "pet_name": "测试狗子",
  "avatar_color": "#E5E7EB",
  ...
}
```

### 3. 测试Service API

```bash
# 获取宠物列表（需要认证）
curl "http://localhost:8006/api/pet/list" \
  -H "Cookie: openbduss=xxx; stoken=xxx"
```

**预期返回**包含字段:
```json
{
  "ret": 0,
  "ret_msg": "success",
  "data": {
    "pets": [{
      "petId": "1",
      "petName": "测试狗子",
      "avatarColor": "#E5E7EB",
      ...
    }]
  }
}
```

---

## 🗂️ 数据库位置说明

### 最终决定

**数据库位置**: `backend/database/history.db` ✅

**原因**:
- 与服务器保持一致
- Backend代码在backend目录下，数据库放在同级更清晰
- 避免路径混乱

### 目录结构

```
pet-videos/
├── backend/
│   ├── database/
│   │   ├── history.db              ✅ 使用这个
│   │   ├── history.db.backup_*     (备份)
│   │   └── video_cache/
│   ├── migrations/
│   │   ├── migrate_init_all.py     ✅ 推荐使用
│   │   └── migrate_pets_upgrade.py
│   └── main.py
├── service/
│   └── app.py
└── .env
```

---

## ⚠️ 重要提示

1. **数据库位置已改回**: `backend/database/history.db`
2. **服务器执行**: `migrate_init_all.py`（创建最新表）
3. **本地环境**: 已更新配置，使用backend/database
4. **迁移脚本**: 默认路径已更新为backend/database

---

## 📝 变更内容

### Pets表结构（最新）

```sql
CREATE TABLE pets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,  -- ✅ 自增ID
    did VARCHAR(50) NOT NULL,
    pet_name VARCHAR(100) NOT NULL,
    pet_type VARCHAR(50),                  -- 物种
    breed VARCHAR(100),                    -- 品种
    gender VARCHAR(10),
    birth_date VARCHAR(10),
    weight REAL,
    color VARCHAR(100),
    avatar_url VARCHAR(500),
    avatar_color VARCHAR(10),              -- ✅ 头像背景色
    description TEXT,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
);

-- 唯一索引
CREATE UNIQUE INDEX idx_pets_did_name ON pets(did, pet_name);
```

### API变更

**Backend新增接口**:
- `GET /api/internal/pets/by-id/{pet_id}` - 通过ID查询
- `PUT /api/internal/pets/by-id/{pet_id}` - 通过ID更新
- `DELETE /api/internal/pets/by-id/{pet_id}` - 通过ID删除

**Service变更**:
- `petId` 字段使用数据库自增ID
- 支持 `avatarColor` 字段

---

## 🔧 故障排查

### 错误: "no such table: pets"

**解决**: 执行 `migrate_init_all.py` 创建表

### 错误: "数据库文件不存在"

**解决**: 
```bash
# 确保目录存在
mkdir -p backend/database

# 再次执行迁移
python3 backend/migrations/migrate_init_all.py
```

### 错误: Backend连接不上

**解决**:
```bash
# 检查端口
netstat -tlnp | grep 8002

# 查看日志
tail -f logs/backend.log
```

---

## 📊 部署检查清单

部署完成后检查：

- [ ] 数据库文件存在: `backend/database/history.db`
- [ ] pets表创建成功，包含id和avatar_color字段
- [ ] Backend服务运行正常（端口8002）
- [ ] Service服务运行正常（端口8006）
- [ ] Backend API返回包含id字段
- [ ] Service API返回包含petId字段

---

**预计时间**: < 1分钟  
**数据风险**: 无（自动备份）  
**停服时间**: 重启服务（< 10秒）
