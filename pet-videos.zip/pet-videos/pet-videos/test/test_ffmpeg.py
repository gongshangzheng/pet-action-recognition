#!/usr/bin/env python3
"""测试 FFmpeg 是否正确安装并可用"""
import subprocess
import sys
import shutil

def test_ffmpeg():
    print("=" * 60)
    print("  FFmpeg 安装测试")
    print("=" * 60)
    print()
    
    # 1. 检查 ffmpeg 是否在 PATH 中
    ffmpeg_path = shutil.which('ffmpeg')
    if ffmpeg_path:
        print(f"✓ 找到 FFmpeg: {ffmpeg_path}")
    else:
        print("✗ 未找到 FFmpeg 命令")
        print()
        print("请按照 INSTALL_FFMPEG.md 安装 FFmpeg")
        return False
    
    # 2. 检查 FFmpeg 版本
    try:
        result = subprocess.run(
            ['ffmpeg', '-version'],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if result.returncode == 0:
            # 提取版本号（第一行）
            version_line = result.stdout.split('\n')[0]
            print(f"✓ FFmpeg 版本: {version_line}")
        else:
            print(f"✗ FFmpeg 命令执行失败: {result.stderr}")
            return False
            
    except subprocess.TimeoutExpired:
        print("✗ FFmpeg 命令超时")
        return False
    except Exception as e:
        print(f"✗ 执行 FFmpeg 失败: {e}")
        return False
    
    # 3. 检查 libx264 编码器
    try:
        result = subprocess.run(
            ['ffmpeg', '-codecs'],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if 'libx264' in result.stdout:
            print("✓ libx264 编码器可用")
        else:
            print("⚠ 警告: 未找到 libx264 编码器")
            print("  视频编码可能无法正常工作")
            
    except Exception as e:
        print(f"⚠ 无法检查编码器: {e}")
    
    # 4. 测试生成简单视频
    print()
    print("测试生成视频文件...")
    
    test_file = "ffmpeg_test.mp4"
    command = [
        'ffmpeg',
        '-y',
        '-f', 'lavfi',
        '-i', 'testsrc=duration=1:size=320x240:rate=10',
        '-c:v', 'libx264',
        '-pix_fmt', 'yuv420p',
        '-preset', 'ultrafast',
        test_file
    ]
    
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            timeout=10
        )
        
        if result.returncode == 0:
            print(f"✓ 成功生成测试视频: {test_file}")
            
            # 检查文件大小
            import os
            if os.path.exists(test_file):
                size = os.path.getsize(test_file)
                print(f"  文件大小: {size} 字节")
                
                # 清理测试文件
                try:
                    os.remove(test_file)
                    print(f"  已清理测试文件")
                except:
                    pass
            else:
                print("⚠ 警告: 文件未生成")
                return False
        else:
            print(f"✗ 生成视频失败:")
            print(result.stderr.decode('utf-8', errors='ignore'))
            return False
            
    except subprocess.TimeoutExpired:
        print("✗ 生成视频超时")
        return False
    except Exception as e:
        print(f"✗ 生成视频失败: {e}")
        return False
    
    print()
    print("=" * 60)
    print("  ✓ FFmpeg 测试通过！")
    print("=" * 60)
    print()
    print("现在可以正常使用视频切片功能了。")
    return True

if __name__ == "__main__":
    success = test_ffmpeg()
    sys.exit(0 if success else 1)
