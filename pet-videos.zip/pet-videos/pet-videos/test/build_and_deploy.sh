#!/bin/bash
# 构建并部署生产版本

set -e

echo "=== 构建生产版本 ==="

# 1. 构建前端
echo "[1/3] 构建前端..."
cd frontend
npm run build
cd ..

# 2. 停止开发服务器
echo "[2/3] 停止开发服务器..."
pkill -f "vite" || echo "Vite未运行"

# 3. 使用 nginx 或其他 web 服务器提供静态文件
echo "[3/3] 部署完成"
echo ""
echo "前端静态文件已构建到: frontend/dist"
echo ""
echo "配置 nginx 示例："
echo "---"
echo "server {"
echo "  listen 8173;"
echo "  server_name bbc0411.kj01.bddx.dxm-int.com;"
echo ""
echo "  # 前端静态文件"
echo "  root /path/to/pet-videos/frontend/dist;"
echo "  index index.html;"
echo ""
echo "  # 前端路由"
echo "  location / {"
echo "    try_files \$uri \$uri/ /index.html;"
echo "  }"
echo ""
echo "  # 后端 API 代理"
echo "  location /api {"
echo "    proxy_pass http://127.0.0.1:8002;"
echo "    proxy_set_header Host \$host;"
echo "    proxy_set_header X-Real-IP \$remote_addr;"
echo "  }"
echo "}"
echo "---"
