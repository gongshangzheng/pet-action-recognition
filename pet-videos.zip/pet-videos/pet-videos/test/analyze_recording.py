#!/usr/bin/env python3
"""分析录制日志，找出为什么总是 15 秒"""
import sys
import re
from pathlib import Path
from datetime import datetime, timedelta


def parse_log_file(log_path):
    """解析任务日志文件"""
    if not Path(log_path).exists():
        print(f"❌ 日志文件不存在: {log_path}")
        return None
    
    print("=" * 70)
    print(f"分析日志: {log_path}")
    print("=" * 70)
    print()
    
    with open(log_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    # 提取关键信息
    recordings = []
    current_recording = None
    detection_count = 0
    yolo_enabled = None
    motion_threshold = None
    
    for line in lines:
        # 提取配置信息
        if "enable_yolo=" in line:
            match = re.search(r"enable_yolo=(True|False)", line)
            if match:
                yolo_enabled = match.group(1) == "True"
        
        if "motion_threshold=" in line:
            match = re.search(r"motion_threshold=(\d+)", line)
            if match:
                motion_threshold = int(match.group(1))
        
        # 开始录制
        if "开始录制" in line:
            timestamp_match = re.search(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", line)
            if timestamp_match:
                current_recording = {
                    'start_time': timestamp_match.group(1),
                    'start_dt': datetime.strptime(timestamp_match.group(1), "%Y-%m-%d %H:%M:%S"),
                    'detections': 0,
                    'filename': None
                }
                if "开始录制:" in line:
                    filename_match = re.search(r"开始录制: (.+\.mp4)", line)
                    if filename_match:
                        current_recording['filename'] = Path(filename_match.group(1)).name
        
        # 停止录制
        elif "停止录制" in line or "视频编码器已释放" in line:
            if current_recording:
                timestamp_match = re.search(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", line)
                if timestamp_match:
                    stop_dt = datetime.strptime(timestamp_match.group(1), "%Y-%m-%d %H:%M:%S")
                    duration = (stop_dt - current_recording['start_dt']).total_seconds()
                    current_recording['duration'] = duration
                    current_recording['stop_time'] = timestamp_match.group(1)
                    recordings.append(current_recording)
                    current_recording = None
    
    # 输出分析结果
    print(f"【配置信息】")
    print(f"  YOLO 检测: {'启用' if yolo_enabled else '禁用（运动检测模式）'}")
    if motion_threshold:
        print(f"  运动阈值: {motion_threshold}")
    print()
    
    if not recordings:
        print("❌ 未找到录制记录")
        return None
    
    print(f"【录制记录】（共 {len(recordings)} 段）")
    print()
    
    durations = []
    for i, rec in enumerate(recordings, 1):
        print(f"录制 #{i}:")
        print(f"  文件名: {rec.get('filename', 'N/A')}")
        print(f"  开始时间: {rec['start_time']}")
        print(f"  结束时间: {rec.get('stop_time', 'N/A')}")
        if 'duration' in rec:
            print(f"  时长: {rec['duration']:.1f} 秒")
            durations.append(rec['duration'])
        print()
    
    # 统计分析
    if durations:
        print("【统计分析】")
        avg_duration = sum(durations) / len(durations)
        print(f"  平均时长: {avg_duration:.1f} 秒")
        print(f"  最短: {min(durations):.1f} 秒")
        print(f"  最长: {max(durations):.1f} 秒")
        
        # 判断是否都是 15 秒左右
        all_15s = all(13 <= d <= 17 for d in durations)
        if all_15s:
            print()
            print("⚠️  所有录制都是 15 秒左右（后摇时长）")
            print()
            print("可能原因:")
            if yolo_enabled:
                print("  1. YOLO 模式下，只检测到一次宠物就离开了")
                print("  2. YOLO 模型置信度不够，未持续识别")
                print("  3. 检测频率太低（每 4 帧），漏掉了宠物")
                print("  4. 第一帧误判触发录制（如果未更新脚本）")
            else:
                print("  1. 运动检测模式下，只触发一次运动就静止了")
                print(f"  2. motion_threshold={motion_threshold} 太高，后续运动未达标")
                print("  3. 时间水印遮罩覆盖了主要运动区域")
                print("  4. 第一帧误判触发录制（如果未更新脚本）")
            
            print()
            print("建议:")
            print("  1. 确认已更新脚本（修复第一帧误判）")
            print("  2. 检查视频中是否真的有宠物/运动")
            print("  3. 降低 motion_threshold 或提高 YOLO 检测频率")
    
    print()
    print("=" * 70)
    
    return recordings


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python analyze_recording.py <日志文件路径>")
        print("\n示例:")
        print("  python analyze_recording.py D:\\pet-videos\\backend\\logs\\tasks\\task_1.log")
        sys.exit(1)
    
    log_path = sys.argv[1]
    parse_log_file(log_path)
