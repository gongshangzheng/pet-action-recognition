#!/usr/bin/env python3
"""简单的后端测试脚本"""
import sys
import os
from pathlib import Path

# 切换到项目根目录
project_root = Path(__file__).parent
os.chdir(project_root)
print(f"工作目录: {os.getcwd()}")

# 加载环境变量
print("\n[1] 加载环境变量...")
try:
    from dotenv import load_dotenv
    load_dotenv()
    print("✓ 环境变量已加载")
    print(f"  BACKEND_PORT: {os.getenv('BACKEND_PORT')}")
    print(f"  ADMIN_USERNAME: {os.getenv('ADMIN_USERNAME')}")
except Exception as e:
    print(f"✗ 加载环境变量失败: {e}")
    sys.exit(1)

# 测试导入backend模块
print("\n[2] 测试导入backend模块...")
try:
    sys.path.insert(0, str(project_root))
    from backend import config
    print("✓ backend.config 导入成功")
    print(f"  backend_port: {config.settings.backend_port}")
except Exception as e:
    print(f"✗ 导入失败: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# 测试导入main
print("\n[3] 测试导入main...")
try:
    from backend import main
    print("✓ backend.main 导入成功")
except Exception as e:
    print(f"✗ 导入失败: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# 测试数据库
print("\n[4] 测试数据库...")
try:
    from backend.models import database
    print("✓ 数据库模块导入成功")
    database.init_db()
    print("✓ 数据库初始化成功")
except Exception as e:
    print(f"✗ 数据库失败: {e}")
    import traceback
    traceback.print_exc()

# 测试认证
print("\n[5] 测试认证模块...")
try:
    from backend.utils.security import verify_password, get_password_hash
    from backend.api.auth import authenticate_user
    print("✓ 认证模块导入成功")
    
    # 测试密码验证
    admin_password = os.getenv('ADMIN_PASSWORD', 'admin123')
    hashed = get_password_hash(admin_password)
    result = verify_password(admin_password, hashed)
    print(f"✓ 密码加密验证: {result}")
except Exception as e:
    print(f"✗ 认证模块失败: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*50)
print("所有测试完成！")
print("="*50)
