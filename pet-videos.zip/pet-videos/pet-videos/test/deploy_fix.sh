#!/bin/bash
# 部署修复脚本 - 解决无限刷新问题

set -e

echo "=== Pet Videos 部署修复 ==="

# 1. 执行数据库迁移
echo "[1/5] 执行数据库迁移..."
cd backend
python migrations/add_model_name.py
cd ..

# 2. 停止服务
echo "[2/5] 停止服务..."
pkill -f "uvicorn main:app" || echo "后端未运行"
pkill -f "vite" || echo "前端未运行"

# 3. 清除前端缓存
echo "[3/5] 清除前端缓存..."
cd frontend
rm -rf node_modules/.vite dist .vite
cd ..

# 4. 重启后端
echo "[4/5] 启动后端..."
./start_backend.sh &
BACKEND_PID=$!
echo "后端 PID: $BACKEND_PID"

# 等待后端启动
sleep 3

# 5. 测试 API
echo "[5/5] 测试 API..."
if curl -s http://localhost:8002/api/models | grep -q "qwen"; then
    echo "✓ API 测试成功"
else
    echo "✗ API 测试失败"
    exit 1
fi

# 6. 启动前端
echo "启动前端..."
./start_frontend.sh &
FRONTEND_PID=$!
echo "前端 PID: $FRONTEND_PID"

echo ""
echo "=== 部署完成 ==="
echo "请在浏览器中："
echo "1. 打开开发者工具 (F12)"
echo "2. 右键刷新按钮 → 清空缓存并硬性重新加载"
echo ""
echo "如果还有问题，请查看："
echo "- 后端日志: tail -f logs/app.log"
echo "- 浏览器控制台的错误信息"
