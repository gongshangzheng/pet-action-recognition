#!/usr/bin/env python3
"""后端诊断脚本 - 检查后端服务状态和登录问题"""

import os
import sys
import requests
import subprocess
import socket
from pathlib import Path

# 添加项目路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))
os.chdir(project_root)

# 加载环境变量
from dotenv import load_dotenv
load_dotenv()

print("=" * 60)
print("后端诊断工具")
print("=" * 60)

# 1. 检查端口
def check_port(port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex(('127.0.0.1', port))
    sock.close()
    return result == 0

backend_port = int(os.getenv('BACKEND_PORT', 8002))
print(f"\n[1] 检查后端端口 {backend_port}...")
if check_port(backend_port):
    print(f"   ✓ 端口 {backend_port} 正在监听")
else:
    print(f"   ✗ 端口 {backend_port} 未监听 - 后端未启动！")
    print(f"\n   启动建议:")
    print(f"   cd {project_root}")
    print(f"   python3 -m uvicorn backend.main:app --host 0.0.0.0 --port {backend_port} --reload")
    sys.exit(1)

# 2. 检查API响应
print(f"\n[2] 检查API响应...")
try:
    response = requests.get(f"http://localhost:{backend_port}/docs", timeout=5)
    if response.status_code == 200:
        print(f"   ✓ API 文档可访问: http://localhost:{backend_port}/docs")
    else:
        print(f"   ⚠ API 响应异常: {response.status_code}")
except Exception as e:
    print(f"   ✗ 无法连接API: {e}")
    sys.exit(1)

# 3. 测试登录
print(f"\n[3] 测试登录...")
admin_username = os.getenv('ADMIN_USERNAME', 'admin')
admin_password = os.getenv('ADMIN_PASSWORD', 'admin123')

print(f"   用户名: {admin_username}")
print(f"   密码: {'*' * len(admin_password)}")

try:
    response = requests.post(
        f"http://localhost:{backend_port}/api/auth/login",
        json={"username": admin_username, "password": admin_password},
        timeout=5
    )
    
    if response.status_code == 200:
        data = response.json()
        print(f"   ✓ 登录成功！")
        print(f"   Token: {data.get('access_token', '')[:50]}...")
    elif response.status_code == 401:
        print(f"   ✗ 登录失败: 用户名或密码错误")
        print(f"   响应: {response.json()}")
        print(f"\n   请检查 .env 文件中的配置:")
        print(f"   ADMIN_USERNAME={admin_username}")
        print(f"   ADMIN_PASSWORD={admin_password}")
    else:
        print(f"   ✗ 登录失败: HTTP {response.status_code}")
        print(f"   响应: {response.text}")
except Exception as e:
    print(f"   ✗ 登录请求失败: {e}")
    sys.exit(1)

# 4. 检查配置
print(f"\n[4] 检查环境配置...")
print(f"   DASHSCOPE_API_KEY: {'已设置' if os.getenv('DASHSCOPE_API_KEY') else '未设置'}")
print(f"   JWT_SECRET: {'已设置' if os.getenv('JWT_SECRET') else '未设置'}")
print(f"   VIDEO_DIRS: {os.getenv('VIDEO_DIRS', '未设置')}")
print(f"   DATABASE_PATH: {os.getenv('DATABASE_PATH', './database/history.db')}")

# 5. 检查数据库
print(f"\n[5] 检查数据库...")
db_path = Path(os.getenv('DATABASE_PATH', './database/history.db'))
if db_path.exists():
    print(f"   ✓ 数据库文件存在: {db_path}")
    print(f"   大小: {db_path.stat().st_size / 1024:.2f} KB")
else:
    print(f"   ⚠ 数据库文件不存在: {db_path}")
    print(f"   (首次运行时会自动创建)")

# 6. 检查日志
print(f"\n[6] 检查日志...")
log_file = Path(os.getenv('LOG_FILE', './logs/app.log'))
if log_file.exists():
    print(f"   ✓ 日志文件存在: {log_file}")
    # 读取最后10行
    with open(log_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        print(f"   最后10行日志:")
        for line in lines[-10:]:
            print(f"      {line.rstrip()}")
else:
    print(f"   ⚠ 日志文件不存在: {log_file}")

print("\n" + "=" * 60)
print("诊断完成")
print("=" * 60)
