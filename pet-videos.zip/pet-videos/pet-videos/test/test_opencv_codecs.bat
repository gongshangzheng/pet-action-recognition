@echo off
chcp 65001 >nul
echo ========================================
echo   OpenCV Codec Test
echo ========================================
echo.

REM Check if Python is available
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Python not found
    pause
    exit /b 1
)

REM Check if test script exists
if not exist "test_opencv_codecs.py" (
    echo Error: test_opencv_codecs.py not found
    pause
    exit /b 1
)

REM Run test script
python test_opencv_codecs.py

echo.
pause
