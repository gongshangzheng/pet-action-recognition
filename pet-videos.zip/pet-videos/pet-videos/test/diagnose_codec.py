#!/usr/bin/env python3
"""诊断 OpenCV 编码器兼容性"""
import cv2
import os
import sys

print("=" * 80)
print("OpenCV 编码器诊断工具")
print("=" * 80)

# 1. OpenCV 版本
opencv_version = cv2.__version__
print(f"\n✓ OpenCV 版本: {opencv_version}")

# 2. 检查已安装的 OpenH264
app_data = os.path.expandvars(r'%LOCALAPPDATA%')
print(f"\n检查目录: {app_data}")

import glob
openh264_files = glob.glob(os.path.join(app_data, "openh264*.dll"))
if openh264_files:
    print("\n已安装的 OpenH264 文件:")
    for f in openh264_files:
        size = os.path.getsize(f) / 1024
        print(f"  ✓ {os.path.basename(f)} ({size:.1f} KB)")
else:
    print("\n✗ 未找到 openh264*.dll 文件")

# 3. 测试可用的编码器
print("\n" + "=" * 80)
print("测试编码器兼容性")
print("=" * 80)

test_codecs = [
    ('avc1', 'H.264 (OpenH264)'),
    ('H264', 'H.264 (通用)'),
    ('X264', 'H.264 (x264)'),
    ('mp4v', 'MPEG-4'),
    ('XVID', 'XVID'),
    ('MJPG', 'Motion JPEG'),
]

available_codecs = []
test_file = "test_codec.mp4"

for codec_id, codec_name in test_codecs:
    try:
        fourcc = cv2.VideoWriter_fourcc(*codec_id)
        writer = cv2.VideoWriter(test_file, fourcc, 20.0, (640, 480))
        
        if writer.isOpened():
            available_codecs.append((codec_id, codec_name))
            print(f"  ✓ {codec_name:25s} [{codec_id:4s}] - 可用")
            writer.release()
            if os.path.exists(test_file):
                os.remove(test_file)
        else:
            print(f"  ✗ {codec_name:25s} [{codec_id:4s}] - 不可用")
            writer.release()
    except Exception as e:
        print(f"  ✗ {codec_name:25s} [{codec_id:4s}] - 错误: {e}")

# 4. 推荐方案
print("\n" + "=" * 80)
print("推荐方案")
print("=" * 80)

if available_codecs:
    print(f"\n✓ 找到 {len(available_codecs)} 个可用编码器:\n")
    for codec_id, codec_name in available_codecs:
        print(f"  • {codec_name} [{codec_id}]")
    
    print(f"\n推荐使用: {available_codecs[0][1]} [{available_codecs[0][0]}]")
    print(f"\n修改 scripts/pet_monitor.py:")
    print(f"  fourcc = cv2.VideoWriter_fourcc(*'{available_codecs[0][0]}')")
else:
    print("\n✗ 未找到可用的编码器！")
    print("\n请检查：")
    print("  1. OpenCV 是否正确安装")
    print("  2. 系统是否缺少必要的编解码器")

# 5. OpenH264 版本对应关系
print("\n" + "=" * 80)
print("OpenCV 与 OpenH264 版本对应")
print("=" * 80)
print("""
OpenCV 版本          推荐 OpenH264 版本
------------------  -------------------
4.5.x - 4.7.x       v1.8.0
4.8.x - 4.10.x      v2.3.1
4.11.x - 4.12.x     v2.4.1
4.13.x+             v2.5.1
""")

major, minor = map(int, opencv_version.split('.')[:2])
if major == 4:
    if minor <= 7:
        recommended = "1.8.0"
    elif minor <= 10:
        recommended = "2.3.1"
    elif minor <= 12:
        recommended = "2.4.1"
    else:
        recommended = "2.5.1"
    
    print(f"当前 OpenCV {opencv_version} 推荐使用: OpenH264 v{recommended}")
    print(f"\n下载地址:")
    print(f"https://github.com/cisco/openh264/releases/download/v{recommended}/openh264-{recommended}-win64.dll.bz2")

print("\n" + "=" * 80)
