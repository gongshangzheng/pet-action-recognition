#!/bin/bash
# 宠物监控脚本启动器
# 使用 backend venv 中的 Python 环境

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$(dirname "$SCRIPT_DIR")/backend"
VENV_PYTHON="$BACKEND_DIR/venv/bin/python3"

if [ ! -f "$VENV_PYTHON" ]; then
    echo "❌ 错误：找不到 venv Python：$VENV_PYTHON"
    exit 1
fi

echo "🐾 使用 Python: $VENV_PYTHON"
echo "📝 脚本目录: $SCRIPT_DIR"
echo ""

# 执行监控脚本，传递所有参数
exec "$VENV_PYTHON" "$SCRIPT_DIR/pet_monitor_pyav.py" "$@"
