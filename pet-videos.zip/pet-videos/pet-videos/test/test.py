from noah_python_sdk.clients import BNSClient, BNSGroupHttpClient
import pprint
import requests

bns_client = BNSClient()
bns_client.bns_group_clients = [BNSGroupHttpClient()]
service_name = "smart.group.user-service.licai-licai"
instances = bns_client.get_instances_by_service(service_name, True)
instances_dict = [vars(instance) for instance in instances]
pprint.pprint(instances_dict)

# 选择第一个可用的实例
if instances:
    instance = instances[0]
    url = f"http://{instance.ip}:{instance.port}/user/getSessionInfo"
    
    # 请求参数
    params = {
        'openBduss': 'QAAAAEAAABvolHSbgEXzlY5jZ4N-gelOs1GcMEYPl3-HR6zSRV3Jd_xp6q_R_5AvZl_5Km17xQo9_M4BrJmGmZsHrNp28eV0a3bEOsEiHBOSRCMiWLee9GpnmjRqTfagm9zB6DxQroh0-wnOW40tb2-qZhva5P5jTEGL3ogVLPZHObfAonZZgA',
        'bduss': '',
        'stoken': None,
        'from': 'pc',
        'version': '0.0.0',
        'os': 'windows',
        'ua': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0'
    }
    
    print(f"\n发起请求到: {url}")
    print(f"请求参数: {params}")
    
    try:
        response = requests.post(url, json=params, timeout=5)
        print(f"\n响应状态码: {response.status_code}")
        print(f"响应内容:")
        pprint.pprint(response.json())
    except Exception as e:
        print(f"请求失败: {e}")
else:
    print("未找到可用实例")