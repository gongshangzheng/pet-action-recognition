#!/usr/bin/env python3
"""检查任务状态和心跳"""
import sys
sys.path.insert(0, 'backend')

from database.db import SessionLocal
from models.database import SlicingTask
from datetime import datetime, timedelta

db = SessionLocal()

try:
    tasks = db.query(SlicingTask).all()
    
    print("=" * 80)
    print("任务状态诊断")
    print("=" * 80)
    print()
    
    for task in tasks:
        print(f"任务 ID: {task.source_id}")
        print(f"  状态: {task.status}")
        print(f"  PID: {task.pid}")
        print(f"  启动时间: {task.last_start_time}")
        print(f"  最后心跳: {task.last_heartbeat}")
        
        if task.last_heartbeat:
            age = datetime.now() - task.last_heartbeat
            print(f"  心跳间隔: {age.total_seconds():.1f} 秒")
            
            if age > timedelta(minutes=1):
                print(f"  ⚠️  心跳超时！(超过 1 分钟)")
            else:
                print(f"  ✓ 心跳正常")
        else:
            if task.last_start_time:
                age = datetime.now() - task.last_start_time
                print(f"  启动后时长: {age.total_seconds():.1f} 秒")
                if age > timedelta(minutes=1):
                    print(f"  ⚠️  启动后超过 1 分钟未收到心跳")
                else:
                    print(f"  ⏳ 等待首次心跳（宽限期内）")
            else:
                print(f"  ⚠️  未启动")
        
        print(f"  连续失败: {task.consecutive_failures} 次")
        if task.error_msg:
            print(f"  错误信息: {task.error_msg[:100]}")
        print()

finally:
    db.close()
