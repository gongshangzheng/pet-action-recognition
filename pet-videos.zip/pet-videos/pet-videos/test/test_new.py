"""
使用封装后的 BNS 客户端进行测试
对比原始方式和新封装方式
"""

from bns_client import get_bns_client
import pprint

# 测试用的 OpenBDUSS
TEST_OPEN_BDUSS = 'QAAAAEAAABvolHSbgEXzlY5jZ4N-gelOs1GcMEYPl3-HR6zSRV3Jd_xp6q_R_5AvZl_5Km17xQo9_M4BrJmGmZsHrNp28eV0a3bEOsEiHBOSRCMiWLee9GpnmjRqTfagm9zB6DxQroh0-wnOW40tb2-qZhva5P5jTEGL3ogVLPZHObfAonZZgA'


def main():
    """使用新封装的客户端"""
    print("="*60)
    print("使用新封装的 BNS 客户端")
    print("="*60)
    
    # 创建客户端
    client = get_bns_client()
    
    # 方式1：使用便捷方法（推荐）
    print("\n【方式1】使用便捷方法 get_session_info:")
    print("-"*60)
    
    result = client.get_session_info(
        open_bduss=TEST_OPEN_BDUSS,
        uri='/index.html',  # ← 添加了 uri 参数
        from='pc',
        os='windows',
        ua='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
    )
    
    if result['success']:
        print(f"\n✅ 请求成功!")
        print(f"实例: {result['instance']}")
        print(f"状态码: {result['status_code']}")
        print("\n响应数据:")
        pprint.pprint(result['data'])
    else:
        print(f"\n❌ 请求失败!")
        print(f"错误: {result['error']}")
        print(f"状态码: {result['status_code']}")
    
    # 方式2：使用通用方法（更灵活）
    print("\n\n【方式2】使用通用方法 request:")
    print("-"*60)
    
    result2 = client.request(
        service_name="smart.group.user-service.licai-licai",
        api_path="/user/getSessionInfo",
        uri="/user/profile",  # 模拟从个人中心调用
        params={
            'openBduss': TEST_OPEN_BDUSS,
            'bduss': '',
            'stoken': None,
            'from': 'pc',
            'version': '0.0.0',
            'os': 'windows',
            'ua': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        },
        method="POST",
        timeout=5,
        verbose=True
    )
    
    if result2['success']:
        print(f"\n✅ 请求成功!")
        print(f"实例: {result2['instance']}")
    else:
        print(f"\n❌ 请求失败!")
        print(f"错误: {result2['error']}")
    
    print("\n" + "="*60)
    print("测试完成")
    print("="*60 + "\n")


if __name__ == '__main__':
    main()
