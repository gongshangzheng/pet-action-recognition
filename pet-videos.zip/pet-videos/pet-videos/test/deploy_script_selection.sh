#!/bin/bash
# 部署脚本选择功能 - Linux/macOS
# 运行此脚本以部署新功能

set -e

echo "================================================================================"
echo "部署脚本选择功能"
echo "================================================================================"
echo

echo "[1/4] 检查环境..."
if [ ! -f "backend/venv/bin/python" ]; then
    echo "[错误] 虚拟环境不存在"
    exit 1
fi

if [ ! -f "backend/database/history.db" ]; then
    echo "[错误] 数据库文件不存在"
    exit 1
fi

echo "OK"
echo

echo "[2/4] 运行数据库迁移..."
backend/venv/bin/python backend/migrations/add_script_file_to_tasks.py
echo "OK"
echo

echo "[3/4] 重启后端服务..."
echo "提示：请手动重启后端服务"
echo "  - 在终端按 Ctrl+C 停止"
echo "  - 运行: backend/venv/bin/python -m uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000"
echo
read -p "按回车继续..."
echo

echo "[4/4] 刷新前端..."
echo "提示：请在浏览器中刷新页面 (Ctrl+F5 或 Cmd+Shift+R)"
echo

echo "================================================================================"
echo "部署完成！"
echo "================================================================================"
echo
echo "验证步骤："
echo "1. 打开浏览器访问前端页面"
echo "2. 进入\"系统管理\" → \"任务监控\""
echo "3. 点击\"新建任务\""
echo "4. 确认表单中有\"脚本文件\"选择器"
echo "5. 确认任务列表中显示\"脚本文件\"列"
echo
echo "如有问题，请查看文档：SCRIPT_SELECTION.md"
echo
