@echo off
chcp 65001 >nul
echo ========================================
echo   FFmpeg Installation Test
echo ========================================
echo.

REM Check if Python is available
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Python not found
    echo Please install Python first
    pause
    exit /b 1
)

REM Check if test script exists
if not exist "test_ffmpeg.py" (
    echo Error: test_ffmpeg.py not found
    pause
    exit /b 1
)

REM Run test script
python test_ffmpeg.py

pause
