#!/usr/bin/env python3
"""检查 OpenCV 和 OpenH264 版本兼容性"""
import cv2
import os

print("=" * 80)
print("OpenCV 版本信息")
print("=" * 80)
print(f"OpenCV 版本: {cv2.__version__}")

# 检查构建信息
build_info = cv2.getBuildInformation()

# 提取 FFMPEG 和 OpenH264 相关信息
print("\n" + "=" * 80)
print("FFMPEG/OpenH264 配置")
print("=" * 80)

for line in build_info.split('\n'):
    line_upper = line.upper()
    if any(keyword in line_upper for keyword in ['FFMPEG', 'OPENH264', 'VIDEO', 'CODEC']):
        print(line)

# 检查已安装的 OpenH264 文件
print("\n" + "=" * 80)
print("已安装的 OpenH264 文件")
print("=" * 80)

app_data = os.path.expandvars(r'%LOCALAPPDATA%')
print(f"\n检查目录: {app_data}\n")

import glob
openh264_files = glob.glob(os.path.join(app_data, "openh264*.dll"))
if openh264_files:
    for f in openh264_files:
        size = os.path.getsize(f) / 1024
        print(f"✓ {os.path.basename(f)} ({size:.1f} KB)")
else:
    print("✗ 未找到 openh264*.dll 文件")

# 推荐方案
print("\n" + "=" * 80)
print("解决方案")
print("=" * 80)
print("""
问题：OpenCV 要求 v1.8.0，但你安装了 v2.4.1

方案 1：安装 OpenCV 要求的版本（推荐）
----------------------------------------
下载 OpenH264 v1.8.0:
https://github.com/cisco/openh264/releases/download/v1.8.0/openh264-1.8.0-win64.dll.bz2

解压后复制到：
%LOCALAPPDATA%\\openh264-1.8.0-win64.dll

方案 2：升级 OpenCV
----------------------------------------
pip install opencv-python --upgrade

然后安装对应版本的 OpenH264（可能需要 v2.x）
""")
