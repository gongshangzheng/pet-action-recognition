#!/usr/bin/env python3
"""诊断数据库路径和任务状态"""
import sys
import os
from pathlib import Path

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / "backend"))

print("=" * 70)
print("数据库路径和任务诊断")
print("=" * 70)
print()

# 1. 检查配置的数据库路径
print("【1】配置的数据库路径:")
try:
    from backend.config.settings import settings
    print(f"  settings.database_path = {settings.database_path}")
    print(f"  绝对路径 = {os.path.abspath(settings.database_path)}")
    print(f"  文件存在? {os.path.exists(settings.database_path)}")
    if os.path.exists(settings.database_path):
        size_kb = os.path.getsize(settings.database_path) / 1024
        print(f"  文件大小: {size_kb:.1f} KB")
except Exception as e:
    print(f"  ❌ 错误: {e}")

print()

# 2. 搜索所有可能的数据库文件
print("【2】搜索所有 history.db 文件:")
possible_locations = [
    Path("D:/pet-videos/database/history.db"),
    Path("D:/pet-videos/backend/database/history.db"),
    Path("./database/history.db"),
    Path("./backend/database/history.db"),
]

found_dbs = []
for loc in possible_locations:
    if loc.exists():
        size_kb = loc.stat().st_size / 1024
        print(f"  ✓ {loc.absolute()} ({size_kb:.1f} KB)")
        found_dbs.append(loc)
    else:
        print(f"  ✗ {loc.absolute()} (不存在)")

print()

# 3. 检查每个数据库文件中的任务
if found_dbs:
    print("【3】检查每个数据库文件的内容:")
    import sqlite3
    
    for db_path in found_dbs:
        print(f"\n  数据库: {db_path.absolute()}")
        try:
            conn = sqlite3.connect(str(db_path))
            cursor = conn.cursor()
            
            # 检查表
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            print(f"    表: {', '.join(tables)}")
            
            # 检查 slicing_tasks
            if 'slicing_tasks' in tables:
                cursor.execute("SELECT COUNT(*) FROM slicing_tasks")
                count = cursor.fetchone()[0]
                print(f"    slicing_tasks 记录数: {count}")
                
                if count > 0:
                    cursor.execute("""
                        SELECT id, source_id, status, pid, last_heartbeat, script_file 
                        FROM slicing_tasks
                    """)
                    print("    任务列表:")
                    for row in cursor.fetchall():
                        print(f"      - ID={row[0]}, source_id={row[1]}, status={row[2]}, "
                              f"pid={row[3]}, heartbeat={row[4]}, script={row[5]}")
            
            # 检查 stream_sources
            if 'stream_sources' in tables:
                cursor.execute("SELECT COUNT(*) FROM stream_sources")
                count = cursor.fetchone()[0]
                print(f"    stream_sources 记录数: {count}")
            
            conn.close()
        except Exception as e:
            print(f"    ❌ 错误: {e}")
else:
    print("【3】❌ 没有找到任何 history.db 文件!")

print()

# 4. 检查当前工作目录
print("【4】当前工作目录:")
print(f"  {os.getcwd()}")

print()

# 5. 检查运行中的 Python 进程
print("【5】检查运行中的 pet_monitor 进程:")
try:
    import subprocess
    if sys.platform == "win32":
        result = subprocess.run(
            ['powershell', '-Command', 
             'Get-Process | Where-Object {$_.CommandLine -like "*pet_monitor*"} | Select-Object Id,CommandLine'],
            capture_output=True, text=True, timeout=5
        )
        if result.stdout.strip():
            print(result.stdout)
        else:
            print("  未找到运行中的 pet_monitor 进程")
            # 尝试另一种方法
            result2 = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq python.exe'], 
                                    capture_output=True, text=True)
            print("\n  所有 python.exe 进程:")
            print(result2.stdout)
except Exception as e:
    print(f"  ❌ 检查进程失败: {e}")

print()
print("=" * 70)
print("诊断建议:")
print("1. 如果找到多个 history.db，检查哪个包含任务数据")
print("2. 后端服务应该使用包含任务数据的那个数据库")
print("3. 确保后端启动时的工作目录正确")
print("=" * 70)
