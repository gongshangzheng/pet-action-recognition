"""
BNS客户端使用示例
包含同步和异步两种方式的对比
"""

import asyncio
import time
from bns_client import request_bns_service, get_bns_client
from bns_client_async import request_bns_service_async, get_async_bns_client, batch_request


# 测试用的 OpenBDUSS（请替换为真实值）
TEST_OPEN_BDUSS = 'QAAAAEAAABvolHSbgEXzlY5jZ4N-gelOs1GcMEYPl3-HR6zSRV3Jd_xp6q_R_5AvZl_5Km17xQo9_M4BrJmGmZsHrNp28eV0a3bEOsEiHBOSRCMiWLee9GpnmjRqTfagm9zB6DxQroh0-wnOW40tb2-qZhva5P5jTEGL3ogVLPZHObfAonZZgA'


def test_sync_basic():
    """测试1：同步方式 - 基础用法"""
    print("\n" + "="*60)
    print("测试1：同步方式 - 基础用法")
    print("="*60)
    
    result = request_bns_service(
        service_name="smart.group.user-service.licai-licai",
        api_path="/user/getSessionInfo",
        uri="/index.html",  # 模拟从首页调用
        params={
            'openBduss': TEST_OPEN_BDUSS,
            'bduss': '',
            'stoken': None,
            'from': 'pc',
            'version': '0.0.0',
            'os': 'windows',
            'ua': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)'
        }
    )
    
    if result['success']:
        print(f"\n✅ 请求成功")
        print(f"实例: {result['instance']}")
        print(f"数据: {result['data']}")
    else:
        print(f"\n❌ 请求失败")
        print(f"错误: {result['error']}")


def test_sync_convenient():
    """测试2：同步方式 - 便捷方法"""
    print("\n" + "="*60)
    print("测试2：同步方式 - 便捷方法")
    print("="*60)
    
    client = get_bns_client()
    
    result = client.get_session_info(
        open_bduss=TEST_OPEN_BDUSS,
        uri="/user/profile",  # 模拟从个人中心调用
        verbose=True
    )
    
    if result['success']:
        print(f"\n✅ 请求成功")
        print(f"实例: {result['instance']}")
    else:
        print(f"\n❌ 请求失败")
        print(f"错误: {result['error']}")


def test_sync_multiple():
    """测试3：同步方式 - 多次请求（串行）"""
    print("\n" + "="*60)
    print("测试3：同步方式 - 多次请求（串行执行）")
    print("="*60)
    
    client = get_bns_client()
    
    start_time = time.time()
    
    for i in range(3):
        print(f"\n--- 第 {i+1} 次请求 ---")
        result = client.get_session_info(
            open_bduss=TEST_OPEN_BDUSS,
            uri=f"/page{i}",
            verbose=False  # 关闭详细日志
        )
        print(f"请求{i+1}: {'✅成功' if result['success'] else '❌失败'} | 实例: {result['instance']}")
    
    elapsed = time.time() - start_time
    print(f"\n总耗时: {elapsed:.2f}秒")


async def test_async_basic():
    """测试4：异步方式 - 基础用法"""
    print("\n" + "="*60)
    print("测试4：异步方式 - 基础用法")
    print("="*60)
    
    result = await request_bns_service_async(
        service_name="smart.group.user-service.licai-licai",
        api_path="/user/getSessionInfo",
        uri="/index.html",
        params={
            'openBduss': TEST_OPEN_BDUSS,
            'bduss': '',
            'from': 'pc'
        }
    )
    
    if result['success']:
        print(f"\n✅ 异步请求成功")
        print(f"实例: {result['instance']}")
    else:
        print(f"\n❌ 异步请求失败")
        print(f"错误: {result['error']}")


async def test_async_concurrent():
    """测试5：异步方式 - 并发请求"""
    print("\n" + "="*60)
    print("测试5：异步方式 - 并发请求（同时执行）")
    print("="*60)
    
    client = get_async_bns_client()
    
    start_time = time.time()
    
    # 创建3个并发任务
    tasks = [
        client.get_session_info(
            open_bduss=TEST_OPEN_BDUSS,
            uri=f"/page{i}",
            verbose=False
        )
        for i in range(3)
    ]
    
    # 并发执行
    results = await asyncio.gather(*tasks)
    
    # 打印结果
    for i, result in enumerate(results):
        print(f"请求{i+1}: {'✅成功' if result['success'] else '❌失败'} | 实例: {result['instance']}")
    
    elapsed = time.time() - start_time
    print(f"\n总耗时: {elapsed:.2f}秒 (并发执行)")


async def test_async_batch():
    """测试6：异步方式 - 批量请求"""
    print("\n" + "="*60)
    print("测试6：异步方式 - 批量请求（使用 batch_request）")
    print("="*60)
    
    start_time = time.time()
    
    # 定义批量请求
    requests = [
        {
            'service_name': 'smart.group.user-service.licai-licai',
            'api_path': '/user/getSessionInfo',
            'uri': f'/page{i}',
            'params': {
                'openBduss': TEST_OPEN_BDUSS,
                'bduss': '',
                'from': 'pc'
            },
            'verbose': False
        }
        for i in range(5)  # 5个并发请求
    ]
    
    # 批量执行
    results = await batch_request(requests)
    
    # 统计结果
    success_count = sum(1 for r in results if r['success'])
    print(f"\n成功: {success_count}/{len(results)}")
    
    for i, result in enumerate(results):
        status = '✅' if result['success'] else '❌'
        print(f"请求{i+1}: {status} | 实例: {result.get('instance', 'N/A')}")
    
    elapsed = time.time() - start_time
    print(f"\n总耗时: {elapsed:.2f}秒")


def main():
    """主函数"""
    print("\n" + "🚀" + "="*58 + "🚀")
    print("  BNS客户端测试套件")
    print("🚀" + "="*58 + "🚀")
    
    # 同步测试
    test_sync_basic()
    test_sync_convenient()
    test_sync_multiple()
    
    # 异步测试
    print("\n" + "🔄" + "="*58 + "🔄")
    print("  开始异步测试")
    print("🔄" + "="*58 + "🔄")
    
    asyncio.run(test_async_basic())
    asyncio.run(test_async_concurrent())
    asyncio.run(test_async_batch())
    
    print("\n" + "✨" + "="*58 + "✨")
    print("  所有测试完成")
    print("✨" + "="*58 + "✨\n")


if __name__ == '__main__':
    main()
