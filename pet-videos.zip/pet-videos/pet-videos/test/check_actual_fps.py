#!/usr/bin/env python3
"""检查视频的声明FPS vs 实际FPS"""
import cv2
import sys
from pathlib import Path


def check_video_fps(video_path):
    """分析视频的帧率"""
    print("=" * 70)
    print(f"检查视频: {video_path}")
    print("=" * 70)
    
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print("❌ 无法打开视频文件")
        return
    
    # 读取元数据
    declared_fps = cap.get(cv2.CAP_PROP_FPS)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = frame_count / declared_fps if declared_fps > 0 else 0
    
    print(f"\n【元数据信息】")
    print(f"  声明 FPS: {declared_fps:.2f}")
    print(f"  总帧数: {frame_count}")
    print(f"  声明时长: {duration:.2f} 秒")
    
    # 实际读取帧，计算真实 FPS
    print(f"\n【实际测试】正在读取所有帧...")
    
    actual_frame_count = 0
    frame_times = []
    
    # 读取所有帧
    while True:
        ret = cap.grab()
        if not ret:
            break
        actual_frame_count += 1
    
    cap.release()
    
    actual_fps = actual_frame_count / duration if duration > 0 else 0
    
    print(f"  实际帧数: {actual_frame_count}")
    print(f"  实际 FPS: {actual_fps:.2f}")
    
    # 对比分析
    print(f"\n【对比分析】")
    if abs(declared_fps - actual_fps) < 0.1:
        print(f"  ✅ 帧率一致（误差 < 0.1）")
    else:
        diff_percent = abs(declared_fps - actual_fps) / declared_fps * 100
        print(f"  ⚠️  帧率不一致！")
        print(f"     声明: {declared_fps:.2f} FPS")
        print(f"     实际: {actual_fps:.2f} FPS")
        print(f"     差异: {diff_percent:.1f}%")
        
        if actual_fps < declared_fps:
            print(f"\n  原因分析:")
            print(f"    - 录制时主循环处理慢，未能写入所有帧")
            print(f"    - YOLO 检测耗时过长")
            print(f"    - 磁盘写入慢")
            print(f"\n  后果:")
            print(f"    - 视频播放时会卡顿、跳帧")
            print(f"    - 播放器期望 {declared_fps:.0f} 帧/秒，但只有 {actual_fps:.0f} 帧/秒")
    
    print("\n" + "=" * 70)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python check_actual_fps.py <视频文件路径>")
        print("\n示例:")
        print("  python check_actual_fps.py D:\\pet-videos\\videos\\test\\event_20260122_123456.mp4")
        sys.exit(1)
    
    video_path = Path(sys.argv[1])
    
    if not video_path.exists():
        print(f"❌ 文件不存在: {video_path}")
        sys.exit(1)
    
    check_video_fps(video_path)
