#!/usr/bin/env python3
"""检查已安装的 OpenH264 版本和 OpenCV 配置"""
import os
import glob
import cv2

print("=" * 80)
print("OpenH264 版本检查")
print("=" * 80)

# 1. 检查 OpenCV 版本
opencv_version = cv2.__version__
print(f"\n✓ OpenCV 版本: {opencv_version}")

# 2. 检查所有可能的安装位置
search_paths = [
    os.path.expandvars(r'%LOCALAPPDATA%'),
    os.path.expandvars(r'%SystemRoot%\System32'),
    os.path.dirname(os.path.abspath(__file__)),  # 当前目录
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'scripts'),
]

print("\n" + "=" * 80)
print("搜索 OpenH264 DLL 文件")
print("=" * 80)

found_files = []
for path in search_paths:
    if os.path.exists(path):
        pattern = os.path.join(path, "openh264*.dll")
        files = glob.glob(pattern)
        if files:
            for f in files:
                size_kb = os.path.getsize(f) / 1024
                # 从文件名提取版本号
                filename = os.path.basename(f)
                # openh264-X.X.X-win64.dll
                version = filename.replace('openh264-', '').replace('-win64.dll', '')
                found_files.append({
                    'path': f,
                    'version': version,
                    'size_kb': size_kb,
                    'location': path
                })

if found_files:
    print(f"\n✓ 找到 {len(found_files)} 个 OpenH264 文件:\n")
    for i, info in enumerate(found_files, 1):
        print(f"{i}. 版本: {info['version']}")
        print(f"   路径: {info['path']}")
        print(f"   大小: {info['size_kb']:.1f} KB")
        print()
else:
    print("\n✗ 未找到任何 OpenH264 DLL 文件！")

# 3. 检查 OpenCV 构建信息中的 OpenH264 配置
print("=" * 80)
print("OpenCV 构建配置")
print("=" * 80)

build_info = cv2.getBuildInformation()
relevant_lines = []
for line in build_info.split('\n'):
    line_upper = line.upper()
    if any(keyword in line_upper for keyword in ['OPENH264', 'FFMPEG', 'H264', 'VIDEO I/O']):
        relevant_lines.append(line)

if relevant_lines:
    print()
    for line in relevant_lines[:20]:  # 只显示前20行
        print(line)
else:
    # 如果没有找到关键字，显示 Video I/O 部分
    in_video_section = False
    for line in build_info.split('\n'):
        if 'Video I/O' in line:
            in_video_section = True
        if in_video_section:
            print(line)
            if line.strip() == '' and in_video_section:
                break

# 4. 推荐的 OpenH264 版本
print("\n" + "=" * 80)
print("版本兼容性分析")
print("=" * 80)

major, minor, *_ = opencv_version.split('.')
major, minor = int(major), int(minor)

# 根据 OpenCV 版本推荐 OpenH264 版本
version_map = {
    (4, 5): "1.8.0",
    (4, 6): "1.8.0",
    (4, 7): "1.8.0",
    (4, 8): "2.3.1",
    (4, 9): "2.3.1",
    (4, 10): "2.3.1",
    (4, 11): "2.4.1",
    (4, 12): "2.4.1",
}

recommended_version = version_map.get((major, minor), "2.5.1")

print(f"\nOpenCV {opencv_version} 推荐 OpenH264 版本: {recommended_version}")

if found_files:
    installed_versions = [f['version'] for f in found_files]
    print(f"已安装版本: {', '.join(installed_versions)}")
    
    if recommended_version in installed_versions:
        print(f"\n✓ 版本匹配！但仍然报错，可能原因：")
        print("  1. OpenCV 编译时指定了特定的库版本")
        print("  2. 系统环境变量配置问题")
        print("  3. OpenCV 的 FFMPEG 后端配置问题")
    else:
        print(f"\n✗ 版本不匹配！")
        print(f"  需要: {recommended_version}")
        print(f"  当前: {', '.join(installed_versions)}")

# 5. 解决方案
print("\n" + "=" * 80)
print("解决方案")
print("=" * 80)

print(f"""
方案 1：使用其他编码器（推荐，已在脚本中实现）
------------------------------------------------
脚本已更新为自动尝试多个编码器：
• H264 (通用)
• X264 (x264)  
• mp4v (MPEG-4)

无需 OpenH264 库，立即可用！

方案 2：手动安装匹配的 OpenH264 版本
------------------------------------------------
1. 删除所有旧版本:
""")

if found_files:
    for info in found_files:
        if info['version'] != recommended_version:
            print(f"   del \"{info['path']}\"")

print(f"""
2. 下载 OpenH264 v{recommended_version}:
   https://github.com/cisco/openh264/releases/download/v{recommended_version}/openh264-{recommended_version}-win64.dll.bz2

3. 解压后复制到:
   {os.path.expandvars(r'%LOCALAPPDATA%')}\\openh264-{recommended_version}-win64.dll

方案 3：升级/重装 OpenCV（最彻底）
------------------------------------------------
pip uninstall opencv-python opencv-python-headless
pip install opencv-python --upgrade
""")

print("=" * 80)
