#!/usr/bin/env python3
"""快速测试 x264 编码器是否可用"""
import cv2
import numpy as np
import os

def quick_test_x264():
    """快速测试 x264 编码器"""
    print("=" * 60)
    print("快速测试: x264 编码器")
    print("=" * 60)
    print()
    
    # 测试参数
    test_file = "test_x264_quick.mp4"
    width, height = 640, 480
    fps = 20
    
    print(f"创建测试视频: {test_file}")
    print(f"分辨率: {width}x{height}, 帧率: {fps}")
    print()
    
    try:
        # 尝试使用 X264 编码器
        fourcc = cv2.VideoWriter_fourcc(*'X264')
        writer = cv2.VideoWriter(test_file, fourcc, fps, (width, height))
        
        if not writer.isOpened():
            print("✗ 失败: VideoWriter 无法使用 X264 编码器")
            print()
            print("可能的原因:")
            print("  1. Windows 系统不支持 X264 编码器")
            print("  2. OpenCV 编译时未包含 X264 支持")
            print("  3. 需要安装额外的编解码器")
            print()
            print("建议:")
            print("  - 使用 FFmpeg 管道编码（推荐）")
            print("  - 或使用 'mp4v' 编码器（兼容性最好）")
            return False
        
        print("✓ X264 编码器可用")
        print()
        print("写入测试帧...")
        
        # 写入 30 帧
        for i in range(30):
            frame = np.zeros((height, width, 3), dtype=np.uint8)
            frame[:, :] = [100, 150, 200]
            cv2.putText(frame, f"Frame {i+1}/30", (50, height // 2), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            writer.write(frame)
        
        writer.release()
        
        # 检查文件
        if os.path.exists(test_file):
            file_size = os.path.getsize(test_file)
            print(f"✓ 视频文件已创建: {file_size:,} 字节")
            
            # 清理
            os.remove(test_file)
            print("✓ 测试文件已清理")
            print()
            print("=" * 60)
            print("✓✓✓ X264 编码器测试通过！")
            print("=" * 60)
            print()
            print("可以在 pet_monitor.py 中使用:")
            print("  fourcc = cv2.VideoWriter_fourcc(*'X264')")
            return True
        else:
            print("✗ 文件未生成")
            return False
    
    except Exception as e:
        print(f"✗ 测试失败: {e}")
        return False


if __name__ == "__main__":
    import sys
    success = quick_test_x264()
    sys.exit(0 if success else 1)
