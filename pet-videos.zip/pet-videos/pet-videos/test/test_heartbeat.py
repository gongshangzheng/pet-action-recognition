#!/usr/bin/env python3
"""测试心跳 API 是否正常工作"""
import requests
import sys

def test_heartbeat(source_id=1, port=8000):
    """测试心跳 API"""
    url = f"http://127.0.0.1:{port}/api/tasks/{source_id}/heartbeat"
    
    print("=" * 60)
    print(f"测试心跳 API")
    print("=" * 60)
    print(f"\n目标: {url}\n")
    
    try:
        print("发送 POST 请求...")
        response = requests.post(url, timeout=5)
        
        print(f"响应状态码: {response.status_code}")
        print(f"响应内容: {response.text}")
        
        if response.status_code == 200:
            print("\n✓ 心跳 API 测试成功！")
            return True
        else:
            print(f"\n✗ 心跳 API 返回错误: HTTP {response.status_code}")
            return False
            
    except requests.exceptions.ConnectionError:
        print(f"\n✗ 连接失败: 后端服务未运行或端口 {port} 不正确")
        print(f"\n请检查:")
        print(f"  1. 后端服务是否已启动")
        print(f"  2. .env 中的 BACKEND_PORT 配置")
        print(f"  3. 防火墙是否阻止了连接")
        return False
        
    except requests.exceptions.Timeout:
        print(f"\n✗ 请求超时")
        return False
        
    except Exception as e:
        print(f"\n✗ 测试失败: {e}")
        return False

if __name__ == "__main__":
    # 可以从命令行传入 source_id 和 port
    source_id = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 8000
    
    success = test_heartbeat(source_id, port)
    sys.exit(0 if success else 1)
