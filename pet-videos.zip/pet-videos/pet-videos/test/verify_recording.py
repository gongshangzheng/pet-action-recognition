#!/usr/bin/env python3
"""验证最新录制的视频是否成功"""
import os
import sys
import cv2
from pathlib import Path
from datetime import datetime, timedelta

def verify_video(video_dir):
    """验证最新的视频文件"""
    print("=" * 60)
    print("视频录制验证")
    print("=" * 60)
    print()
    
    # 查找最新的视频文件
    video_files = list(Path(video_dir).glob("event_*.mp4"))
    if not video_files:
        print(f"✗ 未找到视频文件: {video_dir}")
        return False
    
    # 按修改时间排序，获取最新的
    latest_video = max(video_files, key=lambda p: p.stat().st_mtime)
    
    print(f"最新视频: {latest_video.name}")
    print()
    
    # 检查文件基本信息
    file_size = latest_video.stat().st_size
    file_time = datetime.fromtimestamp(latest_video.stat().st_mtime)
    time_ago = datetime.now() - file_time
    
    print(f"文件大小: {file_size:,} 字节 ({file_size/1024/1024:.2f} MB)")
    print(f"创建时间: {file_time.strftime('%Y-%m-%d %H:%M:%S')} ({time_ago.total_seconds():.0f} 秒前)")
    
    if file_size == 0:
        print("\n✗ 失败: 文件大小为 0")
        return False
    
    print()
    
    # 使用 OpenCV 读取视频
    try:
        cap = cv2.VideoCapture(str(latest_video))
        
        if not cap.isOpened():
            print("✗ 失败: 无法打开视频文件")
            return False
        
        # 读取视频属性
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = int(cap.get(cv2.CAP_PROP_FPS))
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = frame_count / fps if fps > 0 else 0
        fourcc = int(cap.get(cv2.CAP_PROP_FOURCC))
        
        # 转换 fourcc 为可读字符串
        fourcc_str = "".join([chr((fourcc >> 8 * i) & 0xFF) for i in range(4)])
        
        print("视频属性:")
        print(f"  分辨率: {width}x{height}")
        print(f"  帧率: {fps} fps")
        print(f"  总帧数: {frame_count}")
        print(f"  时长: {duration:.1f} 秒")
        print(f"  编码: {fourcc_str}")
        print()
        
        # 尝试读取第一帧
        ret, frame = cap.read()
        if ret and frame is not None:
            print(f"✓ 第一帧读取成功: {frame.shape}")
        else:
            print("✗ 警告: 无法读取第一帧")
        
        cap.release()
        
        # 最终判断
        print()
        print("=" * 60)
        if frame_count > 0 and ret:
            print("✓✓✓ 视频录制成功！")
            print("=" * 60)
            print()
            print("结论:")
            print("  • 视频文件完整")
            print("  • 可以正常读取")
            print("  • 编码器工作正常")
            print(f"  • OpenCV 警告可以忽略（最终使用了 {fourcc_str} 编码）")
            return True
        else:
            print("✗✗✗ 视频录制失败！")
            print("=" * 60)
            return False
        
    except Exception as e:
        print(f"✗ 读取视频时出错: {e}")
        return False


if __name__ == "__main__":
    if len(sys.argv) > 1:
        video_dir = sys.argv[1]
    else:
        video_dir = input("请输入视频目录路径（例如 D:\\pet-videos\\videos\\chfi7hg）: ").strip()
    
    if not os.path.exists(video_dir):
        print(f"错误: 目录不存在: {video_dir}")
        sys.exit(1)
    
    success = verify_video(video_dir)
    sys.exit(0 if success else 1)
