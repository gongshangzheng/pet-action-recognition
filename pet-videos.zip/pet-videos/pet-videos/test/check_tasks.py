#!/usr/bin/env python3
"""检查任务配置和心跳情况"""
import sys
import os
from pathlib import Path

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / "backend"))

# 强制切换到 backend 目录，确保使用正确的数据库
os.chdir(str(project_root / "backend"))

from backend.database.db import SessionLocal
from backend.models.database import SlicingTask, StreamSource
from datetime import datetime

db = SessionLocal()

print("=" * 70)
print("任务配置和心跳检查")
print("=" * 70)
print()

try:
    # 获取所有任务
    tasks = db.query(SlicingTask).all()
    
    if not tasks:
        print("❌ 没有找到任何任务")
        sys.exit(0)
    
    print(f"找到 {len(tasks)} 个任务:\n")
    
    for task in tasks:
        # 获取源信息
        source = db.query(StreamSource).filter(StreamSource.id == task.source_id).first()
        source_name = source.name if source else "未知"
        
        # 计算心跳延迟
        heartbeat_delay = "N/A"
        if task.last_heartbeat:
            delta = datetime.now() - task.last_heartbeat
            heartbeat_delay = f"{delta.total_seconds():.0f} 秒前"
        
        print(f"任务 ID: {task.id}")
        print(f"  Source ID: {task.source_id}")
        print(f"  源名称: {source_name}")
        print(f"  状态: {task.status}")
        print(f"  PID: {task.pid or 'N/A'}")
        print(f"  脚本文件: {task.script_file}")
        print(f"  最近心跳: {task.last_heartbeat or 'N/A'} ({heartbeat_delay})")
        print()
    
    # 检查是否有重复的 source_id
    source_ids = [t.source_id for t in tasks]
    if len(source_ids) != len(set(source_ids)):
        print("⚠️  警告: 发现重复的 source_id!")
        from collections import Counter
        duplicates = [sid for sid, count in Counter(source_ids).items() if count > 1]
        print(f"  重复的 source_id: {duplicates}")
        print()
    
    # 检查心跳时间是否完全一致
    heartbeats = [t.last_heartbeat for t in tasks if t.last_heartbeat]
    if len(heartbeats) > 1:
        time_diff = (max(heartbeats) - min(heartbeats)).total_seconds()
        
        if len(set(heartbeats)) == 1:
            print("⚠️  警告: 所有任务的心跳时间完全相同!")
            print(f"  心跳时间: {heartbeats[0]}")
            print("  可能原因:")
            print("    1. 多个任务使用了相同的 source_id")
            print("    2. 任务启动命令传递了错误的 source_id")
            print("    3. 脚本实例之间存在状态共享")
        elif time_diff < 2:
            print(f"ℹ️  注意: 任务心跳时间非常接近（相差 {time_diff:.3f} 秒）")
            print("  这是正常现象，原因:")
            print("    - 两个任务几乎同时发送心跳（心跳间隔都是10秒）")
            print("    - 网络延迟相近，请求几乎同时到达后端")
            print("    - 前端显示精度到秒，所以看起来'完全一致'")
            print("  ✓ 只要 source_id 和 PID 不同，就没有问题")
    
    print()
    print("=" * 70)
    print("建议检查:")
    print("1. 查看任务日志，确认每个脚本使用的 source_id")
    print("2. 检查任务启动命令: 应该是不同的 --source-id 参数")
    print("3. 确认任务的 PID 不同（说明是不同的进程）")
    print("=" * 70)
    
except Exception as e:
    print(f"❌ 错误: {e}")
    import traceback
    traceback.print_exc()
finally:
    db.close()
