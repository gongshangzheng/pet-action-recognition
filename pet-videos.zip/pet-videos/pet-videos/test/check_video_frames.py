#!/usr/bin/env python3
"""检查视频文件的跳帧情况"""
import cv2
import sys
import numpy as np
from pathlib import Path


def check_video_frames(video_path):
    """分析视频帧的连续性"""
    print("=" * 70)
    print(f"检查视频: {video_path}")
    print("=" * 70)
    
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print("❌ 无法打开视频文件")
        return
    
    # 获取视频信息
    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = frame_count / fps if fps > 0 else 0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    print(f"\n【基本信息】")
    print(f"  分辨率: {width}x{height}")
    print(f"  FPS: {fps:.2f}")
    print(f"  总帧数: {frame_count}")
    print(f"  时长: {duration:.2f} 秒")
    print(f"  理论帧间隔: {1000/fps:.1f} ms")
    
    # 读取前100帧，检测跳帧
    print(f"\n【帧连续性分析】（采样前100帧）")
    
    prev_frame = None
    frame_diffs = []
    large_jumps = []
    
    for i in range(min(100, frame_count)):
        ret, frame = cap.read()
        if not ret:
            break
        
        if prev_frame is not None:
            # 计算帧间差异（SSIM 或简单的像素差）
            diff = cv2.absdiff(prev_frame, frame)
            mean_diff = np.mean(diff)
            frame_diffs.append(mean_diff)
            
            # 检测异常大的跳变（可能是跳帧）
            if len(frame_diffs) > 5:
                avg_diff = np.mean(frame_diffs[-5:])
                if mean_diff > avg_diff * 3:  # 差异超过平均值3倍
                    large_jumps.append((i, mean_diff, avg_diff))
        
        prev_frame = frame.copy()
    
    cap.release()
    
    if frame_diffs:
        avg_diff = np.mean(frame_diffs)
        max_diff = np.max(frame_diffs)
        std_diff = np.std(frame_diffs)
        
        print(f"  平均帧间差异: {avg_diff:.2f}")
        print(f"  最大帧间差异: {max_diff:.2f}")
        print(f"  标准差: {std_diff:.2f}")
        
        if large_jumps:
            print(f"\n  ⚠️  检测到 {len(large_jumps)} 处可能的跳帧:")
            for frame_idx, diff, avg in large_jumps[:10]:  # 只显示前10个
                print(f"    - 帧 #{frame_idx}: 差异={diff:.2f} (平均={avg:.2f}, {diff/avg:.1f}x)")
        else:
            print(f"\n  ✓ 未检测到明显的跳帧")
    
    # 帧差异波动分析
    if len(frame_diffs) > 10:
        print(f"\n【帧率稳定性】")
        coef_var = (std_diff / avg_diff) * 100 if avg_diff > 0 else 0
        print(f"  变异系数: {coef_var:.1f}%")
        
        if coef_var < 30:
            print(f"  评价: ✓ 帧率稳定")
        elif coef_var < 60:
            print(f"  评价: ⚠️  帧率波动")
        else:
            print(f"  评价: ❌ 严重跳帧")
    
    print("\n" + "=" * 70)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python check_video_frames.py <视频文件路径>")
        print("\n示例:")
        print("  python check_video_frames.py D:\\pet-videos\\videos\\test\\event_20260122_123456.mp4")
        sys.exit(1)
    
    video_path = Path(sys.argv[1])
    
    if not video_path.exists():
        print(f"❌ 文件不存在: {video_path}")
        sys.exit(1)
    
    check_video_frames(video_path)
