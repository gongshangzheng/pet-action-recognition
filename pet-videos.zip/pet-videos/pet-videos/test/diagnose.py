#!/usr/bin/env python3
"""
完整诊断脚本 - 检查所有可能导致"加载源配置失败"的问题
"""
import sys
import os
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / "backend"))

def test_database():
    """测试数据库连接和表结构"""
    print("=" * 70)
    print("【1】检查数据库")
    print("=" * 70)
    
    try:
        from sqlalchemy import create_engine, text, inspect
        from backend.config import settings
        
        database_url = f"sqlite:///{settings.database_path}"
        print(f"数据库路径: {settings.database_path}")
        
        if not Path(settings.database_path).exists():
            print("✗ 数据库文件不存在！")
            return False
        
        print("✓ 数据库文件存在")
        
        engine = create_engine(database_url)
        inspector = inspect(engine)
        
        # 检查必需的表
        tables = inspector.get_table_names()
        required_tables = ['stream_sources', 'slicing_tasks']
        
        for table in required_tables:
            if table in tables:
                print(f"✓ {table} 表存在")
                
                # 显示列
                columns = [col['name'] for col in inspector.get_columns(table)]
                print(f"  字段: {', '.join(columns)}")
            else:
                print(f"✗ {table} 表不存在！")
                return False
        
        # 检查是否有源数据
        with engine.connect() as conn:
            result = conn.execute(text("SELECT COUNT(*) FROM stream_sources"))
            count = result.scalar()
            print(f"\n当前有 {count} 个源配置")
            
            if count > 0:
                result = conn.execute(text("SELECT id, name, alias, is_active FROM stream_sources"))
                sources = result.fetchall()
                for source in sources:
                    status = "启用" if source[3] else "禁用"
                    print(f"  - ID={source[0]}: {source[1]} ({source[2]}) [{status}]")
        
        print("✓ 数据库检查通过\n")
        return True
        
    except Exception as e:
        print(f"✗ 数据库检查失败: {e}\n")
        import traceback
        traceback.print_exc()
        return False

def test_backend_api():
    """测试后端 API"""
    print("=" * 70)
    print("【2】检查后端 API")
    print("=" * 70)
    
    try:
        import requests
        
        # 测试健康检查
        try:
            response = requests.get("http://localhost:8000/health", timeout=2)
            if response.status_code == 200:
                print("✓ 后端服务运行正常")
            else:
                print(f"✗ 后端健康检查失败: HTTP {response.status_code}")
                return False
        except requests.exceptions.ConnectionError:
            print("✗ 无法连接到后端服务 (http://localhost:8000)")
            print("  请确保后端服务已启动:")
            print("  cd backend && ../backend/venv/bin/python -m uvicorn main:app --host 0.0.0.0 --port 8000")
            return False
        except Exception as e:
            print(f"✗ 后端连接错误: {e}")
            return False
        
        # 测试源配置 API（不需要认证的话）
        try:
            response = requests.get("http://localhost:8000/api/sources/", timeout=2)
            if response.status_code == 200:
                sources = response.json()
                print(f"✓ 源配置 API 正常 (返回 {len(sources)} 个源)")
            elif response.status_code == 401:
                print("✓ 源配置 API 需要认证 (正常)")
            else:
                print(f"⚠ 源配置 API 返回: HTTP {response.status_code}")
                print(f"  响应: {response.text[:200]}")
        except Exception as e:
            print(f"✗ 源配置 API 错误: {e}")
            return False
        
        print("✓ 后端 API 检查通过\n")
        return True
        
    except ImportError:
        print("✗ requests 模块未安装")
        return False

def test_config():
    """测试配置文件"""
    print("=" * 70)
    print("【3】检查配置文件")
    print("=" * 70)
    
    try:
        from backend.config import settings
        
        env_file = project_root / ".env"
        if env_file.exists():
            print(f"✓ .env 文件存在: {env_file}")
        else:
            print(f"⚠ .env 文件不存在: {env_file}")
            print("  使用默认配置")
        
        print(f"✓ 后端端口: {settings.backend_port}")
        print(f"✓ 数据库路径: {settings.database_path}")
        print(f"✓ 日志级别: {settings.log_level}")
        print("✓ 配置检查通过\n")
        return True
        
    except Exception as e:
        print(f"✗ 配置检查失败: {e}\n")
        return False

def main():
    """运行所有诊断"""
    print("\n" + "=" * 70)
    print(" Pet-Videos 诊断工具")
    print("=" * 70)
    print()
    
    results = {
        "配置文件": test_config(),
        "数据库": test_database(),
        "后端API": test_backend_api(),
    }
    
    print("=" * 70)
    print("【诊断总结】")
    print("=" * 70)
    
    all_passed = True
    for name, passed in results.items():
        status = "✓ 通过" if passed else "✗ 失败"
        print(f"{name:<20} {status}")
        if not passed:
            all_passed = False
    
    print()
    
    if all_passed:
        print("✓✓✓ 所有检查通过！")
        print("\n如果前端仍然显示'加载源配置失败'，请:")
        print("1. 打开浏览器开发者工具 (F12)")
        print("2. 切换到 Console 标签，查看错误信息")
        print("3. 切换到 Network 标签，查看失败的请求")
        print("4. 截图或复制错误信息")
    else:
        print("✗✗✗ 发现问题，请根据上述信息修复")
        print("\n常见解决方案:")
        print("1. 数据库问题: 运行 python backend/migrations/migrate_all.py")
        print("2. 后端未启动: cd backend && ../backend/venv/bin/python -m uvicorn main:app --reload")
        print("3. 端口被占用: 杀掉占用 8000 端口的进程")
    
    print("=" * 70)
    print()
    
    return 0 if all_passed else 1

if __name__ == "__main__":
    sys.exit(main())
