@echo off
REM 部署脚本选择功能 - Windows
REM 运行此脚本以部署新功能

echo ================================================================================
echo 部署脚本选择功能
echo ================================================================================
echo.

echo [1/4] 检查环境...
if not exist "backend\venv\Scripts\python.exe" (
    echo [错误] 虚拟环境不存在
    pause
    exit /b 1
)

if not exist "backend\database\history.db" (
    echo [错误] 数据库文件不存在
    pause
    exit /b 1
)

echo OK
echo.

echo [2/4] 运行数据库迁移...
backend\venv\Scripts\python.exe backend\migrations\add_script_file_to_tasks.py
if errorlevel 1 (
    echo [错误] 数据库迁移失败
    pause
    exit /b 1
)
echo OK
echo.

echo [3/4] 重启后端服务...
echo 提示：请手动重启后端服务
echo   - 在终端按 Ctrl+C 停止
echo   - 运行: backend\venv\Scripts\python.exe -m uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
echo.
pause
echo.

echo [4/4] 刷新前端...
echo 提示：请在浏览器中刷新页面 (Ctrl+F5 或 Cmd+Shift+R)
echo.

echo ================================================================================
echo 部署完成！
echo ================================================================================
echo.
echo 验证步骤：
echo 1. 打开浏览器访问前端页面
echo 2. 进入"系统管理" → "任务监控"
echo 3. 点击"新建任务"
echo 4. 确认表单中有"脚本文件"选择器
echo 5. 确认任务列表中显示"脚本文件"列
echo.
echo 如有问题，请查看文档：SCRIPT_SELECTION.md
echo.
pause
