#!/usr/bin/env python3
"""检查数据库是否有 script_file 字段"""
import sys
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / "backend"))

from sqlalchemy import create_engine, text, inspect
from backend.config import settings

def check_database():
    """检查数据库状态"""
    print("=" * 60)
    print("检查数据库 script_file 字段")
    print("=" * 60)
    print()
    
    try:
        database_url = f"sqlite:///{settings.database_path}"
        engine = create_engine(database_url)
        
        # 使用 Inspector 检查表结构
        inspector = inspect(engine)
        
        # 检查 slicing_tasks 表
        if 'slicing_tasks' not in inspector.get_table_names():
            print("✗ slicing_tasks 表不存在！")
            return False
        
        print("✓ slicing_tasks 表存在")
        print()
        
        # 获取列信息
        columns = inspector.get_columns('slicing_tasks')
        column_names = [col['name'] for col in columns]
        
        print("表结构：")
        for col in columns:
            col_type = str(col['type'])
            nullable = "NULL" if col['nullable'] else "NOT NULL"
            default = f", DEFAULT={col['default']}" if col.get('default') else ""
            print(f"  - {col['name']:<25} {col_type:<20} {nullable}{default}")
        
        print()
        
        # 检查 script_file 字段
        if 'script_file' in column_names:
            print("✓ script_file 字段存在")
            
            # 检查现有任务的 script_file 值
            with engine.connect() as conn:
                result = conn.execute(text("SELECT id, source_id, script_file, status FROM slicing_tasks"))
                tasks = result.fetchall()
                
                if tasks:
                    print()
                    print("现有任务：")
                    for task in tasks:
                        print(f"  Task ID={task[0]}, Source={task[1]}, Script={task[2]}, Status={task[3]}")
                else:
                    print("  （暂无任务）")
            
            print()
            print("=" * 60)
            print("✓ 数据库检查通过！")
            print("=" * 60)
            return True
        else:
            print("✗ script_file 字段不存在！")
            print()
            print("需要运行迁移脚本：")
            print("  python backend/migrations/add_script_file_to_tasks.py")
            print()
            print("或者运行部署脚本：")
            print("  Windows: deploy_script_selection.bat")
            print("  Linux/macOS: ./deploy_script_selection.sh")
            return False
            
    except Exception as e:
        print(f"✗ 检查失败: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = check_database()
    sys.exit(0 if success else 1)
