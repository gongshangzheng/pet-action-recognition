"""修复 .env 文件编码问题"""
import os
import sys
from pathlib import Path

def detect_encoding(file_path):
    """检测文件编码"""
    encodings = ['utf-8', 'utf-8-sig', 'gbk', 'gb2312', 'ascii']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
                return encoding, content
        except UnicodeDecodeError:
            continue
        except Exception as e:
            print(f"尝试 {encoding} 编码时出错: {e}")
            continue
    
    return None, None

def fix_env_file():
    """检查并修复 .env 文件编码"""
    env_path = Path(__file__).parent / '.env'
    
    if not env_path.exists():
        print(f"❌ .env 文件不存在: {env_path}")
        return False
    
    print("=" * 60)
    print("检查 .env 文件编码")
    print("=" * 60)
    print(f"文件路径: {env_path}")
    
    # 检测当前编码
    detected_encoding, content = detect_encoding(env_path)
    
    if detected_encoding is None:
        print("❌ 无法识别文件编码")
        return False
    
    print(f"\n✅ 检测到编码: {detected_encoding}")
    print(f"文件大小: {os.path.getsize(env_path)} 字节")
    
    # 显示文件内容
    print("\n" + "-" * 60)
    print("当前 .env 文件内容:")
    print("-" * 60)
    for i, line in enumerate(content.split('\n'), 1):
        if line.strip() and not line.strip().startswith('#'):
            # 隐藏敏感信息
            if 'API_KEY' in line or 'PASSWORD' in line or 'SECRET' in line:
                key, _, value = line.partition('=')
                display_value = '***' if value.strip() else ''
                print(f"{i:3d}: {key}={display_value}")
            else:
                print(f"{i:3d}: {line}")
    print("-" * 60)
    
    # 检查是否需要转换
    if detected_encoding.lower() in ['utf-8', 'ascii']:
        print(f"\n✅ 文件编码正确 ({detected_encoding})，无需转换")
        
        # 但检查是否有 UTF-8 BOM
        with open(env_path, 'rb') as f:
            raw = f.read(3)
            if raw == b'\xef\xbb\xbf':
                print("⚠️  检测到 UTF-8 BOM，建议移除")
                response = input("是否移除 BOM？(y/n): ").strip().lower()
                if response == 'y':
                    # 移除 BOM
                    with open(env_path, 'r', encoding='utf-8-sig') as f:
                        content = f.read()
                    with open(env_path, 'w', encoding='utf-8', newline='\n') as f:
                        f.write(content)
                    print("✅ 已移除 BOM 并保存为 UTF-8")
                    return True
        return True
    else:
        print(f"\n⚠️  文件当前编码为 {detected_encoding}，建议转换为 UTF-8")
        response = input("是否转换为 UTF-8？(y/n): ").strip().lower()
        
        if response != 'y':
            print("已取消")
            return False
        
        # 备份原文件
        backup_path = str(env_path) + '.backup'
        with open(env_path, 'rb') as f:
            with open(backup_path, 'wb') as bf:
                bf.write(f.read())
        print(f"✅ 已备份原文件到: {backup_path}")
        
        # 转换为 UTF-8（使用 LF 换行符）
        try:
            with open(env_path, 'w', encoding='utf-8', newline='\n') as f:
                f.write(content)
            print("✅ 已转换为 UTF-8 编码（LF 换行符）")
            
            # 验证转换
            with open(env_path, 'r', encoding='utf-8') as f:
                new_content = f.read()
            
            if new_content == content:
                print("✅ 验证成功：文件内容一致")
                return True
            else:
                print("❌ 验证失败：内容不一致，已恢复备份")
                with open(backup_path, 'rb') as bf:
                    with open(env_path, 'wb') as f:
                        f.write(bf.read())
                return False
                
        except Exception as e:
            print(f"❌ 转换失败: {e}")
            print("正在恢复备份...")
            with open(backup_path, 'rb') as bf:
                with open(env_path, 'wb') as f:
                    f.write(bf.read())
            return False
    
    return True

if __name__ == "__main__":
    try:
        success = fix_env_file()
        print("\n" + "=" * 60)
        if success:
            print("✅ 处理完成")
            print("\n⚠️  重要：必须重启后端服务才能加载新配置！")
            print("   Windows: 关闭后端窗口并重新运行 start_backend.bat")
        else:
            print("❌ 处理失败或已取消")
        print("=" * 60)
        
    except KeyboardInterrupt:
        print("\n\n已取消")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ 发生错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
