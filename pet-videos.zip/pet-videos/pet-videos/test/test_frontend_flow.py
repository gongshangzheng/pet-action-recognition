#!/usr/bin/env python3
"""模拟前端流程测试"""
import requests

BASE_URL = "http://localhost:8002"

print("=" * 60)
print("模拟前端登录和加载源配置流程")
print("=" * 60)
print()

# 1. 登录
print("[1] 尝试登录...")
try:
    response = requests.post(
        f"{BASE_URL}/api/login",
        json={"username": "admin", "password": "petadmin@20260115"},
        timeout=5
    )
    
    if response.status_code == 200:
        data = response.json()
        token = data.get("token")
        print(f"✓ 登录成功，获得 token: {token[:20]}...")
    else:
        print(f"✗ 登录失败: HTTP {response.status_code}")
        print(f"  响应: {response.text}")
        exit(1)
except Exception as e:
    print(f"✗ 登录请求失败: {e}")
    exit(1)

print()

# 2. 获取源配置
print("[2] 获取源配置列表...")
try:
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get(
        f"{BASE_URL}/api/sources/",
        headers=headers,
        timeout=5
    )
    
    if response.status_code == 200:
        sources = response.json()
        print(f"✓ 成功获取 {len(sources)} 个源配置:")
        for source in sources:
            status = "启用" if source["is_active"] else "禁用"
            print(f"  - {source['name']} ({source['alias']}) [{status}]")
    else:
        print(f"✗ 获取源配置失败: HTTP {response.status_code}")
        print(f"  响应: {response.text}")
        exit(1)
except Exception as e:
    print(f"✗ 获取源配置请求失败: {e}")
    exit(1)

print()

# 3. 获取任务列表
print("[3] 获取任务列表...")
try:
    response = requests.get(
        f"{BASE_URL}/api/tasks/",
        headers=headers,
        timeout=5
    )
    
    if response.status_code == 200:
        tasks = response.json()
        print(f"✓ 成功获取 {len(tasks)} 个任务:")
        for task in tasks:
            print(f"  - Source {task['source_id']}: {task['status']} (script: {task.get('script_file', 'N/A')})")
    else:
        print(f"✗ 获取任务失败: HTTP {response.status_code}")
        print(f"  响应: {response.text}")
except Exception as e:
    print(f"⚠ 获取任务请求失败: {e}")

print()

# 4. 获取可用脚本
print("[4] 获取可用脚本列表...")
try:
    response = requests.get(
        f"{BASE_URL}/api/tasks/scripts",
        headers=headers,
        timeout=5
    )
    
    if response.status_code == 200:
        scripts = response.json()
        print(f"✓ 成功获取 {len(scripts)} 个脚本:")
        for script in scripts:
            desc = script.get('description', '无描述')
            print(f"  - {script['filename']}: {desc}")
    else:
        print(f"✗ 获取脚本列表失败: HTTP {response.status_code}")
        print(f"  响应: {response.text}")
except Exception as e:
    print(f"⚠ 获取脚本请求失败: {e}")

print()
print("=" * 60)
print("✓ 所有测试通过！前端应该可以正常工作")
print("=" * 60)
