#!/usr/bin/env python3
"""
测试 OpenCV VideoWriter 在 Windows 上支持的编码器

检查哪些编码器可以直接使用，无需额外配置
"""
import cv2
import numpy as np
import os
import sys
from datetime import datetime

def test_codec(codec_fourcc, codec_name, width=640, height=480, fps=20):
    """
    测试指定的编码器是否可用
    
    Args:
        codec_fourcc: 四字符编码器代码
        codec_name: 编码器名称（用于显示）
        width: 视频宽度
        height: 视频高度
        fps: 帧率
    
    Returns:
        dict: 测试结果
    """
    test_file = f"test_{codec_fourcc}.mp4"
    result = {
        'codec': codec_fourcc,
        'name': codec_name,
        'success': False,
        'can_open': False,
        'can_write': False,
        'file_size': 0,
        'error': None
    }
    
    try:
        # 尝试创建 VideoWriter
        fourcc = cv2.VideoWriter_fourcc(*codec_fourcc)
        writer = cv2.VideoWriter(test_file, fourcc, fps, (width, height))
        
        # 检查是否成功打开
        if not writer.isOpened():
            result['error'] = "VideoWriter 无法打开"
            writer.release()
            return result
        
        result['can_open'] = True
        
        # 尝试写入几帧测试数据
        for i in range(30):  # 写入 30 帧（约 1.5 秒）
            # 创建测试图像（渐变色）
            frame = np.zeros((height, width, 3), dtype=np.uint8)
            frame[:, :] = [i * 8 % 256, (i * 16) % 256, (i * 24) % 256]
            
            # 添加文字
            cv2.putText(frame, f"Frame {i}", (50, height // 2), 
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            
            writer.write(frame)
        
        result['can_write'] = True
        writer.release()
        
        # 检查文件是否生成
        if os.path.exists(test_file):
            result['file_size'] = os.path.getsize(test_file)
            
            if result['file_size'] > 0:
                result['success'] = True
            else:
                result['error'] = "文件大小为 0"
            
            # 清理测试文件
            try:
                os.remove(test_file)
            except:
                pass
        else:
            result['error'] = "文件未生成"
    
    except Exception as e:
        result['error'] = str(e)
    
    return result


def main():
    """主测试函数"""
    print("=" * 80)
    print("OpenCV VideoWriter 编码器测试（Windows）")
    print("=" * 80)
    print(f"\n测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"OpenCV 版本: {cv2.__version__}")
    print(f"平台: {sys.platform}")
    print()
    
    # 定义要测试的编码器列表
    codecs_to_test = [
        ('X264', 'H.264 (x264)'),
        ('H264', 'H.264 (通用)'),
        ('avc1', 'H.264 (OpenH264/avc1)'),
        ('mp4v', 'MPEG-4 Part 2'),
        ('XVID', 'XVID'),
        ('MJPG', 'Motion JPEG'),
        ('DIVX', 'DivX'),
        ('WMV1', 'Windows Media Video 7'),
        ('WMV2', 'Windows Media Video 8'),
    ]
    
    print("=" * 80)
    print("开始测试编码器...")
    print("=" * 80)
    print()
    
    results = []
    
    for fourcc, name in codecs_to_test:
        print(f"测试 {name:30s} [{fourcc:4s}] ... ", end='', flush=True)
        result = test_codec(fourcc, name)
        results.append(result)
        
        if result['success']:
            print(f"✓ 成功 ({result['file_size']} 字节)")
        else:
            error_msg = result['error'] if result['error'] else "未知错误"
            print(f"✗ 失败 ({error_msg})")
    
    # 汇总结果
    print()
    print("=" * 80)
    print("测试结果汇总")
    print("=" * 80)
    print()
    
    success_codecs = [r for r in results if r['success']]
    failed_codecs = [r for r in results if not r['success']]
    
    if success_codecs:
        print(f"✓ 可用的编码器 ({len(success_codecs)} 个):")
        print()
        for r in success_codecs:
            print(f"  • {r['name']:30s} [{r['codec']:4s}]  文件大小: {r['file_size']:,} 字节")
    else:
        print("✗ 没有找到可用的编码器！")
    
    print()
    
    if failed_codecs:
        print(f"✗ 不可用的编码器 ({len(failed_codecs)} 个):")
        print()
        for r in failed_codecs:
            error = r['error'] if r['error'] else '未知原因'
            print(f"  • {r['name']:30s} [{r['codec']:4s}]  原因: {error}")
    
    # 推荐配置
    print()
    print("=" * 80)
    print("推荐配置")
    print("=" * 80)
    print()
    
    if success_codecs:
        # 按文件大小排序（小的压缩率更好）
        sorted_codecs = sorted(success_codecs, key=lambda x: x['file_size'])
        best_codec = sorted_codecs[0]
        
        print(f"推荐使用: {best_codec['name']} [{best_codec['codec']}]")
        print(f"  - 文件大小最小: {best_codec['file_size']:,} 字节")
        print(f"  - 代码示例:")
        print(f"    fourcc = cv2.VideoWriter_fourcc(*'{best_codec['codec']}')")
        print(f"    writer = cv2.VideoWriter('output.mp4', fourcc, 20, (640, 480))")
        
        # 如果有 H.264 编码器
        h264_codecs = [r for r in success_codecs if 'H.264' in r['name']]
        if h264_codecs:
            print()
            print("H.264 编码器:")
            for r in h264_codecs:
                print(f"  ✓ {r['name']} [{r['codec']}]")
    else:
        print("⚠️  警告: 没有找到可用的编码器！")
        print("建议:")
        print("  1. 安装 FFmpeg 并使用管道编码")
        print("  2. 重新安装 opencv-python")
        print("  3. 检查系统编解码器")
    
    print()
    print("=" * 80)
    
    return len(success_codecs) > 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
