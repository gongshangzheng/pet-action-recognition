#!/usr/bin/env python3
"""
重置任务状态，清零失败计数

注意：
- 正常情况下不需要运行此脚本
- 手动启动任务时会自动清零失败计数
- 此脚本仅用于批量重置或特殊场景
"""
import sys
sys.path.insert(0, 'backend')

from database.db import SessionLocal
from models.database import SlicingTask

db = SessionLocal()

try:
    tasks = db.query(SlicingTask).all()
    
    print("=" * 60)
    print("重置任务状态")
    print("=" * 60)
    print()
    
    for task in tasks:
        print(f"任务 {task.source_id}:")
        print(f"  当前状态: {task.status}")
        print(f"  失败计数: {task.consecutive_failures}")
        
        if task.consecutive_failures > 0 or task.status == 'error':
            task.consecutive_failures = 0
            task.status = 'stopped'
            task.error_msg = None
            task.pid = None
            task.last_heartbeat = None
            print(f"  → 已重置为: stopped, 失败计数清零")
        else:
            print(f"  → 无需重置")
        print()
    
    db.commit()
    print("✓ 所有任务已重置，现在可以重新启动任务了。")
    
finally:
    db.close()
