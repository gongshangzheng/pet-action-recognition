"""登录调试脚本 - 用于排查登录问题"""
from config import settings
import sys

print("=" * 60)
print("登录配置调试信息")
print("=" * 60)

# 1. 显示配置值
print(f"\n【配置文件读取】")
print(f"用户名: '{settings.admin_username}'")
print(f"密码: '{settings.admin_password}'")
print(f"JWT密钥: '{settings.jwt_secret}'")

# 2. 显示长度
print(f"\n【字符串长度】")
print(f"用户名长度: {len(settings.admin_username)}")
print(f"密码长度: {len(settings.admin_password)}")

# 3. 显示字节表示（检查隐藏字符）
print(f"\n【字节表示】")
print(f"用户名 bytes: {settings.admin_username.encode('utf-8')}")
print(f"密码 bytes: {settings.admin_password.encode('utf-8')}")

# 4. 显示每个字符的 ASCII/Unicode 值
print(f"\n【用户名字符分析】")
for i, char in enumerate(settings.admin_username):
    print(f"  [{i}] '{char}' (ord={ord(char)})")

print(f"\n【密码字符分析】")
for i, char in enumerate(settings.admin_password):
    print(f"  [{i}] '{char}' (ord={ord(char)})")

# 5. 检查前后空格
print(f"\n【前后空格检查】")
print(f"用户名开头空格: {settings.admin_username != settings.admin_username.lstrip()}")
print(f"用户名末尾空格: {settings.admin_username != settings.admin_username.rstrip()}")
print(f"密码开头空格: {settings.admin_password != settings.admin_password.lstrip()}")
print(f"密码末尾空格: {settings.admin_password != settings.admin_password.rstrip()}")

# 6. 交互式测试
print("\n" + "=" * 60)
print("交互式测试")
print("=" * 60)
print("请输入你在前端登录界面输入的用户名和密码进行对比")
print()

try:
    test_username = input("输入用户名: ")
    test_password = input("输入密码: ")
    
    print(f"\n【对比结果】")
    username_match = test_username == settings.admin_username
    password_match = test_password == settings.admin_password
    
    print(f"用户名匹配: {username_match}")
    if not username_match:
        print(f"  期望: '{settings.admin_username}' (长度={len(settings.admin_username)})")
        print(f"  实际: '{test_username}' (长度={len(test_username)})")
        print(f"  差异字符: ", end="")
        for i in range(max(len(settings.admin_username), len(test_username))):
            expected_char = settings.admin_username[i] if i < len(settings.admin_username) else '(无)'
            actual_char = test_username[i] if i < len(test_username) else '(无)'
            if expected_char != actual_char:
                print(f"位置{i}: 期望'{expected_char}'(ord={ord(expected_char) if expected_char != '(无)' else 'N/A'}) vs 实际'{actual_char}'(ord={ord(actual_char) if actual_char != '(无)' else 'N/A'})", end=" ")
        print()
    
    print(f"密码匹配: {password_match}")
    if not password_match:
        print(f"  期望: '{settings.admin_password}' (长度={len(settings.admin_password)})")
        print(f"  实际: '{test_password}' (长度={len(test_password)})")
        print(f"  差异字符: ", end="")
        for i in range(max(len(settings.admin_password), len(test_password))):
            expected_char = settings.admin_password[i] if i < len(settings.admin_password) else '(无)'
            actual_char = test_password[i] if i < len(test_password) else '(无)'
            if expected_char != actual_char:
                print(f"位置{i}: 期望'{expected_char}'(ord={ord(expected_char) if expected_char != '(无)' else 'N/A'}) vs 实际'{actual_char}'(ord={ord(actual_char) if actual_char != '(无)' else 'N/A'})", end=" ")
        print()
    
    if username_match and password_match:
        print("\n✅ 登录凭据完全匹配！")
    else:
        print("\n❌ 登录凭据不匹配，请检查上面的差异")
        
except KeyboardInterrupt:
    print("\n\n已取消")
    sys.exit(0)

print("\n" + "=" * 60)
