#!/usr/bin/env python3
"""检查 OpenCV 版本和推荐的 OpenH264 版本"""
import cv2
import sys

def get_opencv_build_info():
    """获取 OpenCV 构建信息"""
    return cv2.getBuildInformation()

def recommend_openh264_version(opencv_version):
    """根据 OpenCV 版本推荐 OpenH264 版本"""
    major, minor = map(int, opencv_version.split('.')[:2])
    
    if major == 4:
        if minor <= 7:
            return "2.1.1", "https://github.com/cisco/openh264/releases/download/v2.1.1/openh264-2.1.1-win64.dll.bz2"
        elif minor <= 10:
            return "2.3.1", "https://github.com/cisco/openh264/releases/download/v2.3.1/openh264-2.3.1-win64.dll.bz2"
        else:
            return "2.4.1", "https://github.com/cisco/openh264/releases/download/v2.4.1/openh264-2.4.1-win64.dll.bz2"
    
    # OpenCV 5.x 或更新版本
    return "2.5.1", "https://github.com/cisco/openh264/releases/download/v2.5.1/openh264-2.5.1-win64.dll.bz2"

def main():
    print("=" * 80)
    print("OpenCV 版本检查")
    print("=" * 80)
    
    # OpenCV 版本
    opencv_version = cv2.__version__
    print(f"\n✓ OpenCV 版本: {opencv_version}")
    
    # 推荐的 OpenH264 版本
    openh264_version, download_url = recommend_openh264_version(opencv_version)
    print(f"\n推荐的 OpenH264 版本: {openh264_version}")
    print(f"下载地址: {download_url}")
    
    # 安装位置
    install_path = r"C:\Users\{用户名}\AppData\Local"
    print(f"\n安装位置: {install_path}")
    print(f"文件名: openh264-{openh264_version}-win64.dll")
    
    # 检查构建信息中的 FFMPEG
    build_info = get_opencv_build_info()
    print("\n" + "=" * 80)
    print("FFMPEG 支持检查")
    print("=" * 80)
    
    if "FFMPEG" in build_info:
        ffmpeg_lines = [line for line in build_info.split('\n') if 'FFMPEG' in line or 'ffmpeg' in line]
        for line in ffmpeg_lines[:10]:  # 只显示前10行
            print(line)
    else:
        print("⚠️  未找到 FFMPEG 支持信息")
    
    # 总结
    print("\n" + "=" * 80)
    print("操作步骤")
    print("=" * 80)
    print(f"""
1. 下载 OpenH264 {openh264_version}:
   {download_url}

2. 解压 .bz2 文件（使用 7-Zip 或 WinRAR）

3. 删除旧版本（如果存在）:
   {install_path}\\openh264-*.dll

4. 复制新 DLL 到:
   {install_path}\\openh264-{openh264_version}-win64.dll

5. 重启切片任务
""")

if __name__ == "__main__":
    main()
