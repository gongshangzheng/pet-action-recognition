# Pending状态修复报告

## 问题分析

服务器数据库 `server/history.db` 中发现：
- **9条pending状态记录**：API调用失败后重试1次仍失败
- **1条processing状态记录**：长时间处于processing状态

根本原因：代码中仍有部分逻辑使用旧的 `pending`、`failed` 状态，未完全迁移到NULL状态架构。

## 修复内容

### 1. 数据库修复
将所有 `pending` 和超时的 `processing` 记录重置为 `NULL`：
- pending状态：9条 → 0条
- processing状态：1条 → 0条  
- NULL状态：9957条 → 9967条

**修复后状态分布**：
- NULL: 9,967条（包含待处理任务）
- completed: 141条

### 2. 代码修复

#### 2.1 `backend/services/llm_worker_service.py`
**文件**: `_handle_processing_error` 方法（第526-552行）

**修复前**:
```python
record.llm_status = 'pending'  # 重新排队
```

**修复后**:
```python
record.llm_status = None  # 重新排队（NULL状态）
```

**同时修复**: 超过重试次数时的状态
```python
# 从 'failed' 改为 'completed'
record.llm_status = 'completed'  
```

#### 2.2 `backend/api/llm_queue.py`
**文件**: `retry_record` 端点（第75行）

**修复前**:
```python
record.llm_status = 'pending'
```

**修复后**:
```python
record.llm_status = None  # NULL状态表示待处理
```

**额外改进**: 允许重试 `completed` 状态的记录（带错误信息的完成记录）

#### 2.3 `backend/models/schemas.py`
**文件**: `VideoRecordResponse` schema（第263行）

**修复前**:
```python
llm_status: str = 'pending'
```

**修复后**:
```python
llm_status: Optional[str] = None  # NULL表示待处理
```

#### 2.4 `backend/services/llm_worker_service.py`
**文件**: 调试日志查询（第268行）

**修复前**:
```python
VideoRecord.llm_status == 'pending'
```

**修复后**:
```python
VideoRecord.llm_status.is_(None)  # 查询NULL状态
```

## 验证结果

### 代码验证
✅ 所有Python代码中不再有 `record.llm_status = 'pending'/'failed'/'expired'` 赋值语句

### 数据库验证
```sql
-- 验证修复结果
SELECT llm_status, COUNT(*) FROM video_records GROUP BY llm_status;
```

结果：
```
|9967      -- NULL状态
completed|141
```

## 影响分析

### 修复后的行为
1. **API调用失败时**：
   - 增加retry_count
   - 设置next_retry_at（延迟重试）
   - **状态设为NULL**（而非pending）
   
2. **超过最大重试次数时**：
   - **状态设为completed**（而非failed）
   - 保留error信息
   - 不再尝试处理

3. **手动重试时**：
   - 重置retry_count
   - 清除error
   - **状态设为NULL**（而非pending）

### 兼容性
- ✅ 新代码完全基于NULL状态架构
- ✅ 旧的pending/expired记录已清理
- ✅ Worker只查询NULL状态的记录

## 下一步行动

1. **上传修复后的代码到服务器**
2. **重启后端服务**使新代码生效
3. **监控日志**确认不再产生pending状态

## 重试策略

当前配置（`.env`）：
- `LLM_WORKER_MAX_RETRIES=3`（最多重试3次）
- `LLM_WORKER_RETRY_DELAYS=60,300,900`（延迟60s、5min、15min）

对于已经retry_count=1的记录：
- 将重新进入处理队列
- 可再重试2次
- 如果是永久性错误（如视频文件损坏），将在3次后标记为completed

---

**修复时间**: 2026-01-23  
**修复范围**: 数据库 + 4个代码文件  
**验证状态**: ✅ 通过
