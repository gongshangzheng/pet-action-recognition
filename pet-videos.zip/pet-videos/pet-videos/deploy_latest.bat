@echo off
chcp 65001 >nul
REM 最新版一键部署脚本（Windows 版本）
REM 用途：自动完成备份、迁移、重启的完整流程
REM 适用于：Windows Server 2016+

setlocal enabledelayedexpansion

echo ======================================================================
echo 🚀 Pet-Videos 最新版部署脚本
echo ======================================================================
echo.
echo 本次更新内容：
echo   - 数据库表重命名：video_pet_analysis -^> pet_behaviors
echo   - 新增表：pets, daily_reports
echo   - 扩展 video_records 表（LLM 调用信息）
echo   - 修复异常 FPS 值
echo.

REM 检查是否在正确的目录
if not exist "backend" (
    echo ❌ 错误：请在 pet-videos 项目根目录执行此脚本
    exit /b 1
)

if not exist "frontend" (
    echo ❌ 错误：请在 pet-videos 项目根目录执行此脚本
    exit /b 1
)

REM 询问是否继续
set /p CONFIRM="是否继续部署？(y/n) "
if /i not "%CONFIRM%"=="y" (
    echo 部署已取消
    exit /b 0
)

REM ============================================================
REM 步骤 1: 备份数据库
REM ============================================================
echo.
echo 📝 步骤 1/5: 备份数据库
echo ----------------------------------------------------------------------

set "DB_PATH=backend\database\history.db"
if not exist "%DB_PATH%" (
    echo ⚠️  数据库文件不存在: %DB_PATH%
    echo 这可能是首次部署，跳过备份
    set "BACKUP_PATH="
) else (
    set "TIMESTAMP=%date:~0,4%%date:~5,2%%date:~8,2%_%time:~0,2%%time:~3,2%%time:~6,2%"
    set "TIMESTAMP=!TIMESTAMP: =0!"
    set "BACKUP_PATH=%DB_PATH%.backup.!TIMESTAMP!"
    copy "%DB_PATH%" "!BACKUP_PATH!" >nul
    echo ✅ 备份完成: !BACKUP_PATH!
)

REM ============================================================
REM 步骤 2: 停止服务
REM ============================================================
echo.
echo 📝 步骤 2/5: 停止服务
echo ----------------------------------------------------------------------

if exist "stop_all.bat" (
    call stop_all.bat
    echo ✅ 服务已停止
) else (
    echo ⚠️  stop_all.bat 不存在，手动停止服务
    
    REM 停止 Backend (8002)
    for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":8002" ^| findstr "LISTENING"') do (
        taskkill /F /PID %%a >nul 2>&1
    )
    
    REM 停止 Service (8006)
    for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":8006" ^| findstr "LISTENING"') do (
        taskkill /F /PID %%a >nul 2>&1
    )
    
    REM 停止 Frontend (8173)
    for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":8173" ^| findstr "LISTENING"') do (
        taskkill /F /PID %%a >nul 2>&1
    )
    
    echo ✅ 端口已清理
)

timeout /t 2 /nobreak >nul

REM ============================================================
REM 步骤 3: 执行数据库迁移
REM ============================================================
echo.
echo 📝 步骤 3/5: 执行数据库迁移
echo ----------------------------------------------------------------------

cd backend

if exist "run_server_migration.bat" (
    echo 使用一键迁移脚本...
    call run_server_migration.bat
    if errorlevel 1 (
        echo ❌ 迁移失败
        if not "%BACKUP_PATH%"=="" (
            echo 回滚命令: copy "%BACKUP_PATH%" "%DB_PATH%"
        )
        cd ..
        exit /b 1
    )
) else (
    echo 手动执行迁移脚本...
    
    set "MIGRATIONS[0]=migrate_add_did_to_stream_sources.py"
    set "MIGRATIONS[1]=migrate_unify_video_records.py"
    set "MIGRATIONS[2]=migrate_add_pets_table.py"
    set "MIGRATIONS[3]=migrate_add_weight_to_pets.py"
    set "MIGRATIONS[4]=migrate_add_avatar_color_to_pets.py"
    set "MIGRATIONS[5]=migrate_add_video_pet_analysis_table.py"
    set "MIGRATIONS[6]=migrate_rename_video_pet_analysis_to_pet_behaviors.py"
    set "MIGRATIONS[7]=migrate_add_daily_reports_table.py"
    
    for /L %%i in (0,1,7) do (
        set "SCRIPT=!MIGRATIONS[%%i]!"
        if exist "migrations\!SCRIPT!" (
            echo   执行: !SCRIPT!
            python "migrations\!SCRIPT!"
            if errorlevel 1 (
                echo ❌ 迁移失败: !SCRIPT!
                if not "%BACKUP_PATH%"=="" (
                    echo 回滚命令: copy "%BACKUP_PATH%" "%DB_PATH%"
                )
                cd ..
                exit /b 1
            )
        ) else (
            echo   ⚠️  脚本不存在: !SCRIPT!
        )
    )
)

REM ============================================================
REM 步骤 4: 修复异常 FPS
REM ============================================================
echo.
echo 📝 步骤 4/5: 修复异常 FPS 值
echo ----------------------------------------------------------------------

if exist "migrations\fix_abnormal_fps.py" (
    python migrations\fix_abnormal_fps.py
    if errorlevel 1 (
        echo ⚠️  FPS 修复失败，但不影响主流程
    )
) else (
    echo ⚠️  fix_abnormal_fps.py 不存在，跳过
)

cd ..

REM ============================================================
REM 步骤 5: 启动服务
REM ============================================================
echo.
echo 📝 步骤 5/5: 启动服务
echo ----------------------------------------------------------------------

if exist "start_all.bat" (
    start "" cmd /c start_all.bat
    echo ✅ 服务启动中...
) else (
    echo ⚠️  start_all.bat 不存在，请手动启动服务
)

REM 等待服务启动
echo.
echo 等待服务启动...
timeout /t 5 /nobreak >nul

REM ============================================================
REM 验证部署
REM ============================================================
echo.
echo 📝 验证部署
echo ----------------------------------------------------------------------

REM 检查 Backend
curl -s http://localhost:8002/api/sources/ >nul 2>&1
if errorlevel 1 (
    echo ⚠️  Backend API (8002) 未响应
) else (
    echo ✅ Backend API (8002) 正常
)

REM 检查 Service
curl -s http://localhost:8006/api/sources/ >nul 2>&1
if errorlevel 1 (
    echo ⚠️  Service API (8006) 未响应
) else (
    echo ✅ Service API (8006) 正常
)

REM 检查 Frontend
curl -s http://localhost:8173/ >nul 2>&1
if errorlevel 1 (
    echo ⚠️  Frontend (8173) 未响应
) else (
    echo ✅ Frontend (8173) 正常
)

REM 检查数据库表
echo.
echo 检查数据库表...

REM 检查 pet_behaviors 表
sqlite3 backend\database\history.db ".tables" | findstr "pet_behaviors" >nul 2>&1
if errorlevel 1 (
    echo ❌ pet_behaviors 表不存在
) else (
    echo ✅ pet_behaviors 表已创建
)

REM 检查 pets 表
sqlite3 backend\database\history.db ".tables" | findstr "pets" >nul 2>&1
if errorlevel 1 (
    echo ❌ pets 表不存在
) else (
    echo ✅ pets 表已创建
)

REM 检查 daily_reports 表
sqlite3 backend\database\history.db ".tables" | findstr "daily_reports" >nul 2>&1
if errorlevel 1 (
    echo ❌ daily_reports 表不存在
) else (
    echo ✅ daily_reports 表已创建
)

REM ============================================================
REM 部署总结
REM ============================================================
echo.
echo ======================================================================
echo 📊 部署总结
echo ======================================================================
echo.
echo ✅ 部署完成！
echo.
echo 📝 后续操作：
echo   1. 访问前端: http://localhost:8173
echo   2. 检查视频列表 FPS 是否正常（10-30 范围）
echo   3. 测试宠物管理功能
echo   4. 查看日志: type backend\logs\app.log
echo.

if not "%BACKUP_PATH%"=="" (
    echo 📂 备份文件: %BACKUP_PATH%
    echo.
)

echo ⚠️  如果遇到问题：
echo   - 查看日志: type backend\logs\app.log
if not "%BACKUP_PATH%"=="" (
    echo   - 回滚数据库: copy "%BACKUP_PATH%" "%DB_PATH%"
)
echo   - 重启服务: stop_all.bat ^&^& start_all.bat
echo.
echo ======================================================================

pause
