@echo off
set "ROOT=%~dp0"
cd /d "%ROOT%backend"

echo ===================================================
echo   Starting Backend Service...
echo ===================================================

if not exist "venv\Scripts\activate.bat" (
    echo [ERROR] Virtual environment not found. Please run install.bat first.
    exit /b 1
)

call venv\Scripts\activate.bat
set _NOAHEE_INSTANCEID=5.android-container.licai-licai
python -m uvicorn main:app --host 127.0.0.1 --port 8002 --reload
