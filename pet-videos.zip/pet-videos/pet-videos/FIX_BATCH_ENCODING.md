# Windows批处理文件编码问题修复指南

## 问题现象

运行 `.bat` 文件时出现乱码和错误：

```
'd' 不是内部或外部命令，也不是可运行的程序或批处理文件。
'斤拷锟斤拷锟斤拷朔锟斤拷锟?..' 不是内部或外部命令
[??] ???????????? install.bat
```

## 问题原因

Windows批处理文件（`.bat`）必须使用 **ANSI/GBK** 编码，不能使用UTF-8编码。
如果文件包含中文并且使用UTF-8编码，Windows命令行会显示乱码。

## 已修复的文件

以下核心启动脚本已移除中文，改用英文（不再有编码问题）：

- ✅ `install.bat` - 安装脚本
- ✅ `start_backend.bat` - 启动Backend
- ✅ `start_frontend.bat` - 启动Frontend  
- ✅ `start_service.bat` - 启动Service

## 解决方案

### 方案1：使用更新后的文件（推荐）

```bash
# 拉取最新代码
git pull

# 现在可以直接运行（已无中文）
start_backend.bat
start_frontend.bat
start_service.bat
```

### 方案2：手动修复其他.bat文件（如果遇到问题）

如果其他批处理文件也有编码问题：

1. **用记事本打开**文件
2. **另存为** → 选择 **ANSI** 编码
3. 保存并关闭

### 方案3：禁用命令行快速编辑模式

如果遇到服务"卡住"的问题：

```powershell
# 以管理员权限运行PowerShell，执行：
.\disable_quickedit.ps1
```

或者手动修改注册表：

```cmd
reg add "HKCU\Console" /v QuickEdit /t REG_DWORD /d 0 /f
```

## 验证修复

```cmd
D:\pet-videos> start_backend.bat
===================================================
  Starting Backend Service...
===================================================
[OK] Python found
```

如果看到正常的英文输出（不是乱码），说明已修复成功。

## 替代方案：使用PowerShell

如果不想处理编码问题，可以使用PowerShell脚本（`.ps1`），它默认使用UTF-8：

```powershell
# 启动Backend
.\backend\start.ps1

# 启动Service
.\service\start.ps1
```

## 检查所有.bat文件编码

如果需要批量检查项目中所有批处理文件的编码：

```powershell
# 运行编码检查脚本
.\check_bat_encoding.ps1
```

## 注意事项

1. **避免在.bat文件中使用中文**
   - 使用英文注释和提示信息
   - 如果必须使用中文，确保保存为ANSI编码

2. **Git配置**
   ```bash
   # 避免Git自动转换文件编码
   git config core.autocrlf false
   ```

3. **编辑器设置**
   - VS Code：在文件右下角点击编码 → 选择"通过编码保存" → 选择"GBK"
   - Notepad++：编码 → 转为ANSI编码
   - 记事本：另存为 → 编码选择ANSI

## 常见.bat文件列表

核心文件（已修复）：
- `install.bat`
- `start_backend.bat`
- `start_frontend.bat`
- `start_service.bat`

其他工具脚本：
- `start_all.bat`
- `stop_all.bat`
- `deploy_latest.bat`
- `backend/run_server_migration.bat`
- 等等...

如果这些文件也出现乱码，请按照上述方案2手动修复。

## 最佳实践

**推荐做法：**
- 使用PowerShell脚本（`.ps1`）替代批处理文件
- PowerShell原生支持UTF-8，无编码问题
- 功能更强大，语法更现代

**创建PowerShell启动脚本示例：**

```powershell
# start_backend.ps1
Write-Host "Starting Backend Service..." -ForegroundColor Green
Set-Location backend
& venv\Scripts\Activate.ps1
python -m uvicorn main:app --host 127.0.0.1 --port 8002 --reload
```

运行PowerShell脚本：
```powershell
powershell -ExecutionPolicy Bypass -File .\start_backend.ps1
```
