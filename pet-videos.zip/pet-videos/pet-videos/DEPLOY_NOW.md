# 🚀 服务器部署 - 快速指南

## 服务器执行命令（推荐）

```bash
# Windows
python backend\migrations\migrate_init_all.py

# Linux/macOS
python3 backend/migrations/migrate_init_all.py
```

**说明**：这个脚本会自动检测pets表是否存在，如果不存在就创建最新结构的表。

---

## 或根据情况选择

### 情况1: 全新部署或pets表不存在 ✅

```bash
python3 backend/migrations/migrate_init_all.py
```

### 情况2: 已有旧结构的pets表，需要升级

```bash
python3 backend/migrations/migrate_pets_upgrade.py
```

## 完整流程

```bash
# 1. 拉取代码
git pull

# 2. 执行迁移（根据实际情况选择）

# 如果pets表不存在（全新部署）
python3 backend/migrations/migrate_init_all.py

# 如果pets表已存在（升级现有数据库）
python3 backend/migrations/migrate_pets_upgrade.py

# 3. 重启服务
pkill -f "python.*backend/main.py" && python3 backend/main.py &
pkill -f "python.*service.app" && python3 -m service.app &

# 4. 验证
curl http://localhost:8002/health
```

## 变更内容

✅ pets表添加自增ID主键  
✅ pets表添加avatar_color字段

## 特性

- ✅ 自动备份数据库
- ✅ 幂等性（可重复执行）
- ✅ 保留所有数据
- ✅ 详细进度输出
- ✅ 失败自动提示恢复

## 验证

```bash
# 查看表结构
sqlite3 database/history.db "PRAGMA table_info(pets);" | grep -E "^0\||avatar_color"

# 应该看到：
# 0|id|INTEGER|0||1              ← 自增ID
# 13|avatar_color|VARCHAR(10)... ← 头像背景色
```

## 问题？

查看完整文档：`SERVER_DEPLOYMENT.md`

---

**估计时间**：< 1分钟  
**停服时间**：建议重启（< 10秒）  
**数据风险**：无（自动备份）
