# 添加时间水印遮罩，避免频繁触发画面变动检测; motion_threshold提升至2000，减少异常画面变动造成的检测触发
# 使用 H.264 (avc1) 编码

import cv2
import time
import datetime
import os
import threading
import argparse
import requests
from pathlib import Path
from collections import deque
from ultralytics import YOLO


def log(message):
    """辅助函数：打印带时间戳的日志"""
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{current_time}] {message}")


class VideoStream:
    """
    专门负责读取RTSP流的线程类
    """

    def __init__(self, src):
        self.capture = cv2.VideoCapture(src)
        self.status = self.capture.isOpened()
        self.frame = None
        self.lock = threading.Lock()
        self.stopped = False

        if self.status:
            self.thread = threading.Thread(target=self.update, args=())
            self.thread.daemon = True
            self.thread.start()

    def update(self):
        while not self.stopped:
            if not self.capture.isOpened():
                self.status = False
                break

            # 使用 grab() 快速抓取
            ret = self.capture.grab()
            if not ret:
                self.status = False
                break

            # 仅当需要时解码
            ret, frame = self.capture.retrieve()
            if ret:
                with self.lock:
                    self.frame = frame
            else:
                self.status = False
                break

            time.sleep(0.01)

    def read(self):
        with self.lock:
            return self.status, self.frame

    def get_fps(self):
        fps = int(self.capture.get(cv2.CAP_PROP_FPS))
        if fps == 0 or fps > 100: fps = 25
        return fps

    def stop(self):
        self.stopped = True
        if hasattr(self, 'thread'):
            self.thread.join(timeout=1)
        self.capture.release()


class PetMonitor:
    def __init__(self, model_path, save_dir, buffer_seconds=5, post_event_seconds=15, source_id=None, api_base_url=None,
                 enable_yolo=True):
        self.save_dir = save_dir
        self.source_id = source_id
        self.api_base_url = api_base_url or "http://127.0.0.1:8002/api"
        self.enable_yolo = enable_yolo

        # 输出初始化参数，方便调试
        log(f"初始化参数: source_id={source_id}, api_base_url={self.api_base_url}, enable_yolo={enable_yolo}")

        try:
            if not os.path.exists(save_dir):
                os.makedirs(save_dir)
            log(f"视频存储路径已确认: {self.save_dir}")
        except Exception as e:
            log(f"创建目录失败: {e}")
            return

        if self.enable_yolo:
            log("正在加载 YOLO 模型...")
            self.model = YOLO(model_path)
            self.target_classes = [15, 16]  # 15=cat, 16=dog
            log("YOLO 宠物检测已启用")
        else:
            self.model = None
            self.target_classes = []
            log("YOLO 检测已关闭，将使用运动检测触发录制")

        self.buffer_seconds = buffer_seconds
        self.post_event_seconds = post_event_seconds

        self.is_recording = False
        self.record_start_time = 0
        self.last_detection_time = 0
        self.frame_buffer = deque()
        self.video_writer = None
        self.current_filename = None

    def update_heartbeat(self):
        """通过 API 更新心跳时间"""
        if self.source_id is None:
            log("警告: source_id 为空，无法更新心跳")
            return

        try:
            url = f"{self.api_base_url}/tasks/{self.source_id}/heartbeat"
            # 禁用代理，确保可以访问本地 API
            response = requests.post(url, timeout=5, proxies={'http': None, 'https': None})
            if response.status_code == 200:
                log(f"心跳已更新 (source_id={self.source_id})")
            else:
                log(f"心跳更新失败: HTTP {response.status_code}, URL: {url}")
        except Exception as e:
            log(f"心跳更新失败: {e}, URL: {url}")

    def start_monitoring(self, video_source):
        # 强制TCP传输
        os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = "rtsp_transport;tcp|stimeout;10000000"

        # 【配置参数】
        max_record_seconds = 60
        detect_skip = 4
        motion_threshold = 2000

        while True:
            log(f">>> 正在尝试连接视频流: {video_source}")
            stream = VideoStream(video_source)

            # --- 【修复重连0x0问题的核心逻辑】 ---
            log("等待接收第一帧数据...")
            start_wait_time = time.time()
            is_valid_stream = False
            width, height = 0, 0

            # 循环等待最多 15 秒，直到获取到有效的分辨率
            while time.time() - start_wait_time < 15:
                # 期间也尝试更新下心跳，表示进程还在尝试连接
                self.update_heartbeat()

                if stream.frame is not None:
                    # 直接从图片里读分辨率，这比 get(PROP) 靠谱
                    height, width = stream.frame.shape[:2]
                    if width > 0 and height > 0:
                        is_valid_stream = True
                        break
                time.sleep(0.5)

            if not is_valid_stream:
                log(f"错误: 连接超时或获取分辨率失败 (0x0)，5秒后重试...")
                stream.stop()
                time.sleep(5)
                continue  # 重新开始外层循环
            # ----------------------------------------

            fps = stream.get_fps()
            if fps > 60 or fps < 1: fps = 15

            max_buffer_len = fps * self.buffer_seconds
            log(f"连接成功! FPS: {fps}, 真实分辨率: {width}x{height}")
            log(f"配置: 单文件最大时长 {max_record_seconds}秒, 运动检测已开启, 后摇时间 {self.post_event_seconds}秒")

            frame_counter = 0
            prev_gray = None
            last_heartbeat_time = 0

            try:
                while stream.status:
                    status, frame = stream.read()
                    if not status or frame is None:
                        time.sleep(0.01)
                        continue

                    frame_counter += 1
                    current_time = time.time()

                    # 每 10 秒更新一次心跳
                    if current_time - last_heartbeat_time > 10:
                        self.update_heartbeat()
                        last_heartbeat_time = current_time

                    detected = False

                    # --- 1. 运动检测 ---
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                    gray = cv2.GaussianBlur(gray, (21, 21), 0)
                    # 【新增】绘制遮罩：解决时间水印导致的频繁误触发
                    # 屏蔽【右上角】时间戳，区域：右侧 600像素 x 顶部 150像素
                    cv2.rectangle(gray, (width - 600, 0), (width, 150), (0), -1)

                    is_moving = False
                    if prev_gray is None:
                        # 第一帧只初始化参考帧，不触发运动检测
                        prev_gray = gray
                        # is_moving 保持 False
                    else:
                        frame_delta = cv2.absdiff(prev_gray, gray)
                        thresh = cv2.threshold(frame_delta, 25, 255, cv2.THRESH_BINARY)[1]
                        if cv2.countNonZero(thresh) > motion_threshold:
                            is_moving = True
                        prev_gray = gray

                    # --- 2. YOLO 检测逻辑 ---
                    if self.enable_yolo:
                        # YOLO 检测模式：只有检测到宠物才触发录制
                        should_run_yolo = is_moving or self.is_recording or \
                                          (current_time - self.last_detection_time < self.post_event_seconds)

                        # 如果正在录制，减少跳帧频率(每2帧测一次)，防止漏检
                        current_skip = 2 if self.is_recording else detect_skip

                        if should_run_yolo and (frame_counter % current_skip == 0):
                            # 置信度设为 0.5
                            results = self.model.predict(frame, conf=0.5, classes=self.target_classes, verbose=False,
                                                         imgsz=640)

                            found_target = False
                            for result in results:
                                if len(result.boxes) > 0:
                                    found_target = True
                                    break

                            if found_target:
                                self.last_detection_time = current_time
                    else:
                        # 运动检测模式：检测到画面变动就触发录制
                        if is_moving:
                            self.last_detection_time = current_time

                    # --- 3. 录像逻辑 ---
                    should_record = (current_time - self.last_detection_time < self.post_event_seconds)

                    # 强制切片
                    if self.is_recording and (current_time - self.record_start_time > max_record_seconds):
                        log(f"单文件时长达 {max_record_seconds}s，强制切片...")
                        self.stop_recording()

                    if should_record:
                        if not self.is_recording:
                            self.start_recording(fps, width, height)

                        # 写入帧
                        if self.video_writer:
                            self.video_writer.write(frame)

                    elif self.is_recording:
                        log("事件结束，停止录制。")
                        self.stop_recording()

                    # --- 4. 维护缓存 ---
                    if not self.is_recording:
                        self.frame_buffer.append(frame)
                        if len(self.frame_buffer) > max_buffer_len:
                            self.frame_buffer.popleft()

            except KeyboardInterrupt:
                log("用户手动停止 (Ctrl+C)")
                stream.stop()
                self.stop_recording()
                return

            log("[警告] 视频流中断！")
            stream.stop()
            self.stop_recording()
            log("清理资源，5秒后准备重连...")
            time.sleep(5)

    def start_recording(self, fps, width, height):
        self.is_recording = True
        self.record_start_time = time.time()
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.current_filename = os.path.join(self.save_dir, f"event_{timestamp}.mp4")
        log(f"开始录制: {self.current_filename}")

        # 使用 H.264 (avc1) 编码
        fourcc = cv2.VideoWriter_fourcc(*'avc1')
        self.video_writer = cv2.VideoWriter(self.current_filename, fourcc, fps, (width, height))

        if not self.video_writer.isOpened():
            log("错误: 无法初始化视频编码器")
            self.is_recording = False
            self.video_writer = None
            return

        log("✓ 视频编码器初始化成功 (H.264)")

        # 写入缓存的前几秒
        temp_buffer = list(self.frame_buffer)
        for f in temp_buffer:
            self.video_writer.write(f)

    def stop_recording(self):
        self.is_recording = False
        wall_clock_duration = time.time() - self.record_start_time if hasattr(self, 'record_start_time') else 0
        
        if self.video_writer:
            try:
                self.video_writer.release()
                log(f"视频编码器已释放")
            except Exception as e:
                log(f"释放视频编码器失败: {e}")
            finally:
                self.video_writer = None

            # 录制结束后，记录视频信息到后端
            if hasattr(self, 'current_filename') and self.current_filename:
                # 从视频文件读取实际时长
                actual_duration = self._get_video_duration(self.current_filename)
                if actual_duration is None:
                    actual_duration = int(wall_clock_duration)
                    log(f"⚠️ 无法读取视频实际时长，使用墙上时钟: {actual_duration}s")
                else:
                    log(f"视频实际时长: {actual_duration}s (墙上时钟: {wall_clock_duration:.1f}s)")
                
                self.record_video(self.current_filename, actual_duration)

        self.frame_buffer.clear()
    
    def _get_video_duration(self, video_path):
        """获取视频文件的实际时长（秒）"""
        try:
            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                return None
            
            fps = cap.get(cv2.CAP_PROP_FPS)
            frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            cap.release()
            
            if fps > 0 and frame_count > 0:
                duration = frame_count / fps
                return int(duration)
            return None
        except Exception as e:
            log(f"读取视频时长失败: {e}")
            return None

    def record_video(self, file_path, duration):
        """通过 API 记录视频切片信息"""
        if self.source_id is None:
            return

        try:
            # 获取文件大小
            file_size = os.path.getsize(file_path) if os.path.exists(file_path) else None

            url = f"{self.api_base_url}/videos/record"
            payload = {
                "source_id": self.source_id,
                "file_path": file_path,
                "file_name": os.path.basename(file_path),
                "duration": duration,
                "file_size": file_size,
                "detection_type": "pet" if self.enable_yolo else "motion"
            }

            # 禁用代理，确保可以访问本地 API
            response = requests.post(url, json=payload, timeout=5, proxies={'http': None, 'https': None})
            if response.status_code == 200:
                log(f"视频已记录: {os.path.basename(file_path)}")
            else:
                log(f"视频记录失败: HTTP {response.status_code}")
        except Exception as e:
            log(f"视频记录失败: {e}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Pet Monitor Slicing Script")
    parser.add_argument("--url", type=str, help="RTSP Stream URL")
    parser.add_argument("--path", type=str, help="Storage Directory Path")
    parser.add_argument("--source_id", type=int, help="Stream Source ID")
    parser.add_argument("--api-url", type=str, default="http://127.0.0.1:8002/api", help="Backend API base URL")
    parser.add_argument("--model", type=str, default="yolov13n.pt", help="YOLO model path")
    parser.add_argument("--enable-yolo", type=str, default="true", help="Enable YOLO pet detection (true/false)")

    args = parser.parse_args()

    # 如果提供了命令行参数则优先使用，否则使用默认值（用于开发调试）
    RTSP_URL = args.url if args.url else "rtsp://59.110.63.88:8554/rtp/chfi7hg"
    SAVE_PATH = args.path if args.path else r"D:\video_demo_web"
    ENABLE_YOLO = args.enable_yolo.lower() in ['true', '1', 'yes']

    monitor = PetMonitor(
        model_path=args.model,
        save_dir=SAVE_PATH,
        buffer_seconds=5,
        post_event_seconds=15,
        source_id=args.source_id,
        api_base_url=args.api_url,
        enable_yolo=ENABLE_YOLO
    )

    monitor.start_monitoring(video_source=RTSP_URL)
