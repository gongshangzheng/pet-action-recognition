# 宠物监控脚本 - 工业级 PyAV 流拷贝 + 多进程版
# 解决 2.5K 高分辨率下的卡顿、跳帧、加速及 CPU 占用过高问题
# 核心原理：直接拷贝 H.265 数据包（不重编码），独立进程跑 YOLO

import av
import cv2
import time
import datetime
import os
import argparse
import threading
import requests
import numpy as np
import multiprocessing as mp
from collections import deque
from queue import Queue, Empty
from fractions import Fraction

# 尝试导入 YOLO
try:
    from ultralytics import YOLO
except ImportError:
    YOLO = None


# ==========================================
# 可调参数配置区
# ==========================================
# 运动检测参数
MOTION_THRESHOLD = 4000          # 运动检测阈值（变化像素数）
MOTION_CHECK_INTERVAL = 3.0      # 运动检测间隔（秒）

# 录制参数
PRE_BUFFER_SECONDS = 15          # 前摇缓存时长（秒）
POST_EVENT_SECONDS = 15          # 后摇录制时长（秒）
MOTION_TRIGGER_COOLDOWN = 60     # 运动触发冷却时间（秒），设置为0表示关闭冷却功能

# AI 检测参数
AI_CHECK_INTERVAL = 2.0          # AI 检测间隔（秒）
YOLO_CONFIDENCE = 0.5            # YOLO 检测置信度阈值

# 队列参数
MUX_QUEUE_SIZE = 150             # 录制队列大小
DECODE_QUEUE_SIZE = 30           # 检测队列大小

# 心跳参数
HEARTBEAT_INTERVAL = 60          # 心跳上报间隔（秒）

# 统计日志参数
STATS_LOG_INTERVAL = 30          # 统计日志输出间隔（秒）
MOTION_LOG_INTERVAL = 5          # 运动检测日志间隔（秒）
STATUS_LOG_INTERVAL = 3          # 状态日志间隔（秒，运动时）/ 10秒（静止时）
# ==========================================


def log(message):
    """辅助函数：打印带时间戳和进程号的日志"""
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    pid = os.getpid()
    print(f"[{current_time}] [PID:{pid}] {message}", flush=True)


# ==========================================
# 1. Packet 读取线程
# ==========================================
class PacketReaderThread(threading.Thread):
    """
    独立线程：专注于快速读取RTSP流的packet
    参考OpenCV的VideoStream实现，解决客户端读取慢导致的服务器断连问题
    
    🔑 关键改进：复制packet到两个队列
    - mux_queue: 用于录制/流拷贝（原始packet，不decode）
    - decode_queue: 用于运动检测/AI（可以decode）
    这样彻底隔离，互不影响
    """
    def __init__(self, container, video_stream, stop_event):
        super().__init__()
        self.container = container
        self.video_stream = video_stream
        # 两个独立队列
        self.mux_queue = Queue(maxsize=MUX_QUEUE_SIZE)      # 用于录制
        self.decode_queue = Queue(maxsize=DECODE_QUEUE_SIZE)    # 用于检测（容量小，保持低延迟）
        self.stop_event = stop_event
        self.exception = None
        self.daemon = True
        self.packet_lock = threading.Lock()      # 🔑 保护packet的并发访问
        
    def run(self):
        """线程主循环：持续快速读取packet并分发到两个队列"""
        try:
            for packet in self.container.demux(self.video_stream):
                if self.stop_event.is_set():
                    break
                
                # 🔑 关键：mux队列放原packet，decode队列放字节副本
                # 原packet用于录制（不decode），副本用于检测（可decode）
                
                # 1. 原packet放入mux队列（用于录制）
                try:
                    self.mux_queue.put(packet, timeout=0.1)
                except:
                    pass  # mux队列满，丢弃
                
                # 2. 原packet也放入decode队列（用于检测）
                # 🔑 方案C：两个队列共享原packet，使用锁保护并发访问
                try:
                    # decode队列可以更激进地丢弃，保持低延迟
                    if self.decode_queue.full():
                        try:
                            self.decode_queue.get_nowait()  # 丢弃旧的
                        except:
                            pass
                    
                    # 提取is_keyframe（在放入队列前，避免持锁）
                    is_keyframe = packet.is_keyframe
                    
                    # 放入原packet引用 + is_keyframe
                    self.decode_queue.put((packet, is_keyframe), timeout=0.1)
                except Exception as e:
                    pass
                    
        except Exception as e:
            self.exception = e
            log(f"[读取线程异常] {type(e).__name__}: {e}")
    
    def get_mux_packet(self, timeout=1.0):
        """从mux队列获取packet（用于录制）"""
        try:
            return self.mux_queue.get(timeout=timeout)
        except Empty:
            return None
    
    def get_decode_packet(self, timeout=0.1):
        """从decode队列获取packet（用于检测）"""
        try:
            return self.decode_queue.get(timeout=timeout)
        except Empty:
            return None


# ==========================================
# 2. AI 独立进程逻辑
# ==========================================
def ai_worker(model_path, target_classes, input_q, shared_last_pet_time, stop_event):
    """
    独立进程：负责 YOLO 检测
    """
    try:
        log(f"AI进程启动: PID={os.getpid()}, model_path={model_path}")
        
        if YOLO is None:
            log("AI进程错误: ultralytics 未安装")
            return

        log("AI进程: 正在加载 YOLO 模型...")
        model = YOLO(model_path)
        log("AI进程: YOLO 模型加载完成")
    except Exception as e:
        log(f"AI进程初始化失败: {e}")
        import traceback
        log(f"详细错误:\n{traceback.format_exc()}")
        return

    frame_count = 0
    
    while not stop_event.is_set():
        try:
            # 获取待检测帧（非阻塞）
            try:
                frame = input_q.get(timeout=0.5)
            except Empty:
                continue

            if frame is None: break

            frame_count += 1
            current_time = time.time()

            # 执行检测
            results = model.predict(frame, conf=0.5, classes=target_classes, verbose=False, imgsz=640)
            
            found = False
            detected_objects = []
            for r in results:
                if len(r.boxes) > 0:
                    found = True
                    # 收集检测到的目标信息
                    for box in r.boxes:
                        cls_id = int(box.cls[0])
                        conf = float(box.conf[0])
                        detected_objects.append(f"{model.names[cls_id]}({conf:.2f})")
            
            if found:
                # 只有检测到目标才更新时间戳
                shared_last_pet_time.value = current_time
                objects_str = ", ".join(detected_objects[:5])  # 最多显示5个
                log(f"[YOLO #{frame_count}] ✓ {objects_str}")
            else:
                log(f"[YOLO #{frame_count}] ✗ 无目标")
                
        except Exception as e:
            log(f"AI进程运行异常: {e}")
            time.sleep(1)


# ==========================================
# 3. 监控管理类 (基于 PyAV)
# ==========================================
class PetMonitor:
    def __init__(self, model_path, save_dir, source_id=None, api_base_url=None,
                 buffer_seconds=PRE_BUFFER_SECONDS, 
                 post_event_seconds=POST_EVENT_SECONDS,
                 motion_trigger_cooldown=MOTION_TRIGGER_COOLDOWN,
                 motion_threshold=MOTION_THRESHOLD,
                 ai_check_interval=AI_CHECK_INTERVAL,
                 enable_yolo=True):
        self.model_path = model_path
        self.save_dir = save_dir
        self.source_id = source_id
        self.api_base_url = api_base_url
        self.enable_yolo = enable_yolo
        
        # 录制参数
        self.buffer_seconds = buffer_seconds
        self.post_event_seconds = post_event_seconds
        self.motion_trigger_cooldown = motion_trigger_cooldown
        
        # 检测参数
        self.motion_threshold = motion_threshold
        self.ai_check_interval = ai_check_interval

        # 录制状态
        self.is_recording = False
        self.record_start_time = 0
        self.last_motion_trigger_time = 0  # 🔑 上次运动触发时间（用于冷却计算）
        self.packet_buffer = deque() # 存储原始数据包 (Packets)
        self.output_container = None
        self.output_stream = None
        self.pts_offset = None  # 时间戳偏移量，用于让录制文件从0开始
        self.dts_offset = None
        
        # 多进程共享变量
        self.shared_last_pet_time = mp.Value('d', 0.0)
        self.ai_input_q = mp.Queue(maxsize=1) # 只存最新一帧
        self.stop_event = mp.Event()
        self.ai_proc = None

        if not os.path.exists(save_dir):
            os.makedirs(save_dir)

    def _motion_detection_worker(self, packet_reader, video_stream, start_time):
        """
        独立线程：处理decode队列，进行运动检测
        与主循环（录制）完全隔离，互不影响
        """
        # 🔑 创建独立的decoder（维护完整codec context）
        try:
            decoder = av.CodecContext.create(video_stream.codec_context.name, 'r')
            # 复制codec参数（只复制decoder需要的参数）
            if video_stream.codec_context.extradata:
                decoder.extradata = video_stream.codec_context.extradata
            decoder.width = video_stream.codec_context.width
            decoder.height = video_stream.codec_context.height
            if video_stream.codec_context.pix_fmt:
                decoder.pix_fmt = video_stream.codec_context.pix_fmt
            # 注意：time_base是编码器属性，decoder不需要设置
            decoder.open()
            log("[检测线程] 独立decoder创建成功")
        except Exception as e:
            log(f"[检测线程] 创建decoder失败: {e}")
            return
        
        prev_gray = None
        motion_threshold = self.motion_threshold
        last_ai_decode_time = 0
        ai_interval = self.ai_check_interval
        
        # 统计decode成功率
        decode_success_count = 0
        decode_fail_count = 0
        keyframe_success = 0
        keyframe_fail = 0
        last_stats_log = time.time()
        
        while not self.stop_event.is_set():
            # 从decode队列获取(packet, is_keyframe)
            result = packet_reader.get_decode_packet(timeout=1.0)
            if result is None:
                continue
            
            packet, is_keyframe = result
            
            current_time = time.time()
            
            try:
                # 🔑 方案C：使用锁保护decode操作（与mux操作互斥）
                with packet_reader.packet_lock:
                    if not packet:
                        continue
                    
                    # 使用独立decoder解码原packet（完整context）
                    frames = decoder.decode(packet)
                    
                if not frames:
                    decode_fail_count += 1
                    if is_keyframe:
                        keyframe_fail += 1
                    continue
                
                # decode成功
                decode_success_count += 1
                if is_keyframe:
                    keyframe_success += 1
                
            except ValueError as e:
                # decode失败
                decode_fail_count += 1
                if is_keyframe:
                    keyframe_fail += 1
                if "avcodec_send_packet" not in str(e):
                    log(f"[检测线程异常] {type(e).__name__}: {e}")
                time.sleep(0.01)
                continue
            except Exception as e:
                decode_fail_count += 1
                if is_keyframe:
                    keyframe_fail += 1
                log(f"[检测线程异常] {type(e).__name__}: {e}")
                time.sleep(0.01)
                continue
            
            # 成功decode后的处理
            try:
                
                frame = frames[0]
                img_bgr = frame.to_ndarray(format='bgr24')
                
                gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
                gray = cv2.GaussianBlur(gray, (21, 21), 0)

                if prev_gray is not None and current_time - start_time > 3.0:
                    delta = cv2.absdiff(prev_gray, gray)
                    thresh = cv2.threshold(delta, 25, 255, cv2.THRESH_BINARY)[1]
                    motion_pixels = cv2.countNonZero(thresh)
                    
                    # 调试日志
                    debug_log_time = getattr(self, '_debug_motion_log_time', 0)
                    if current_time - debug_log_time >= MOTION_CHECK_INTERVAL:
                        self._debug_motion_log_time = current_time
                        log(f"[调试-PyAV] 运动像素={motion_pixels}, 阈值={motion_threshold}")
                    
                    # 运动判断
                    is_moving = motion_pixels > motion_threshold
                    
                    if is_moving:
                        last_log_time = getattr(self, '_last_motion_log_time', 0)
                        if current_time - last_log_time >= MOTION_LOG_INTERVAL:
                            self._last_motion_log_time = current_time
                            log(f"检测到运动: 变化像素={motion_pixels}, 阈值={motion_threshold}")
                        
                        # 🔑 YOLO模式：只触发AI检测，不直接触发录制
                        # 非YOLO模式：运动检测直接触发录制
                        if self.enable_yolo:
                            # YOLO模式：由AI检测结果决定是否录制
                            if current_time - last_ai_decode_time > ai_interval:
                                try:
                                    self.ai_input_q.put_nowait(img_bgr)
                                except:
                                    pass
                                last_ai_decode_time = current_time
                        else:
                            # 非YOLO模式：运动检测直接触发录制
                            self.shared_last_pet_time.value = current_time
                    
                    # 状态日志
                    if not hasattr(self, '_last_motion_state'):
                        self._last_motion_state = False
                    if not hasattr(self, '_last_motion_state_log_time'):
                        self._last_motion_state_log_time = 0
                    
                    if is_moving:
                        if current_time - self._last_motion_state_log_time >= STATUS_LOG_INTERVAL:
                            self._last_motion_state_log_time = current_time
                            if not self._last_motion_state:
                                log(f"[状态] 检测到画面运动")
                                self._last_motion_state = True
                    else:
                        if current_time - self._last_motion_state_log_time >= (STATUS_LOG_INTERVAL * 3):
                            self._last_motion_state_log_time = current_time
                            if self._last_motion_state:
                                log(f"[状态] 画面静止")
                                self._last_motion_state = False
                
                prev_gray = gray
                
                # 定期输出decode统计
                if current_time - last_stats_log >= STATS_LOG_INTERVAL:
                    total = decode_success_count + decode_fail_count
                    if total > 0:
                        success_rate = (decode_success_count / total) * 100
                        effective_fps = (decode_success_count / STATS_LOG_INTERVAL)  # 统计间隔内的平均fps
                        
                        # 关键帧统计
                        keyframe_total = keyframe_success + keyframe_fail
                        keyframe_rate = (keyframe_success / keyframe_total * 100) if keyframe_total > 0 else 0
                        
                        log(f"[检测统计] decode成功率: {success_rate:.1f}% (成功:{decode_success_count} 失败:{decode_fail_count}) 有效帧率: {effective_fps:.1f}fps | 关键帧: {keyframe_rate:.1f}% ({keyframe_success}/{keyframe_total})")
                    last_stats_log = current_time
                    # 重置计数
                    decode_success_count = 0
                    decode_fail_count = 0
                    keyframe_success = 0
                    keyframe_fail = 0
                
            except Exception as e:
                log(f"[检测线程异常] {type(e).__name__}: {e}")
                time.sleep(0.1)
        
        # 清理资源
        try:
            decoder.close()
            log("[检测线程] 独立decoder已关闭")
        except:
            pass
    
    def update_heartbeat(self):
        """通过 API 更新心跳时间"""
        if not self.source_id or not self.api_base_url:
            return
        try:
            url = f"{self.api_base_url}/tasks/{self.source_id}/heartbeat"
            response = requests.post(url, timeout=5, proxies={'http': None, 'https': None})
            if response.status_code == 200:
                log(f"心跳已更新 (source_id={self.source_id})")
            else:
                log(f"心跳更新失败: HTTP {response.status_code}")
        except Exception as e:
            log(f"心跳更新失败: {e}")

    def record_video_info(self, file_path, duration):
        if not self.api_base_url or not self.source_id: return
        try:
            file_size = os.path.getsize(file_path)
            file_name = os.path.basename(file_path)
            url = f"{self.api_base_url}/videos/record"
            data = {
                "source_id": self.source_id,
                "file_path": file_path,
                "file_name": file_name,
                "duration": duration,
                "file_size": file_size,
                "detection_type": "pet" if self.enable_yolo else "motion"
            }
            requests.post(url, json=data, timeout=5, proxies={'http': None, 'https': None})
            log(f"视频已记录: {file_name}")
        except Exception as e:
            log(f"记录视频失败: {e}")

    def start_monitoring(self, video_source):
        # 🔑 打印所有参数配置
        log("=" * 60)
        log("监控参数配置:")
        log(f"  [检测] YOLO检测: {'启用' if self.enable_yolo else '禁用'}")
        log(f"  [检测] 运动阈值: {self.motion_threshold} 像素")
        log(f"  [检测] AI检测间隔: {self.ai_check_interval}秒")
        log(f"  [录制] 前摇缓存: {self.buffer_seconds}秒")
        log(f"  [录制] 后摇时长: {self.post_event_seconds}秒")
        log(f"  [运动] 触发冷却: {self.motion_trigger_cooldown}秒（两次运动触发之间的最小间隔）")
        log(f"  [队列] 录制队列: {MUX_QUEUE_SIZE}, 检测队列: {DECODE_QUEUE_SIZE}")
        log(f"  [日志] 统计间隔: {STATS_LOG_INTERVAL}秒")
        log(f"  [存储] 保存目录: {self.save_dir}")
        if self.source_id:
            log(f"  [API] Source ID: {self.source_id}")
            log(f"  [API] 后端地址: {self.api_base_url}")
            log(f"  [API] 心跳间隔: {HEARTBEAT_INTERVAL}秒")
        log("=" * 60)
        
        # 启动 AI 进程
        if self.enable_yolo:
            self.ai_proc = mp.Process(target=ai_worker, 
                                     args=(self.model_path, [15, 16], self.ai_input_q, 
                                           self.shared_last_pet_time, self.stop_event))
            self.ai_proc.daemon = True
            self.ai_proc.start()
            log("主进程: AI 检测进程已启动")

        while not self.stop_event.is_set():
            connection_start_time = None
            packet_reader = None  # 读取线程引用
            
            try:
                log(f">>> 正在尝试连接视频流: {video_source}")
                self.update_heartbeat()
                
                # 简化FFmpeg配置，只保留核心选项（参考OpenCV源码）
                options = {
                    'rtsp_transport': 'tcp',  # OpenCV也只设置了这一个
                    'stimeout': '5000000',    # 5秒连接超时
                }
                input_container = av.open(video_source, options=options)
                video_stream = input_container.streams.video[0]
                
                fps = video_stream.average_rate
                if not fps: fps = 15
                else: fps = float(fps)
                
                connection_start_time = time.time()
                log(f"连接成功! 分辨率: {video_stream.width}x{video_stream.height}, FPS: {fps}")
                
                # 🔑 关键：启动独立的packet读取线程（模仿OpenCV的VideoStream）
                packet_reader = PacketReaderThread(input_container, video_stream, self.stop_event)
                packet_reader.start()
                log("[读取线程] Packet读取线程已启动，双队列架构")
                
                # 🔑 启动独立的运动检测线程（处理decode队列）
                motion_thread = threading.Thread(
                    target=self._motion_detection_worker,
                    args=(packet_reader, video_stream, connection_start_time),
                    daemon=True
                )
                motion_thread.start()
                log("[检测线程] 运动检测线程已启动")
                
                max_buffer_packets = int(fps * self.buffer_seconds)
                last_heartbeat = 0
                last_keyframe_time = 0  # 用于统计 GOP 间隔

                # 🔑 主循环：只处理mux队列（录制流程），运动检测在独立线程
                while not self.stop_event.is_set():
                    # 检查读取线程是否异常退出
                    if not packet_reader.is_alive():
                        if packet_reader.exception:
                            raise packet_reader.exception
                        else:
                            log("[读取线程] 线程已退出")
                            break
                    
                    # 从mux队列获取packet（用于录制，不decode）
                    packet = packet_reader.get_mux_packet(timeout=1.0)
                    if packet is None:
                        continue
                    current_time = time.time()

                    # 🔑 统计关键帧间隔 (GOP)
                    try:
                        is_keyframe_check = packet.is_keyframe
                    except:
                        is_keyframe_check = False
                    
                    if is_keyframe_check:
                        if last_keyframe_time > 0:
                            gop_duration = current_time - last_keyframe_time
                            # 仅在 GOP 发生变化或每隔一段时间打印，避免日志过碎
                            if not hasattr(self, '_last_gop_log_time') or current_time - self._last_gop_log_time > 30:
                                log(f"[流信息] 检测到关键帧, GOP间隔: {gop_duration:.2f}秒")
                                self._last_gop_log_time = current_time
                        last_keyframe_time = current_time
                    
                    # 1. 心跳
                    if current_time - last_heartbeat > HEARTBEAT_INTERVAL:
                        self.update_heartbeat()
                        last_heartbeat = current_time

                    # 2. 先存入buffer或mux（保存原始packet）
                    last_pet_time = self.shared_last_pet_time.value
                    time_since_last_pet = current_time - last_pet_time if last_pet_time > 0 else 999
                    
                    # 🔑 运动触发冷却检查（从上次触发运动开始算）
                    time_since_last_trigger = current_time - self.last_motion_trigger_time if self.last_motion_trigger_time > 0 else 999
                    in_cooldown = time_since_last_trigger < self.motion_trigger_cooldown
                    
                    should_record = (last_pet_time > 0 and time_since_last_pet < self.post_event_seconds)

                    if should_record:
                        if not self.is_recording:
                            # 🔑 检查是否在运动触发冷却期
                            if in_cooldown:
                                cooldown_log_time = getattr(self, '_cooldown_log_time', 0)
                                if current_time - cooldown_log_time >= 10.0:
                                    self._cooldown_log_time = current_time
                                    remaining = self.motion_trigger_cooldown - time_since_last_trigger
                                    log(f"[运动触发冷却] 距上次运动触发 {time_since_last_trigger:.1f}秒，剩余冷却 {remaining:.1f}秒")
                            else:
                                # 🔑 触发新录制，记录触发时间
                                self.last_motion_trigger_time = current_time
                                # 🔑 重置运动时间，确保有完整的后摇时长
                                self.shared_last_pet_time.value = current_time
                                buffer_duration = len(self.packet_buffer) / 15.0
                                log(f"[录制开始] 距上次运动 {time_since_last_pet:.1f}秒 (已重置), 前摇缓存 {buffer_duration:.1f}秒 ({len(self.packet_buffer)}包)")
                                self.start_recording(video_stream)
                        
                        # 🔑 直接mux原始packet，不修改任何属性
                        if packet.dts is not None:
                            if self.pts_offset is None:
                                self.pts_offset = packet.pts if packet.pts is not None else 0
                                self.dts_offset = packet.dts if packet.dts is not None else 0
                                log(f"[时间戳基准] PTS offset={self.pts_offset}, DTS offset={self.dts_offset}")
                            
                            # 🔑 方案C：使用锁保护packet修改和mux操作
                            try:
                                with packet_reader.packet_lock:  # 加锁，与decode互斥
                                    # 🔑 全面检查packet有效性（可能被decode线程破坏）
                                    if packet.stream is None:
                                        # packet已被破坏，跳过
                                        continue
                                    
                                    # 检查packet的关键属性
                                    if packet.dts is None and packet.pts is None:
                                        # 时间戳全部丢失，跳过
                                        continue
                                    
                                    # 保存原始值（这些值可能为None，但不能是被破坏的对象）
                                    try:
                                        orig_pts = packet.pts
                                        orig_dts = packet.dts  
                                        orig_stream = packet.stream
                                    except AttributeError:
                                        # packet对象本身已损坏
                                        continue
                                    
                                    # 临时修改用于mux
                                    if packet.pts is not None:
                                        packet.pts = packet.pts - self.pts_offset
                                    if packet.dts is not None:
                                        packet.dts = packet.dts - self.dts_offset
                                    packet.stream = self.output_stream
                                    
                                    # 再次检查output_stream有效性
                                    if self.output_stream is None:
                                        log(f"[录制错误] output_stream 为 None，停止录制")
                                        self.stop_recording()
                                        break
                                    
                                    self.output_container.mux(packet)
                                    
                                    # 立即恢复
                                    packet.pts = orig_pts
                                    packet.dts = orig_dts
                                    packet.stream = orig_stream
                            except Exception as e:
                                log(f"写入 Packet 失败: {e}")
                        
                        # 定期输出录制状态
                        if not hasattr(self, '_last_recording_status_log'):
                            self._last_recording_status_log = current_time
                        if current_time - self._last_recording_status_log >= 5.0:
                            self._last_recording_status_log = current_time
                            recording_duration = current_time - self.record_start_time
                            remaining_tail = self.post_event_seconds - time_since_last_pet
                            log(f"[录制中] 已录 {recording_duration:.1f}秒, 后摇剩余 {remaining_tail:.1f}秒 (距上次运动 {time_since_last_pet:.1f}秒)")
                    else:
                        if self.is_recording:
                            recording_duration = current_time - self.record_start_time
                            log(f"[录制结束] 总时长 {recording_duration:.1f}秒 (后摇 {self.post_event_seconds}秒已满)")
                            self.stop_recording()

                        # 存入buffer
                        if len(self.packet_buffer) >= max_buffer_packets:
                            # 查找关键帧（可能packet已被破坏）
                            try:
                                keyframe_indices = [i for i, p in enumerate(self.packet_buffer) if p.is_keyframe]
                            except:
                                keyframe_indices = []
                            
                            if len(keyframe_indices) >= 2:
                                num_to_remove = keyframe_indices[1]
                                for _ in range(num_to_remove):
                                    self.packet_buffer.popleft()
                            else:
                                if len(self.packet_buffer) > max_buffer_packets * 1.2:
                                    self.packet_buffer.popleft()
                        
                        self.packet_buffer.append(packet)

                # 清理资源
                if packet_reader and packet_reader.is_alive():
                    self.stop_event.set()
                    packet_reader.join(timeout=2)
                    log("[读取线程] 已停止")
                
                input_container.close()
                log("[连接] 已关闭")

            except Exception as e:
                import traceback
                error_type = type(e).__name__
                error_msg = str(e)
                
                # 计算连接持续时长
                if connection_start_time:
                    duration = time.time() - connection_start_time
                    log(f"[连接断开] {error_type}: {error_msg} (持续时长: {duration:.1f}秒)")
                else:
                    log(f"[连接断开] {error_type}: {error_msg}")
                
                # 记录详细堆栈（仅在非常规断开时）
                if "10054" in error_msg or "Connection reset" in error_msg:
                    log(f"[网络重置] 服务器主动断开连接")
                
                if self.is_recording:
                    self.stop_recording()
                
                # 清理读取线程
                if packet_reader and packet_reader.is_alive():
                    self.stop_event.set()
                    packet_reader.join(timeout=2)
                
                # 重置stop_event以便下次连接
                self.stop_event.clear()
                
                log("清理完成，5秒后重连...")
                self.update_heartbeat()
                time.sleep(5)

    def start_recording(self, input_video_stream):
        self.is_recording = True
        self.record_start_time = time.time()
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.current_path = os.path.join(self.save_dir, f"event_{ts}.mp4")
        
        # 重置时间戳偏移量
        self.pts_offset = None
        self.dts_offset = None

        try:
            self.output_container = av.open(self.current_path, mode='w')
            
            # PyAV 流拷贝的正确 API：add_stream_from_template()
            # 这个方法会自动复制所有参数，并且不会启动编码器
            self.output_stream = self.output_container.add_stream_from_template(input_video_stream)
            
            # 🔑 修正帧率元数据（某些摄像头报告错误的帧率导致FPS显示异常如1000000.0）
            # 从实际packet时间戳计算真实FPS
            source_fps = input_video_stream.average_rate
            calculated_fps = None
            
            # 方法1：从buffer中的packet时间戳计算实际帧率
            if len(self.packet_buffer) >= 10:
                valid_packets = [p for p in list(self.packet_buffer)[-30:] if p.dts is not None]
                if len(valid_packets) >= 10:
                    first_dts = valid_packets[0].dts
                    last_dts = valid_packets[-1].dts
                    time_base = input_video_stream.time_base
                    
                    # 计算时间跨度（秒）
                    duration_seconds = (last_dts - first_dts) * float(time_base)
                    if duration_seconds > 0:
                        calculated_fps = len(valid_packets) / duration_seconds
                        log(f"[录制配置] 从时间戳计算实际FPS: {calculated_fps:.1f} ({len(valid_packets)}帧/{duration_seconds:.2f}秒)")
            
            # 方法2：检查源流的FPS是否合理
            if source_fps and 1 <= float(source_fps) <= 120:
                # 元数据FPS合理
                if calculated_fps and abs(float(source_fps) - calculated_fps) > 5:
                    # 但与实际计算差异较大，使用计算值
                    self.output_stream.rate = Fraction(int(calculated_fps * 1000), 1000)
                    log(f"[录制配置] 元数据FPS({source_fps})与实际差异大，使用计算值: {calculated_fps:.1f}fps")
                else:
                    # 元数据合理且与实际接近，保持不变
                    log(f"[录制配置] 使用源流FPS: {source_fps}")
            else:
                # 元数据FPS异常
                if calculated_fps:
                    # 使用计算的FPS
                    self.output_stream.rate = Fraction(int(calculated_fps * 1000), 1000)
                    log(f"[录制配置] 源流FPS异常({source_fps})，使用计算值: {calculated_fps:.1f}fps")
                else:
                    # 无法计算，使用标准值
                    self.output_stream.rate = Fraction(20, 1)
                    log(f"[录制配置] 源流FPS异常({source_fps})且无法计算，使用默认: 20fps")
            
            # 🔑 H.265关键修复：确保从关键帧开始写入
            # 查找buffer中第一个关键帧的位置
            first_keyframe_idx = -1
            for i, p in enumerate(self.packet_buffer):
                try:
                    if p.is_keyframe and p.dts is not None:
                        first_keyframe_idx = i
                        break
                except:
                    # packet可能已被破坏，跳过
                    continue
            
            # 如果找到关键帧，从关键帧开始；否则使用整个buffer
            packets_to_write = list(self.packet_buffer)
            if first_keyframe_idx > 0:
                packets_to_write = packets_to_write[first_keyframe_idx:]
                log(f"[前摇优化] 跳过前{first_keyframe_idx}个非关键帧包，从关键帧开始")
            
            buffer_duration = len(packets_to_write) / 15.0  # 假设15fps
            log(f"[前摇写入] {len(packets_to_write)} 个包 (约 {buffer_duration:.1f}秒)")
            
            # 需要packet_reader引用来使用锁
            # 这部分packet来自buffer，理论上不会与decode线程并发访问
            # 但为保险起见，在需要时可以考虑加锁
            for p in packets_to_write:
                if p.dts is None:
                    continue
                
                # 记录第一个有效packet的时间戳作为偏移量
                if self.pts_offset is None:
                    self.pts_offset = p.pts if p.pts is not None else 0
                    self.dts_offset = p.dts if p.dts is not None else 0
                    log(f"[时间戳基准] PTS offset={self.pts_offset}, DTS offset={self.dts_offset}, 第一帧是关键帧={p.is_keyframe}")
                
                # 🔑 保存原始状态并mux（buffer中的packets通常已经过了decode队列）
                original_pts = p.pts
                original_dts = p.dts
                original_stream = p.stream
                
                # 重新映射时间戳，让录制文件从0开始
                if p.pts is not None:
                    p.pts -= self.pts_offset
                if p.dts is not None:
                    p.dts -= self.dts_offset
                
                p.stream = self.output_stream
                self.output_container.mux(p)
                
                # 恢复原始状态
                p.pts = original_pts
                p.dts = original_dts
                p.stream = original_stream
            
            self.packet_buffer.clear()
        except Exception as e:
            log(f"初始化录制失败: {e}")
            self.is_recording = False

    def stop_recording(self):
        if self.output_container:
            try:
                self.output_container.close()
                duration = int(time.time() - self.record_start_time)
                
                # 获取文件大小
                file_size_mb = 0
                if os.path.exists(self.current_path):
                    file_size_mb = os.path.getsize(self.current_path) / (1024 * 1024)
                
                log(f"录制已保存: {os.path.basename(self.current_path)}, 时长 {duration}秒, 大小 {file_size_mb:.2f}MB")
                self.record_video_info(self.current_path, duration)
            except Exception as e:
                log(f"关闭录制文件失败: {e}")
        
        self.is_recording = False
        self.output_container = None
        self.output_stream = None


if __name__ == "__main__":
    # 多进程必须在 __main__ 下启动
    mp.set_start_method('spawn', force=True)

    parser = argparse.ArgumentParser(description='宠物监控脚本 (PyAV 流拷贝版)')
    parser.add_argument('--url', type=str)
    parser.add_argument('--path', type=str)
    parser.add_argument('--source_id', type=int)
    parser.add_argument('--api-url', type=str, default='http://127.0.0.1:8002/api')
    parser.add_argument('--model', type=str, default='yolov13n.pt')
    parser.add_argument('--enable-yolo', type=str, default='true')
    args = parser.parse_args()

    ENABLE_YOLO = args.enable_yolo.lower() in ['true', '1', 'yes']

    monitor = PetMonitor(
        model_path=args.model,
        save_dir=args.path,
        source_id=args.source_id,
        api_base_url=args.api_url,
        enable_yolo=ENABLE_YOLO
    )
    monitor.start_monitoring(args.url)
