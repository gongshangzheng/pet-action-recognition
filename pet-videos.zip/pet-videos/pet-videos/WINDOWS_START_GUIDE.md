# Windows 启动指南

## 编码问题已修复

所有核心批处理文件已移除中文，改用英文提示。不再有编码问题。

## 快速启动

### 方式1：使用批处理文件（推荐）

```cmd
# 1. 启动Backend（管理系统后端）
start_backend.bat

# 2. 启动Frontend（管理系统前端）
start_frontend.bat

# 3. 启动Service（App API）
start_service.bat
```

### 方式2：使用PowerShell脚本（无编码问题）

```powershell
# 1. 启动Backend
powershell -ExecutionPolicy Bypass -File .\start_backend.ps1

# 2. 启动Service
powershell -ExecutionPolicy Bypass -File .\start_service.ps1
```

### 方式3：一键启动所有服务

```cmd
start_all.bat
```

## 停止服务

```cmd
stop_all.bat
```

## 端口说明

| 服务 | 端口 | 说明 |
|------|------|------|
| Backend | 8002 | 管理系统后端 |
| Frontend | 5173 | 管理系统前端 |
| Service | 8006 | App API |

## 访问地址

- 管理系统：http://localhost:5173
- Backend API：http://localhost:8002/docs
- Service API：http://localhost:8006/pet/health

## 常见问题

### 1. 提示"乱码"或"不是内部命令"

**原因**：批处理文件编码问题

**解决**：
```bash
# 拉取最新代码（已修复）
git pull
```

### 2. 服务启动后"卡住"不响应

**原因**：Windows命令行"快速编辑模式"

**解决**：
```powershell
# 禁用快速编辑模式
.\disable_quickedit.ps1
```

或手动操作：
1. 右键点击命令行窗口标题栏
2. 属性 → 选项 → 取消勾选"快速编辑模式"

### 3. 端口被占用

**错误提示**：
```
error while attempting to bind on address ('0.0.0.0', 8002): address already in use
```

**解决**：
```cmd
# 查看占用端口的进程
netstat -ano | findstr :8002

# 停止进程（替换PID为实际进程ID）
taskkill /F /PID <PID>

# 或使用停止脚本
stop_all.bat
```

### 4. Python或Node.js未安装

**Backend需要**：Python 3.8+
**Frontend需要**：Node.js 16+

**检查版本**：
```cmd
python --version
node --version
```

**安装依赖**：
```cmd
install.bat
```

## 开发模式启动

### Backend（带热重载）

```cmd
cd backend
call venv\Scripts\activate.bat
python -m uvicorn main:app --host 127.0.0.1 --port 8002 --reload
```

### Service（带热重载）

```cmd
python -m service.app
```

### Frontend（开发服务器）

```cmd
cd frontend
npm run dev
```

## 生产环境部署

参考：`SERVER_DEPLOYMENT.md`

## 日志查看

### Windows命令行

```cmd
# 实时查看日志
type logs\backend.log
type logs\service.log

# 查看最后100行
powershell -Command "Get-Content logs\backend.log -Tail 100"
```

### PowerShell

```powershell
# 实时跟踪日志
Get-Content logs\backend.log -Wait

# 查看最新日志
Get-Content logs\backend.log -Tail 50
```

## 数据库管理

### 检查数据库

```cmd
# 使用Python脚本
python backend\check_pets_database.py

# 或手动检查
sqlite3 database\history.db ".tables"
```

### 数据库迁移

```cmd
# 执行迁移
python backend\migrations\migrate_pets_upgrade.py

# 全新初始化
python backend\migrations\migrate_init_all.py
```

## 文件编码说明

- `.bat` 文件：不包含中文，使用ASCII编码
- `.ps1` 文件：UTF-8编码，支持中文
- `.py` 文件：UTF-8编码
- `.md` 文件：UTF-8编码

## 推荐配置

### Git配置

```bash
# 禁用自动转换行尾符
git config core.autocrlf false

# 设置默认编辑器
git config core.editor "code --wait"
```

### VS Code设置

```json
{
  "files.encoding": "utf8",
  "files.eol": "\n",
  "[bat]": {
    "files.encoding": "gbk"
  }
}
```

## 更多帮助

- Backend API文档：http://localhost:8002/docs
- Service API文档：`service/appdoc/API接口文档.md`
- 数据库修复指南：`SERVER_DATABASE_FIX.md`
- 批处理编码指南：`FIX_BATCH_ENCODING.md`
