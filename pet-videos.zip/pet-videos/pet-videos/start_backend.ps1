# PowerShell script to start Backend service
# UTF-8 encoding, no encoding issues

$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location "$ROOT\backend"

Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "  Starting Backend Service..." -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host ""

# Check virtual environment
if (!(Test-Path "venv\Scripts\Activate.ps1")) {
    Write-Host "[ERROR] Virtual environment not found" -ForegroundColor Red
    Write-Host "Please run: python -m venv venv" -ForegroundColor Yellow
    exit 1
}

# Activate virtual environment
Write-Host "[INFO] Activating virtual environment..." -ForegroundColor Green
& "venv\Scripts\Activate.ps1"

# Check Python
try {
    $pythonVersion = python --version
    Write-Host "[OK] $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Python not found" -ForegroundColor Red
    exit 1
}

# Start service
Write-Host ""
Write-Host "Starting uvicorn server..." -ForegroundColor Green
Write-Host "Backend URL: http://127.0.0.1:8002" -ForegroundColor Yellow
Write-Host "Press Ctrl+C to stop" -ForegroundColor Yellow
Write-Host ""

python -m uvicorn main:app --host 127.0.0.1 --port 8002 --reload
