import React, { useState, useEffect } from 'react';
import { Layout, Tabs, message, Tag, Space, Typography, Button, Divider, Spin, Card } from 'antd';
import {
  VideoCameraOutlined,
  ThunderboltOutlined,
  HistoryOutlined,
  BarChartOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  LogoutOutlined,
  UserOutlined,
  EditOutlined,
  SettingOutlined,
  SyncOutlined,
  SmileOutlined,
  HeartOutlined,
  FileTextOutlined,
} from '@ant-design/icons';
import DirectorySelector from './components/DirectorySelector';
import VideoList from './components/VideoList';
import ParamConfig from './components/ParamConfig';
import PromptInput from './components/PromptInput';
import CostEstimate from './components/CostEstimate';
import ResultDisplay from './components/ResultDisplay';
import History from './components/History';
import SliceStats from './components/SliceStats';
import PromptManagement from './components/PromptManagement';
import SourceManagement from './components/System/SourceManagement';
import TaskManagement from './components/System/TaskManagement';
import PetManagement from './components/PetManagement';
import PetBehaviors from './components/PetBehaviors';
import DailyReports from './components/DailyReports';
import Login from './components/Login';
import { healthCheck, getConfig, getDirectories, getVideos, checkAuth, logout } from './services/api';
import { getPets } from './services/petApi';
import type { VideoInfo, DirectoryInfo, AnalysisResponse } from './types';
import type { Pet } from './types/pet';
import './App.css';

const { Header, Content } = Layout;
const { Title, Text } = Typography;

const App: React.FC = () => {
  // 认证状态
  const [isLoggedIn, setIsLoggedIn] = useState<boolean | null>(null); // null 表示正在检查
  
  // Tab状态
  const [activeTab, setActiveTab] = useState<string>('analyze');
  const [statsRefreshKey, setStatsRefreshKey] = useState(0);
  const [historyRefreshKey, setHistoryRefreshKey] = useState(0);
  const [promptsRefreshKey, setPromptsRefreshKey] = useState(0);
  const [sourcesRefreshKey, setSourcesRefreshKey] = useState(0);
  const [tasksRefreshKey, setTasksRefreshKey] = useState(0);
  const [petsRefreshKey, setPetsRefreshKey] = useState(0);
  
  // 状态管理
  const [backendHealthy, setBackendHealthy] = useState(false);
  const [directories, setDirectories] = useState<DirectoryInfo[]>([]);
  const [selectedAlias, setSelectedAlias] = useState<string | null>(null);
  const [selectedDid, setSelectedDid] = useState<string | null>(null);
  const [videos, setVideos] = useState<VideoInfo[]>([]);
  const [totalVideos, setTotalVideos] = useState(0);
  const [videoPage, setVideoPage] = useState(1);
  const [videoPageSize, setVideoPageSize] = useState(10);
  const [selectedVideo, setSelectedVideo] = useState<VideoInfo | null>(null);
  const [loadingVideos, setLoadingVideos] = useState(false);

  // 参数状态
  const [fps, setFps] = useState(2.0);
  const [maxPixels, setMaxPixels] = useState(640 * 32 * 32);
  const [minPixels, setMinPixels] = useState(4 * 32 * 32);
  const [prompt, setPrompt] = useState('请描述视频中的主要内容和场景');
  const [promptId, setPromptId] = useState<number | null>(null);
  const [promptName, setPromptName] = useState<string | null>(null);
  const [modelName, setModelName] = useState('qwen3-vl-plus');
  const [vlHighResolutionImages, setVlHighResolutionImages] = useState(false);

  // 分析结果
  const [analysisResult, setAnalysisResult] = useState<AnalysisResponse | null>(null);
  
  // 宠物信息
  const [pets, setPets] = useState<Pet[]>([]);

  // 初始化
  useEffect(() => {
    initApp();

    // 监听 401 事件（添加防抖，避免频繁触发）
    let unauthorizedTimeout: number | null = null;
    const handleUnauthorized = () => {
      if (unauthorizedTimeout) {
        clearTimeout(unauthorizedTimeout);
      }
      unauthorizedTimeout = setTimeout(() => {
        console.warn('[Auth] 401 detected, logging out...');
        setIsLoggedIn(false);
        unauthorizedTimeout = null;
      }, 500); // 500ms 防抖
    };
    window.addEventListener('pet-videos-unauthorized', handleUnauthorized);
    
    return () => {
      if (unauthorizedTimeout) {
        clearTimeout(unauthorizedTimeout);
      }
      window.removeEventListener('pet-videos-unauthorized', handleUnauthorized);
    };
  }, []);

  const initApp = async () => {
    const isAuth = await checkAuth();
    setIsLoggedIn(isAuth);
    
    checkHealth();
    
    if (isAuth) {
      loadConfig();
      loadDirectories();
      // 宠物列表会在选择目录后自动加载（通过 useEffect 监听 selectedDid）
    }
  };
  
  // 加载宠物信息
  const loadPets = async (did?: string) => {
    try {
      const petList = await getPets(did);
      setPets(petList);
    } catch (error) {
      console.error('Failed to load pets:', error);
      // 静默失败，不影响其他功能
    }
  };

  // 切换目录或分页时加载视频
  useEffect(() => {
    if (isLoggedIn && selectedAlias) {
      loadVideos(selectedAlias, videoPage, videoPageSize);
    }
  }, [selectedAlias, videoPage, videoPageSize, isLoggedIn]);
  
  // 切换目录时加载对应用户的宠物列表
  useEffect(() => {
    if (isLoggedIn && selectedDid) {
      loadPets(selectedDid);
    }
  }, [selectedDid, isLoggedIn]);
  
  // 宠物列表更新时重新加载
  useEffect(() => {
    if (isLoggedIn && petsRefreshKey > 0) {
      // 刷新时使用当前选中目录的 did
      loadPets(selectedDid || undefined);
    }
  }, [petsRefreshKey, isLoggedIn]);

  const checkHealth = async () => {
    const healthy = await healthCheck();
    setBackendHealthy(healthy);
    if (!healthy) {
      message.error('后端服务未启动，请先启动后端');
    }
  };

  const loadConfig = async () => {
    try {
      await getConfig();
    } catch (error) {
      console.error('加载配置失败', error);
    }
  };

  const loadDirectories = async () => {
    try {
      const dirs = await getDirectories();
      setDirectories(dirs);
      // 自动选择第一个有效目录
      const firstValid = dirs.find((d) => d.exists && d.video_count > 0);
      if (firstValid) {
        setSelectedAlias(firstValid.alias);
        setSelectedDid(firstValid.did || null);
      }
    } catch (error) {
      message.error('加载目录列表失败');
    }
  };

  const handleLoginSuccess = () => {
    setIsLoggedIn(true);
    loadConfig();
    loadDirectories();
  };

  const handleLogout = () => {
    logout();
  };

  const loadVideos = async (directory: string, page: number, pageSize: number) => {
    setLoadingVideos(true);
    try {
      const result = await getVideos(directory, page, pageSize);
      setVideos(result.videos);
      setTotalVideos(result.total);
      // 如果当前页没有数据且不是第一页，自动跳转到第一页
      if (result.videos.length === 0 && page > 1) {
        setVideoPage(1);
      }
      // 从视频列表中获取 did（优先使用视频的 did）
      if (result.videos.length > 0 && result.videos[0].did) {
        const videoDid = result.videos[0].did;
        if (videoDid !== selectedDid) {
          setSelectedDid(videoDid);
        }
      }
      setSelectedVideo(null);
      setAnalysisResult(null);
    } catch (error) {
      message.error('加载视频列表失败');
      setVideos([]);
      setTotalVideos(0);
    } finally {
      setLoadingVideos(false);
    }
  };

  const handleAnalysisComplete = (result: AnalysisResponse) => {
    setAnalysisResult(result);
    message.success('分析完成！');
  };

  const handleDirectorySelect = (alias: string) => {
    setSelectedAlias(alias);
    setVideoPage(1); // 切换目录重置页码
    // 查找对应目录的 did
    const selectedDir = directories.find(d => d.alias === alias);
    setSelectedDid(selectedDir?.did || null);
  };

  const handleTabChange = (key: string) => {
    setActiveTab(key);
    
    // 切换标签页时，根据不同页面执行刷新
    switch (key) {
      case 'analyze':
        // 刷新视频列表（如果已选择目录）
        if (selectedAlias) {
          loadVideos(selectedAlias, videoPage, videoPageSize);
        }
        break;
      case 'stats':
        // 刷新切片统计
        setStatsRefreshKey(prev => prev + 1);
        break;
      case 'history':
        // 刷新调用历史
        setHistoryRefreshKey(prev => prev + 1);
        break;
      case 'prompts':
        // 刷新切片Prompt
        setPromptsRefreshKey(prev => prev + 1);
        break;
      case 'sources':
        // 刷新源管理
        setSourcesRefreshKey(prev => prev + 1);
        break;
      case 'tasks':
        // 刷新任务监控
        setTasksRefreshKey(prev => prev + 1);
        break;
      case 'pets':
        // 刷新宠物列表
        setPetsRefreshKey(prev => prev + 1);
        break;
    }
  };

  if (isLoggedIn === null) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', background: '#f0f2f5' }}>
        <Card>
          <Space direction="vertical" align="center">
            <Spin size="large" />
            <Text>正在检查登录状态...</Text>
          </Space>
        </Card>
      </div>
    );
  }

  if (!isLoggedIn) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  const tabItems = [
    {
      key: 'analyze',
      label: (
        <span>
          <ThunderboltOutlined />
          视频分析
        </span>
      ),
      children: (
        <div className="main-content">
          <div className="left-panel">
            <Space direction="vertical" style={{ width: '100%' }} size="middle">
              <DirectorySelector
                directories={directories}
                selectedAlias={selectedAlias}
                onSelectDirectory={handleDirectorySelect}
              />
              <VideoList
                videos={videos}
                total={totalVideos}
                page={videoPage}
                pageSize={videoPageSize}
                selectedVideo={selectedVideo}
                onSelectVideo={setSelectedVideo}
                onPageChange={(page, pageSize) => {
                  setVideoPage(page);
                  setVideoPageSize(pageSize);
                }}
                loading={loadingVideos}
              />
            </Space>
          </div>
          <div className="right-panel">
            <Space direction="vertical" style={{ width: '100%' }} size="middle">
              {selectedVideo && (
                <div className="selected-video-info">
                  <Text strong>已选择: </Text>
                  <Tag color="blue">{selectedVideo.filename}</Tag>
                </div>
              )}
              <ParamConfig
                fps={fps}
                maxPixels={maxPixels}
                minPixels={minPixels}
                vlHighResolutionImages={vlHighResolutionImages}
                modelName={modelName}
                selectedDid={selectedDid}
                onFpsChange={setFps}
                onMaxPixelsChange={setMaxPixels}
                onMinPixelsChange={setMinPixels}
                onVlHighResolutionImagesChange={setVlHighResolutionImages}
                onModelNameChange={setModelName}
              />
              <PromptInput 
                prompt={prompt} 
                onPromptChange={setPrompt}
                onPromptIdChange={(id, name) => {
                  setPromptId(id);
                  setPromptName(name || null);
                }}
                pets={pets}
              />
              <CostEstimate
                selectedVideo={selectedVideo}
                fps={fps}
                maxPixels={maxPixels}
                minPixels={minPixels}
                prompt={prompt}
                promptId={promptId || undefined}
                promptName={promptName || undefined}
                modelName={modelName}
                vlHighResolutionImages={vlHighResolutionImages}
                onAnalysisComplete={handleAnalysisComplete}
              />
              {analysisResult && <ResultDisplay result={analysisResult} />}
            </Space>
          </div>
        </div>
      ),
    },
    {
      key: 'stats',
      label: (
        <span>
          <BarChartOutlined />
          切片统计
        </span>
      ),
      children: (
        <div style={{ padding: '24px' }}>
          <SliceStats key={statsRefreshKey} />
        </div>
      ),
    },
    {
      key: 'history',
      label: (
        <span>
          <HistoryOutlined />
          调用记录
        </span>
      ),
      children: (
        <div style={{ padding: '24px' }}>
          <History key={historyRefreshKey} />
        </div>
      ),
    },
    {
      key: 'prompts',
      label: (
        <span>
          <EditOutlined />
          切片Prompt
        </span>
      ),
      children: (
        <div style={{ padding: '24px' }}>
          <PromptManagement key={promptsRefreshKey} />
        </div>
      ),
    },
    {
      key: 'sources',
      label: (
        <span>
          <SettingOutlined />
          源管理
        </span>
      ),
      children: (
        <div style={{ padding: '24px' }}>
          <SourceManagement key={sourcesRefreshKey} />
        </div>
      ),
    },
    {
      key: 'tasks',
      label: (
        <span>
          <SyncOutlined />
          切片任务
        </span>
      ),
      children: (
        <div style={{ padding: '24px' }}>
          <TaskManagement key={tasksRefreshKey} />
        </div>
      ),
    },
    {
      key: 'pets',
      label: (
        <span>
          <SmileOutlined />
          宠物列表
        </span>
      ),
      children: (
        <div style={{ padding: '24px' }}>
          <PetManagement key={petsRefreshKey} />
        </div>
      ),
    },
    {
      key: 'behaviors',
      label: (
        <span>
          <HeartOutlined />
          宠物行为
        </span>
      ),
      children: (
        <PetBehaviors />
      ),
    },
    {
      key: 'daily-reports',
      label: (
        <span>
          <FileTextOutlined />
          宠物日报
        </span>
      ),
      children: (
        <DailyReports />
      ),
    },
  ];

  return (
    <Layout className="app-layout">
      <Header className="app-header">
        <div className="header-content">
          <Space>
            <VideoCameraOutlined style={{ fontSize: 32, color: '#fff' }} />
            <Title level={3} style={{ margin: 0, color: '#fff' }}>
              Pet Videos Analysis
            </Title>
          </Space>
          <Space>
            <Text style={{ color: '#fff' }}>后端状态:</Text>
            {backendHealthy ? (
              <Tag icon={<CheckCircleOutlined />} color="success">
                正常
              </Tag>
            ) : (
              <Tag icon={<CloseCircleOutlined />} color="error">
                离线
              </Tag>
            )}
            <Divider type="vertical" style={{ background: 'rgba(255,255,255,0.3)' }} />
            <Text style={{ color: '#fff' }}>
              <UserOutlined /> {localStorage.getItem('pet_videos_user') || '管理员'}
            </Text>
            <Button 
              type="link" 
              icon={<LogoutOutlined />} 
              onClick={handleLogout}
              style={{ color: '#fff', padding: 0 }}
            >
              退出
            </Button>
          </Space>
        </div>
      </Header>
      <Content className="app-content">
        <Tabs
          activeKey={activeTab}
          onChange={handleTabChange}
          items={tabItems}
          size="large"
          style={{ padding: '0 24px' }}
        />
      </Content>
    </Layout>
  );
};

export default App;
