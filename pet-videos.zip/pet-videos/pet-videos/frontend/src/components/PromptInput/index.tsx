/**
 * 提示词选择器组件
 */
import React, { useState, useEffect } from 'react';
import { Card, Select, Space, Tag, message, Button, Alert } from 'antd';
import { MessageOutlined, ReloadOutlined, InfoCircleOutlined } from '@ant-design/icons';
import type { Prompt } from '../../types/prompt';
import type { Pet } from '../../types/pet';
import { getPrompts, getDefaultPrompt } from '../../services/promptApi';
import { replacePromptVariables, detectPromptVariables } from '../../utils/promptUtils';
import type { VariableContext } from '../../utils/variableConfig';

interface PromptInputProps {
  prompt: string;
  onPromptChange: (value: string) => void;
  onPromptIdChange?: (promptId: number | null, promptName?: string) => void;
  pets?: Pet[];  // 新增：宠物信息列表
}

const PromptInput: React.FC<PromptInputProps> = ({ 
  onPromptChange,
  onPromptIdChange,
  pets = []  // 默认空数组
}) => {
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [selectedPromptId, setSelectedPromptId] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [originalPrompt, setOriginalPrompt] = useState<string>('');  // 原始提示词（模板）

  // 加载提示词列表
  const loadPrompts = async () => {
    setLoading(true);
    try {
      const data = await getPrompts(true); // 只加载启用的提示词
      setPrompts(data.prompts);
      
      // 如果没有选中的提示词，优先使用localStorage记录的用户最后使用的提示词
      if (!selectedPromptId && data.prompts.length > 0) {
        let selectedPrompt: Prompt | null = null;
        
        // 1. 尝试从localStorage获取用户最后使用的提示词
        const lastUsedPromptId = localStorage.getItem('pet_videos_last_prompt_id');
        if (lastUsedPromptId) {
          const lastUsedId = parseInt(lastUsedPromptId, 10);
          selectedPrompt = data.prompts.find(p => p.id === lastUsedId) || null;
        }
        
        // 2. 如果没有找到，使用第一个可用的提示词
        if (!selectedPrompt) {
          selectedPrompt = data.prompts[0];
        }
        
        // 设置选中的提示词
        setSelectedPromptId(selectedPrompt.id);
        setOriginalPrompt(selectedPrompt.content);
        
        // 替换变量后再传递
        const context: VariableContext = {
          pets: pets,
          userId: undefined,
          userName: undefined,
        };
        const replacedPrompt = replacePromptVariables(selectedPrompt.content, context);
        onPromptChange(replacedPrompt);
        onPromptIdChange?.(selectedPrompt.id, selectedPrompt.name);
      }
    } catch (error: any) {
      message.error('加载提示词失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPrompts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // 只在组件挂载时加载一次，避免循环依赖

  // 切换提示词
  const handlePromptChange = (promptId: number) => {
    const selectedPrompt = prompts.find(p => p.id === promptId);
    if (selectedPrompt) {
      setSelectedPromptId(promptId);
      setOriginalPrompt(selectedPrompt.content);  // 保存原始模板
      
      // 保存用户的选择到localStorage
      localStorage.setItem('pet_videos_last_prompt_id', promptId.toString());
      
      // 替换变量后传递给父组件
      const context: VariableContext = {
        pets: pets,
        userId: undefined, // TODO: 从认证信息获取
        userName: undefined,
      };
      const replacedPrompt = replacePromptVariables(selectedPrompt.content, context);
      onPromptChange(replacedPrompt);
      onPromptIdChange?.(promptId, selectedPrompt.name);
    }
  };

  // 当宠物信息变化时，重新替换变量
  useEffect(() => {
    if (originalPrompt) {
      const context: VariableContext = {
        pets: pets,
        userId: undefined,
        userName: undefined,
      };
      const replacedPrompt = replacePromptVariables(originalPrompt, context);
      onPromptChange(replacedPrompt);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pets, originalPrompt]); // 添加 originalPrompt 依赖，确保提示词加载后也会触发替换

  // 获取当前选中的提示词对象
  const currentPrompt = prompts.find(p => p.id === selectedPromptId);
  
  // 检测模板中的变量
  const variables = currentPrompt ? detectPromptVariables(currentPrompt.content) : [];
  
  // 替换后的提示词（用于显示）
  const context: VariableContext = {
    pets: pets,
    userId: undefined,
    userName: undefined,
  };
  const displayPrompt = currentPrompt 
    ? replacePromptVariables(currentPrompt.content, context)
    : '';

  return (
    <Card 
      title={
        <Space>
          <MessageOutlined />
          <span>提示词</span>
        </Space>
      }
      size="small"
      extra={
        <Button
          type="link"
          size="small"
          icon={<ReloadOutlined />}
          onClick={loadPrompts}
        >
          刷新
        </Button>
      }
    >
      <Space direction="vertical" style={{ width: '100%' }} size="middle">
        <div>
          <div style={{ marginBottom: 8 }}>
            <Space>
              <span>选择版本：</span>
              {currentPrompt?.is_default && (
                <Tag color="gold">自动</Tag>
              )}
            </Space>
          </div>
          <Select
            value={selectedPromptId}
            onChange={handlePromptChange}
            style={{ width: '100%' }}
            loading={loading}
            placeholder="请选择提示词版本"
            disabled={loading || prompts.length === 0}
            options={prompts.map(p => ({
              value: p.id,
              label: (
                <Space>
                  <span>{p.name}</span>
                  {p.is_default && <Tag color="gold" style={{ fontSize: '12px' }}>自动</Tag>}
                  {p.description && (
                    <span style={{ color: '#999', fontSize: '12px' }}>- {p.description}</span>
                  )}
                </Space>
              )
            }))}
          />
        </div>

        {currentPrompt && (
          <div>
            {/* 变量提示 */}
            {variables.length > 0 && (
              <Alert
                message={
                  <Space>
                    <InfoCircleOutlined />
                    <span>
                      检测到变量：
                      {variables.map(v => (
                        <Tag key={v} color="blue" style={{ marginLeft: 4 }}>
                          {`{{${v}}}`}
                        </Tag>
                      ))}
                    </span>
                  </Space>
                }
                type="info"
                style={{ marginBottom: 12, fontSize: '12px' }}
              />
            )}
            
            <div style={{ marginBottom: 8, color: '#666', fontSize: '12px' }}>
              完整提示词（变量已替换）：
            </div>
            <div style={{
              padding: '8px 12px',
              background: '#f5f5f5',
              border: '1px solid #d9d9d9',
              borderRadius: '4px',
              fontSize: '13px',
              lineHeight: '1.6',
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word',
              maxHeight: '400px',
              overflowY: 'auto'
            }}>
              {displayPrompt}
            </div>
          </div>
        )}
      </Space>
    </Card>
  );
};

export default PromptInput;
