import React, { useEffect, useState } from 'react';
import { Card, Button, Space, Statistic, Row, Col, Divider, Tag, Spin } from 'antd';
import { ThunderboltOutlined, SendOutlined, InfoCircleOutlined } from '@ant-design/icons';
import { estimateCost, analyzeVideo } from '../../services/api';
import type { VideoInfo, EstimateResponse, AnalysisResponse } from '../../types';

interface CostEstimateProps {
  selectedVideo: VideoInfo | null;
  fps: number;
  maxPixels: number;
  minPixels: number;
  prompt: string;
  promptId?: number;
  promptName?: string;
  modelName: string;
  vlHighResolutionImages: boolean;
  onAnalysisComplete?: (result: AnalysisResponse) => void;
}

const CostEstimate: React.FC<CostEstimateProps> = ({
  selectedVideo,
  fps,
  maxPixels,
  minPixels,
  prompt,
  promptId,
  promptName,
  modelName,
  vlHighResolutionImages,
  onAnalysisComplete,
}) => {
  const [estimate, setEstimate] = useState<EstimateResponse | null>(null);
  const [estimating, setEstimating] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [detailExpanded, setDetailExpanded] = useState(false);

  // 自动预估
  useEffect(() => {
    if (selectedVideo) {
      handleEstimate();
    }
  }, [selectedVideo, fps, maxPixels, minPixels, prompt, vlHighResolutionImages]);

  const handleEstimate = async () => {
    if (!selectedVideo) return;

    setEstimating(true);
    try {
      const result = await estimateCost({
        video_path: selectedVideo.path,
        fps,
        max_pixels: maxPixels,
        min_pixels: minPixels,
        prompt,
        vl_high_resolution_images: vlHighResolutionImages,
      });
      setEstimate(result);
    } catch (error) {
      console.error('预估失败:', error);
    } finally {
      setEstimating(false);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedVideo || !prompt.trim()) {
      return;
    }

    setAnalyzing(true);
    try {
      const result = await analyzeVideo({
        video_path: selectedVideo.path,
        prompt,
        prompt_id: promptId,
        prompt_name: promptName,
        model_name: modelName,
        fps,
        max_pixels: maxPixels,
        min_pixels: minPixels,
        vl_high_resolution_images: vlHighResolutionImages,
      });
      onAnalysisComplete?.(result);
    } catch (error: any) {
      console.error('分析失败:', error);
      alert('分析失败: ' + (error.response?.data?.detail || error.message));
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <Card
      title={
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Space>
            <ThunderboltOutlined />
            <span>费用预估</span>
            {estimate && !estimating && (
              <Tag color="green" style={{ fontSize: 14, fontWeight: 'bold', margin: 0 }}>
                ¥{estimate.estimated_cost.toFixed(6)}
              </Tag>
            )}
          </Space>
          {estimate && !estimating && (
            <Button
              type="link"
              size="small"
              icon={<InfoCircleOutlined />}
              onClick={() => setDetailExpanded(!detailExpanded)}
              style={{ padding: 0 }}
            >
              {detailExpanded ? '收起详情' : '查看详情'}
            </Button>
          )}
        </div>
      }
      size="small"
    >
      {!selectedVideo ? (
        <div style={{ 
          textAlign: 'center', 
          padding: '8px 20px',
          background: '#fafafa',
          borderRadius: '4px',
          border: '1px dashed #d9d9d9',
          height: '40px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '8px'
        }}>
          <span style={{ fontSize: '16px' }}>📹</span>
          <span style={{ fontSize: '14px', color: '#666' }}>
            请先在左侧选择一个视频文件
          </span>
        </div>
      ) : estimating ? (
        <Spin tip="预估中..." />
      ) : estimate ? (
        <>
          {detailExpanded && (
            <>
              <Row gutter={[16, 16]}>
                <Col span={8}>
                  <Statistic
                    title="抽取帧数"
                    value={estimate.frame_count}
                    suffix="帧"
                    valueStyle={{ fontSize: 18 }}
                  />
                </Col>
                <Col span={8}>
                  <Statistic
                    title="视频Token"
                    value={estimate.video_tokens}
                    valueStyle={{ fontSize: 18 }}
                  />
                </Col>
                <Col span={8}>
                  <Statistic
                    title="提示词Token"
                    value={estimate.prompt_tokens}
                    valueStyle={{ fontSize: 18 }}
                  />
                </Col>
              </Row>

              <Divider style={{ margin: '12px 0' }} />

              <Row gutter={[16, 16]}>
                <Col span={12}>
                  <Statistic
                    title="预估输入Token"
                    value={estimate.total_input_tokens}
                    valueStyle={{ color: '#1890ff', fontSize: 18 }}
                  />
                </Col>
                <Col span={12}>
                  <Statistic
                    title="预估输出Token"
                    value={estimate.estimated_output_tokens}
                    valueStyle={{ color: '#52c41a', fontSize: 18 }}
                  />
                </Col>
              </Row>

              <Divider style={{ margin: '12px 0' }} />

              <div style={{ fontSize: 12, color: '#888', marginBottom: 12 }}>
                <div>输入费用: ¥{estimate.breakdown.input_cost.toFixed(6)}</div>
                <div>输出费用: ¥{estimate.breakdown.output_cost.toFixed(6)}</div>
              </div>
            </>
          )}

          <Button
            type="primary"
            icon={<SendOutlined />}
            loading={analyzing}
            disabled={!prompt.trim()}
            onClick={handleAnalyze}
            block
            size="large"
          >
            {analyzing ? '分析中...' : '发送分析'}
          </Button>
        </>
      ) : null}
    </Card>
  );
};

export default CostEstimate;
