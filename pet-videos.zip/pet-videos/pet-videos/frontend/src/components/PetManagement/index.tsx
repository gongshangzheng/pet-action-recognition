import React, { useState, useEffect } from 'react';
import { Table, Card, Input, InputNumber, message, Space, Tag, Button, Modal, Form, Select, DatePicker, Upload } from 'antd';
import { SearchOutlined, PlusOutlined, EditOutlined, DeleteOutlined, ReloadOutlined } from '@ant-design/icons';
import { getPets, createPet, updatePet, deletePet } from '../../services/petApi';
import type { Pet } from '../../types/pet';
import type { ColumnsType } from 'antd/es/table';
import dayjs from 'dayjs';

const { TextArea } = Input;

const PetManagement: React.FC = () => {
  const [pets, setPets] = useState<Pet[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchDid, setSearchDid] = useState('');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingPet, setEditingPet] = useState<Pet | null>(null);
  const [form] = Form.useForm();

  useEffect(() => {
    loadPets();
  }, []);

  const loadPets = async (did?: string) => {
    setLoading(true);
    try {
      const data = await getPets(did || searchDid);
      setPets(data);
    } catch (error) {
      message.error('加载宠物列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    loadPets(searchDid);
  };

  const handleAdd = () => {
    setEditingPet(null);
    form.resetFields();
    setIsModalVisible(true);
  };

  const handleEdit = (record: Pet) => {
    setEditingPet(record);
    form.setFieldsValue({
      ...record,
      birth_date: record.birth_date ? dayjs(record.birth_date) : undefined,
    });
    setIsModalVisible(true);
  };

  const handleDelete = (record: Pet) => {
    Modal.confirm({
      title: '确认删除',
      content: `确定要删除宠物 "${record.pet_name}" 吗？`,
      onOk: async () => {
        try {
          await deletePet(record.did, record.pet_name);
          message.success('删除成功');
          loadPets();
        } catch (error) {
          message.error('删除失败');
        }
      },
    });
  };

  const handleModalOk = async () => {
    try {
      const values = await form.validateFields();
      const petData = {
        ...values,
        birth_date: values.birth_date ? values.birth_date.format('YYYY-MM-DD') : undefined,
      };

      if (editingPet) {
        await updatePet(editingPet.did, editingPet.pet_name, petData);
        message.success('更新成功');
      } else {
        await createPet(petData);
        message.success('添加成功');
      }
      
      setIsModalVisible(false);
      loadPets();
    } catch (error: any) {
      if (error.errorFields) {
        message.error('请填写必填字段');
      } else {
        message.error(editingPet ? '更新失败' : '添加失败');
      }
    }
  };

  const columns: ColumnsType<Pet> = [
    {
      title: 'DID',
      dataIndex: 'did',
      key: 'did',
      width: 150,
    },
    {
      title: '宠物名称',
      dataIndex: 'pet_name',
      key: 'pet_name',
      width: 120,
    },
    {
      title: '类型',
      dataIndex: 'pet_type',
      key: 'pet_type',
      width: 80,
      render: (type: string) => type || '-',
    },
    {
      title: '品种',
      dataIndex: 'breed',
      key: 'breed',
      width: 120,
      render: (breed: string) => breed || '-',
    },
    {
      title: '性别',
      dataIndex: 'gender',
      key: 'gender',
      width: 60,
      render: (gender: string) => gender || '-',
    },
    {
      title: '出生日期',
      dataIndex: 'birth_date',
      key: 'birth_date',
      width: 120,
      render: (date: string) => date || '-',
    },
    {
      title: '体重',
      dataIndex: 'weight',
      key: 'weight',
      width: 100,
      render: (weight: number) => weight ? `${weight} kg` : '-',
    },
    {
      title: '颜色',
      dataIndex: 'color',
      key: 'color',
      width: 100,
      render: (color: string) => color || '-',
    },
    {
      title: '描述',
      dataIndex: 'description',
      key: 'description',
      ellipsis: true,
      render: (desc: string) => desc || '-',
    },
    {
      title: '创建时间',
      dataIndex: 'created_at',
      key: 'created_at',
      width: 180,
      render: (time: string) => dayjs(time).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: '操作',
      key: 'action',
      width: 150,
      fixed: 'right' as const,
      render: (_: any, record: Pet) => (
        <Space size="small">
          <Button
            type="link"
            size="small"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
          >
            编辑
          </Button>
          <Button
            type="link"
            size="small"
            danger
            icon={<DeleteOutlined />}
            onClick={() => handleDelete(record)}
          >
            删除
          </Button>
        </Space>
      ),
    },
  ];

  return (
    <Card
      title="宠物列表"
      extra={
        <Space>
          <Input
            placeholder="输入DID搜索"
            value={searchDid}
            onChange={(e) => setSearchDid(e.target.value)}
            onPressEnter={handleSearch}
            style={{ width: 200 }}
            prefix={<SearchOutlined />}
          />
          <Button onClick={handleSearch} loading={loading}>
            搜索
          </Button>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={handleAdd}
          >
            添加宠物
          </Button>
          <Button
            icon={<ReloadOutlined />}
            onClick={() => loadPets()}
            loading={loading}
          >
            刷新
          </Button>
        </Space>
      }
    >
      <Table
        columns={columns}
        dataSource={pets}
        rowKey={(record) => `${record.did}_${record.pet_name}`}
        loading={loading}
        pagination={{
          showSizeChanger: true,
          showTotal: (total) => `共 ${total} 条记录`,
        }}
        scroll={{ x: 1500 }}
      />

      <Modal
        title={editingPet ? '编辑宠物' : '添加宠物'}
        open={isModalVisible}
        onOk={handleModalOk}
        onCancel={() => setIsModalVisible(false)}
        width={600}
        okText="确定"
        cancelText="取消"
      >
        <Form
          form={form}
          layout="vertical"
          autoComplete="off"
        >
          <Form.Item
            name="did"
            label="用户ID (DID)"
            rules={[{ required: true, message: '请输入用户ID' }]}
          >
            <Input placeholder="请输入用户ID" disabled={!!editingPet} />
          </Form.Item>

          <Form.Item
            name="pet_name"
            label="宠物名称"
            rules={[{ required: true, message: '请输入宠物名称' }]}
          >
            <Input placeholder="请输入宠物名称" disabled={!!editingPet} />
          </Form.Item>

          <Form.Item
            name="pet_type"
            label="宠物类型"
          >
            <Select placeholder="请选择宠物类型">
              <Select.Option value="猫">猫</Select.Option>
              <Select.Option value="狗">狗</Select.Option>
              <Select.Option value="兔子">兔子</Select.Option>
              <Select.Option value="鸟">鸟</Select.Option>
              <Select.Option value="其他">其他</Select.Option>
            </Select>
          </Form.Item>

          <Form.Item
            name="breed"
            label="品种"
          >
            <Input placeholder="请输入品种" />
          </Form.Item>

          <Form.Item
            name="gender"
            label="性别"
          >
            <Select placeholder="请选择性别">
              <Select.Option value="公">公</Select.Option>
              <Select.Option value="母">母</Select.Option>
            </Select>
          </Form.Item>

          <Form.Item
            name="birth_date"
            label="出生日期"
          >
            <DatePicker style={{ width: '100%' }} />
          </Form.Item>

          <Form.Item
            name="weight"
            label="体重（kg）"
            rules={[
              {
                type: 'number',
                min: 0.01,
                message: '体重必须大于0',
              },
            ]}
          >
            <InputNumber
              placeholder="例如：3.5"
              min={0.01}
              step={0.1}
              precision={2}
              style={{ width: '100%' }}
              addonAfter="kg"
            />
          </Form.Item>

          <Form.Item
            name="color"
            label="颜色/外观特征"
          >
            <Input placeholder="请输入颜色或外观特征" />
          </Form.Item>

          <Form.Item
            name="description"
            label="描述"
          >
            <TextArea rows={4} placeholder="请输入宠物描述" />
          </Form.Item>
        </Form>
      </Modal>
    </Card>
  );
};

export default PetManagement;
