import React, { useState, useEffect } from 'react';
import { Table, Button, Space, Modal, Form, Input, message, Popconfirm, Card, Tag, Tooltip } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined, VideoCameraOutlined, PoweroffOutlined, CheckCircleOutlined } from '@ant-design/icons';
import { getSources, createSource, updateSource, deleteSource, disableSource, enableSource, getTasks } from '../../services/api';
import type { StreamSource, SlicingTask } from '../../types';

const SourceManagement: React.FC = () => {
  const [sources, setSources] = useState<StreamSource[]>([]);
  const [tasks, setTasks] = useState<SlicingTask[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingSource, setEditingSource] = useState<StreamSource | null>(null);
  const [form] = Form.useForm();

  const loadSources = async () => {
    setLoading(true);
    try {
      const [sourcesData, tasksData] = await Promise.all([getSources(), getTasks()]);
      setSources(sourcesData);
      setTasks(tasksData);
    } catch (error) {
      message.error('加载源配置失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSources();
  }, []);

  const hasRelatedTasks = (sourceId: number): boolean => {
    return tasks.some(task => task.source_id === sourceId);
  };

  const getRelatedTasksCount = (sourceId: number): number => {
    return tasks.filter(task => task.source_id === sourceId).length;
  };

  const handleAdd = () => {
    setEditingSource(null);
    form.resetFields();
    setModalVisible(true);
  };

  const handleEdit = (source: StreamSource) => {
    setEditingSource(source);
    form.setFieldsValue(source);
    setModalVisible(true);
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteSource(id);
      message.success('删除成功');
      loadSources();
    } catch (error: any) {
      message.error(error.response?.data?.detail || '删除失败');
    }
  };

  const handleDisable = async (id: number) => {
    try {
      const response = await disableSource(id);
      const stoppedTasks = response.stopped_tasks || 0;
      if (stoppedTasks > 0) {
        message.success(`已停用源并停止了 ${stoppedTasks} 个运行中的任务`);
      } else {
        message.success('已停用源');
      }
      loadSources();
    } catch (error: any) {
      message.error(error.response?.data?.detail || '停用失败');
    }
  };

  const handleEnable = async (id: number) => {
    try {
      await enableSource(id);
      message.success('已启用源');
      loadSources();
    } catch (error: any) {
      message.error(error.response?.data?.detail || '启用失败');
    }
  };

  const handleModalOk = async () => {
    try {
      const values = await form.validateFields();
      if (editingSource) {
        await updateSource(editingSource.id, values);
        message.success('更新成功');
      } else {
        await createSource(values);
        message.success('创建成功');
      }
      setModalVisible(false);
      loadSources();
    } catch (error: any) {
      message.error(error.response?.data?.detail || '操作失败');
    }
  };

  const columns = [
    {
      title: '名称',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '别名',
      dataIndex: 'alias',
      key: 'alias',
      render: (text: string) => <Tag color="blue">{text}</Tag>
    },
    {
      title: 'DID',
      dataIndex: 'did',
      key: 'did',
      width: 150,
      render: (text: string) => text ? <Tag color="purple">{text}</Tag> : <span style={{ color: '#999' }}>-</span>
    },
    {
      title: '流地址',
      dataIndex: 'stream_url',
      key: 'stream_url',
      ellipsis: true,
    },
    {
      title: '存储目录',
      dataIndex: 'storage_path',
      key: 'storage_path',
      ellipsis: true,
    },
    {
      title: '状态',
      dataIndex: 'is_active',
      key: 'is_active',
      render: (active: boolean) => (
        <Tag color={active ? 'green' : 'red'}>{active ? '启用' : '禁用'}</Tag>
      ),
    },
    {
      title: '操作',
      key: 'action',
      width: 280,
      render: (_: any, record: StreamSource) => (
        <Space size="small">
          {record.is_active ? (
            <Popconfirm
              title="确认停用此源？"
              description="将自动停止该源关联的所有运行中任务"
              onConfirm={() => handleDisable(record.id)}
              okText="确认"
              cancelText="取消"
            >
              <Button icon={<PoweroffOutlined />} size="small">停用</Button>
            </Popconfirm>
          ) : (
            <Button icon={<CheckCircleOutlined />} size="small" type="primary" onClick={() => handleEnable(record.id)}>启用</Button>
          )}
          <Button icon={<EditOutlined />} onClick={() => handleEdit(record)} size="small">编辑</Button>
          {hasRelatedTasks(record.id) ? (
            <Tooltip title={`该源有 ${getRelatedTasksCount(record.id)} 个关联任务，需先删除所有任务才能删除源`}>
              <Button icon={<DeleteOutlined />} danger size="small" disabled>删除</Button>
            </Tooltip>
          ) : (
            <Popconfirm
              title="确定删除此源吗？"
              description="此操作不可恢复"
              onConfirm={() => handleDelete(record.id)}
              okText="确认"
              cancelText="取消"
            >
              <Button icon={<DeleteOutlined />} danger size="small">删除</Button>
            </Popconfirm>
          )}
        </Space>
      ),
    },
  ];

  return (
    <Card 
      title={<Space><VideoCameraOutlined /><span>摄像头源管理</span></Space>}
      extra={<Button type="primary" icon={<PlusOutlined />} onClick={handleAdd}>添加源</Button>}
    >
      <Table 
        columns={columns} 
        dataSource={sources} 
        rowKey="id" 
        loading={loading}
        size="small"
      />

      <Modal
        title={editingSource ? '编辑源配置' : '添加源配置'}
        open={modalVisible}
        onOk={handleModalOk}
        onCancel={() => setModalVisible(false)}
        destroyOnHidden
      >
        <Form form={form} layout="vertical">
          <Form.Item name="name" label="用户名称" rules={[{ required: true, message: '请输入名称' }]}>
            <Input placeholder="例如：客厅摄像头" />
          </Form.Item>
          <Form.Item name="alias" label="别名 (唯一标识)" rules={[{ required: true, message: '请输入唯一别名' }]}>
            <Input placeholder="例如：living_room" disabled={!!editingSource} />
          </Form.Item>
          <Form.Item name="did" label="DID (可选)" extra="用于多用户数据隔离，不填则为系统管理员添加">
            <Input placeholder="例如：user123" />
          </Form.Item>
          <Form.Item name="stream_url" label="流地址" rules={[{ required: true, message: '请输入流地址' }]}>
            <Input placeholder="rtsp://..." />
          </Form.Item>
          <Form.Item name="storage_path" label="存储目录" rules={[{ required: true, message: '请输入存储目录' }]}>
            <Input placeholder="/path/to/storage" />
          </Form.Item>
        </Form>
      </Modal>
    </Card>
  );
};

export default SourceManagement;
