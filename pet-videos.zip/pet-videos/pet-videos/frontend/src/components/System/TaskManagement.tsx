import React, { useState, useEffect, useRef } from 'react';
import { Table, Button, Space, Modal, Form, Select, message, Card, Tag, Tooltip, Switch, Popconfirm } from 'antd';
import { PlayCircleOutlined, StopOutlined, PlusOutlined, SyncOutlined, BugOutlined, DeleteOutlined, FileTextOutlined, FileSearchOutlined } from '@ant-design/icons';
import { getTasks, startTask, stopTask, deleteTask, getAvailableSources, getSources, getAvailableScripts, getTaskLogs, TaskLogResponse } from '../../services/api';
import type { SlicingTask, StreamSource, ScriptFileInfo } from '../../types';

const TaskManagement: React.FC = () => {
  const [tasks, setTasks] = useState<SlicingTask[]>([]);
  const [sources, setSources] = useState<StreamSource[]>([]);
  const [availableSources, setAvailableSources] = useState<StreamSource[]>([]);
  const [availableScripts, setAvailableScripts] = useState<ScriptFileInfo[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [logModalVisible, setLogModalVisible] = useState(false);
  const [currentLogs, setCurrentLogs] = useState<TaskLogResponse | null>(null);
  const [logsLoading, setLogsLoading] = useState(false);
  const logRefreshTimerRef = useRef<number | null>(null);
  const [form] = Form.useForm();

  const loadData = async () => {
    setLoading(true);
    try {
      const [taskData, sourceData, scriptsData] = await Promise.all([
        getTasks(), 
        getSources(),
        getAvailableScripts()
      ]);
      setTasks(taskData);
      setSources(sourceData);
      setAvailableScripts(scriptsData);
    } catch (error) {
      message.error('加载任务数据失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const timer = setInterval(loadData, 10000); // 10秒自动刷新
    return () => {
      clearInterval(timer);
      if (logRefreshTimerRef.current) {
        clearInterval(logRefreshTimerRef.current);
      }
    };
  }, []);

  const handleCreateTask = async () => {
    try {
      const sourcesData = await getAvailableSources();
      setAvailableSources(sourcesData);
      
      if (sourcesData.length === 0) {
        message.info('没有可用的摄像头源（所有源都已启动任务）');
        return;
      }
      setModalVisible(true);
    } catch (error) {
      message.error('获取可用源失败');
    }
  };

  const handleStart = async (sourceId: number, enableYolo: boolean = true, scriptFile: string = 'pet_monitor.py') => {
    try {
      await startTask(sourceId, enableYolo, scriptFile);
      message.success('任务启动命令已发送');
      loadData();
    } catch (error) {
      message.error('启动失败');
    }
  };

  const handleStop = async (sourceId: number) => {
    try {
      await stopTask(sourceId);
      message.success('任务停止命令已发送');
      loadData();
    } catch (error) {
      message.error('停止失败');
    }
  };

  const handleDelete = async (taskId: number) => {
    try {
      await deleteTask(taskId);
      message.success('任务已删除');
      loadData();
    } catch (error) {
      message.error('删除失败');
    }
  };

  const handleModalOk = async () => {
    try {
      const { sourceId, enable_yolo, script_file } = await form.validateFields();
      await startTask(sourceId, enable_yolo === true, script_file || 'pet_monitor.py');
      message.success('任务已创建并启动');
      setModalVisible(false);
      loadData();
    } catch (error) {
      message.error('创建任务失败');
    }
  };

  const getSourceName = (sourceId: number) => {
    const source = sources.find(s => s.id === sourceId);
    return source ? `${source.name} (${source.alias})` : `Unknown (${sourceId})`;
  };

  const handleViewLogs = async (sourceId: number) => {
    setLogsLoading(true);
    setLogModalVisible(true);
    
    try {
      const logs = await getTaskLogs(sourceId);
      setCurrentLogs(logs);
      
      // 启动自动刷新（每3秒）
      if (logRefreshTimerRef.current) {
        clearInterval(logRefreshTimerRef.current);
      }
      logRefreshTimerRef.current = setInterval(async () => {
        try {
          const updatedLogs = await getTaskLogs(sourceId);
          setCurrentLogs(updatedLogs);
        } catch (error) {
          console.error('刷新日志失败:', error);
        }
      }, 3000);
      
    } catch (error) {
      message.error('加载日志失败');
    } finally {
      setLogsLoading(false);
    }
  };

  const handleCloseLogModal = () => {
    setLogModalVisible(false);
    setCurrentLogs(null);
    if (logRefreshTimerRef.current) {
      clearInterval(logRefreshTimerRef.current);
      logRefreshTimerRef.current = null;
    }
  };

  const columns = [
    {
      title: '摄像头源',
      dataIndex: 'source_id',
      key: 'source_id',
      render: (id: number) => getSourceName(id),
    },
    {
      title: '脚本文件',
      dataIndex: 'script_file',
      key: 'script_file',
      width: 200,
      render: (file: string) => {
        const scriptInfo = availableScripts.find(s => s.filename === file);
        const tooltipContent = scriptInfo?.description || file;
        return (
          <Tooltip title={<div style={{ whiteSpace: 'pre-line' }}>{tooltipContent}</div>}>
            <Tag icon={<FileTextOutlined />} color="blue">{file}</Tag>
          </Tooltip>
        );
      },
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 90,
      render: (status: string) => {
        let color = 'default';
        let text = '已停止';
        if (status === 'running') {
          color = 'processing';
          text = '运行中';
        } else if (status === 'error') {
          color = 'error';
          text = '异常';
        }
        return <Tag color={color}>{text}</Tag>;
      },
    },
    {
      title: 'PID',
      dataIndex: 'pid',
      key: 'pid',
      width: 80,
      render: (pid: number) => pid || '-',
    },
    {
      title: '最近心跳',
      dataIndex: 'last_heartbeat',
      key: 'last_heartbeat',
      render: (time: string) => time ? new Date(time).toLocaleString() : '-',
    },
    {
      title: '启动时间',
      dataIndex: 'last_start_time',
      key: 'last_start_time',
      render: (time: string) => time ? new Date(time).toLocaleString() : '-',
    },
    {
      title: '检测模式',
      dataIndex: 'enable_yolo',
      key: 'enable_yolo',
      render: (enabled: boolean) => (
        <Tag color={enabled ? 'processing' : 'default'}>
          {enabled ? '宠物检测' : '运动检测'}
        </Tag>
      ),
    },
    {
      title: '失败计数',
      dataIndex: 'consecutive_failures',
      key: 'consecutive_failures',
      width: 80,
      render: (count: number) => {
        if (count === 0) {
          return '-';
        }
        let color = 'warning';
        if (count >= 3) {
          color = 'error';
        }
        return <Tag color={color}>{count}/3</Tag>;
      },
    },
    {
      title: '日志',
      key: 'logs',
      width: 80,
      align: 'center' as const,
      render: (_: any, record: SlicingTask) => (
        <Button 
          icon={<FileSearchOutlined />} 
          size="small" 
          onClick={() => handleViewLogs(record.source_id)}
        >
          查看
        </Button>
      ),
    },
    {
      title: '错误信息',
      dataIndex: 'error_msg',
      key: 'error_msg',
      ellipsis: true,
      render: (msg: string) => msg ? (
        <Tooltip title={msg}>
          <Tag icon={<BugOutlined />} color="error">详情</Tag>
        </Tooltip>
      ) : '-',
    },
    {
      title: '操作',
      key: 'action',
      width: 240,
      render: (_: any, record: SlicingTask) => (
        <Space size="small">
          {record.status !== 'running' ? (
            <Button icon={<PlayCircleOutlined />} type="primary" size="small" onClick={() => handleStart(record.source_id, record.enable_yolo, record.script_file)}>启动</Button>
          ) : (
            <Button icon={<StopOutlined />} danger size="small" onClick={() => handleStop(record.source_id)}>停止</Button>
          )}
          <Button icon={<SyncOutlined />} size="small" onClick={() => handleStart(record.source_id, record.enable_yolo, record.script_file)}>重启</Button>
          <Popconfirm
            title="确认删除任务？"
            description={record.status === 'running' ? '任务正在运行，将自动停止后删除' : '此操作不可恢复'}
            onConfirm={() => handleDelete(record.id)}
            okText="确认"
            cancelText="取消"
          >
            <Button icon={<DeleteOutlined />} danger size="small">删除</Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <Card 
      title={
        <Space>
          <SyncOutlined spin={loading} />
          <span>切片任务监控</span>
          <span style={{ fontSize: '12px', color: '#999', fontWeight: 'normal' }}>
            （每30秒心跳检测，连续失败3次停止自动重启，稳定运行2分钟重置计数）
          </span>
        </Space>
      }
      extra={<Button type="primary" icon={<PlusOutlined />} onClick={handleCreateTask}>新建任务</Button>}
    >
      <Table 
        columns={columns} 
        dataSource={tasks} 
        rowKey="id" 
        loading={loading}
        size="small"
      />

      {/* 日志查看弹窗 */}
      <Modal
        title={
          <Space>
            <FileSearchOutlined />
            <span>任务日志</span>
            {currentLogs && (
              <Tag color="blue">
                Source ID: {currentLogs.source_id}
              </Tag>
            )}
            <Tag color="green">自动刷新中</Tag>
          </Space>
        }
        open={logModalVisible}
        onCancel={handleCloseLogModal}
        width={1000}
        footer={[
          <Button key="close" onClick={handleCloseLogModal}>
            关闭
          </Button>,
        ]}
      >
        {logsLoading ? (
          <div style={{ textAlign: 'center', padding: '40px' }}>
            <SyncOutlined spin style={{ fontSize: '32px' }} />
            <div style={{ marginTop: '16px' }}>加载日志中...</div>
          </div>
        ) : currentLogs ? (
          <div>
            <div style={{ marginBottom: '12px', color: '#666' }}>
              <Space>
                <span>总行数: {currentLogs.total_lines}</span>
                <span>|</span>
                <span>显示: {currentLogs.lines.length} 行</span>
                {currentLogs.total_lines > 5000 && (
                  <>
                    <span>|</span>
                    <span style={{ color: '#ff9800' }}>（仅显示最新5000行）</span>
                  </>
                )}
                <span>|</span>
                <span>最新的日志在上方</span>
              </Space>
            </div>
            {currentLogs.exists ? (
              <div
                style={{
                  maxHeight: '600px',
                  overflow: 'auto',
                  backgroundColor: '#1e1e1e',
                  color: '#d4d4d4',
                  padding: '12px',
                  borderRadius: '4px',
                  fontFamily: 'Monaco, Consolas, monospace',
                  fontSize: '12px',
                  lineHeight: '1.6',
                }}
              >
                {currentLogs.lines.map((line, index) => (
                  <div
                    key={index}
                    style={{
                      borderBottom: index < currentLogs.lines.length - 1 ? '1px solid #333' : 'none',
                      paddingBottom: '4px',
                      marginBottom: '4px',
                      whiteSpace: 'pre-wrap',
                      wordBreak: 'break-all',
                    }}
                  >
                    {line}
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: '40px', color: '#999' }}>
                日志文件不存在
              </div>
            )}
          </div>
        ) : null}
      </Modal>

      <Modal
        title="新建切片任务"
        open={modalVisible}
        onOk={handleModalOk}
        onCancel={() => setModalVisible(false)}
        destroyOnHidden
      >
        <Form form={form} layout="vertical" initialValues={{ enable_yolo: true, script_file: 'pet_monitor.py' }}>
          <Form.Item name="sourceId" label="选择摄像头源" rules={[{ required: true, message: '请选择一个源' }]}>
            <Select placeholder="请选择尚未启动任务的摄像头">
              {availableSources.map(s => (
                <Select.Option key={s.id} value={s.id}>{s.name} ({s.alias})</Select.Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item 
            name="script_file" 
            label="脚本文件" 
            rules={[{ required: true, message: '请选择一个脚本文件' }]}
            tooltip="选择要执行的 Python 脚本"
          >
            <Select 
              placeholder="请选择脚本文件"
              optionLabelProp="label"
            >
              {availableScripts.map(s => (
                <Select.Option 
                  key={s.filename} 
                  value={s.filename}
                  label={s.filename}
                >
                  <Tooltip title={s.description} placement="right">
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <span>{s.filename}</span>
                      {s.description && (
                        <span style={{ fontSize: '12px', color: '#999', marginLeft: '8px' }}>
                          ({s.description.substring(0, 20)}{s.description.length > 20 ? '...' : ''})
                        </span>
                      )}
                    </div>
                  </Tooltip>
                </Select.Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item 
            name="enable_yolo" 
            label="检测模式" 
            valuePropName="checked"
            tooltip="启用：使用YOLO检测宠物后录制；关闭：检测到画面变动即录制"
          >
            <Switch 
              defaultChecked 
              checkedChildren="宠物检测" 
              unCheckedChildren="运动检测" 
            />
          </Form.Item>
          <div style={{ color: '#666', fontSize: '12px' }}>
            提示：新建任务将立即启动后台切片脚本。
          </div>
        </Form>
      </Modal>
    </Card>
  );
};

export default TaskManagement;
