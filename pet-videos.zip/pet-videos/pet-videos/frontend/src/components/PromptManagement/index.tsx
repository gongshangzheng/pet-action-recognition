/**
 * 切片Prompt管理组件
 */
import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Space, Modal, Form, Input, Switch, message, Popconfirm, Tag, Row, Col } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined, StarOutlined, StarFilled } from '@ant-design/icons';
import dayjs from 'dayjs';
import type { Prompt } from '../../types/prompt';
import type { Pet } from '../../types/pet';
import {
  getPrompts,
  createPrompt,
  updatePrompt,
  setDefaultPrompt,
  deletePrompt
} from '../../services/promptApi';
import { getPets } from '../../services/petApi';
import VariableList from '../VariableList';
import type { VariableContext } from '../../utils/variableConfig';
import './index.css';

const { TextArea } = Input;

const PromptManagement: React.FC = () => {
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingPrompt, setEditingPrompt] = useState<Prompt | null>(null);
  const [contentModalVisible, setContentModalVisible] = useState(false);
  const [viewingPrompt, setViewingPrompt] = useState<Prompt | null>(null);
  const [pets, setPets] = useState<Pet[]>([]);
  const [form] = Form.useForm();

  // 加载宠物信息（用于变量列表）
  useEffect(() => {
    const loadPets = async () => {
      try {
        const data = await getPets();
        setPets(data);
      } catch (error) {
        console.error('加载宠物信息失败:', error);
      }
    };
    loadPets();
  }, []);

  // 加载提示词列表
  const loadPrompts = async () => {
    setLoading(true);
    try {
      const data = await getPrompts(false);
      setPrompts(data.prompts);
    } catch (error: any) {
      message.error(error.response?.data?.detail || '加载提示词列表失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPrompts();
  }, []);

  // 打开新建/编辑对话框
  const handleOpenModal = (prompt?: Prompt) => {
    setEditingPrompt(prompt || null);
    if (prompt) {
      form.setFieldsValue({
        name: prompt.name,
        content: prompt.content,
        description: prompt.description,
        is_active: prompt.is_active
      });
    } else {
      form.resetFields();
      form.setFieldsValue({ is_active: true });
    }
    setModalVisible(true);
  };

  // 保存提示词
  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      
      if (editingPrompt) {
        await updatePrompt(editingPrompt.id, values);
        message.success('更新成功');
      } else {
        await createPrompt(values);
        message.success('创建成功');
      }
      
      setModalVisible(false);
      loadPrompts();
    } catch (error: any) {
      if (error.errorFields) {
        message.error('请检查表单输入');
      } else {
        message.error(error.response?.data?.detail || '保存失败');
      }
    }
  };

  // 设置为自动
  const handleSetDefault = async (id: number) => {
    try {
      await setDefaultPrompt(id);
      message.success('已设置为自动调用提示词');
      loadPrompts();
    } catch (error: any) {
      message.error(error.response?.data?.detail || '设置失败');
    }
  };

  // 删除提示词（假删除）
  const handleDelete = async (id: number) => {
    try {
      await deletePrompt(id);
      message.success('删除成功');
      loadPrompts();
    } catch (error: any) {
      message.error(error.response?.data?.detail || '删除失败');
    }
  };

  // 查看提示词内容
  const handleViewContent = (prompt: Prompt) => {
    setViewingPrompt(prompt);
    setContentModalVisible(true);
  };

  // 从查看弹窗跳转到编辑
  const handleEditFromView = () => {
    if (viewingPrompt) {
      setContentModalVisible(false);
      handleOpenModal(viewingPrompt);
    }
  };

  const columns = [
    {
      title: '名称',
      dataIndex: 'name',
      key: 'name',
      width: 180,
      render: (text: string, record: Prompt) => (
        <Space>
          {text}
          {record.is_default && <Tag color="gold" icon={<StarFilled />}>自动</Tag>}
        </Space>
      ),
    },
    {
      title: '内容',
      dataIndex: 'content',
      key: 'content',
      width: 250,
      ellipsis: true,
      render: (text: string, record: Prompt) => (
        <div 
          style={{ 
            cursor: 'pointer',
            color: '#1890ff',
            overflow: 'hidden', 
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap'
          }}
          onClick={() => handleViewContent(record)}
        >
          {text}
        </div>
      ),
    },
    {
      title: '描述',
      dataIndex: 'description',
      key: 'description',
      width: 180,
      ellipsis: true,
    },
    {
      title: '状态',
      dataIndex: 'is_active',
      key: 'is_active',
      width: 80,
      render: (active: boolean) => (
        <Tag color={active ? 'green' : 'default'}>
          {active ? '启用' : '禁用'}
        </Tag>
      ),
    },
    {
      title: '创建时间',
      dataIndex: 'created_at',
      key: 'created_at',
      width: 160,
      render: (time: string) => dayjs(time).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: '操作',
      key: 'action',
      width: 260,
      fixed: 'right' as const,
      render: (_: any, record: Prompt) => (
        <Space size="small">
          {!record.is_default && (
            <Button
              type="link"
              size="small"
              icon={<StarOutlined />}
              onClick={() => handleSetDefault(record.id)}
            >
              设为自动
            </Button>
          )}
          <Button
            type="link"
            size="small"
            icon={<EditOutlined />}
            onClick={() => handleOpenModal(record)}
          >
            编辑
          </Button>
          <Popconfirm
            title="确定删除这个提示词吗？"
            description="删除后不可恢复"
            onConfirm={() => handleDelete(record.id)}
            okText="确定"
            cancelText="取消"
            disabled={record.is_default}
          >
            <Button
              type="link"
              size="small"
              danger
              icon={<DeleteOutlined />}
              disabled={record.is_default}
            >
              删除
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <div className="prompt-management">
      <Card
        title="切片Prompt管理"
        extra={
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => handleOpenModal()}
          >
            新建提示词
          </Button>
        }
      >
        <Table
          dataSource={prompts}
          columns={columns}
          rowKey="id"
          loading={loading}
          scroll={{ x: 1200 }}
          pagination={{
            pageSize: 10,
            showTotal: (total) => `共 ${total} 条`,
          }}
        />
      </Card>

      {/* 内容查看弹窗 */}
      <Modal
        title={
          <Space>
            <span>提示词内容</span>
            {viewingPrompt?.is_default && <Tag color="gold" icon={<StarFilled />}>自动</Tag>}
          </Space>
        }
        open={contentModalVisible}
        onCancel={() => setContentModalVisible(false)}
        width={700}
        footer={[
          <Button key="close" onClick={() => setContentModalVisible(false)}>
            关闭
          </Button>,
          <Button
            key="edit"
            type="primary"
            icon={<EditOutlined />}
            onClick={handleEditFromView}
          >
            编辑
          </Button>,
        ]}
      >
        {viewingPrompt && (
          <div>
            <div style={{ marginBottom: 16 }}>
              <strong>名称：</strong>{viewingPrompt.name}
            </div>
            {viewingPrompt.description && (
              <div style={{ marginBottom: 16 }}>
                <strong>描述：</strong>{viewingPrompt.description}
              </div>
            )}
            <div style={{ marginBottom: 8 }}>
              <strong>内容：</strong>
            </div>
            <div style={{
              padding: '12px',
              background: '#f5f5f5',
              border: '1px solid #d9d9d9',
              borderRadius: '4px',
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word',
              maxHeight: '400px',
              overflow: 'auto',
              lineHeight: '1.6'
            }}>
              {viewingPrompt.content}
            </div>
            <div style={{ marginTop: 16, color: '#999', fontSize: '12px' }}>
              创建时间：{dayjs(viewingPrompt.created_at).format('YYYY-MM-DD HH:mm:ss')}
            </div>
          </div>
        )}
      </Modal>

      <Modal
        title={editingPrompt ? '编辑提示词' : '新建提示词'}
        open={modalVisible}
        onOk={handleSave}
        onCancel={() => setModalVisible(false)}
        width={1200}
        okText="保存"
        cancelText="取消"
      >
        <Row gutter={16}>
          {/* 左侧：表单 */}
          <Col span={14}>
            <Form
              form={form}
              layout="vertical"
              initialValues={{ is_active: true }}
            >
              <Form.Item
                name="name"
                label="名称"
                rules={[
                  { required: true, message: '请输入提示词名称' },
                  { max: 100, message: '名称不能超过100个字符' }
                ]}
              >
                <Input placeholder="例如：v1.0 基础版" />
              </Form.Item>

              <Form.Item
                name="content"
                label="提示词内容"
                rules={[{ required: true, message: '请输入提示词内容' }]}
              >
                <TextArea
                  rows={15}
                  placeholder="请输入提示词内容，可使用变量如 {{pet1_name}}..."
                  showCount
                />
              </Form.Item>

              <Form.Item
                name="description"
                label="描述（可选）"
                rules={[{ max: 500, message: '描述不能超过500个字符' }]}
              >
                <Input.TextArea
                  rows={2}
                  placeholder="简要描述这个提示词的用途..."
                />
              </Form.Item>

              <Form.Item
                name="is_active"
                label="启用状态"
                valuePropName="checked"
              >
                <Switch checkedChildren="启用" unCheckedChildren="禁用" />
              </Form.Item>
            </Form>
          </Col>

          {/* 右侧：变量列表 */}
          <Col span={10}>
            <VariableList
              context={{
                pets: pets,
                userId: undefined,
                userName: undefined,
              }}
            />
          </Col>
        </Row>
      </Modal>
    </div>
  );
};

export default PromptManagement;
