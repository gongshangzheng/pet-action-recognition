import React, { useState, useEffect } from 'react';
import { Card, Table, Tag, Space, Button, Input, DatePicker, Select, Statistic, Row, Col, Modal, Typography, Divider, message } from 'antd';
import { EyeOutlined, SearchOutlined, BarChartOutlined, HeartOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import dayjs from 'dayjs';
import {
  getPetBehaviors,
  getPetBehaviorDetail,
  getBehaviorStats,
  type PetBehavior,
  type PetBehaviorDetail,
  type BehaviorStats,
  type BehaviorListResponse
} from '../../services/petBehaviorApi';

const { Option } = Select;
const { Text, Title } = Typography;
const { RangePicker } = DatePicker;

const PetBehaviors: React.FC = () => {
  const [behaviors, setBehaviors] = useState<PetBehavior[]>([]);
  const [loading, setLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [stats, setStats] = useState<BehaviorStats | null>(null);
  const [selectedBehavior, setSelectedBehavior] = useState<PetBehaviorDetail | null>(null);
  const [detailModalVisible, setDetailModalVisible] = useState(false);
  const [statsModalVisible, setStatsModalVisible] = useState(false);

  // 过滤条件
  const [filters, setFilters] = useState({
    pet_name: '',
    did: '',
    date: ''
  });

  const fetchBehaviors = async (page = 1, size = 10, filterParams = filters) => {
    setLoading(true);
    try {
      const params = {
        page,
        page_size: size,
        ...(filterParams.pet_name && { pet_name: filterParams.pet_name }),
        ...(filterParams.did && { did: filterParams.did }),
        ...(filterParams.date && { date: filterParams.date })
      };

      const data = await getPetBehaviors(params);
      setBehaviors(data.behaviors);
      setTotal(data.total);
      setCurrentPage(data.page);
      setPageSize(data.page_size);
    } catch (error) {
      console.error('Error fetching behaviors:', error);
      message.error('获取宠物行为数据失败');
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const data = await getBehaviorStats({});
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
      message.error('获取统计数据失败');
    }
  };

  const fetchBehaviorDetail = async (videoId: number, petName: string) => {
    try {
      const data = await getPetBehaviorDetail(videoId, petName);
      setSelectedBehavior(data);
      setDetailModalVisible(true);
    } catch (error) {
      console.error('Error fetching behavior detail:', error);
      message.error('获取行为详情失败');
    }
  };

  useEffect(() => {
    fetchBehaviors();
    fetchStats();
  }, []);

  const handleSearch = () => {
    fetchBehaviors(1, pageSize, filters);
  };

  const handleReset = () => {
    const resetFilters = { pet_name: '', did: '', date: '' };
    setFilters(resetFilters);
    fetchBehaviors(1, pageSize, resetFilters);
  };

  const getScoreColor = (score: number) => {
    if (score >= 8) return 'green';
    if (score >= 6) return 'orange';
    return 'red';
  };

  const columns: ColumnsType<PetBehavior> = [
    {
      title: '宠物名称',
      dataIndex: 'pet_name',
      key: 'pet_name',
      width: 100,
      render: (text: string) => <Tag color="blue">{text}</Tag>,
    },
    {
      title: '用户DID',
      dataIndex: 'did',
      key: 'did',
      width: 120,
      render: (text: string) => <Tag color="purple">{text}</Tag>,
    },
    {
      title: '行为类型',
      dataIndex: 'actions',
      key: 'actions',
      width: 150,
      render: (actions: string) => (
        <Space wrap>
          {actions?.split(',').map((action, index) => (
            <Tag key={index} color="cyan">{action.trim()}</Tag>
          ))}
        </Space>
      ),
    },
    {
      title: '描述',
      dataIndex: 'description',
      key: 'description',
      ellipsis: true,
      width: 200,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 150,
      ellipsis: true,
    },
    {
      title: '位置',
      dataIndex: 'location',
      key: 'location',
      width: 120,
    },
    {
      title: '评分',
      dataIndex: 'score',
      key: 'score',
      width: 80,
      render: (score: number) => (
        <Tag color={getScoreColor(score)}>{score}</Tag>
      ),
      sorter: (a, b) => a.score - b.score,
    },
    {
      title: '视频文件',
      dataIndex: 'video_file_name',
      key: 'video_file_name',
      width: 180,
      ellipsis: true,
    },
    {
      title: '记录时间',
      dataIndex: 'created_at',
      key: 'created_at',
      width: 150,
      render: (time: string) => dayjs(time).format('MM-DD HH:mm'),
      sorter: (a, b) => dayjs(a.created_at).unix() - dayjs(b.created_at).unix(),
    },
    {
      title: '操作',
      key: 'action',
      width: 80,
      render: (_, record) => (
        <Button
          type="link"
          icon={<EyeOutlined />}
          onClick={() => fetchBehaviorDetail(record.video_id, record.pet_name)}
        >
          详情
        </Button>
      ),
    },
  ];

  return (
    <div style={{ padding: '24px' }}>
      {/* 行为记录表格 */}
      <Card
        title={
          <Space>
            <HeartOutlined />
            <span>宠物行为</span>
            <Tag color="blue">{total} 条记录</Tag>
          </Space>
        }
        extra={
          <Space wrap>
            <Input
              placeholder="宠物名称"
              value={filters.pet_name}
              onChange={(e) => setFilters({ ...filters, pet_name: e.target.value })}
              style={{ width: 120 }}
            />
            <Input
              placeholder="用户DID"
              value={filters.did}
              onChange={(e) => setFilters({ ...filters, did: e.target.value })}
              style={{ width: 120 }}
            />
            <DatePicker
              placeholder="选择日期"
              value={filters.date ? dayjs(filters.date) : null}
              onChange={(date) => setFilters({ ...filters, date: date ? date.format('YYYY-MM-DD') : '' })}
            />
            <Button type="primary" icon={<SearchOutlined />} onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        }
      >
        <Table
          columns={columns}
          dataSource={behaviors}
          loading={loading}
          rowKey={(record) => `${record.video_id}-${record.pet_name}`}
          pagination={{
            current: currentPage,
            pageSize: pageSize,
            total: total,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total, range) => `第 ${range[0]}-${range[1]} 条，共 ${total} 条`,
            onChange: (page, size) => {
              fetchBehaviors(page, size || pageSize);
            },
          }}
        />
      </Card>

      {/* 详情模态框 */}
      <Modal
        title="宠物行为详情"
        open={detailModalVisible}
        onCancel={() => setDetailModalVisible(false)}
        footer={null}
        width={800}
      >
        {selectedBehavior && (
          <div>
            <Row gutter={16}>
              <Col span={12}>
                <Text strong>宠物名称：</Text>
                <Tag color="blue">{selectedBehavior.pet_name}</Tag>
              </Col>
              <Col span={12}>
                <Text strong>评分：</Text>
                <Tag color={getScoreColor(selectedBehavior.score)}>{selectedBehavior.score}</Tag>
              </Col>
            </Row>
            
            <Divider />
            
            <div style={{ marginBottom: '16px' }}>
              <Text strong>行为类型：</Text>
              <div style={{ marginTop: '8px' }}>
                <Space wrap>
                  {selectedBehavior.actions_list?.map((action, index) => (
                    <Tag key={index} color="cyan">{action}</Tag>
                  ))}
                </Space>
              </div>
            </div>

            <div style={{ marginBottom: '16px' }}>
              <Text strong>描述：</Text>
              <div style={{ marginTop: '8px', padding: '8px', backgroundColor: '#f5f5f5', borderRadius: '4px' }}>
                {selectedBehavior.description}
              </div>
            </div>

            <div style={{ marginBottom: '16px' }}>
              <Text strong>状态：</Text>
              <div style={{ marginTop: '8px', padding: '8px', backgroundColor: '#f5f5f5', borderRadius: '4px' }}>
                {selectedBehavior.status}
              </div>
            </div>

            <Row gutter={16} style={{ marginBottom: '16px' }}>
              <Col span={12}>
                <Text strong>位置：</Text> {selectedBehavior.location}
              </Col>
              <Col span={12}>
                <Text strong>用户DID：</Text> {selectedBehavior.did}
              </Col>
            </Row>

            <Divider />

            <div style={{ marginBottom: '16px' }}>
              <Text strong>视频信息：</Text>
              <div style={{ marginTop: '8px' }}>
                <div><Text>文件名：</Text>{selectedBehavior.video_file_name}</div>
                <div><Text>时长：</Text>{selectedBehavior.video_duration}秒</div>
                <div><Text>录制时间：</Text>{dayjs(selectedBehavior.video_recorded_at).format('YYYY-MM-DD HH:mm:ss')}</div>
                <div><Text>分析状态：</Text><Tag color="green">{selectedBehavior.video_llm_status}</Tag></div>
              </div>
            </div>

            {selectedBehavior.raw_result && (
              <div>
                <Text strong>原始分析结果：</Text>
                <pre style={{ 
                  marginTop: '8px', 
                  padding: '12px', 
                  backgroundColor: '#f5f5f5', 
                  borderRadius: '4px',
                  fontSize: '12px',
                  overflow: 'auto'
                }}>
                  {JSON.stringify(selectedBehavior.raw_result, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* 统计模态框 */}
      <Modal
        title="宠物行为统计"
        open={statsModalVisible}
        onCancel={() => setStatsModalVisible(false)}
        footer={null}
        width={800}
      >
        {stats && (
          <div>
            <Row gutter={16} style={{ marginBottom: '24px' }}>
              <Col span={8}>
                <Card>
                  <Statistic title="总行为记录" value={stats.total_behaviors} />
                </Card>
              </Col>
              <Col span={8}>
                <Card>
                  <Statistic title="宠物数量" value={stats.total_pets} />
                </Card>
              </Col>
              <Col span={8}>
                <Card>
                  <Statistic title="平均评分" value={stats.avg_score} precision={2} />
                </Card>
              </Col>
            </Row>

            <div style={{ marginBottom: '24px' }}>
              <Title level={4}>行为类型统计</Title>
              <Space wrap>
                {Object.entries(stats.action_stats).map(([action, count]) => (
                  <Tag key={action} color="blue">
                    {action}: {count}次
                  </Tag>
                ))}
              </Space>
            </div>

            <div>
              <Title level={4}>宠物统计</Title>
              {Object.entries(stats.pet_stats).map(([petName, petStat]) => (
                <Card key={petName} size="small" style={{ marginBottom: '12px' }}>
                  <Row gutter={16}>
                    <Col span={6}>
                      <Text strong>{petName}</Text>
                    </Col>
                    <Col span={6}>
                      <Text>行为记录: {petStat.behavior_count}条</Text>
                    </Col>
                    <Col span={6}>
                      <Text>平均评分: {petStat.avg_score.toFixed(2)}</Text>
                    </Col>
                    <Col span={6}>
                      <Text>最新记录: {dayjs(petStat.latest_behavior).format('MM-DD HH:mm')}</Text>
                    </Col>
                  </Row>
                </Card>
              ))}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default PetBehaviors;