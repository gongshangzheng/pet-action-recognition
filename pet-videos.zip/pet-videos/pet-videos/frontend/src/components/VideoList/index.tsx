import React, { useState } from 'react';
import { Card, List, Tag, Space, Empty, Button, Modal, Spin } from 'antd';
import { VideoCameraOutlined, PlayCircleOutlined } from '@ant-design/icons';
import type { VideoInfo } from '../../types';

interface VideoListProps {
  videos: VideoInfo[];
  total: number;
  page: number;
  pageSize: number;
  selectedVideo: VideoInfo | null;
  onSelectVideo: (video: VideoInfo) => void;
  onPageChange: (page: number, pageSize: number) => void;
  loading?: boolean;
}

const VideoList: React.FC<VideoListProps> = ({
  videos,
  total,
  page,
  pageSize,
  selectedVideo,
  onSelectVideo,
  onPageChange,
  loading = false,
}) => {
  const [previewVideo, setPreviewVideo] = useState<VideoInfo | null>(null);

  const handlePlay = (video: VideoInfo, e: React.MouseEvent) => {
    e.stopPropagation(); // 阻止冒泡，避免触发选择
    setPreviewVideo(video);
  };

  return (
    <>
      <Card
        title={
          <Space>
            <VideoCameraOutlined />
            <span>视频列表</span>
            {!loading && total > 0 && <Tag color="blue">{total} 个视频</Tag>}
          </Space>
        }
        size="small"
        style={{ height: '100%' }}
        styles={{ body: { height: 'calc(100% - 57px)', overflow: 'auto', padding: loading ? '40px 0' : '12px' } }}
      >
        <Spin spinning={loading} tip="正在加载视频列表...">
          {videos.length === 0 && !loading ? (
            <Empty description="暂无视频" />
          ) : (
            <List
              dataSource={videos}
              pagination={{
                current: page,
                pageSize: pageSize,
                total: total,
                size: 'small',
                onChange: onPageChange,
                showSizeChanger: true,
                showTotal: (total) => `共 ${total} 条`,
                style: { marginTop: 16, textAlign: 'center' }
              }}
              renderItem={(video) => (
                <List.Item
                  style={{
                    cursor: 'pointer',
                    background: selectedVideo && selectedVideo.id === video.id ? '#e6f7ff' : 'transparent',
                    padding: '12px',
                    borderRadius: '4px',
                  }}
                  onClick={() => onSelectVideo(video)}
                  extra={
                    <Button
                      type="primary"
                      icon={<PlayCircleOutlined />}
                      onClick={(e) => handlePlay(video, e)}
                      size="small"
                    >
                      播放
                    </Button>
                  }
                >
                  <List.Item.Meta
                    title={video.filename}
                    description={
                      <Space direction="vertical" size="small">
                        <Space size="small" wrap>
                          <Tag color="blue">{video.resolution}</Tag>
                          <Tag color="green">{video.duration_formatted}</Tag>
                          <Tag>{video.size_mb.toFixed(2)} MB</Tag>
                          <Tag color="orange">{video.fps.toFixed(1)} FPS</Tag>
                          <Tag color="purple">{video.codec.toUpperCase()}</Tag>
                        </Space>
                        {video.created_at && (
                          <span style={{ color: '#999', fontSize: '12px' }}>
                            创建时间: {new Date(video.created_at).toLocaleString('zh-CN')}
                          </span>
                        )}
                      </Space>
                    }
                  />
                </List.Item>
              )}
            />
          )}
        </Spin>
      </Card>

      {/* 视频预览模态框 */}
      <Modal
        title={
          <Space>
            <PlayCircleOutlined />
            <span>{previewVideo?.filename}</span>
          </Space>
        }
        open={!!previewVideo}
        onCancel={() => setPreviewVideo(null)}
        footer={null}
        width={900}
        centered
        destroyOnHidden
      >
        {previewVideo && (
          <div style={{ background: '#000', borderRadius: '4px' }}>
            <video
              controls
              autoPlay
              style={{ width: '100%', maxHeight: '70vh' }}
              src={`/api/video/stream?token=${encodeURIComponent(previewVideo.stream_token)}`}
            >
              您的浏览器不支持视频播放
            </video>
            <div style={{ padding: '12px', background: '#f5f5f5' }}>
              <Space size="small" wrap>
                <Tag color="blue">{previewVideo.resolution}</Tag>
                <Tag color="green">{previewVideo.duration_formatted}</Tag>
                <Tag>{previewVideo.size_mb.toFixed(2)} MB</Tag>
                <Tag>{previewVideo.fps.toFixed(1)} FPS</Tag>
                <Tag>{previewVideo.codec}</Tag>
                <Tag>{previewVideo.bitrate_mbps.toFixed(2)} Mbps</Tag>
              </Space>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
};

export default VideoList;
