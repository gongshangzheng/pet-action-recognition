import React, { useState, useEffect } from 'react';
import { Card, Table, Space, DatePicker, Input, Button, Tag, Modal, Statistic, Row, Col, message, Alert, Spin, Collapse } from 'antd';
import { FileTextOutlined, CalendarOutlined, SearchOutlined, CheckCircleOutlined, CloseCircleOutlined, ReloadOutlined, PlayCircleOutlined, PauseCircleOutlined, CodeOutlined } from '@ant-design/icons';
import type { ColumnsType } from 'antd/es/table';
import dayjs, { Dayjs } from 'dayjs';
import axios from 'axios';

const API_BASE = '/api';

// 创建 axios 实例
const api = axios.create({
  baseURL: API_BASE,
  withCredentials: true,
});

// 请求拦截器：自动添加 JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('pet_videos_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// 响应拦截器：处理 401 错误
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('pet_videos_token');
      localStorage.removeItem('pet_videos_user');
      window.dispatchEvent(new Event('pet-videos-unauthorized'));
    }
    return Promise.reject(error);
  }
);

interface DailyReport {
  id: number;  // 自增ID
  did: string;
  date: string;
  pet_name: string;
  summary: string;
  daily_tag?: string;  // 日报标签（如：精力过剩、岁月静好、饭桶）
  insight_text?: string;  // 洞察建议
  llm_request?: string;  // LLM请求的原始提示词（用于追踪）
  llm_response?: string;  // LLM返回的原始JSON（用于追踪）
  video_count: number;
  total_duration: number;
  generation_status: string;  // pending/processing/completed/failed
  error_message?: string;
  retry_count: number;
  created_at: string;
  updated_at: string;
}

interface DailyReportListResponse {
  reports: DailyReport[];
  total: number;
}

interface GeneratorStatus {
  worker_running: boolean;
  last_generation_time: string | null;
  today_reports_count: number;
  total_reports_count: number;
  processing_count: number;
  queue_size: number;
  status_stats: Record<string, number>;
  config: {
    peak_interval_minutes: number;
    off_peak_interval_minutes: number;
    peak_hours: string;
    max_concurrent: number;
  };
}

const DailyReports: React.FC = () => {
  const [reports, setReports] = useState<DailyReport[]>([]);
  const [loading, setLoading] = useState(false);
  const [total, setTotal] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(20);

  // 搜索条件
  const [searchPetName, setSearchPetName] = useState('');
  const [searchDate, setSearchDate] = useState<Dayjs | null>(null);
  
  // 详情模态框
  const [detailModalVisible, setDetailModalVisible] = useState(false);
  const [selectedReport, setSelectedReport] = useState<DailyReport | null>(null);

  // 生成器状态
  const [generatorStatus, setGeneratorStatus] = useState<GeneratorStatus | null>(null);
  const [statusLoading, setStatusLoading] = useState(false);
  const [operationLoading, setOperationLoading] = useState(false);

  // 加载日报列表
  const fetchReports = async (page = 1) => {
    setLoading(true);
    try {
      const params: any = {
        page,
        page_size: pageSize,
      };

      if (searchPetName) {
        params.pet_name = searchPetName;
      }
      if (searchDate) {
        params.date = searchDate.format('YYYY-MM-DD');
      }

      const response = await api.get<DailyReportListResponse>('/daily-reports/', { params });
      setReports(response.data.reports);
      setTotal(response.data.total);
      setCurrentPage(page);
    } catch (error: any) {
      message.error(`加载日报失败: ${error.response?.data?.detail || error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // 获取生成器状态
  const fetchGeneratorStatus = async () => {
    setStatusLoading(true);
    try {
      const response = await api.get<GeneratorStatus>('/daily-report-generator/status');
      setGeneratorStatus(response.data);
    } catch (error: any) {
      console.error('获取生成器状态失败:', error);
    } finally {
      setStatusLoading(false);
    }
  };

  // 启动生成器
  const handleStartGenerator = async () => {
    setOperationLoading(true);
    try {
      await api.post('/daily-report-generator/start');
      message.success('日报生成器已启动');
      fetchGeneratorStatus();
    } catch (error: any) {
      message.error(`启动失败: ${error.response?.data?.detail || error.message}`);
    } finally {
      setOperationLoading(false);
    }
  };

  // 停止生成器
  const handleStopGenerator = async () => {
    setOperationLoading(true);
    try {
      await api.post('/daily-report-generator/stop');
      message.success('日报生成器已停止');
      fetchGeneratorStatus();
    } catch (error: any) {
      message.error(`停止失败: ${error.response?.data?.detail || error.message}`);
    } finally {
      setOperationLoading(false);
    }
  };

  // 手动触发生成
  const handleManualGenerate = async () => {
    setOperationLoading(true);
    try {
      await api.post('/daily-report-generator/generate');
      message.success('已触发日报生成，请稍后查看结果');
      setTimeout(() => {
        fetchReports(currentPage);
        fetchGeneratorStatus();
      }, 2000);
    } catch (error: any) {
      message.error(`触发失败: ${error.response?.data?.detail || error.message}`);
    } finally {
      setOperationLoading(false);
    }
  };

  // 初始加载
  useEffect(() => {
    fetchReports(1);
    fetchGeneratorStatus();
    
    // 定时刷新状态（每30秒）
    const interval = setInterval(fetchGeneratorStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  // 搜索
  const handleSearch = () => {
    fetchReports(1);
  };

  // 重置搜索
  const handleReset = () => {
    setSearchPetName('');
    setSearchDate(null);
    // 重置后重新加载
    setTimeout(() => fetchReports(1), 0);
  };

  // 查看详情
  const handleViewDetail = (record: DailyReport) => {
    setSelectedReport(record);
    setDetailModalVisible(true);
  };

  // 表格列定义
  const columns: ColumnsType<DailyReport> = [
    {
      title: '日期',
      dataIndex: 'date',
      key: 'date',
      width: 120,
      render: (text: string) => (
        <Tag icon={<CalendarOutlined />} color="blue">
          {text}
        </Tag>
      ),
    },
    {
      title: '宠物名称',
      dataIndex: 'pet_name',
      key: 'pet_name',
      width: 120,
      render: (text: string) => <Tag color="green">{text}</Tag>,
    },
    {
      title: '用户DID',
      dataIndex: 'did',
      key: 'did',
      width: 120,
      render: (text: string) => <Tag color="purple">{text}</Tag>,
    },
    {
      title: '视频数量',
      dataIndex: 'video_count',
      key: 'video_count',
      width: 100,
      align: 'center',
    },
    {
      title: '总时长',
      dataIndex: 'total_duration',
      key: 'total_duration',
      width: 120,
      align: 'center',
      render: (duration: number) => `${Math.round(duration)}秒`,
    },
    {
      title: '生成状态',
      dataIndex: 'generation_status',
      key: 'generation_status',
      width: 120,
      align: 'center',
      render: (status: string, record: DailyReport) => {
        const statusConfig: Record<string, { color: string; icon: any; text: string }> = {
          completed: { color: 'success', icon: <CheckCircleOutlined />, text: '已完成' },
          processing: { color: 'processing', icon: <Spin size="small" />, text: '生成中' },
          failed: { color: 'error', icon: <CloseCircleOutlined />, text: '失败' },
          pending: { color: 'default', icon: null, text: '待生成' },
        };
        const config = statusConfig[status] || statusConfig.pending;
        return (
          <Tag icon={config.icon} color={config.color}>
            {config.text}
            {status === 'failed' && record.retry_count > 0 && ` (${record.retry_count}/${3})`}
          </Tag>
        );
      },
    },
    {
      title: '标签',
      dataIndex: 'daily_tag',
      key: 'daily_tag',
      width: 120,
      align: 'center',
      render: (tag: string, record: DailyReport) => {
        if (record.generation_status !== 'completed' || !tag) return '-';
        
        // 根据标签类型设置不同的颜色
        const tagColors: Record<string, string> = {
          '精力过剩': 'red',
          '岁月静好': 'green',
          '饭桶': 'orange',
          '活力满满': 'volcano',
          '懒洋洋': 'blue',
          '好奇宝宝': 'purple',
          '安静天使': 'cyan',
          '调皮捣蛋': 'magenta',
        };
        
        return <Tag color={tagColors[tag] || 'default'}>{tag}</Tag>;
      },
    },
    {
      title: '日报摘要',
      dataIndex: 'summary',
      key: 'summary',
      width: 300,
      ellipsis: true,
      render: (text: string, record: DailyReport) => (
        <div style={{ maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {record.generation_status === 'completed' ? (text || '暂无摘要') : 
           record.generation_status === 'failed' ? (record.error_message || '生成失败') : 
           '生成中...'}
        </div>
      ),
    },
    {
      title: '洞察建议',
      dataIndex: 'insight_text',
      key: 'insight_text',
      width: 250,
      ellipsis: true,
      render: (text: string, record: DailyReport) => {
        if (record.generation_status !== 'completed' || !text) return '-';
        return (
          <div style={{ maxWidth: 250, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {text}
          </div>
        );
      },
    },
    {
      title: '生成时间',
      dataIndex: 'created_at',
      key: 'created_at',
      width: 180,
      render: (text: string) => dayjs(text).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: '操作',
      key: 'action',
      width: 100,
      fixed: 'right',
      render: (_: any, record: DailyReport) => (
        <Button type="link" size="small" onClick={() => handleViewDetail(record)}>
          查看详情
        </Button>
      ),
    },
  ];

  return (
    <div style={{ padding: '24px' }}>
      {/* 日报生成器状态面板 */}
      <Card
        title={
          <Space>
            <FileTextOutlined />
            <span>日报生成器状态</span>
            {statusLoading && <Spin size="small" />}
          </Space>
        }
        extra={
          <Space>
            <Button
              size="small"
              icon={<ReloadOutlined />}
              onClick={fetchGeneratorStatus}
              loading={statusLoading}
            >
              刷新状态
            </Button>
            {generatorStatus?.worker_running ? (
              <Button
                size="small"
                danger
                icon={<PauseCircleOutlined />}
                onClick={handleStopGenerator}
                loading={operationLoading}
              >
                停止服务
              </Button>
            ) : (
              <Button
                size="small"
                type="primary"
                icon={<PlayCircleOutlined />}
                onClick={handleStartGenerator}
                loading={operationLoading}
              >
                启动服务
              </Button>
            )}
            <Button
              size="small"
              type="default"
              onClick={handleManualGenerate}
              loading={operationLoading}
              disabled={!generatorStatus?.worker_running}
            >
              立即生成
            </Button>
          </Space>
        }
        style={{ marginBottom: 16 }}
      >
        {generatorStatus ? (
          <>
            <Alert
              message={
                generatorStatus.worker_running ? (
                  <Space>
                    <CheckCircleOutlined style={{ color: '#52c41a' }} />
                    <span>服务运行中</span>
                  </Space>
                ) : (
                  <Space>
                    <CloseCircleOutlined style={{ color: '#ff4d4f' }} />
                    <span>服务已停止</span>
                  </Space>
                )
              }
              type={generatorStatus.worker_running ? 'success' : 'warning'}
              showIcon={false}
              style={{ marginBottom: 16 }}
            />
            
            <Row gutter={16}>
              <Col span={4}>
                <Statistic
                  title="今日生成"
                  value={generatorStatus.today_reports_count}
                  suffix="条"
                />
              </Col>
              <Col span={4}>
                <Statistic
                  title="累计总数"
                  value={generatorStatus.total_reports_count}
                  suffix="条"
                />
              </Col>
              <Col span={4}>
                <Statistic
                  title="正在处理"
                  value={generatorStatus.processing_count}
                  suffix="个"
                  valueStyle={{ color: generatorStatus.processing_count > 0 ? '#1890ff' : undefined }}
                />
              </Col>
              <Col span={4}>
                <Statistic
                  title="队列等待"
                  value={generatorStatus.queue_size}
                  suffix="个"
                  valueStyle={{ color: generatorStatus.queue_size > 0 ? '#faad14' : undefined }}
                />
              </Col>
              <Col span={4}>
                <Statistic
                  title="最大并发"
                  value={generatorStatus.config.max_concurrent}
                  suffix="个"
                />
              </Col>
              <Col span={4}>
                <Statistic
                  title="今日失败"
                  value={generatorStatus.status_stats?.failed || 0}
                  suffix="条"
                  valueStyle={{ color: (generatorStatus.status_stats?.failed || 0) > 0 ? '#ff4d4f' : undefined }}
                />
              </Col>
            </Row>
            
            <Row gutter={16} style={{ marginTop: 16 }}>
              <Col span={8}>
                <Card type="inner" size="small">
                  <Statistic
                    title="最后生成时间"
                    value={
                      generatorStatus.last_generation_time
                        ? dayjs(generatorStatus.last_generation_time).format('YYYY-MM-DD HH:mm:ss')
                        : '从未生成'
                    }
                    valueStyle={{ fontSize: 14 }}
                  />
                </Card>
              </Col>
              <Col span={8}>
                <Card type="inner" size="small">
                  <Statistic
                    title="高峰时段调度"
                    value={`${generatorStatus.config.peak_hours} / ${generatorStatus.config.peak_interval_minutes}分钟`}
                    valueStyle={{ fontSize: 14 }}
                  />
                </Card>
              </Col>
              <Col span={8}>
                <Card type="inner" size="small">
                  <Statistic
                    title="低峰时段调度"
                    value={`${generatorStatus.config.off_peak_interval_minutes}分钟`}
                    valueStyle={{ fontSize: 14 }}
                  />
                </Card>
              </Col>
            </Row>
          </>
        ) : (
          <div style={{ textAlign: 'center', padding: '20px' }}>
            <Spin tip="加载状态中..." />
          </div>
        )}
      </Card>

      {/* 日报列表 */}
      <Card
        title={
          <Space>
            <FileTextOutlined />
            <span>宠物日报</span>
            <Tag color="blue">{total} 条记录</Tag>
          </Space>
        }
        extra={
          <Space wrap>
            <Input
              placeholder="宠物名称"
              value={searchPetName}
              onChange={(e) => setSearchPetName(e.target.value)}
              style={{ width: 150 }}
            />
            <DatePicker
              placeholder="选择日期"
              value={searchDate}
              onChange={(date) => setSearchDate(date)}
              format="YYYY-MM-DD"
            />
            <Button type="primary" icon={<SearchOutlined />} onClick={handleSearch}>
              搜索
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Space>
        }
      >
        <Table
          columns={columns}
          dataSource={reports}
          loading={loading}
          rowKey={(record) => record.id}
          pagination={{
            current: currentPage,
            pageSize: pageSize,
            total: total,
            showSizeChanger: false,
            showTotal: (total) => `共 ${total} 条记录`,
            onChange: (page) => fetchReports(page),
          }}
          scroll={{ x: 1200 }}
        />
      </Card>

      {/* 详情模态框 */}
      <Modal
        title={
          <Space>
            <FileTextOutlined />
            <span>日报详情</span>
          </Space>
        }
        open={detailModalVisible}
        onCancel={() => setDetailModalVisible(false)}
        footer={[
          <Button key="close" onClick={() => setDetailModalVisible(false)}>
            关闭
          </Button>,
        ]}
        width={800}
      >
        {selectedReport && (
          <div>
            {/* 基本信息 */}
            <Card type="inner" title="基本信息" style={{ marginBottom: 16 }}>
              <Row gutter={16}>
                <Col span={8}>
                  <Statistic title="日期" value={selectedReport.date} />
                </Col>
                <Col span={8}>
                  <Statistic title="宠物名称" value={selectedReport.pet_name} />
                </Col>
                <Col span={8}>
                  <Statistic title="用户DID" value={selectedReport.did} />
                </Col>
              </Row>
              <Row gutter={16} style={{ marginTop: 16 }}>
                <Col span={6}>
                  <Statistic title="视频片段数" value={selectedReport.video_count} />
                </Col>
                <Col span={6}>
                  <Statistic 
                    title="总时长" 
                    value={Math.round(selectedReport.total_duration)} 
                    suffix="秒" 
                  />
                </Col>
                <Col span={6}>
                  <Statistic 
                    title="生成时间" 
                    value={dayjs(selectedReport.created_at).format('HH:mm:ss')} 
                  />
                </Col>
                <Col span={6}>
                  <div>
                    <div style={{ color: 'rgba(0, 0, 0, 0.45)', fontSize: 14, marginBottom: 4 }}>
                      生成状态
                    </div>
                    {selectedReport.generation_status === 'completed' && (
                      <Tag icon={<CheckCircleOutlined />} color="success">已完成</Tag>
                    )}
                    {selectedReport.generation_status === 'processing' && (
                      <Tag icon={<Spin size="small" />} color="processing">生成中</Tag>
                    )}
                    {selectedReport.generation_status === 'failed' && (
                      <Tag icon={<CloseCircleOutlined />} color="error">
                        失败 ({selectedReport.retry_count}/3)
                      </Tag>
                    )}
                    {selectedReport.generation_status === 'pending' && (
                      <Tag color="default">待生成</Tag>
                    )}
                  </div>
                </Col>
              </Row>
            </Card>

            {/* 错误信息（如果有） */}
            {selectedReport.generation_status === 'failed' && selectedReport.error_message && (
              <Alert
                message="生成失败"
                description={selectedReport.error_message}
                type="error"
                showIcon
                style={{ marginBottom: 16 }}
              />
            )}

            {/* 日报标签 */}
            {selectedReport.generation_status === 'completed' && selectedReport.daily_tag && (
              <Card type="inner" title="今日标签" style={{ marginBottom: 16 }}>
                <div style={{ textAlign: 'center', padding: '10px' }}>
                  <Tag 
                    color={
                      selectedReport.daily_tag === '精力过剩' ? 'red' :
                      selectedReport.daily_tag === '岁月静好' ? 'green' :
                      selectedReport.daily_tag === '饭桶' ? 'orange' :
                      selectedReport.daily_tag === '活力满满' ? 'volcano' :
                      selectedReport.daily_tag === '懒洋洋' ? 'blue' :
                      selectedReport.daily_tag === '好奇宝宝' ? 'purple' :
                      selectedReport.daily_tag === '安静天使' ? 'cyan' :
                      selectedReport.daily_tag === '调皮捣蛋' ? 'magenta' : 'default'
                    }
                    style={{ fontSize: 18, padding: '8px 20px' }}
                  >
                    {selectedReport.daily_tag}
                  </Tag>
                </div>
              </Card>
            )}

            {/* 日报摘要 */}
            <Card type="inner" title="今日摘要" style={{ marginBottom: 16 }}>
              {selectedReport.generation_status === 'completed' ? (
                <div 
                  style={{ lineHeight: 1.8, fontSize: 15 }}
                  dangerouslySetInnerHTML={{
                    __html: (selectedReport.summary || '暂无内容')
                      .replace(/\*\*(.*?)\*\*/g, '<strong style="color: #1890ff;">$1</strong>')
                  }}
                />
              ) : selectedReport.generation_status === 'processing' ? (
                <div style={{ textAlign: 'center', padding: '40px' }}>
                  <Spin tip="正在生成日报，请稍候..." />
                </div>
              ) : selectedReport.generation_status === 'failed' ? (
                <Alert
                  message="日报生成失败"
                  description="请查看上方错误信息，或稍后重试"
                  type="warning"
                  showIcon
                />
              ) : (
                <Alert
                  message="日报待生成"
                  description="日报将在定时任务中自动生成"
                  type="info"
                  showIcon
                />
              )}
            </Card>

            {/* 洞察建议 */}
            {selectedReport.generation_status === 'completed' && selectedReport.insight_text && (
              <Card type="inner" title="💡 洞察建议" style={{ marginBottom: 16 }}>
                <Alert
                  message={selectedReport.insight_text}
                  type="info"
                  showIcon
                  style={{ fontSize: 14 }}
                />
              </Card>
            )}

            {/* LLM原始数据（用于调试和追踪） */}
            {(selectedReport.llm_request || selectedReport.llm_response) && (
              <Collapse
                items={[
                  {
                    key: 'llm-data',
                    label: (
                      <Space>
                        <CodeOutlined />
                        <span>LLM原始数据（用于调试）</span>
                      </Space>
                    ),
                    children: (
                      <div>
                        {/* LLM请求 */}
                        {selectedReport.llm_request && (
                          <Card type="inner" title="📤 LLM请求提示词" size="small" style={{ marginBottom: 12 }}>
                            <pre style={{ 
                              whiteSpace: 'pre-wrap', 
                              wordBreak: 'break-word',
                              backgroundColor: '#f5f5f5',
                              padding: 12,
                              borderRadius: 4,
                              fontSize: 12,
                              maxHeight: 300,
                              overflow: 'auto'
                            }}>
                              {selectedReport.llm_request}
                            </pre>
                          </Card>
                        )}

                        {/* LLM响应 */}
                        {selectedReport.llm_response && (
                          <Card type="inner" title="📥 LLM原始响应" size="small">
                            <pre style={{ 
                              whiteSpace: 'pre-wrap', 
                              wordBreak: 'break-word',
                              backgroundColor: '#f5f5f5',
                              padding: 12,
                              borderRadius: 4,
                              fontSize: 12,
                              maxHeight: 300,
                              overflow: 'auto'
                            }}>
                              {selectedReport.llm_response}
                            </pre>
                          </Card>
                        )}
                      </div>
                    ),
                  },
                ]}
              />
            )}

            {/* 更新时间 */}
            <div style={{ marginTop: 16, textAlign: 'right', color: '#999' }}>
              最后更新: {dayjs(selectedReport.updated_at).format('YYYY-MM-DD HH:mm:ss')}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default DailyReports;
