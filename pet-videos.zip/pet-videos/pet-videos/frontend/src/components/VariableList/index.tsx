/**
 * 变量列表展示组件
 * 用于在提示词编辑界面展示所有可用变量
 */
import React, { useState } from 'react';
import { Card, Collapse, Space, Tag, Button, message, Typography, Empty } from 'antd';
import { InfoCircleOutlined, CopyOutlined, BulbOutlined } from '@ant-design/icons';
import {
  getAvailableVariables,
  groupVariablesByCategory,
  CATEGORY_LABELS,
  VariableCategory,
  type VariableContext,
  type VariableDefinition
} from '../../utils/variableConfig';

const { Text, Paragraph } = Typography;

interface VariableListProps {
  context: VariableContext;
}

const VariableList: React.FC<VariableListProps> = ({ context }) => {
  // 获取所有可用变量
  const availableVariables = getAvailableVariables(context);
  const groupedVariables = groupVariablesByCategory(availableVariables);

  // 复制变量名到剪贴板
  const handleCopy = (varName: string) => {
    const textToCopy = `{{${varName}}}`;
    navigator.clipboard.writeText(textToCopy).then(() => {
      message.success(`已复制：${textToCopy}`);
    }).catch(() => {
      message.error('复制失败');
    });
  };

  // 渲染变量项
  const renderVariableItem = (variable: VariableDefinition) => (
    <div
      key={variable.name}
      style={{
        padding: '12px',
        marginBottom: '8px',
        background: '#fafafa',
        border: '1px solid #e8e8e8',
        borderRadius: '4px',
      }}
    >
      <Space direction="vertical" style={{ width: '100%' }} size="small">
        {/* 变量名 */}
        <Space>
          <Tag
            color="blue"
            style={{
              fontFamily: 'monospace',
              fontSize: '13px',
              cursor: 'pointer',
            }}
            onClick={() => handleCopy(variable.name)}
          >
            {`{{${variable.name}}}`}
          </Tag>
          <Button
            type="link"
            size="small"
            icon={<CopyOutlined />}
            onClick={() => handleCopy(variable.name)}
            style={{ padding: 0, height: 'auto' }}
          >
            复制
          </Button>
        </Space>

        {/* 显示名称 */}
        <Text strong style={{ fontSize: '13px' }}>
          {variable.displayName}
        </Text>

        {/* 描述 */}
        <Paragraph
          type="secondary"
          style={{
            margin: 0,
            fontSize: '12px',
            lineHeight: '1.5',
          }}
        >
          {variable.description}
        </Paragraph>

        {/* 示例 */}
        {variable.example && (
          <div
            style={{
              padding: '6px 8px',
              background: '#fff',
              border: '1px solid #d9d9d9',
              borderRadius: '3px',
              fontSize: '12px',
              fontFamily: 'monospace',
              color: '#666',
            }}
          >
            示例：{variable.example}
          </div>
        )}
      </Space>
    </div>
  );

  // 渲染分类折叠面板
  const renderCategoryPanel = (category: VariableCategory) => {
    const variables = groupedVariables[category];
    
    if (variables.length === 0) {
      return null;
    }

    return {
      key: category,
      label: (
        <Space>
          <span>{CATEGORY_LABELS[category]}</span>
          <Tag color="cyan">{variables.length}</Tag>
        </Space>
      ),
      children: (
        <div>
          {variables.map(renderVariableItem)}
        </div>
      ),
    };
  };

  const collapseItems = [
    VariableCategory.PET,
    VariableCategory.SYSTEM,
    VariableCategory.USER,
  ]
    .map(renderCategoryPanel)
    .filter(Boolean) as any[];

  return (
    <Card
      title={
        <Space>
          <BulbOutlined />
          <span>可用变量</span>
        </Space>
      }
      size="small"
    >
      <Space direction="vertical" style={{ width: '100%' }} size="middle">
        {/* 使用说明 */}
        <div
          style={{
            padding: '12px',
            background: '#e6f7ff',
            border: '1px solid #91d5ff',
            borderRadius: '4px',
          }}
        >
          <Space direction="vertical" size="small" style={{ width: '100%' }}>
            <Space>
              <InfoCircleOutlined style={{ color: '#1890ff' }} />
              <Text strong style={{ fontSize: '13px' }}>
                使用方法
              </Text>
            </Space>
            <ul style={{ margin: 0, paddingLeft: 20, fontSize: '12px', lineHeight: '1.8' }}>
              <li>在提示词中使用 <Tag color="blue" style={{ fontSize: '11px' }}>{'{{变量名}}'}</Tag> 格式插入变量</li>
              <li>变量会在实际使用时被替换为对应的值</li>
              <li>点击变量名或「复制」按钮可快速复制到剪贴板</li>
              <li>无法替换的变量会保持原样输出</li>
            </ul>
          </Space>
        </div>

        {/* 变量列表 */}
        {collapseItems.length > 0 ? (
          <Collapse
            size="small"
            defaultActiveKey={[VariableCategory.PET]}
            items={collapseItems}
          />
        ) : (
          <Empty
            description="暂无可用变量"
            image={Empty.PRESENTED_IMAGE_SIMPLE}
          />
        )}
      </Space>
    </Card>
  );
};

export default VariableList;
