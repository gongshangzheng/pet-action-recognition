import React from 'react';
import { Card, Select, Space, Tag } from 'antd';
import { FolderOutlined } from '@ant-design/icons';
import type { DirectoryInfo } from '../../types';

interface DirectorySelectorProps {
  directories: DirectoryInfo[];
  selectedAlias: string | null;
  onSelectDirectory: (alias: string) => void;
  loading?: boolean;
}

const DirectorySelector: React.FC<DirectorySelectorProps> = ({
  directories,
  selectedAlias,
  onSelectDirectory,
  loading = false,
}) => {
  return (
    <Card
      title={
        <Space>
          <FolderOutlined />
          <span>选择视频目录</span>
        </Space>
      }
      size="small"
    >
      <Select
        style={{ width: '100%' }}
        placeholder="选择一个目录"
        value={selectedAlias}
        onChange={onSelectDirectory}
        loading={loading}
        options={directories.map((dir) => ({
          value: dir.alias,
          label: (
            <Space>
              <span>{dir.alias}</span>
              {dir.name !== dir.alias && <span style={{ color: '#999', fontSize: '12px' }}>({dir.name})</span>}
              <Tag color={dir.exists ? 'green' : 'red'}>
                {dir.exists ? `${dir.video_count} 视频` : '不存在'}
              </Tag>
            </Space>
          ),
          disabled: !dir.exists || dir.video_count === 0,
        }))}
      />
    </Card>
  );
};

export default DirectorySelector;
