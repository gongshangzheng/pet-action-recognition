import React, { useState } from 'react';
import { Card, Descriptions, Tag, Typography, Space, Divider, Row, Col, Statistic, Button } from 'antd';
import { CheckCircleOutlined, InfoCircleOutlined } from '@ant-design/icons';
import type { AnalysisResponse } from '../../types';

const { Text, Paragraph } = Typography;

interface ResultDisplayProps {
  result: AnalysisResponse | null;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result }) => {
  const [detailExpanded, setDetailExpanded] = useState(false);

  if (!result) {
    return null;
  }

  return (
    <Card
      title={
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Space>
            <CheckCircleOutlined style={{ color: '#52c41a' }} />
            <span>分析结果</span>
            <Tag color="red" style={{ fontSize: 14, fontWeight: 'bold', margin: 0 }}>
              ¥{result.actual.cost.toFixed(6)}
            </Tag>
          </Space>
          <Button
            type="link"
            size="small"
            icon={<InfoCircleOutlined />}
            onClick={() => setDetailExpanded(!detailExpanded)}
            style={{ padding: 0 }}
          >
            {detailExpanded ? '收起详情' : '查看详情'}
          </Button>
        </div>
      }
      size="small"
    >
      {detailExpanded && (
        <>
          {/* Token 统计 */}
          <Row gutter={16} style={{ marginBottom: 16 }}>
            <Col span={8}>
              <Statistic
                title="输入Token"
                value={result.actual.input_tokens}
                valueStyle={{ color: '#1890ff', fontSize: 20 }}
              />
            </Col>
            <Col span={8}>
              <Statistic
                title="输出Token"
                value={result.actual.output_tokens}
                valueStyle={{ color: '#52c41a', fontSize: 20 }}
              />
            </Col>
            <Col span={8}>
              <Statistic
                title="总Token"
                value={result.actual.total_tokens}
                valueStyle={{ fontSize: 20 }}
              />
            </Col>
          </Row>

          <div style={{ fontSize: 12, color: '#888', marginBottom: 16 }}>
            <Space split={<Divider type="vertical" />}>
              <span>输入费用: ¥{result.actual.breakdown.input_cost.toFixed(6)}</span>
              <span>输出费用: ¥{result.actual.breakdown.output_cost.toFixed(6)}</span>
            </Space>
          </div>

          {/* 统计信息 */}
          <Descriptions size="small" column={2} bordered>
            <Descriptions.Item label="处理时长">
              {result.statistics.duration_sec.toFixed(2)}秒
            </Descriptions.Item>
            <Descriptions.Item label="预估准确率">
              <Tag color={result.statistics.accuracy_rate >= 95 ? 'green' : 'orange'}>
                {result.statistics.accuracy_rate.toFixed(1)}%
              </Tag>
            </Descriptions.Item>
            <Descriptions.Item label="每帧Token">
              {result.statistics.tokens_per_frame.toFixed(1)}
            </Descriptions.Item>
            <Descriptions.Item label="处理速度">
              {result.statistics.processing_speed.toFixed(0)} tokens/s
            </Descriptions.Item>
            <Descriptions.Item label="每帧费用">
              ¥{result.statistics.cost_per_frame.toFixed(6)}
            </Descriptions.Item>
            <Descriptions.Item label="每秒费用">
              ¥{result.statistics.cost_per_second.toFixed(6)}
            </Descriptions.Item>
          </Descriptions>
          <Divider style={{ margin: '16px 0' }} />
        </>
      )}

      {/* 模型回复 */}
      <div>
        <Text strong>模型回复:</Text>
        <Card
          size="small"
          style={{ marginTop: 8, background: '#f5f5f5' }}
          styles={{ body: { maxHeight: 400, overflow: 'auto' } }}
        >
          <Paragraph style={{ whiteSpace: 'pre-wrap', margin: 0 }}>
            {result.model_response}
          </Paragraph>
        </Card>
      </div>
    </Card>
  );
};

export default ResultDisplay;
