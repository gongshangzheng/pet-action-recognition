import React, { useState, useEffect } from 'react';
import { Table, Card, Button, Space, Tag, Modal, List, Spin, Empty, Pagination } from 'antd';
import { BarChartOutlined, PlayCircleOutlined } from '@ant-design/icons';
import { getVideoStats, getVideosByDate } from '../../services/api';
import type { DirectoryStat, VideoInfo } from '../../types';

const SliceStats: React.FC = () => {
  const [stats, setStats] = useState<DirectoryStat[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedVideos, setSelectedVideos] = useState<VideoInfo[]>([]);
  const [loadingVideos, setLoadingVideos] = useState(false);
  const [previewVideo, setPreviewVideo] = useState<VideoInfo | null>(null);
  const [viewingDate, setViewingDate] = useState<{ alias: string; name: string; date: string } | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [totalVideos, setTotalVideos] = useState(0);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    setLoading(true);
    try {
      const data = await getVideoStats();
      setStats(data);
    } catch (error) {
      console.error('Failed to load stats', error);
    } finally {
      setLoading(false);
    }
  };

  const handleShowVideos = async (alias: string, name: string, date: string, page: number = 1) => {
    setViewingDate({ alias, name, date });
    setCurrentPage(page);
    setLoadingVideos(true);
    try {
      const response = await getVideosByDate(alias, date, page, pageSize);
      setSelectedVideos(response.videos);
      setTotalVideos(response.total);
    } catch (error) {
      console.error('Failed to load videos', error);
    } finally {
      setLoadingVideos(false);
    }
  };

  const handlePageChange = (page: number, newPageSize?: number) => {
    if (viewingDate) {
      if (newPageSize && newPageSize !== pageSize) {
        setPageSize(newPageSize);
        handleShowVideos(viewingDate.alias, viewingDate.name, viewingDate.date, 1);
      } else {
        handleShowVideos(viewingDate.alias, viewingDate.name, viewingDate.date, page);
      }
    }
  };

  const handlePlay = (video: VideoInfo) => {
    setPreviewVideo(video);
  };

  const columns = [
    {
      title: '目录',
      dataIndex: 'alias',
      key: 'alias',
      width: '200px',
      render: (text: string, record: DirectoryStat) => (
        <Space>
          <span>{text}</span>
          {record.name !== record.alias && <span style={{ color: '#999', fontSize: '12px' }}>({record.name})</span>}
        </Space>
      )
    },
    {
      title: '自然日统计 (点击日期查看视频)',
      key: 'daily_stats',
      render: (_: any, record: DirectoryStat) => (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', padding: '8px 0' }}>
          {record.daily_stats.map((stat) => (
            <Button 
              key={stat.date} 
              size="small" 
              onClick={() => handleShowVideos(record.alias, record.name, stat.date)}
              style={{ height: 'auto', padding: '4px 8px' }}
            >
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '12px' }}>{stat.date}</div>
                <Tag color="blue" style={{ margin: '2px 0 0 0' }}>{stat.count} 切片</Tag>
              </div>
            </Button>
          ))}
          {record.daily_stats.length === 0 && <span style={{ color: '#999' }}>暂无视频</span>}
        </div>
      ),
    },
  ];

  return (
    <div className="slice-stats">
      <Card 
        title={
          <Space>
            <BarChartOutlined />
            <span>切片数量统计</span>
          </Space>
        }
        size="small"
      >
        <Table 
          dataSource={stats} 
          columns={columns} 
          rowKey="alias" 
          loading={loading}
          pagination={false}
          size="small"
          bordered
        />
      </Card>

      <Modal
        title={
          <Space>
            <span>{viewingDate ? `${viewingDate.date} 视频列表 (${viewingDate.name})` : '视频列表'}</span>
            {totalVideos > 0 && <Tag color="blue">共 {totalVideos} 个</Tag>}
          </Space>
        }
        open={!!viewingDate}
        onCancel={() => {
          setViewingDate(null);
          setCurrentPage(1);
        }}
        footer={null}
        width={900}
        destroyOnHidden
        centered
      >
        <div style={{ maxHeight: '60vh', overflow: 'auto' }}>
          <Spin spinning={loadingVideos}>
            <List
              dataSource={selectedVideos}
              renderItem={(video) => (
                <List.Item
                  extra={
                    <Button
                      type="primary"
                      icon={<PlayCircleOutlined />}
                      onClick={() => handlePlay(video)}
                      size="small"
                    >
                      播放
                    </Button>
                  }
                >
                  <List.Item.Meta
                    title={video.filename}
                    description={
                      <Space direction="vertical" size="small">
                        <Space size="small" wrap>
                          <Tag>{video.resolution}</Tag>
                          <Tag color="green">{video.duration_formatted}</Tag>
                          <Tag>{video.size_mb.toFixed(2)} MB</Tag>
                          <Tag>{video.fps.toFixed(1)} FPS</Tag>
                          <Tag color="cyan">{video.codec}</Tag>
                        </Space>
                        {video.created_at && (
                          <span style={{ color: '#999', fontSize: '12px' }}>
                            创建时间: {new Date(video.created_at).toLocaleString('zh-CN')}
                          </span>
                        )}
                      </Space>
                    }
                  />
                </List.Item>
              )}
              locale={{ emptyText: <Empty description="该日期下无视频" /> }}
            />
          </Spin>
        </div>
        {totalVideos > pageSize && (
          <div style={{ marginTop: 16, textAlign: 'center' }}>
            <Pagination
              current={currentPage}
              pageSize={pageSize}
              total={totalVideos}
              onChange={handlePageChange}
              onShowSizeChange={handlePageChange}
              showSizeChanger
              showQuickJumper
              showTotal={(total) => `共 ${total} 个视频`}
              pageSizeOptions={['20', '50', '100', '200']}
            />
          </div>
        )}
      </Modal>

      <Modal
        title={
          <Space>
            <PlayCircleOutlined />
            <span>{previewVideo?.filename}</span>
          </Space>
        }
        open={!!previewVideo}
        onCancel={() => setPreviewVideo(null)}
        footer={null}
        width={800}
        centered
        destroyOnHidden
      >
        {previewVideo && (
          <div style={{ background: '#000', borderRadius: '4px' }}>
            <video
              controls
              autoPlay
              style={{ width: '100%', maxHeight: '60vh' }}
              src={`/api/video/stream?token=${encodeURIComponent(previewVideo.stream_token)}`}
            >
              您的浏览器不支持视频播放
            </video>
            <div style={{ padding: '12px', background: '#f5f5f5' }}>
              <Space size="small" wrap>
                <Tag color="blue">{previewVideo.resolution}</Tag>
                <Tag color="green">{previewVideo.duration_formatted}</Tag>
                <Tag>{previewVideo.size_mb.toFixed(2)} MB</Tag>
                <Tag>{previewVideo.fps.toFixed(1)} FPS</Tag>
                <Tag>{previewVideo.codec}</Tag>
                <Tag>{previewVideo.bitrate_mbps.toFixed(2)} Mbps</Tag>
              </Space>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default SliceStats;
