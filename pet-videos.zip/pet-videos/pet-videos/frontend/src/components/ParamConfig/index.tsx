import React, { useEffect, useState } from 'react';
import { Collapse, Form, Slider, InputNumber, Switch, Space, Tag, Select, Spin, Card, Typography, Alert, Button } from 'antd';
import { SettingOutlined, CopyOutlined, ReloadOutlined, InfoCircleOutlined } from '@ant-design/icons';
import { getAvailableModels } from '../../services/api';
import { getPets } from '../../services/petApi';
import type { ModelInfo } from '../../types';
import type { Pet } from '../../types/pet';

const { Text } = Typography;

interface ParamConfigProps {
  fps: number;
  maxPixels: number;
  minPixels: number;
  vlHighResolutionImages: boolean;
  modelName: string;
  selectedDid?: string | null;  // 新增：当前选中目录的用户ID
  onFpsChange: (value: number) => void;
  onMaxPixelsChange: (value: number) => void;
  onMinPixelsChange: (value: number) => void;
  onVlHighResolutionImagesChange: (value: boolean) => void;
  onModelNameChange: (value: string) => void;
}

const ParamConfig: React.FC<ParamConfigProps> = ({
  fps,
  maxPixels,
  minPixels,
  vlHighResolutionImages,
  modelName,
  selectedDid,
  onFpsChange,
  onMaxPixelsChange,
  onMinPixelsChange,
  onVlHighResolutionImagesChange,
  onModelNameChange,
}) => {
  const [models, setModels] = useState<ModelInfo[]>([]);
  const [loadingModels, setLoadingModels] = useState(false);
  const [pets, setPets] = useState<Pet[]>([]);
  const [loadingPets, setLoadingPets] = useState(false);
  const [petsError, setPetsError] = useState<string | null>(null);

  // 加载可用模型列表
  useEffect(() => {
    const loadModels = async () => {
      setLoadingModels(true);
      try {
        const modelList = await getAvailableModels();
        setModels(modelList);
      } catch (error: any) {
        console.error('Failed to load models:', error);
        // 如果是网络错误或401，使用默认模型列表
        if (error.response?.status === 401 || !error.response) {
          console.warn('Using default model list');
          setModels([{
            name: 'qwen3-vl-plus',
            label: 'Qwen3-VL-Plus',
            description: '最新版本，更强视觉推理'
          }]);
        }
      } finally {
        setLoadingModels(false);
      }
    };
    loadModels();
  }, []);

  // 加载当前用户的宠物信息
  const loadPetsInfo = async (did?: string) => {
    setLoadingPets(true);
    setPetsError(null);
    try {
      // 使用传入的 did 参数加载对应用户的宠物
      const petList = await getPets(did);
      setPets(petList);
    } catch (error: any) {
      console.error('Failed to load pets:', error);
      setPetsError('加载宠物信息失败');
    } finally {
      setLoadingPets(false);
    }
  };

  // 当 selectedDid 变化时重新加载宠物
  useEffect(() => {
    if (selectedDid) {
      loadPetsInfo(selectedDid);
    }
  }, [selectedDid]);

  // 计算年龄（从出生日期）
  const calculateAge = (birthDate: string | undefined): string => {
    if (!birthDate) return '未知';
    
    try {
      const birth = new Date(birthDate);
      const now = new Date();
      
      let years = now.getFullYear() - birth.getFullYear();
      let months = now.getMonth() - birth.getMonth();
      
      if (months < 0) {
        years--;
        months += 12;
      }
      
      // 如果不满1岁，只显示月份
      if (years === 0) {
        return `${months}个月`;
      }
      
      // 如果月份为0，只显示年份
      if (months === 0) {
        return `${years}年`;
      }
      
      return `${years}年${months}个月`;
    } catch {
      return '未知';
    }
  };

  // 转换宠物信息用于显示（过滤字段并添加年龄）
  const formatPetsForDisplay = () => {
    return pets.map(pet => {
      const { did, avatar_url, created_at, updated_at, birth_date, ...rest } = pet;
      return {
        ...rest,
        age: calculateAge(birth_date), // 用年龄替代出生日期
      };
    });
  };

  // 复制宠物信息到剪贴板
  const handleCopyPets = () => {
    const displayPets = formatPetsForDisplay();
    const petsJson = JSON.stringify(displayPets, null, 2);
    navigator.clipboard.writeText(petsJson);
  };

  // 预设值
  const maxPixelsPresets = {
    low: 256 * 32 * 32,
    medium: 640 * 32 * 32,
    high: 1280 * 32 * 32,
    ultra: 2000 * 32 * 32,
  };

  const getMaxPixelsLabel = (value: number) => {
    if (value === maxPixelsPresets.low) return 'Low (256K)';
    if (value === maxPixelsPresets.medium) return 'Medium (640K)';
    if (value === maxPixelsPresets.high) return 'High (1280K)';
    if (value === maxPixelsPresets.ultra) return 'Ultra (2000K)';
    return `${Math.floor(value / 1024)}K`;
  };

  return (
    <Space direction="vertical" style={{ width: '100%' }} size="middle">
      <Collapse
        bordered={false}
        style={{ 
          background: '#fff',
          borderRadius: '8px',
          border: '1px solid #d9d9d9'
        }}
        items={[
          {
            key: 'params',
            label: (
              <Space>
                <SettingOutlined />
                <span>参数配置</span>
              </Space>
            ),
            children: (
              <Form layout="vertical">
                <Form.Item label="模型选择">
                  <Select
                    value={modelName}
                    onChange={onModelNameChange}
                    loading={loadingModels}
                    notFoundContent={loadingModels ? <Spin size="small" /> : '无可用模型'}
                    style={{ width: '100%' }}
                    placeholder="选择模型"
                  >
                    {models.map((model) => (
                      <Select.Option key={model.name} value={model.name} title={model.description}>
                        {model.label}
                      </Select.Option>
                    ))}
                  </Select>
                  {modelName && models.find(m => m.name === modelName) && (
                    <div style={{ fontSize: '12px', color: '#999', marginTop: '4px' }}>
                      {models.find(m => m.name === modelName)?.description}
                    </div>
                  )}
                </Form.Item>

                <Form.Item label={`FPS (抽帧频率): ${fps.toFixed(1)}`}>
                  <Slider
                    min={0.1}
                    max={10}
                    step={0.1}
                    value={fps}
                    onChange={onFpsChange}
                    marks={{
                      0.5: '0.5',
                      1: '1',
                      2: '2',
                      5: '5',
                      10: '10',
                    }}
                  />
                </Form.Item>

                <Form.Item label={`Max Pixels: ${getMaxPixelsLabel(maxPixels)}`}>
                  <Slider
                    min={maxPixelsPresets.low}
                    max={maxPixelsPresets.ultra}
                    step={32 * 32}
                    value={maxPixels}
                    onChange={onMaxPixelsChange}
                    marks={{
                      [maxPixelsPresets.low]: 'Low',
                      [maxPixelsPresets.medium]: 'Med',
                      [maxPixelsPresets.high]: 'High',
                      [maxPixelsPresets.ultra]: 'Ultra',
                    }}
                  />
                </Form.Item>

                <Form.Item label={`Min Pixels: ${Math.floor(minPixels / 1024)}K`}>
                  <InputNumber
                    style={{ width: '100%' }}
                    min={4 * 32 * 32}
                    max={maxPixels}
                    step={32 * 32}
                    value={minPixels}
                    onChange={(value) => value && onMinPixelsChange(value)}
                  />
                </Form.Item>

                <Form.Item label="高分辨率模式">
                  <Space>
                    <Switch
                      checked={vlHighResolutionImages}
                      onChange={onVlHighResolutionImagesChange}
                    />
                    {vlHighResolutionImages && (
                      <Tag color="red">高分辨率模式（max_pixels参数无效）</Tag>
                    )}
                  </Space>
                </Form.Item>
              </Form>
            ),
          },
        ]}
      />

      {/* 宠物信息区域 */}
      <Collapse
        size="small"
        defaultActiveKey={[]}
        bordered={false}
        style={{ 
          background: '#fff',
          borderRadius: '8px',
          border: '1px solid #d9d9d9'
        }}
        items={[
          {
            key: 'pets',
            label: (
              <Space>
                <InfoCircleOutlined />
                <Text strong>宠物信息</Text>
                <Tag color="blue" style={{ fontFamily: 'monospace' }}>
                  {'{{pets_info_list}}'}
                </Tag>
              </Space>
            ),
            extra: (
              <Space onClick={(e) => e.stopPropagation()}>
                <Button
                  size="small"
                  icon={<ReloadOutlined />}
                  onClick={() => loadPetsInfo(selectedDid || undefined)}
                  loading={loadingPets}
                >
                  刷新
                </Button>
                <Button
                  size="small"
                  icon={<CopyOutlined />}
                  onClick={handleCopyPets}
                  disabled={pets.length === 0}
                >
                  复制
                </Button>
              </Space>
            ),
            children: (
              <>
                {loadingPets ? (
                  <div style={{ textAlign: 'center', padding: '20px' }}>
                    <Spin />
                  </div>
                ) : petsError ? (
                  <Alert message={petsError} type="error" showIcon />
                ) : pets.length === 0 ? (
                  <Alert
                    message="暂无宠物信息"
                    description="请先在「宠物列表」标签页中添加宠物信息"
                    type="info"
                    showIcon
                  />
                ) : (
                  <div>
                    <Alert
                      message="提示"
                      description="在提示词中可以使用宠物信息，例如：根据下面的宠物特征分析视频中出现的是哪只宠物"
                      type="info"
                      showIcon
                      style={{ marginBottom: 12 }}
                    />
                    <pre
                      style={{
                        background: '#f5f5f5',
                        padding: '12px',
                        borderRadius: '4px',
                        maxHeight: '300px',
                        overflow: 'auto',
                        fontSize: '12px',
                        margin: 0,
                      }}
                    >
                      {JSON.stringify(formatPetsForDisplay(), null, 2)}
                    </pre>
                  </div>
                )}
              </>
            ),
          },
        ]}
      />
    </Space>
  );
};

export default ParamConfig;
