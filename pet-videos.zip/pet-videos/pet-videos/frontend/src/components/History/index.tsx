import React, { useState, useEffect } from 'react';
import {
  Card,
  Table,
  Button,
  Space,
  Tag,
  Popconfirm,
  message,
  Modal,
  Descriptions,
  Typography,
  Radio,
  Form,
  Input,
  DatePicker,
  Row,
  Col,
} from 'antd';
import {
  HistoryOutlined,
  DeleteOutlined,
  EyeOutlined,
  ReloadOutlined,
  UserOutlined,
  RobotOutlined,
  RetweetOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  LoadingOutlined,
  ExclamationCircleOutlined,
  SearchOutlined,
  UnorderedListOutlined,
} from '@ant-design/icons';
import dayjs from 'dayjs';
import type { HistoryRecord, HistoryDetail } from '../../types';
import { getHistory, getHistoryDetail, deleteHistory } from '../../services/api';
import { getLLMQueueStatus, retryLLMRecord } from '../../services/llmApi';
import QueueStatusCard from './QueueStatusCard';
import WorkerControlPanel from './WorkerControlPanel';

const { Paragraph } = Typography;
const { RangePicker } = DatePicker;

const History: React.FC = () => {
  const [records, setRecords] = useState<HistoryRecord[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState({ current: 1, pageSize: 10 });
  const [detailModalVisible, setDetailModalVisible] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<HistoryDetail | null>(null);
  const [callTypeFilter, setCallTypeFilter] = useState<string>('manual');  // 'manual' | 'auto' | 'auto-all'
  const [statusFilter] = useState<string>('all');  // 'all' | 'pending' | 'processing' | 'completed' | 'failed'
  const [queueStats, setQueueStats] = useState<any>(null);
  const [queryForm] = Form.useForm();
  const [searchFilters, setSearchFilters] = useState<{
    did?: string;
    filename?: string;
    date_from?: string;
    date_to?: string;
  }>({});

  const loadHistory = async (page = 1, pageSize = 10) => {
    setLoading(true);
    try {
      const offset = (page - 1) * pageSize;
      
      // 确定实际的call_type: auto-all仍然使用'auto'，但传递额外的查询条件
      const actualCallType = (callTypeFilter === 'auto-all' ? 'auto' : callTypeFilter) as 'manual' | 'auto';
      
      // 只在auto-all模式下传递查询条件
      const filters = callTypeFilter === 'auto-all' ? searchFilters : undefined;
      const queryAll = callTypeFilter === 'auto-all';  // 标识是否查询所有记录
      
      const { records: data, total: totalCount } = await getHistory(
        actualCallType, 
        pageSize, 
        offset,
        filters,
        queryAll
      );
      
      // 根据状态筛选（仅对自动调用有效）
      let filteredData = data;
      if (statusFilter !== 'all' && callTypeFilter === 'auto') {
        filteredData = data.filter(r => (r as any).llm_status === statusFilter);
      }
      
      setRecords(filteredData);
      setTotal(totalCount);
    } catch (error) {
      console.error('Failed to load history:', error);
      message.error(`加载历史记录失败: ${error}`);
    } finally {
      setLoading(false);
    }
  };

  const loadQueueStats = async () => {
    try {
      const response = await getLLMQueueStatus();
      if (response.success) {
        setQueueStats(response.data);
      }
    } catch (error) {
      console.error('Failed to load queue stats:', error);
      message.error(`加载队列状态失败: ${error}`);
    }
  };

  // 自动刷新函数，保持当前分页状态
  const autoRefresh = async () => {
    try {
      await Promise.all([
        loadQueueStats(),
        loadHistory(pagination.current, pagination.pageSize)
      ]);
    } catch (error) {
      console.error('Auto refresh failed:', error);
      // 不显示错误消息，因为loadQueueStats和loadHistory已经有各自的错误处理
    }
  };

  const handleRetry = async (recordId: number) => {
    try {
      await retryLLMRecord(recordId);
      message.success('已重置记录状态，将重新处理');
      loadHistory(pagination.current, pagination.pageSize);
    } catch (error) {
      message.error('重试失败');
    }
  };

  // 处理查询表单提交
  const handleSearch = (values: any) => {
    const filters: any = {};
    if (values.did) filters.did = values.did.trim();
    if (values.filename) filters.filename = values.filename.trim();
    if (values.dateRange && values.dateRange.length === 2) {
      filters.date_from = values.dateRange[0].format('YYYY-MM-DD');
      filters.date_to = values.dateRange[1].format('YYYY-MM-DD');
    }
    
    setSearchFilters(filters);
    setPagination({ current: 1, pageSize: pagination.pageSize });
    // loadHistory将在下一次render时自动调用，因为searchFilters改变了
  };

  // 重置查询条件
  const handleResetSearch = () => {
    queryForm.resetFields();
    setSearchFilters({});
    setPagination({ current: 1, pageSize: pagination.pageSize });
  };

  useEffect(() => {
    // 切换tab时重置查询条件和分页
    if (callTypeFilter === 'auto-all') {
      queryForm.resetFields();
      setSearchFilters({});
    }
    setPagination({ current: 1, pageSize: 10 });
    
    loadHistory(1, 10);
    // 如果显示自动分析，加载队列状态
    if (callTypeFilter === 'auto') {
      loadQueueStats();
    }
  }, [callTypeFilter, statusFilter]);

  // 当searchFilters改变时重新加载数据
  useEffect(() => {
    if (callTypeFilter === 'auto-all') {
      loadHistory(pagination.current, pagination.pageSize);
    }
  }, [searchFilters]);
  
  useEffect(() => {
    loadHistory();
    loadQueueStats();
  }, []);

  // 单独的useEffect处理队列状态和历史记录的同步自动刷新，依赖callTypeFilter
  useEffect(() => {
    let interval: number | null = null;
    
    // 只有在显示自动分析时才设置定时刷新
    if (callTypeFilter === 'auto') {
      loadQueueStats(); // 立即加载一次
      interval = setInterval(() => {
        // 同时刷新队列状态和调用历史，保持数据同步
        autoRefresh();
      }, 10000); // 每10秒同步刷新
    }
    
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [callTypeFilter]);

  const handleDelete = async (record: HistoryRecord) => {
    try {
      await deleteHistory(record.id, record.call_type as 'manual' | 'auto');
      message.success('删除成功');
      loadHistory(pagination.current, pagination.pageSize);
    } catch (error) {
      message.error('删除失败');
    }
  };

  // 查看提示词

  const showDetail = async (record: HistoryRecord) => {
    try {
      setLoading(true);
      const detailData = await getHistoryDetail(record.id, record.call_type as 'manual' | 'auto');
      setSelectedRecord(detailData);
      setDetailModalVisible(true);
    } catch (error) {
      message.error('加载详情失败');
    } finally {
      setLoading(false);
    }
  };

  const columns = [
    {
      title: '时间',
      dataIndex: 'created_at',
      key: 'created_at',
      width: 160,
      render: (time: string) => dayjs(time).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: '视频源',
      dataIndex: 'dir_alias',
      key: 'dir_alias',
      width: 120,
      render: (text: string) => text || '-',
    },
    {
      title: '调用类型',
      dataIndex: 'call_type',
      key: 'call_type',
      width: 100,
      render: (type: string) => {
        if (type === 'auto') {
          return <Tag icon={<RobotOutlined />} color="blue">自动</Tag>;
        }
        return <Tag icon={<UserOutlined />} color="green">手动</Tag>;
      },
    },
    {
      title: '状态',
      dataIndex: 'llm_status',
      key: 'llm_status',
      width: 100,
      render: (status: string, record: HistoryRecord) => {
        // 手动调用没有llm_status，默认显示为已完成
        if (record.call_type === 'manual') {
          return <Tag icon={<CheckCircleOutlined />} color="success">已完成</Tag>;
        }
        
        // 自动调用显示实际状态
        switch (status) {
          case 'pending':
            return <Tag icon={<ClockCircleOutlined />} color="default">等待中</Tag>;
          case 'processing':
            return <Tag icon={<LoadingOutlined />} color="processing">处理中</Tag>;
          case 'completed':
            return <Tag icon={<CheckCircleOutlined />} color="success">已完成</Tag>;
          case 'failed':
            return <Tag icon={<ExclamationCircleOutlined />} color="error">失败</Tag>;
          case 'error':
            return <Tag icon={<ExclamationCircleOutlined />} color="warning">错误</Tag>;
          default:
            // 如果有错误信息，显示为异常
            if (record.llm_error) {
              return <Tag icon={<ExclamationCircleOutlined />} color="error">异常</Tag>;
            }
            return <Tag color="default">{status || '未知'}</Tag>;
        }
      },
    },
    {
      title: '提示词',
      dataIndex: 'prompt',
      key: 'prompt',
      width: 200,
      render: (prompt: string) => {
        if (!prompt) {
          return <span style={{ color: '#999' }}>-</span>;
        }
        // 显示提示词预览（前50个字符）
        const preview = prompt.length > 50 ? prompt.substring(0, 50) + '...' : prompt;
        return (
          <div
            style={{ cursor: 'pointer', color: '#1890ff' }}
            onClick={() => {
              // 直接显示实际使用的提示词
              Modal.info({
                title: '实际使用的提示词',
                width: 700,
                content: (
                  <div style={{ 
                    whiteSpace: 'pre-wrap', 
                    wordBreak: 'break-word',
                    maxHeight: '500px',
                    overflowY: 'auto',
                    padding: '16px',
                    backgroundColor: '#f5f5f5',
                    borderRadius: '4px'
                  }}>
                    {prompt}
                  </div>
                ),
              });
            }}
          >
            {preview}
          </div>
        );
      },
    },
    {
      title: '模型',
      dataIndex: 'model_name',
      key: 'model_name',
      width: 200,
      render: (name: string) => {
        if (!name) {
          return <span style={{ color: '#999' }}>-</span>;
        }
        // 简化显示
        const displayName = name
          .replace('qwen2.5-vl-32b-instruct', 'Qwen2.5-VL-32B')
          .replace('qwen3-vl-plus', 'Qwen3-VL-Plus')
          .replace('qwen2-vl-72b-instruct', 'Qwen2-VL-72B')
          .replace('qwen2-vl-7b-instruct', 'Qwen2-VL-7B');
        return <Tag color="purple">{displayName}</Tag>;
      },
    },
    {
      title: '视频',
      dataIndex: 'video_name',
      key: 'video_name',
      width: 200,
      ellipsis: true,
    },
    {
      title: '重试次数',
      dataIndex: 'llm_retry_count',
      key: 'llm_retry_count',
      width: 90,
      render: (count: number) => {
        if (count === undefined || count === null || count === 0) {
          return <span style={{ color: '#999' }}>0</span>;
        }
        return <Tag color="warning">{count}</Tag>;
      },
    },
    {
      title: '错误信息',
      dataIndex: 'llm_error',
      key: 'llm_error',
      width: 180,
      render: (error: string) => {
        if (!error) {
          return <span style={{ color: '#999' }}>-</span>;
        }
        const preview = error.length > 30 ? error.substring(0, 30) + '...' : error;
        return (
          <div
            style={{ cursor: 'pointer', color: '#ff4d4f' }}
            onClick={() => {
              Modal.error({
                title: '错误详情',
                width: 600,
                content: (
                  <div style={{ 
                    whiteSpace: 'pre-wrap', 
                    wordBreak: 'break-word',
                    maxHeight: '400px',
                    overflowY: 'auto',
                    padding: '12px',
                    backgroundColor: '#fff2f0',
                    borderRadius: '4px',
                    border: '1px solid #ffccc7'
                  }}>
                    {error}
                  </div>
                ),
              });
            }}
          >
            {preview}
          </div>
        );
      },
    },
    {
      title: '时长',
      dataIndex: 'video_duration_sec',
      key: 'video_duration_sec',
      width: 80,
      render: (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
      },
    },
    {
      title: 'FPS',
      dataIndex: 'fps',
      key: 'fps',
      width: 60,
      render: (fps: number) => fps.toFixed(1),
    },
    {
      title: '输入Token',
      dataIndex: 'input_tokens',
      key: 'input_tokens',
      width: 100,
      render: (tokens: number) => tokens.toLocaleString(),
    },
    {
      title: '输出Token',
      dataIndex: 'output_tokens',
      key: 'output_tokens',
      width: 100,
      render: (tokens: number) => tokens.toLocaleString(),
    },
    {
      title: '费用',
      dataIndex: 'cost',
      key: 'cost',
      width: 100,
      render: (cost: number) => (
        <Tag color="green">¥{cost.toFixed(6)}</Tag>
      ),
    },
    {
      title: '操作',
      key: 'action',
      width: 180,
      fixed: 'right' as const,
      render: (_: any, record: HistoryRecord) => (
        <Space>
          <Button
            type="link"
            size="small"
            icon={<EyeOutlined />}
            onClick={() => showDetail(record)}
          >
            详情
          </Button>
          {/* 自动分析的失败记录显示重试按钮 */}
          {record.call_type === 'auto' && 
           ((record as any).llm_status === 'failed' || (record as any).llm_status === 'error') && (
            <Button
              type="link"
              size="small"
              icon={<RetweetOutlined />}
              onClick={() => handleRetry(record.id)}
            >
              重试
            </Button>
          )}
          {/* 删除按钮只在手动调用时显示 */}
          {record.call_type === 'manual' && (
            <Popconfirm
              title="确认删除？"
              onConfirm={() => handleDelete(record)}
              okText="确认"
              cancelText="取消"
            >
              <Button type="link" danger size="small" icon={<DeleteOutlined />}>
                删除
              </Button>
            </Popconfirm>
          )}
        </Space>
      ),
    },
  ];

  return (
    <>
      {/* Worker 控制面板 - 仅在显示自动分析时显示 */}
      {callTypeFilter === 'auto' && queueStats && (
        <WorkerControlPanel 
          workerRunning={queueStats.worker_running}
          systemEnabled={queueStats.system_enabled}
          config={{
            maxConcurrent: queueStats.config?.max_concurrent || 2,
            pollInterval: queueStats.config?.poll_interval || 10,
            maxRetries: queueStats.config?.max_retries || 3,
            timeWindowHours: queueStats.config?.time_window_hours || 25
          }}
          onStatusChange={autoRefresh}
        />
      )}

      {/* 队列状态卡片 - 仅在显示自动分析时显示 */}
      {callTypeFilter === 'auto' && queueStats && (
        <QueueStatusCard stats={{
          workerRunning: queueStats.worker_running,
          systemEnabled: queueStats.system_enabled,
          queueStats: queueStats.queue_stats,
          pendingInWindow: queueStats.pending_in_window,
          pendingOutsideWindow: queueStats.pending_outside_window,
          config: {
            maxConcurrent: queueStats.config?.max_concurrent || 2,
            pollInterval: queueStats.config?.poll_interval || 10,
            maxRetries: queueStats.config?.max_retries || 3,
            timeWindowHours: queueStats.config?.time_window_hours || 25,
            autoStart: queueStats.config?.auto_start || true,
            retryDelays: queueStats.config?.retry_delays || '60,300,900'
          },
          processingCount: queueStats.processing_count || 0
        }} />
      )}
      
      <Card
        title={
          <Space>
            <HistoryOutlined />
            <span>调用历史</span>
            <Tag color="blue">{total} 条记录</Tag>
            {callTypeFilter === 'auto' && (
              <span style={{ 
                fontSize: '12px', 
                color: '#999',
                fontWeight: 'normal'
              }}>
                (每10秒自动刷新)
              </span>
            )}
          </Space>
        }
        extra={
          <Space>
            <Radio.Group
              value={callTypeFilter}
              onChange={(e) => setCallTypeFilter(e.target.value)}
              optionType="button"
              buttonStyle="solid"
              size="small"
            >
              <Radio.Button value="manual">
                <UserOutlined /> 手动
              </Radio.Button>
              <Radio.Button value="auto">
                <RobotOutlined /> 窗口
              </Radio.Button>
              <Radio.Button value="auto-all">
                <UnorderedListOutlined /> 自动
              </Radio.Button>
            </Radio.Group>
            <Button
              icon={<ReloadOutlined />}
              onClick={() => loadHistory(pagination.current, pagination.pageSize)}
              loading={loading}
            >
              刷新
            </Button>
          </Space>
        }
      >
        {/* 查询表单 - 仅在"自动"tab显示 */}
        {callTypeFilter === 'auto-all' && (
          <Card size="small" style={{ marginBottom: 16 }} title={<><SearchOutlined /> 查询条件</>}>
            <Form
              form={queryForm}
              layout="vertical"
              onFinish={handleSearch}
            >
              <Row gutter={16}>
                <Col span={6}>
                  <Form.Item label="DID" name="did">
                    <Input placeholder="请输入DID" allowClear />
                  </Form.Item>
                </Col>
                <Col span={6}>
                  <Form.Item label="视频文件名" name="filename">
                    <Input placeholder="请输入文件名关键词" allowClear />
                  </Form.Item>
                </Col>
                <Col span={8}>
                  <Form.Item label="日期范围" name="dateRange">
                    <RangePicker style={{ width: '100%' }} />
                  </Form.Item>
                </Col>
                <Col span={4} style={{ display: 'flex', alignItems: 'flex-end' }}>
                  <Form.Item>
                    <Space>
                      <Button type="primary" htmlType="submit" icon={<SearchOutlined />}>
                        查询
                      </Button>
                      <Button onClick={handleResetSearch}>
                        重置
                      </Button>
                    </Space>
                  </Form.Item>
                </Col>
              </Row>
            </Form>
          </Card>
        )}
        
        <Table
          columns={columns}
          dataSource={records}
          rowKey="id"
          loading={loading}
          scroll={{ x: 'max-content' }}
          pagination={{
            ...pagination,
            total,
            showSizeChanger: true,
            showTotal: (total) => `共 ${total} 条记录`,
            onChange: (page, pageSize) => {
              setPagination({ current: page, pageSize });
              loadHistory(page, pageSize);
            },
          }}
        />
      </Card>

      <Modal
        title="调用详情"
        open={detailModalVisible}
        onCancel={() => setDetailModalVisible(false)}
        footer={null}
        width={800}
        style={{ top: 20 }}
        styles={{ body: { maxHeight: 'calc(100vh - 200px)', overflowY: 'auto' } }}
      >
        {selectedRecord && (
          <Space direction="vertical" style={{ width: '100%' }} size="large">
            <Descriptions bordered column={2} size="small">
              <Descriptions.Item label="视频">{selectedRecord.video_name}</Descriptions.Item>
              {selectedRecord.dir_alias && (
                <Descriptions.Item label="视频源">{selectedRecord.dir_alias}</Descriptions.Item>
              )}
              <Descriptions.Item label="时间">
                {dayjs(selectedRecord.created_at).format('YYYY-MM-DD HH:mm:ss')}
              </Descriptions.Item>
              {selectedRecord.model_name && (
                <Descriptions.Item label="模型">
                  <Tag color="purple">{selectedRecord.model_name}</Tag>
                </Descriptions.Item>
              )}
              <Descriptions.Item label="FPS">{selectedRecord.fps}</Descriptions.Item>
              <Descriptions.Item label="Max Pixels">
                {selectedRecord.max_pixels.toLocaleString()}
              </Descriptions.Item>
              <Descriptions.Item label="Min Pixels">
                {selectedRecord.min_pixels.toLocaleString()}
              </Descriptions.Item>
              <Descriptions.Item label="高分辨率">
                <Tag color={selectedRecord.vl_high_resolution_images ? 'red' : 'default'}>
                  {selectedRecord.vl_high_resolution_images ? '开启' : '关闭'}
                </Tag>
              </Descriptions.Item>
              <Descriptions.Item label="输入Token">
                {selectedRecord.input_tokens.toLocaleString()}
              </Descriptions.Item>
              <Descriptions.Item label="输出Token">
                {selectedRecord.output_tokens.toLocaleString()}
              </Descriptions.Item>
              <Descriptions.Item label="总Token">
                {selectedRecord.total_tokens.toLocaleString()}
              </Descriptions.Item>
              <Descriptions.Item label="费用">
                <Tag color="green">¥{selectedRecord.cost.toFixed(6)}</Tag>
              </Descriptions.Item>
              <Descriptions.Item label="处理时长">
                {selectedRecord.duration_sec.toFixed(2)}秒
              </Descriptions.Item>
            </Descriptions>

            <Card title="提示词" size="small">
              <Paragraph style={{ whiteSpace: 'pre-wrap', margin: 0 }}>
                {selectedRecord.prompt}
              </Paragraph>
            </Card>

            <Card title="模型回复" size="small">
              <div style={{ 
                whiteSpace: 'pre-wrap', 
                wordBreak: 'break-word',
                lineHeight: '1.6'
              }}>
                {selectedRecord.model_response}
              </div>
            </Card>
          </Space>
        )}
      </Modal>
    </>
  );
};

export default History;
