import React, { useState } from 'react';
import { Card, Switch, Button, Space, message, Popconfirm, Alert, Tooltip } from 'antd';
import {
  PlayCircleOutlined,
  PauseCircleOutlined,
  SettingOutlined,
  ExclamationCircleOutlined,
} from '@ant-design/icons';
import { startLLMWorker, stopLLMWorker, triggerLLMProcessing } from '../../services/llmApi';

interface WorkerControlPanelProps {
  workerRunning: boolean;
  systemEnabled: boolean;  // 系统级开关状态
  config: {
    maxConcurrent: number;
    pollInterval: number;
    maxRetries: number;
    timeWindowHours: number;
  };
  onStatusChange: () => void;
}

const WorkerControlPanel: React.FC<WorkerControlPanelProps> = ({ 
  workerRunning, 
  systemEnabled,
  config,
  onStatusChange 
}) => {
  const [loading, setLoading] = useState(false);

  const handleWorkerToggle = async (enabled: boolean) => {
    if (!systemEnabled) {
      message.error('系统级开关已禁用，无法启动 LLM Worker');
      return;
    }
    
    setLoading(true);
    try {
      if (enabled) {
        await startLLMWorker();
        message.success('LLM Worker 已启动');
      } else {
        await stopLLMWorker();
        message.success('LLM Worker 已停止');
      }
      onStatusChange();
    } catch (error) {
      message.error(`操作失败: ${error}`);
    } finally {
      setLoading(false);
    }
  };

  const handleTriggerProcessing = async () => {
    try {
      await triggerLLMProcessing();
      message.success('已触发队列处理');
      onStatusChange();
    } catch (error) {
      message.error('触发处理失败');
    }
  };

  return (
    <Card 
      title={
        <Space>
          <SettingOutlined />
          LLM Worker 控制
        </Space>
      }
      size="small"
      style={{ marginBottom: 16 }}
    >
      <Space direction="vertical" style={{ width: '100%' }}>
        {/* 系统开关状态 */}
        {!systemEnabled && (
          <Alert
            message="系统级开关已禁用"
            description="LLM Worker 功能已在系统配置中禁用，请联系管理员启用"
            type="error"
            icon={<ExclamationCircleOutlined />}
            showIcon
            style={{ marginBottom: 12 }}
          />
        )}

        {/* Worker 开关 */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>自动分析服务:</span>
          <Space>
            <Tooltip 
              title={workerRunning 
                ? "关闭自动分析服务，停止处理队列中的视频分析任务" 
                : "启动自动分析服务，开始自动处理视频分析任务"
              }
              placement="top"
            >
              <Switch
                checked={workerRunning}
                onChange={handleWorkerToggle}
                loading={loading}
                disabled={!systemEnabled}
                checkedChildren="运行中"
                unCheckedChildren="已停止"
              />
            </Tooltip>
            {workerRunning ? (
              <PlayCircleOutlined style={{ color: '#52c41a' }} />
            ) : (
              <PauseCircleOutlined style={{ color: '#ff4d4f' }} />
            )}
          </Space>
        </div>

        {/* 配置信息 */}
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: '1fr 1fr', 
          gap: '8px',
          fontSize: '12px',
          color: '#666',
          marginTop: '8px',
          padding: '8px',
          backgroundColor: '#fafafa',
          borderRadius: '4px'
        }}>
          <div>最大并发: {config.maxConcurrent}</div>
          <div>轮询间隔: {config.pollInterval}s</div>
          <div>最大重试: {config.maxRetries}次</div>
          <div>时间窗口: {config.timeWindowHours}小时</div>
        </div>

        {/* 控制按钮 */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span>队列控制:</span>
          <Space>
            <Tooltip 
              title="立即检查队列并开始处理待分析的视频，无需等待轮询间隔（10秒）"
              placement="top"
            >
              <Button
                size="small"
                type="primary"
                icon={<PlayCircleOutlined />}
                onClick={handleTriggerProcessing}
                disabled={!workerRunning || !systemEnabled}
              >
                触发处理
              </Button>
            </Tooltip>
            
            <Popconfirm
              title="确定停止 LLM Worker？"
              description="停止后将不再自动处理新的视频分析任务"
              onConfirm={() => handleWorkerToggle(false)}
              okText="确定停止"
              cancelText="取消"
              disabled={!workerRunning || !systemEnabled}
            >
              <Tooltip 
                title="停止LLM Worker服务，将不再自动处理新的视频分析任务"
                placement="top"
              >
                <Button
                  size="small"
                  danger
                  icon={<PauseCircleOutlined />}
                  disabled={!workerRunning || !systemEnabled}
                >
                  停止服务
                </Button>
              </Tooltip>
            </Popconfirm>
          </Space>
        </div>

        {/* 状态提示 */}
        {!workerRunning && (
          <Alert
            message="LLM Worker 已停止"
            description="新的视频切片将不会自动进行 AI 分析，需要手动启动服务"
            type="warning"
            icon={<ExclamationCircleOutlined />}
            showIcon
            closable
          />
        )}
      </Space>
    </Card>
  );
};

export default WorkerControlPanel;