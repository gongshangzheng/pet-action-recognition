import React from 'react';
import { Card, Row, Col, Statistic, Tag, Progress } from 'antd';
import {
  CheckCircleOutlined,
  LoadingOutlined,
  ClockCircleOutlined,
  ExclamationCircleOutlined,
} from '@ant-design/icons';

interface QueueStatusProps {
  stats: {
    workerRunning: boolean;
    systemEnabled: boolean;
    queueStats: Record<string, number>;
    pendingInWindow?: number;  // 新增：窗口内等待数
    pendingOutsideWindow?: number;  // 新增：窗口外等待数
    config: {
      maxConcurrent: number;
      pollInterval: number;
      maxRetries: number;
      timeWindowHours: number;
      autoStart: boolean;
      retryDelays: string;
    };
  } & { processingCount?: number };
}

const QueueStatusCard: React.FC<QueueStatusProps> = ({ stats }) => {
  if (!stats) return null;

  const { 
    workerRunning, 
    queueStats = {}, 
    config, 
    processingCount = 0,
    pendingInWindow,
    pendingOutsideWindow 
  } = stats;
  
  const totalRecords = Object.values(queueStats || {}).reduce((sum, count) => sum + count, 0);
  const processingPercent = config?.maxConcurrent > 0 
    ? Math.round((processingCount / config.maxConcurrent) * 100) 
    : 0;
  
  // 使用窗口内的pending数量，如果没有则回退到总pending
  const pendingToShow = pendingInWindow !== undefined 
    ? pendingInWindow 
    : (queueStats.pending || 0);
  
  // 是否显示窗口外提示
  const hasOutsideWindow = pendingOutsideWindow !== undefined && pendingOutsideWindow > 0;

  return (
    <Card 
      title={
        <span>
          LLM 分析队列状态
          <span style={{ 
            fontSize: '12px', 
            color: '#999', 
            marginLeft: '8px',
            fontWeight: 'normal'
          }}>
            (每10秒自动刷新)
          </span>
        </span>
      }
      size="small" 
      style={{ marginBottom: 16 }}
    >
      <Row gutter={16}>
        <Col span={6}>
          <Statistic
            title="Worker 状态"
            value={workerRunning ? '运行中' : '已停止'}
            valueStyle={{ 
              color: workerRunning ? '#3f8600' : '#cf1322',
              fontSize: 16 
            }}
            prefix={workerRunning ? <CheckCircleOutlined /> : <ExclamationCircleOutlined />}
          />
        </Col>
        <Col span={6}>
          <Statistic
            title="处理进度"
            value={`${processingCount} / ${config.maxConcurrent}`}
            prefix={<LoadingOutlined />}
          />
          <Progress 
            percent={processingPercent} 
            size="small" 
            showInfo={false}
            style={{ marginTop: 8 }}
          />
        </Col>
        <Col span={6}>
          <Statistic
            title={
              <span>
                等待中
                {hasOutsideWindow && (
                  <span style={{ fontSize: '12px', color: '#999', fontWeight: 'normal', marginLeft: '4px' }}>
                    (窗口内)
                  </span>
                )}
              </span>
            }
            value={pendingToShow}
            prefix={<ClockCircleOutlined />}
          />
          {hasOutsideWindow && (
            <div style={{ fontSize: '12px', color: '#999', marginTop: '4px' }}>
              窗口外: {pendingOutsideWindow}
            </div>
          )}
        </Col>
        <Col span={6}>
          <Statistic
            title="总任务数"
            value={totalRecords}
          />
        </Col>
      </Row>
      
      {/* 状态分布 */}
      <div style={{ marginTop: 16 }}>
        <div style={{ marginBottom: 8, fontSize: 14, fontWeight: 500 }}>状态分布:</div>
        <div>
          {Object.entries(queueStats || {}).map(([status, count]) => {
            const statusConfig: Record<string, { color: string; text: string }> = {
              pending: { color: 'default', text: '等待中' },
              processing: { color: 'processing', text: '处理中' },
              completed: { color: 'success', text: '已完成' },
              failed: { color: 'error', text: '失败' },
              error: { color: 'warning', text: '错误' },
              expired: { color: 'default', text: '已过期' }
            };
            
            const config = statusConfig[status] || { color: 'default', text: status };
            
            return (
              <Tag key={status} color={config.color} style={{ margin: '0 8px 4px 0' }}>
                {config.text}: {count}
              </Tag>
            );
          })}
        </div>
      </div>
    </Card>
  );
};

export default QueueStatusCard;