/**
 * 提示词变量替换工具
 */
import type { Pet } from '../types/pet';
import { 
  getAvailableVariables, 
  VARIABLE_DEFINITIONS,
  type VariableContext 
} from './variableConfig';

/**
 * 格式化宠物信息用于提示词（移除不需要的字段，添加年龄）
 */
export const formatPetsForPrompt = (pets: Pet[]): any[] => {
  return pets.map(pet => {
    const { did, avatar_url, created_at, updated_at, birth_date, ...rest } = pet;
    
    // 计算年龄
    const age = calculateAge(birth_date);
    
    return {
      ...rest,
      age,
      // weight 保留（如果有的话）
    };
  });
};

/**
 * 计算年龄（从出生日期）
 */
export const calculateAge = (birthDate: string | undefined): string => {
  if (!birthDate) return '未知';
  
  try {
    const birth = new Date(birthDate);
    const now = new Date();
    
    let years = now.getFullYear() - birth.getFullYear();
    let months = now.getMonth() - birth.getMonth();
    
    if (months < 0) {
      years--;
      months += 12;
    }
    
    // 如果不满1岁，只显示月份
    if (years === 0) {
      return `${months}个月`;
    }
    
    // 如果月份为0，只显示年份
    if (months === 0) {
      return `${years}年`;
    }
    
    return `${years}年${months}个月`;
  } catch {
    return '未知';
  }
};

/**
 * 替换提示词中的变量（新版：支持所有配置的变量）
 * @param prompt 原始提示词
 * @param context 变量上下文
 * @returns 替换后的提示词
 */
export const replacePromptVariables = (
  prompt: string,
  context: VariableContext
): string => {
  if (!prompt) return '';
  
  let result = prompt;
  
  // 获取所有可用变量（包括动态生成的）
  const availableVariables = getAvailableVariables(context);
  
  // 按变量名长度降序排序，避免短变量名误替换长变量名
  // 例如先替换 {{pet1_name}} 再替换 {{pet1}}
  const sortedVariables = [...availableVariables].sort(
    (a, b) => b.name.length - a.name.length
  );
  
  // 逐个替换变量
  for (const varDef of sortedVariables) {
    const varPattern = new RegExp(`\\{\\{\\s*${varDef.name}\\s*\\}\\}`, 'g');
    
    // 获取变量值
    let value = '';
    if (varDef.getValue) {
      // 如果是动态变量（如 pet1_name），需要提取索引
      const match = varDef.name.match(/^pet(\d+)_/);
      const index = match ? parseInt(match[1]) - 1 : undefined;
      value = varDef.getValue(context, index);
    }
    
    // 替换变量（即使值为空也要替换，避免留下未替换的变量占位符）
    result = result.replace(varPattern, value);
  }
  
  // 清理多余的空行和首尾空白
  result = result
    .replace(/\n\s*\n\s*\n/g, '\n\n')  // 将3个及以上连续换行压缩为2个
    .trim();  // 删除首尾空白
  
  return result;
};

/**
 * 检测提示词中的变量
 * @param prompt 提示词
 * @returns 变量名列表
 */
export const detectPromptVariables = (prompt: string): string[] => {
  const regex = /\{\{([^}]+)\}\}/g;
  const variables: string[] = [];
  let match;
  
  while ((match = regex.exec(prompt)) !== null) {
    const varName = match[1].trim();
    if (!variables.includes(varName)) {
      variables.push(varName);
    }
  }
  
  return variables;
};

/**
 * 验证变量是否有效（是否在配置中定义）
 * @param variableName 变量名
 * @param context 变量上下文
 * @returns 是否有效
 */
export const isValidVariable = (
  variableName: string,
  context: VariableContext
): boolean => {
  const availableVariables = getAvailableVariables(context);
  return availableVariables.some(v => v.name === variableName);
};
