/**
 * 提示词变量配置系统
 * 
 * 定义所有可用的变量类型、生成规则和替换逻辑
 */
import type { Pet } from '../types/pet';

/**
 * 变量类型定义
 */
export enum VariableCategory {
  PET = 'pet',           // 宠物相关变量
  SYSTEM = 'system',     // 系统变量
  USER = 'user',         // 用户变量
}

/**
 * 变量定义接口
 */
export interface VariableDefinition {
  /** 变量名（模板），如 "pet{N}_name" 表示动态生成 */
  name: string;
  /** 变量显示名称 */
  displayName: string;
  /** 变量描述 */
  description: string;
  /** 变量分类 */
  category: VariableCategory;
  /** 是否为动态变量（根据数据生成多个实例） */
  isDynamic: boolean;
  /** 示例值 */
  example: string;
  /** 值获取函数 */
  getValue?: (context: VariableContext, index?: number) => string;
}

/**
 * 变量上下文（运行时数据）
 */
export interface VariableContext {
  pets?: Pet[];
  userId?: string;
  userName?: string;
  currentDate?: string;
  currentTime?: string;
}

/**
 * 计算年龄（从出生日期）
 */
const calculateAge = (birthDate: string | undefined): string => {
  if (!birthDate) return '未知';
  
  try {
    const birth = new Date(birthDate);
    const now = new Date();
    
    let years = now.getFullYear() - birth.getFullYear();
    let months = now.getMonth() - birth.getMonth();
    
    if (months < 0) {
      years--;
      months += 12;
    }
    
    if (years === 0) {
      return `${months}个月`;
    }
    
    if (months === 0) {
      return `${years}年`;
    }
    
    return `${years}年${months}个月`;
  } catch {
    return '未知';
  }
};

/**
 * 变量配置表
 */
export const VARIABLE_DEFINITIONS: VariableDefinition[] = [
  // ========== 宠物相关变量 ==========
  {
    name: 'pets_info_list',
    displayName: '宠物信息列表',
    description: '所有宠物的完整信息（JSON 格式）',
    category: VariableCategory.PET,
    isDynamic: false,
    example: '[{"pet_name":"毛毛","pet_type":"猫","age":"3年6个月",...}]',
    getValue: (context) => {
      if (!context.pets || context.pets.length === 0) return '';  // 空列表返回空字符串
      const formatted = context.pets.map(pet => {
        const { did, avatar_url, created_at, updated_at, birth_date, ...rest } = pet;
        return {
          ...rest,
          age: calculateAge(birth_date),
        };
      });
      return JSON.stringify(formatted, null, 2);
    },
  },
  
  // 动态变量：pet{N}_name
  {
    name: 'pet{N}_name',
    displayName: '第N只宠物名称',
    description: '指定序号宠物的名称，例如 {{pet1_name}}、{{pet2_name}}',
    category: VariableCategory.PET,
    isDynamic: true,
    example: 'pet1_name → "毛毛"',
    getValue: (context, index) => {
      if (!context.pets || index === undefined || index >= context.pets.length) {
        return '';
      }
      return context.pets[index].pet_name || '';
    },
  },
  
  // 动态变量：pet{N}_type
  {
    name: 'pet{N}_type',
    displayName: '第N只宠物类型',
    description: '指定序号宠物的类型（猫/狗等），例如 {{pet1_type}}',
    category: VariableCategory.PET,
    isDynamic: true,
    example: 'pet1_type → "猫"',
    getValue: (context, index) => {
      if (!context.pets || index === undefined || index >= context.pets.length) {
        return '';
      }
      return context.pets[index].pet_type || '';
    },
  },
  
  // 动态变量：pet{N}_breed
  {
    name: 'pet{N}_breed',
    displayName: '第N只宠物品种',
    description: '指定序号宠物的品种，例如 {{pet1_breed}}',
    category: VariableCategory.PET,
    isDynamic: true,
    example: 'pet1_breed → "英短"',
    getValue: (context, index) => {
      if (!context.pets || index === undefined || index >= context.pets.length) {
        return '';
      }
      return context.pets[index].breed || '';
    },
  },
  
  // 动态变量：pet{N}_gender
  {
    name: 'pet{N}_gender',
    displayName: '第N只宠物性别',
    description: '指定序号宠物的性别，例如 {{pet1_gender}}',
    category: VariableCategory.PET,
    isDynamic: true,
    example: 'pet1_gender → "公"',
    getValue: (context, index) => {
      if (!context.pets || index === undefined || index >= context.pets.length) {
        return '';
      }
      return context.pets[index].gender || '';
    },
  },
  
  // 动态变量：pet{N}_age
  {
    name: 'pet{N}_age',
    displayName: '第N只宠物年龄',
    description: '指定序号宠物的年龄（自动计算），例如 {{pet1_age}}',
    category: VariableCategory.PET,
    isDynamic: true,
    example: 'pet1_age → "3年6个月"',
    getValue: (context, index) => {
      if (!context.pets || index === undefined || index >= context.pets.length) {
        return '';
      }
      return calculateAge(context.pets[index].birth_date);
    },
  },
  
  // 动态变量：pet{N}_weight
  {
    name: 'pet{N}_weight',
    displayName: '第N只宠物体重',
    description: '指定序号宠物的体重（单位：kg），例如 {{pet1_weight}}',
    category: VariableCategory.PET,
    isDynamic: true,
    example: 'pet1_weight → "3.5"',
    getValue: (context, index) => {
      if (!context.pets || index === undefined || index >= context.pets.length) {
        return '';
      }
      const weight = context.pets[index].weight;
      return weight !== undefined && weight !== null ? String(weight) : '';
    },
  },
  
  // 动态变量：pet{N}_color
  {
    name: 'pet{N}_color',
    displayName: '第N只宠物颜色',
    description: '指定序号宠物的颜色，例如 {{pet1_color}}',
    category: VariableCategory.PET,
    isDynamic: true,
    example: 'pet1_color → "黑白相间"',
    getValue: (context, index) => {
      if (!context.pets || index === undefined || index >= context.pets.length) {
        return '';
      }
      return context.pets[index].color || '';
    },
  },
  
  // 动态变量：pet{N}_description
  {
    name: 'pet{N}_description',
    displayName: '第N只宠物描述',
    description: '指定序号宠物的详细描述，例如 {{pet1_description}}',
    category: VariableCategory.PET,
    isDynamic: true,
    example: 'pet1_description → "性格温顺，喜欢晒太阳"',
    getValue: (context, index) => {
      if (!context.pets || index === undefined || index >= context.pets.length) {
        return '';
      }
      return context.pets[index].description || '';
    },
  },
  
  // ========== 系统变量 ==========
  {
    name: 'current_date',
    displayName: '当前日期',
    description: '当前日期（格式：YYYY-MM-DD）',
    category: VariableCategory.SYSTEM,
    isDynamic: false,
    example: '2026-01-23',
    getValue: () => {
      const now = new Date();
      return now.toISOString().split('T')[0];
    },
  },
  
  {
    name: 'current_time',
    displayName: '当前时间',
    description: '当前时间（格式：HH:mm:ss）',
    category: VariableCategory.SYSTEM,
    isDynamic: false,
    example: '14:30:25',
    getValue: () => {
      const now = new Date();
      return now.toTimeString().split(' ')[0];
    },
  },
  
  {
    name: 'current_datetime',
    displayName: '当前日期时间',
    description: '当前日期和时间（格式：YYYY-MM-DD HH:mm:ss）',
    category: VariableCategory.SYSTEM,
    isDynamic: false,
    example: '2026-01-23 14:30:25',
    getValue: () => {
      const now = new Date();
      const date = now.toISOString().split('T')[0];
      const time = now.toTimeString().split(' ')[0];
      return `${date} ${time}`;
    },
  },
  
  // ========== 用户变量 ==========
  {
    name: 'user_name',
    displayName: '用户名',
    description: '当前用户的显示名称',
    category: VariableCategory.USER,
    isDynamic: false,
    example: '张三',
    getValue: (context) => context.userName || '',
  },
];

/**
 * 获取所有可用变量（包括动态生成的）
 */
export const getAvailableVariables = (context: VariableContext): VariableDefinition[] => {
  const variables: VariableDefinition[] = [];
  
  for (const def of VARIABLE_DEFINITIONS) {
    if (!def.isDynamic) {
      // 静态变量直接添加
      variables.push(def);
    } else {
      // 动态变量根据数据生成多个实例
      if (def.category === VariableCategory.PET && context.pets) {
        const petCount = context.pets.length;
        for (let i = 0; i < petCount; i++) {
          const petIndex = i + 1; // 从 1 开始编号
          const varName = def.name.replace('{N}', String(petIndex));
          
          variables.push({
            ...def,
            name: varName,
            displayName: def.displayName.replace('N', String(petIndex)),
            description: def.description,
            isDynamic: false, // 实例化后不再是动态的
            example: def.example.replace('pet{N}', `pet${petIndex}`).replace('{N}', String(petIndex)),
          });
        }
      }
    }
  }
  
  return variables;
};

/**
 * 按分类分组变量
 */
export const groupVariablesByCategory = (
  variables: VariableDefinition[]
): Record<VariableCategory, VariableDefinition[]> => {
  const grouped: Record<VariableCategory, VariableDefinition[]> = {
    [VariableCategory.PET]: [],
    [VariableCategory.SYSTEM]: [],
    [VariableCategory.USER]: [],
  };
  
  for (const variable of variables) {
    grouped[variable.category].push(variable);
  }
  
  return grouped;
};

/**
 * 分类显示名称映射
 */
export const CATEGORY_LABELS: Record<VariableCategory, string> = {
  [VariableCategory.PET]: '🐾 宠物相关',
  [VariableCategory.SYSTEM]: '⚙️ 系统变量',
  [VariableCategory.USER]: '👤 用户相关',
};
