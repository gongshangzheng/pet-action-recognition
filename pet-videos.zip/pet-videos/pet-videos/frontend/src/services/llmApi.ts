import { apiRequest } from './api';

export interface LLMQueueStatus {
  workerRunning: boolean;
  systemEnabled: boolean;
  queueStats: Record<string, number>;
  processingCount: number;
  config: {
    maxConcurrent: number;
    pollInterval: number;
    maxRetries: number;
    timeWindowHours: number;
    autoStart: boolean;
    retryDelays: string;
  };
}

export interface LLMQueueResponse {
  success: boolean;
  data: LLMQueueStatus;
}

/**
 * 获取 LLM 队列状态
 */
export const getLLMQueueStatus = async (): Promise<LLMQueueResponse> => {
  return apiRequest('/llm/queue/stats');
};

/**
 * 触发 LLM 队列处理
 */
export const triggerLLMProcessing = async (): Promise<{ success: boolean; message: string }> => {
  return apiRequest('/internal/llm/process', {
    method: 'POST'
  });
};

/**
 * 重试失败的 LLM 记录
 */
export const retryLLMRecord = async (recordId: number): Promise<{ success: boolean; message: string }> => {
  return apiRequest(`/internal/llm/retry/${recordId}`, {
    method: 'POST'
  });
};

/**
 * 删除 LLM 队列记录
 */
export const deleteLLMRecord = async (recordId: number): Promise<{ success: boolean; message: string }> => {
  return apiRequest(`/internal/llm/record/${recordId}`, {
    method: 'DELETE'
  });
};

/**
 * 启动 LLM Worker
 */
export const startLLMWorker = async (): Promise<{ success: boolean; message: string }> => {
  return apiRequest('/internal/llm/worker/start', {
    method: 'POST'
  });
};

/**
 * 停止 LLM Worker
 */
export const stopLLMWorker = async (): Promise<{ success: boolean; message: string }> => {
  return apiRequest('/internal/llm/worker/stop', {
    method: 'POST'
  });
};