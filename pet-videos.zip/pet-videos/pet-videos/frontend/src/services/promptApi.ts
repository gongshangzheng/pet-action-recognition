/**
 * 提示词API服务
 */
import axios from 'axios';
import type { Prompt, PromptCreate, PromptUpdate, PromptListResponse } from '../types/prompt';

const API_BASE = '/api';

// 创建带token拦截器的axios实例
const api = axios.create({
  baseURL: API_BASE,
  timeout: 30000,
});

// 请求拦截器注入 Token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('pet_videos_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// 响应拦截器处理 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('pet_videos_token');
      localStorage.removeItem('pet_videos_user');
      window.dispatchEvent(new Event('pet-videos-unauthorized'));
    }
    return Promise.reject(error);
  }
);

/**
 * 获取提示词列表
 */
export const getPrompts = async (activeOnly: boolean = false): Promise<PromptListResponse> => {
  const response = await api.get('/prompts', {
    params: { active_only: activeOnly }
  });
  return response.data;
};

/**
 * 获取自动调用提示词
 */
export const getDefaultPrompt = async (): Promise<Prompt> => {
  const response = await api.get('/prompts/default');
  return response.data;
};

/**
 * 获取指定提示词
 */
export const getPrompt = async (id: number): Promise<Prompt> => {
  const response = await api.get(`/prompts/${id}`);
  return response.data;
};

/**
 * 创建提示词
 */
export const createPrompt = async (data: PromptCreate): Promise<Prompt> => {
  const response = await api.post('/prompts', data);
  return response.data;
};

/**
 * 更新提示词
 */
export const updatePrompt = async (id: number, data: PromptUpdate): Promise<Prompt> => {
  const response = await api.put(`/prompts/${id}`, data);
  return response.data;
};

/**
 * 设置为自动调用提示词
 */
export const setDefaultPrompt = async (id: number): Promise<void> => {
  await api.put(`/prompts/${id}/set-default`);
};

/**
 * 删除提示词
 */
export const deletePrompt = async (id: number): Promise<void> => {
  await api.delete(`/prompts/${id}`);
};
