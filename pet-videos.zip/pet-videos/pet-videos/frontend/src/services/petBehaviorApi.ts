import axios from 'axios';

const API_BASE = '/api';

const api = axios.create({
  baseURL: API_BASE,
  timeout: 30000,
});

// 请求拦截器注入 Token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('pet_videos_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// 响应拦截器处理 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('pet_videos_token');
      localStorage.removeItem('pet_videos_user');
      window.dispatchEvent(new Event('pet-videos-unauthorized'));
    }
    return Promise.reject(error);
  }
);

// 宠物行为相关类型定义
export interface PetBehavior {
  video_id: number;
  pet_name: string;
  did: string;
  actions: string;
  description: string;
  status: string;
  location: string;
  score: number;
  created_at: string;
  video_file_name: string;
  video_duration: number;
  video_recorded_at: string;
}

export interface PetBehaviorDetail extends PetBehavior {
  actions_list: string[];
  raw_result: any;
  video_file_path: string;
  video_llm_status: string;
}

export interface BehaviorListResponse {
  behaviors: PetBehavior[];
  total: number;
  page: number;
  page_size: number;
}

export interface BehaviorStats {
  total_behaviors: number;
  total_pets: number;
  avg_score: number;
  action_stats: Record<string, number>;
  pet_stats: Record<string, {
    behavior_count: number;
    avg_score: number;
    latest_behavior: string;
  }>;
}

// API 函数
export const getPetBehaviors = async (params: {
  page?: number;
  page_size?: number;
  pet_name?: string;
  did?: string;
  date?: string;
}): Promise<BehaviorListResponse> => {
  const response = await api.get('/pet-behaviors/', { params });
  return response.data;
};

export const getPetBehaviorDetail = async (
  videoId: number,
  petName: string
): Promise<PetBehaviorDetail> => {
  const response = await api.get(`/pet-behaviors/${videoId}/${encodeURIComponent(petName)}`);
  return response.data;
};

export const getBehaviorStats = async (params: {
  did?: string;
  start_date?: string;
  end_date?: string;
}): Promise<BehaviorStats> => {
  const response = await api.get('/pet-behaviors/statistics/summary', { params });
  return response.data;
};