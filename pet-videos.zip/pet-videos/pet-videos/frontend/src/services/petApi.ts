import axios from 'axios';
import type { Pet, PetListResponse, PetCreateRequest, PetUpdateRequest } from '../types/pet';

// 使用相对路径，走 Vite 代理
const API_BASE_URL = '/api';

// 创建 axios 实例
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  withCredentials: true,
});

// 请求拦截器：添加 JWT token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('pet_videos_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// 响应拦截器：处理 401 未授权
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // 触发全局未授权事件
      window.dispatchEvent(new CustomEvent('pet-videos-unauthorized'));
    }
    return Promise.reject(error);
  }
);

/**
 * 获取宠物列表
 */
export const getPets = async (did?: string): Promise<Pet[]> => {
  const params = did ? { did } : {};
  const response = await apiClient.get<PetListResponse>('/pets/', { params });
  return response.data.pets;
};

/**
 * 获取单个宠物详情
 */
export const getPet = async (did: string, petName: string): Promise<Pet> => {
  const response = await apiClient.get<Pet>(`/pets/${petName}`, {
    params: { did },
  });
  return response.data;
};

/**
 * 创建宠物
 */
export const createPet = async (data: PetCreateRequest): Promise<Pet> => {
  const response = await apiClient.post<Pet>('/pets/', data, {
    params: { did: data.did },
  });
  return response.data;
};

/**
 * 更新宠物
 */
export const updatePet = async (
  did: string,
  petName: string,
  data: PetUpdateRequest
): Promise<Pet> => {
  const response = await apiClient.put<Pet>(`/pets/${petName}`, data, {
    params: { did },
  });
  return response.data;
};

/**
 * 删除宠物
 */
export const deletePet = async (did: string, petName: string): Promise<void> => {
  await apiClient.delete(`/pets/${petName}`, {
    params: { did },
  });
};
