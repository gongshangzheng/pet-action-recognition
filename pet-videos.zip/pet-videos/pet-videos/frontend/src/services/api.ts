import axios from 'axios';
import type {
  VideoInfo,
  VideoListResponse,
  DirectoryInfo,
  DirectoryStat,
  EstimateResponse,
  AnalysisResponse,
  HistoryRecord,
  HistoryDetail,
  Config,
  LoginResponse,
  StreamSource,
  SlicingTask,
  ScriptFileInfo,
  ModelInfo,
} from '../types';

const API_BASE = '/api';

const api = axios.create({
  baseURL: API_BASE,
  timeout: 300000, // 5分钟超时
});

// 请求拦截器注入 Token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('pet_videos_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// 响应拦截器处理 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('pet_videos_token');
      localStorage.removeItem('pet_videos_user');
      // 发送自定义事件，通知 App 组件更新状态，而不是 reload
      window.dispatchEvent(new Event('pet-videos-unauthorized'));
    }
    return Promise.reject(error);
  }
);

// 通用 API 请求函数
export const apiRequest = async (url: string, options: any = {}) => {
  const response = await api.request({
    url,
    method: options.method || 'GET',
    data: options.body || options.data,
    params: options.params,
    ...options
  });
  return response.data;
};

// 健康检查
export const healthCheck = async (): Promise<boolean> => {
  try {
    const response = await axios.get('/health');
    return response.status === 200;
  } catch {
    return false;
  }
};

// 登录
export const login = async (username: string, password: string): Promise<LoginResponse> => {
  const response = await api.post('/login', { username, password });
  const { token, username: user } = response.data;
  localStorage.setItem('pet_videos_token', token);
  localStorage.setItem('pet_videos_user', user);
  return response.data;
};

// 退出
export const logout = () => {
  localStorage.removeItem('pet_videos_token');
  localStorage.removeItem('pet_videos_user');
  window.location.reload();
};

// 检查登录状态
export const checkAuth = async (): Promise<boolean> => {
  try {
    const response = await api.get('/auth/check');
    return response.status === 200;
  } catch {
    return false;
  }
};

// 获取配置
export const getConfig = async (): Promise<Config> => {
  const response = await api.get('/config');
  return response.data;
};

// 获取可用模型列表
export const getAvailableModels = async (): Promise<ModelInfo[]> => {
  const response = await api.get('/models');
  return response.data;
};

// 获取目录列表
export const getDirectories = async (): Promise<DirectoryInfo[]> => {
  const response = await api.get('/directories');
  return response.data;
};

// 获取视频列表（使用别名）
export const getVideos = async (
  alias: string,
  page: number = 1,
  pageSize: number = 10
): Promise<VideoListResponse> => {
  const response = await api.get('/videos', {
    params: { alias, page, page_size: pageSize },
  });
  return response.data;
};

// 获取视频统计数据
export const getVideoStats = async (): Promise<DirectoryStat[]> => {
  const response = await api.get('/videos/stats');
  return response.data;
};

// 获取指定目录和日期的视频列表（使用别名，支持分页）
export const getVideosByDate = async (
  alias: string, 
  date: string,
  page: number = 1,
  pageSize: number = 20
): Promise<VideoListResponse> => {
  const response = await api.get('/videos/by_date', {
    params: { alias, date, page, page_size: pageSize },
  });
  return response.data;
};

// 获取单个视频信息
export const getVideoInfo = async (videoPath: string): Promise<VideoInfo> => {
  const response = await api.get(`/video/${encodeURIComponent(videoPath)}`);
  return response.data;
};

// 预估费用
export const estimateCost = async (params: {
  video_path: string;
  fps: number;
  max_pixels: number;
  min_pixels: number;
  prompt: string;
  vl_high_resolution_images: boolean;
}): Promise<EstimateResponse> => {
  const response = await api.post('/estimate', params);
  return response.data;
};

// 分析视频
export const analyzeVideo = async (params: {
  video_path: string;
  prompt: string;
  prompt_id?: number;
  prompt_name?: string;
  model_name?: string;
  fps: number;
  max_pixels: number;
  min_pixels: number;
  vl_high_resolution_images: boolean;
}): Promise<AnalysisResponse> => {
  const response = await api.post('/analyze', params);
  return response.data;
};

// 获取历史记录列表
export const getHistory = async (
  callType: 'manual' | 'auto' = 'manual',
  limit: number = 10,
  offset: number = 0,
  filters?: {
    did?: string;
    filename?: string;
    date_from?: string;
    date_to?: string;
  },
  queryAll: boolean = false
): Promise<{ records: HistoryRecord[]; total: number; page: number; page_size: number }> => {
  const params: any = { call_type: callType, limit, offset };
  
  // 如果是查询所有记录模式（auto-all tab）
  if (queryAll) {
    params.query_all = 'true';
  }
  
  // 添加可选的查询条件
  if (filters) {
    if (filters.did) params.did = filters.did;
    if (filters.filename) params.filename = filters.filename;
    if (filters.date_from) params.date_from = filters.date_from;
    if (filters.date_to) params.date_to = filters.date_to;
  }
  
  const response = await api.get('/history', {
    params,
  });
  return response.data;
};

// 获取历史记录详情
export const getHistoryDetail = async (recordId: number, callType: 'manual' | 'auto'): Promise<HistoryDetail> => {
  const response = await api.get(`/history/${recordId}`, {
    params: { call_type: callType },
  });
  return response.data;
};

// 删除历史记录
export const deleteHistory = async (recordId: number, callType: 'manual' | 'auto'): Promise<void> => {
  await api.delete(`/history/${recordId}`, {
    params: { call_type: callType },
  });
};

// 清空历史记录
export const clearHistory = async (callType: 'manual' | 'auto' | 'all' = 'manual'): Promise<void> => {
  await api.delete('/history', {
    params: { call_type: callType },
  });
};

// --- 流配置 API ---
export const getSources = async (): Promise<StreamSource[]> => {
  const response = await api.get('/sources/');
  return response.data;
};

export const createSource = async (data: Partial<StreamSource>): Promise<StreamSource> => {
  const response = await api.post('/sources/', data);
  return response.data;
};

export const updateSource = async (id: number, data: Partial<StreamSource>): Promise<StreamSource> => {
  const response = await api.put(`/sources/${id}`, data);
  return response.data;
};

export const deleteSource = async (id: number): Promise<void> => {
  await api.delete(`/sources/${id}`);
};

export const disableSource = async (id: number): Promise<{ message: string; stopped_tasks: number }> => {
  const response = await api.post(`/sources/${id}/disable`);
  return response.data;
};

export const enableSource = async (id: number): Promise<{ message: string }> => {
  const response = await api.post(`/sources/${id}/enable`);
  return response.data;
};

// --- 切片任务 API ---
export const getTasks = async (): Promise<SlicingTask[]> => {
  const response = await api.get('/tasks/');
  return response.data;
};

export const startTask = async (
  sourceId: number, 
  enableYolo: boolean = true,
  scriptFile: string = 'pet_monitor.py'
): Promise<void> => {
  await api.post(`/tasks/${sourceId}/start`, { 
    enable_yolo: enableYolo,
    script_file: scriptFile
  });
};

export const stopTask = async (sourceId: number): Promise<void> => {
  await api.post(`/tasks/${sourceId}/stop`);
};

export const deleteTask = async (taskId: number): Promise<void> => {
  await api.delete(`/tasks/${taskId}`);
};

export const getAvailableSources = async (): Promise<StreamSource[]> => {
  const response = await api.get('/tasks/available_sources');
  return response.data;
};

export const getAvailableScripts = async (): Promise<ScriptFileInfo[]> => {
  const response = await api.get('/tasks/scripts');
  return response.data;
};

export interface TaskLogResponse {
  source_id: number;
  exists: boolean;
  lines: string[];
  total_lines: number;
}

export const getTaskLogs = async (sourceId: number): Promise<TaskLogResponse> => {
  const response = await api.get(`/tasks/${sourceId}/logs`);
  return response.data;
};
