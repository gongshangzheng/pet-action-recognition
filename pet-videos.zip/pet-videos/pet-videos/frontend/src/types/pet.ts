export interface Pet {
  did: string;
  pet_name: string;
  pet_type?: string;
  breed?: string;
  gender?: string;
  birth_date?: string;
  weight?: number;  // 体重（单位：kg）
  color?: string;
  avatar_url?: string;
  description?: string;
  created_at: string;
  updated_at: string;
}

export interface PetListResponse {
  pets: Pet[];
  total: number;
}

export interface PetCreateRequest {
  did: string;
  pet_name: string;
  pet_type?: string;
  breed?: string;
  gender?: string;
  birth_date?: string;
  weight?: number;  // 体重（单位：kg）
  color?: string;
  avatar_url?: string;
  description?: string;
}

export interface PetUpdateRequest {
  pet_type?: string;
  breed?: string;
  gender?: string;
  birth_date?: string;
  weight?: number;  // 体重（单位：kg）
  color?: string;
  avatar_url?: string;
  description?: string;
}
