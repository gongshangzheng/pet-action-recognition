/**
 * 提示词相关类型定义
 */

export interface Prompt {
  id: number;
  name: string;
  content: string;
  description?: string;
  is_active: boolean;
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export interface PromptCreate {
  name: string;
  content: string;
  description?: string;
  is_active: boolean;
}

export interface PromptUpdate {
  name?: string;
  content?: string;
  description?: string;
  is_active?: boolean;
}

export interface PromptListResponse {
  prompts: Prompt[];
  total: number;
}
