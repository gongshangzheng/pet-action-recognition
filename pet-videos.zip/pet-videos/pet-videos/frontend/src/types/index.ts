export interface VideoInfo {
  id: number; // 唯一标识符
  filename: string;
  dir_alias: string;
  did?: string; // 关联的用户ID
  path: string; // 服务器本地路径（仅用于分析）
  stream_token: string; // 安全的流式传输token（用于播放）
  size_mb: number;
  duration_sec: number;
  duration_formatted: string;
  resolution: string;
  width: number;
  height: number;
  fps: number;
  codec: string;
  bitrate_mbps: number;
  created_at?: string; // 视频创建时间（ISO格式）
}

export interface VideoListResponse {
  videos: VideoInfo[];
  total: number;
  page: number;
  page_size: number;
}

export interface DirectoryInfo {
  alias: string;  // 目录别名
  name: string;
  video_count: number;
  exists: boolean;
  did?: string;  // 关联的用户ID
}

export interface DailyStat {
  date: string;
  count: number;
}

export interface DirectoryStat {
  alias: string;  // 目录别名
  name: string;   // 显示名称
  daily_stats: DailyStat[];
}

export interface EstimateResponse {
  frame_count: number;
  tokens_per_frame: number;
  video_tokens: number;
  prompt_tokens: number;
  total_input_tokens: number;
  estimated_output_tokens: number;
  estimated_total_tokens: number;
  estimated_cost: number;
  breakdown: {
    input_cost: number;
    output_cost: number;
    input_details: CostDetail[];
    output_details: CostDetail[];
  };
  video_info?: {
    original_resolution: string;
    resized_resolution: string;
    total_frames: number;
    video_fps: number;
  };
}

export interface CostDetail {
  tier_name: string;
  tier_range: string;
  tokens_in_tier: number;
  price_per_1k: number;
  tier_cost: number;
}

export interface AnalysisResponse {
  id: number;
  estimated: {
    frames: number;
    video_tokens: number;
    prompt_tokens: number;
    total_input_tokens: number;
    estimated_output_tokens: number;
    cost: number;
    breakdown: any;
  };
  actual: {
    input_tokens: number;
    output_tokens: number;
    total_tokens: number;
    cost: number;
    breakdown: {
      input_cost: number;
      output_cost: number;
      input_details: CostDetail[];
      output_details: CostDetail[];
    };
  };
  model_response: string;
  statistics: {
    duration_sec: number;
    accuracy_rate: number;
    tokens_per_frame: number;
    cost_per_frame: number;
    cost_per_second: number;
    processing_speed: number;
  };
}

export interface ModelInfo {
  name: string;
  label: string;
  description: string;
}

export interface HistoryRecord {
  id: number;
  video_name: string;
  dir_alias?: string;
  video_duration_sec: number;
  prompt: string;
  prompt_id?: number;  // 提示词ID
  prompt_name?: string;  // 提示词名称
  model_name?: string;  // 模型名称
  call_type: string;  // 'manual' | 'auto'
  llm_status?: string;  // LLM处理状态（仅自动调用有效）
  llm_error?: string;  // LLM错误信息（仅自动调用有效）
  llm_retry_count?: number;  // LLM重试次数（仅自动调用有效）
  fps: number;
  max_pixels: number;
  min_pixels: number;
  vl_high_resolution_images: boolean;
  input_tokens: number;
  output_tokens: number;
  total_tokens: number;
  cost: number;
  duration_sec: number;
  model_response?: string;
  created_at: string;
}

export interface HistoryDetail {
  id: number;
  video_name: string;
  video_path: string;
  dir_alias?: string;
  video_duration_sec: number;
  prompt: string;
  prompt_id?: number;  // 提示词ID
  prompt_name?: string;  // 提示词名称
  model_name?: string;  // 模型名称
  call_type: string;  // 'manual' | 'auto'
  fps: number;
  max_pixels: number;
  min_pixels: number;
  vl_high_resolution_images: boolean;
  input_tokens: number;
  output_tokens: number;
  total_tokens: number;
  cost: number;
  duration_sec: number;
  model_response: string;
  created_at: string;
}

export interface Config {
  max_pixels_presets: {
    low: number;
    medium: number;
    high: number;
    ultra: number;
  };
  min_pixels_default: number;
  fps_presets: number[];
  video_dirs: string[];
  pricing: {
    tiers: Array<{
      name: string;
      input: number;
      output: number;
    }>;
  };
  limits: {
    max_video_size_mb: number;
    api_timeout_seconds: number;
    video_max_pixels: number;
  };
}

export interface LoginResponse {
  token: string;
  username: string;
}

export interface StreamSource {
  id: number;
  name: string;
  alias: string;
  stream_url: string;
  storage_path: string;
  is_active: boolean;
  did?: string;  // 用户ID（可选）
  created_at: string;
  updated_at: string;
}

export interface SlicingTask {
  id: number;
  source_id: number;
  pid?: number;
  status: 'running' | 'stopped' | 'error';
  script_file: string;
  last_heartbeat?: string;
  last_start_time?: string;
  error_msg?: string;
  consecutive_failures: number;
  enable_yolo: boolean;
  created_at: string;
  updated_at: string;
}

export interface ScriptFileInfo {
  filename: string;
  path: string;
  description?: string;
}
