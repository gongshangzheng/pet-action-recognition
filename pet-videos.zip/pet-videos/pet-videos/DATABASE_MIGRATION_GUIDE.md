# 数据库位置统一说明

## 变更日期
2026-02-06

## 变更内容

### 数据库位置统一

**变更前**：
- 存在两个数据库文件位置：
  - `database/history.db` (根目录)
  - `backend/database/history.db` (backend子目录)
- Backend可能使用任一位置，造成混乱

**变更后**：
- **统一使用根目录数据库**：`database/history.db`
- 删除/备份了 `backend/database/` 目录
- 所有服务（Backend、Service、Frontend）统一使用根目录数据库

## 配置说明

### Backend配置

**文件**：`backend/config.py`

```python
# 项目根目录（backend的父目录）
BASE_DIR = Path(__file__).resolve().parent.parent

# 数据库路径（默认）
database_path: str = str(BASE_DIR / "database" / "history.db")
```

### 环境变量

**文件**：`.env`

```bash
# 数据库路径（相对于项目根目录）
DATABASE_PATH=database/history.db
```

**说明**：
- macOS/Linux: `database/history.db` 或 `./database/history.db`
- Windows: `database\history.db` 或 `.\database\history.db`（路径分隔符可以用 `/` 或 `\`）

## 目录结构

```
pet-videos/
├── database/
│   ├── history.db              # 统一使用的数据库（已迁移到最新版本）
│   ├── history.db.backup_*     # 自动备份
│   └── video_cache/            # 视频缓存目录
├── backend/
│   ├── database.backup_*       # 已废弃（备份）
│   ├── models/
│   ├── api/
│   └── main.py
├── service/
│   └── app.py
└── frontend/
    └── src/
```

## Windows环境迁移步骤

### 1. 检查当前数据库位置

```cmd
dir database\history.db
dir backend\database\history.db
```

### 2. 如果backend下有数据库，统一到根目录

```cmd
REM 备份根目录数据库
copy database\history.db database\history.db.backup

REM 复制backend数据库到根目录（如果backend的更新）
copy backend\database\history.db database\history.db

REM 重命名backend数据库目录
move backend\database backend\database.backup
```

### 3. 执行pets表ID迁移

```cmd
cd backend\migrations
run_migration_002.bat
```

### 4. 重启服务

```cmd
REM 停止所有服务后重启
python backend\main.py
python -m service.app
```

## 验证步骤

### 1. 验证Backend使用根目录数据库

```bash
# 在根目录数据库添加测试数据
sqlite3 database/history.db "SELECT COUNT(*) FROM pets;"

# 调用Backend API，应该返回相同数量
curl "http://localhost:8002/api/internal/pets/" | jq '.total'
```

### 2. 验证数据一致性

```bash
# 查看pets表结构（应该包含id字段）
sqlite3 database/history.db "PRAGMA table_info(pets);"

# 查询宠物数据
sqlite3 database/history.db "SELECT id, did, pet_name FROM pets LIMIT 5;"
```

### 3. 验证Backend API

```bash
# 通过ID查询
curl "http://localhost:8002/api/internal/pets/by-id/1?did=20000000060148"

# 列表查询
curl "http://localhost:8002/api/internal/pets/?did=20000000060148"
```

## 注意事项

### 1. 数据库备份

- 迁移前会自动创建备份：`database/history.db.backup_YYYYMMDD_HHMMSS`
- backend下的旧数据库会重命名为：`backend/database.backup_YYYYMMDD_HHMMSS`
- 建议保留至少一个最近的备份

### 2. 多环境部署

- **开发环境（本地）**：使用 `database/history.db`
- **测试环境**：使用 `database/history.db`
- **生产环境（服务器）**：使用 `database/history.db`

所有环境统一使用根目录的 `database/history.db`

### 3. .gitignore配置

确保以下文件/目录被忽略：

```gitignore
# 数据库文件
database/history.db
database/history.db-*
database/*.backup*

# 备份目录
backend/database.backup_*/

# 视频缓存
database/video_cache/
```

### 4. 启动命令

无论从哪个目录启动，都应该在项目根目录执行：

```bash
# 正确方式（在项目根目录）
cd /path/to/pet-videos
python3 backend/main.py      # Backend
python3 -m service.app        # Service

# 错误方式（在backend子目录）
cd /path/to/pet-videos/backend
python3 main.py               # ❌ 可能找不到数据库
```

## 回滚方案

如果需要回滚到backend子目录数据库：

```bash
# 1. 停止服务
kill $(lsof -ti:8002)

# 2. 恢复backend/database目录
mv backend/database.backup_YYYYMMDD_HHMMSS backend/database

# 3. 修改.env
# DATABASE_PATH=backend/database/history.db

# 4. 重启服务
python3 backend/main.py
```

## 常见问题

### Q1: Backend启动后找不到数据库文件

**原因**：启动目录不正确，或环境变量配置错误

**解决**：
```bash
# 检查当前目录
pwd  # 应该在项目根目录

# 检查数据库文件是否存在
ls -l database/history.db

# 检查.env配置
cat .env | grep DATABASE_PATH
```

### Q2: Windows环境数据库路径问题

**原因**：Windows路径分隔符与Linux不同

**解决**：
- Python的 pathlib 会自动处理路径分隔符
- `.env` 中可以使用 `/` 或 `\`，建议使用 `/`
- 配置示例：`DATABASE_PATH=database/history.db`

### Q3: 两个数据库数据不一致

**原因**：迁移前未同步数据

**解决**：
```bash
# 比较两个数据库
sqlite3 database/history.db "SELECT COUNT(*) FROM pets;"
sqlite3 backend/database/history.db "SELECT COUNT(*) FROM pets;"

# 选择数据更完整的作为主库
cp backend/database/history.db database/history.db
```

## 相关文档

- pets表ID迁移：`CHANGELOG_pets_id.md`
- 迁移脚本：`backend/migrations/002_add_pets_id.sql`
- Backend配置：`backend/config.py`
- 环境变量：`.env`
