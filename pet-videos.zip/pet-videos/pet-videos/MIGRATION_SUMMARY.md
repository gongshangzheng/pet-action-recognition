# 数据库迁移总结

## 完成日期
2026-02-06

## 完成的迁移

### 1. Pets表自增ID改造 ✅

**变更**：将pets表从联合主键改为自增ID主键

**影响**：
- ✅ 数据库结构：添加 `id` 字段作为主键
- ✅ Backend ORM模型更新
- ✅ Backend Schema更新（PetResponse包含id）
- ✅ Backend新增3个by-id接口
- ✅ Service映射函数改用数据库ID
- ✅ Service API改用by-id路由

**文档**：
- 详细说明：`CHANGELOG_pets_id.md`
- Python迁移脚本：`backend/migrations/migrate_add_pets_id.py` ✅
- ~~SQL脚本：`backend/migrations/002_add_pets_id.sql`~~ (已弃用)
- ~~Shell脚本：`backend/migrations/run_migration_002.sh/bat`~~ (已弃用)

### 2. 数据库位置统一 ✅

**变更**：统一所有服务使用根目录 `database/history.db`

**操作**：
- ✅ 复制backend数据库到根目录
- ✅ 备份并删除 `backend/database/` 目录
- ✅ 更新.env配置明确数据库路径
- ✅ Backend已验证使用根目录数据库

**文档**：
- 详细说明：`DATABASE_MIGRATION_GUIDE.md`
- Python迁移脚本：`backend/migrations/migrate_unify_database_location.py` ✅
- ~~Shell脚本：`migrate_database_location.sh/bat`~~ (已弃用，保留作为参考)

## 当前状态（macOS本地）

### 数据库
- **位置**：`database/history.db` (384KB)
- **备份**：`database/history.db.backup_*`
- **旧库**：`backend/database.backup_*` (已废弃)

### Pets表结构
```sql
CREATE TABLE pets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,  -- 新增
    did VARCHAR(50) NOT NULL,
    pet_name VARCHAR(100) NOT NULL,
    pet_type VARCHAR(50),
    breed VARCHAR(100),
    gender VARCHAR(10),
    birth_date VARCHAR(10),
    weight REAL,
    color VARCHAR(100),
    avatar_url VARCHAR(500),
    description TEXT,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
);

-- 唯一索引
CREATE UNIQUE INDEX idx_pets_did_name ON pets(did, pet_name);
```

### Backend服务
- **状态**：运行中（端口8002）
- **数据库**：`database/history.db`
- **API验证**：✅ 通过

### 验证结果
```bash
# 数据库查询
sqlite3 database/history.db "SELECT id, pet_name FROM pets LIMIT 1;"
# 结果: 1|测试狗子

# Backend API
curl "http://localhost:8002/api/internal/pets/?did=20000000060148"
# 结果: {"total": 1, "pets": [{"id": 1, "pet_name": "测试狗子", ...}]}
```

## Windows环境待执行操作

### 步骤1：统一数据库位置

```cmd
cd D:\pet-videos
python backend\migrations\migrate_unify_database_location.py
```

**检查点**：
- [ ] 根目录 `database\history.db` 存在
- [ ] `backend\database\` 已重命名为 `backend\database.backup_*`
- [ ] 数据库验证通过

### 步骤2：执行pets表ID迁移

```cmd
cd D:\pet-videos
python backend\migrations\migrate_add_pets_id.py
```

**检查点**：
- [ ] 迁移成功完成
- [ ] pets表包含id字段
- [ ] 数据完整性验证通过

### 步骤3：重启服务

```cmd
REM 停止当前运行的服务（Ctrl+C）

REM 启动Backend
python backend\main.py

REM 启动Service（新窗口）
python -m service.app
```

### 步骤4：验证

```cmd
REM 检查数据库
sqlite3 database\history.db "SELECT id, pet_name FROM pets LIMIT 1;"

REM 检查Backend API
curl http://localhost:8002/api/internal/pets/?did=20000000060148
```

**检查点**：
- [ ] Backend API返回包含id字段
- [ ] Service API的petId使用数据库ID
- [ ] App端更新/删除宠物功能正常

## 配置文件变更

### .env
```bash
# 修改前
DATABASE_PATH=./database/history.db

# 修改后（明确路径）
DATABASE_PATH=database/history.db
```

### backend/config.py
```python
# 配置已正确（无需修改）
BASE_DIR = Path(__file__).resolve().parent.parent  # 项目根目录
database_path: str = str(BASE_DIR / "database" / "history.db")
```

## 回滚方案

### 如果需要回滚数据库位置：

```bash
# macOS/Linux
mv backend/database.backup_YYYYMMDD_HHMMSS backend/database
# 修改.env: DATABASE_PATH=backend/database/history.db

# Windows
move backend\database.backup_YYYYMMDD_HHMMSS backend\database
REM 修改.env: DATABASE_PATH=backend\database\history.db
```

### 如果需要回滚pets表ID迁移：

```bash
# 从备份恢复
cp database/history.db.backup_YYYYMMDD_HHMMSS database/history.db

# 或者手动删除id字段（不推荐，建议从备份恢复）
```

## 文档清单

### Python 迁移脚本（推荐使用）
- [x] `backend/migrations/migrate_add_pets_id.py` - Pets表ID迁移 Python脚本 ✅
- [x] `backend/migrations/migrate_unify_database_location.py` - 数据库位置统一 Python脚本 ✅

### 文档
- [x] `CHANGELOG_pets_id.md` - Pets表ID迁移详细说明
- [x] `DATABASE_MIGRATION_GUIDE.md` - 数据库位置统一指南
- [x] `backend/migrations/README.md` - 迁移脚本使用说明（已更新为Python版本）
- [x] `MIGRATION_SUMMARY.md` - 本文档

### 已弃用（保留作为参考）
- ~~`backend/migrations/002_add_pets_id.sql` - SQL脚本（已弃用）~~
- ~~`backend/migrations/run_migration_002.sh` - Shell脚本（已弃用）~~
- ~~`backend/migrations/run_migration_002.bat` - Batch脚本（已弃用）~~
- ~~`migrate_database_location.sh` - Shell脚本（已弃用）~~
- ~~`migrate_database_location.bat` - Batch脚本（已弃用）~~

## 注意事项

1. **备份数据库**：所有迁移操作都会自动创建备份，建议保留至少最近一次备份
2. **服务重启**：完成迁移后必须重启Backend和Service服务
3. **多环境同步**：Windows和macOS环境需要分别执行迁移
4. **启动目录**：始终从项目根目录启动服务（不要在backend子目录启动）
5. **路径分隔符**：Python会自动处理，`.env`中可以使用 `/` 或 `\`

## 测试清单

### macOS本地环境
- [x] pets表ID迁移成功
- [x] 数据库位置统一
- [x] Backend使用根目录数据库
- [x] Backend API通过ID查询
- [x] Backend API通过ID更新
- [x] Backend API列表查询返回id

### Windows环境（待测试）
- [ ] pets表ID迁移成功
- [ ] 数据库位置统一
- [ ] Backend使用根目录数据库
- [ ] Service API返回正确的petId
- [ ] App端更新宠物功能
- [ ] App端删除宠物功能

## 联系支持

如果遇到问题，请提供：
1. 操作系统和版本
2. 执行的命令
3. 错误信息截图
4. 数据库备份文件位置
