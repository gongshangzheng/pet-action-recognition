# 宠物管理 - 自增ID改造

## 变更日期
2026-02-06

## 变更内容

### 1. 数据库变更

**修改前**：
- pets表使用联合主键 `(did, pet_name)`
- 无独立的ID字段

**修改后**：
- pets表使用自增ID作为主键
- 保留 `(did, pet_name)` 的唯一约束

#### 数据库迁移脚本

**文件位置**：`backend/migrations/002_add_pets_id.sql`

**执行方式**：

Linux/macOS:
```bash
cd backend/migrations
./run_migration_002.sh
```

Windows:
```cmd
cd backend\migrations
run_migration_002.bat
```

手动执行:
```bash
# macOS/Linux
sqlite3 backend/database/history.db < backend/migrations/002_add_pets_id.sql

# 根目录数据库（如果需要）
sqlite3 database/history.db < backend/migrations/002_add_pets_id.sql
```

### 2. Backend 变更

#### 2.1 ORM 模型更新

**文件**：`backend/models/database.py`

```python
class Pet(Base):
    __tablename__ = "pets"
    
    # 主键 - 自增ID
    id = Column(Integer, primary_key=True, autoincrement=True)
    
    # 用户和宠物信息（did+pet_name保持唯一）
    did = Column(String(50), nullable=False, index=True)
    pet_name = Column(String(100), nullable=False, index=True)
    
    # ... 其他字段 ...
```

#### 2.2 Schema 更新

**文件**：`backend/models/schemas.py`

```python
class PetResponse(PetBase):
    """宠物信息响应"""
    id: int  # 新增：自增ID
    did: str
    created_at: datetime
    updated_at: datetime
```

#### 2.3 新增API接口

**文件**：`backend/api/pets.py`

新增3个通过ID操作的内部接口：

1. **通过ID查询宠物**
   - `GET /api/internal/pets/by-id/{pet_id}?did={did}`
   - 参数：pet_id (路径), did (查询参数)
   - 返回：PetResponse

2. **通过ID更新宠物**
   - `PUT /api/internal/pets/by-id/{pet_id}?did={did}`
   - 参数：pet_id (路径), did (查询参数), PetUpdate (Body)
   - 返回：PetResponse

3. **通过ID删除宠物**
   - `DELETE /api/internal/pets/by-id/{pet_id}?did={did}`
   - 参数：pet_id (路径), did (查询参数)
   - 返回：{message: "Pet deleted successfully"}

### 3. Service 变更

#### 3.1 映射函数更新

**文件**：`service/app.py`

```python
def map_pet_to_app_format(pet: Dict[str, Any], simple: bool = False) -> Dict[str, Any]:
    """将宠物数据库格式映射为App端格式"""
    result = {
        "petId": str(pet.get("id", "")),  # 使用数据库自增ID
        "petName": pet.get("pet_name", ""),
        "avatarColor": pet.get("avatar_color") or "#E5E7EB"
    }
    # ... 其余字段 ...
```

#### 3.2 API接口更新

**文件**：`service/app.py`

1. **/api/pet/update** - 更新宠物
   - 修改：使用 `by-id` 路由，petId转换为整数
   
2. **/api/pet/delete** - 删除宠物
   - 修改：使用 `by-id` 路由，petId转换为整数

## 影响范围

### 1. App端（移动应用）
- **petId字段**：从宠物名称改为数据库自增ID
- **优点**：
  - 可以更改宠物名称而不影响数据关联
  - 更符合标准的数据库设计
  - 简化了更新和删除操作

### 2. 现有数据
- **兼容性**：迁移脚本会自动保留所有现有数据
- **ID分配**：现有宠物会按创建顺序分配ID（从1开始）

### 3. 服务依赖
- **Backend**：需要重启以加载新的ORM模型
- **Service**：需要重启以使用新的映射逻辑

## 验证步骤

### 1. 验证数据库结构

```bash
sqlite3 database/history.db "PRAGMA table_info(pets);"
# 应该显示第一个字段为: 0|id|INTEGER|0||1
```

### 2. 验证Backend API

```bash
# 查询宠物（通过ID）
curl "http://localhost:8002/api/internal/pets/by-id/1?did=20000000060148"

# 更新宠物
curl -X PUT "http://localhost:8002/api/internal/pets/by-id/1?did=20000000060148" \
  -H "Content-Type: application/json" \
  -d '{"breed":"阿拉斯加","weight":25.5}'

# 删除宠物
curl -X DELETE "http://localhost:8002/api/internal/pets/by-id/1?did=20000000060148"
```

### 3. 验证Service API

```bash
# 获取宠物列表（检查petId字段）
curl "http://localhost:8006/api/pet/list" \
  -H "Cookie: openbduss=xxx; stoken=xxx"
```

## 回滚方案

如果需要回滚，执行以下步骤：

1. 停止所有服务
2. 从备份恢复数据库：
   ```bash
   # 数据库备份文件命名格式：history.db.backup_YYYYMMDD_HHMMSS
   cp database/history.db.backup_20260206_165821 database/history.db
   ```
3. 回退代码到上一个commit
4. 重启服务

## 注意事项

1. **Windows环境**：也需要执行相同的数据库迁移
2. **多环境**：开发、测试、生产环境都需要独立执行迁移
3. **数据备份**：迁移脚本会自动备份，也建议手动备份重要数据
4. **服务重启**：完成迁移后必须重启Backend和Service

## 测试清单

- [x] 数据库迁移成功（macOS）
- [x] Backend ORM模型加载正常
- [x] Backend API通过ID查询宠物
- [x] Backend API通过ID更新宠物
- [ ] Backend API通过ID删除宠物
- [ ] Service API返回正确的petId
- [ ] App端更新宠物功能正常
- [ ] App端删除宠物功能正常
- [ ] Windows环境数据库迁移

## 相关文档

- 数据库迁移说明：`backend/migrations/README.md`
- 迁移脚本：`backend/migrations/002_add_pets_id.sql`
- 执行脚本：`backend/migrations/run_migration_002.sh` (macOS/Linux)
- 执行脚本：`backend/migrations/run_migration_002.bat` (Windows)
