import os
import sys

print("=== 服务器端检查 ===\n")

# 1. 检查代码
print("1. 检查 service/app.py 中的 daily-reports URL:")
with open('service/app.py', 'r', encoding='utf-8') as f:
    for i, line in enumerate(f, 1):
        if 'daily-reports' in line and 'backend_api_url' in line:
            print(f"   Line {i}: {line.strip()}")

# 2. 检查 Service 进程
print("\n2. 检查 Service 进程:")
print("   请运行: tasklist | findstr python")
print("   查找端口 8006 的进程")

# 3. 检查 git 状态
print("\n3. 检查 git 状态:")
os.system('git log -1 --oneline')
print("")
os.system('git status --short')

