@echo off
cd /d "%~dp0"

echo ============================================================
echo   OpenH264 Installation Tool for Windows
echo ============================================================
echo.

REM Check if Python is available
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found
    echo Please install Python 3.8+ first
    pause
    exit /b 1
)

REM Check if install script exists
if not exist install_openh264.py (
    echo [ERROR] install_openh264.py not found
    echo Please extract the complete package
    pause
    exit /b 1
)

REM Run installation script
python install_openh264.py

echo.
pause
