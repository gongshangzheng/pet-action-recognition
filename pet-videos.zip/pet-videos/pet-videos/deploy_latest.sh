#!/bin/bash
# 最新版一键部署脚本
# 用途：自动完成备份、迁移、重启的完整流程

set -e  # 遇到错误立即退出

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "======================================================================"
echo "🚀 Pet-Videos 最新版部署脚本"
echo "======================================================================"
echo ""
echo "本次更新内容："
echo "  - 数据库表重命名：video_pet_analysis → pet_behaviors"
echo "  - 新增表：pets, daily_reports"
echo "  - 扩展 video_records 表（LLM 调用信息）"
echo "  - 修复异常 FPS 值"
echo ""

# 检查是否在正确的目录
if [ ! -d "backend" ] || [ ! -d "frontend" ]; then
    echo "❌ 错误：请在 pet-videos 项目根目录执行此脚本"
    exit 1
fi

# 询问是否继续
read -p "是否继续部署？(y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "部署已取消"
    exit 0
fi

# ============================================================
# 步骤 1: 备份数据库
# ============================================================
echo ""
echo "📝 步骤 1/5: 备份数据库"
echo "----------------------------------------------------------------------"

DB_PATH="backend/database/history.db"
if [ ! -f "$DB_PATH" ]; then
    echo "⚠️  数据库文件不存在: $DB_PATH"
    echo "这可能是首次部署，跳过备份"
else
    BACKUP_PATH="${DB_PATH}.backup.$(date +%Y%m%d_%H%M%S)"
    cp "$DB_PATH" "$BACKUP_PATH"
    echo "✅ 备份完成: $BACKUP_PATH"
fi

# ============================================================
# 步骤 2: 停止服务
# ============================================================
echo ""
echo "📝 步骤 2/5: 停止服务"
echo "----------------------------------------------------------------------"

if [ -f "stop_all.sh" ]; then
    bash stop_all.sh || true
    echo "✅ 服务已停止"
else
    echo "⚠️  stop_all.sh 不存在，手动停止服务"
    # 手动停止
    lsof -ti:8002 | xargs kill -9 2>/dev/null || true
    lsof -ti:8006 | xargs kill -9 2>/dev/null || true
    lsof -ti:8173 | xargs kill -9 2>/dev/null || true
    echo "✅ 端口已清理"
fi

sleep 2

# ============================================================
# 步骤 3: 执行数据库迁移
# ============================================================
echo ""
echo "📝 步骤 3/5: 执行数据库迁移"
echo "----------------------------------------------------------------------"

cd backend

if [ -f "run_server_migration.sh" ]; then
    echo "使用一键迁移脚本..."
    bash run_server_migration.sh
else
    echo "手动执行迁移脚本..."
    
    MIGRATIONS=(
        "migrate_add_did_to_stream_sources.py"
        "migrate_unify_video_records.py"
        "migrate_add_pets_table.py"
        "migrate_add_weight_to_pets.py"
        "migrate_add_avatar_color_to_pets.py"
        "migrate_add_video_pet_analysis_table.py"
        "migrate_rename_video_pet_analysis_to_pet_behaviors.py"
        "migrate_add_daily_reports_table.py"
    )
    
    for script in "${MIGRATIONS[@]}"; do
        if [ -f "migrations/$script" ]; then
            echo "  执行: $script"
            python3 "migrations/$script" || {
                echo "❌ 迁移失败: $script"
                echo "回滚命令: cp $BACKUP_PATH $DB_PATH"
                exit 1
            }
        else
            echo "  ⚠️  脚本不存在: $script"
        fi
    done
fi

# ============================================================
# 步骤 4: 修复异常 FPS
# ============================================================
echo ""
echo "📝 步骤 4/5: 修复异常 FPS 值"
echo "----------------------------------------------------------------------"

if [ -f "migrations/fix_abnormal_fps.py" ]; then
    python3 migrations/fix_abnormal_fps.py || {
        echo "⚠️  FPS 修复失败，但不影响主流程"
    }
else
    echo "⚠️  fix_abnormal_fps.py 不存在，跳过"
fi

cd ..

# ============================================================
# 步骤 5: 启动服务
# ============================================================
echo ""
echo "📝 步骤 5/5: 启动服务"
echo "----------------------------------------------------------------------"

if [ -f "start_all.sh" ]; then
    bash start_all.sh &
    echo "✅ 服务启动中..."
else
    echo "⚠️  start_all.sh 不存在，请手动启动服务"
fi

# 等待服务启动
echo ""
echo "等待服务启动..."
sleep 5

# ============================================================
# 验证部署
# ============================================================
echo ""
echo "📝 验证部署"
echo "----------------------------------------------------------------------"

# 检查 Backend
if curl -s http://localhost:8002/api/sources/ > /dev/null 2>&1; then
    echo "✅ Backend API (8002) 正常"
else
    echo "⚠️  Backend API (8002) 未响应"
fi

# 检查 Service
if curl -s http://localhost:8006/api/sources/ > /dev/null 2>&1; then
    echo "✅ Service API (8006) 正常"
else
    echo "⚠️  Service API (8006) 未响应"
fi

# 检查 Frontend
if curl -s http://localhost:8173/ > /dev/null 2>&1; then
    echo "✅ Frontend (8173) 正常"
else
    echo "⚠️  Frontend (8173) 未响应"
fi

# 检查数据库表
echo ""
echo "检查数据库表..."
if sqlite3 backend/database/history.db ".tables" | grep -q "pet_behaviors"; then
    echo "✅ pet_behaviors 表已创建"
else
    echo "❌ pet_behaviors 表不存在"
fi

if sqlite3 backend/database/history.db ".tables" | grep -q "pets"; then
    echo "✅ pets 表已创建"
else
    echo "❌ pets 表不存在"
fi

if sqlite3 backend/database/history.db ".tables" | grep -q "daily_reports"; then
    echo "✅ daily_reports 表已创建"
else
    echo "❌ daily_reports 表不存在"
fi

# ============================================================
# 部署总结
# ============================================================
echo ""
echo "======================================================================"
echo "📊 部署总结"
echo "======================================================================"
echo ""
echo "✅ 部署完成！"
echo ""
echo "📝 后续操作："
echo "  1. 访问前端: http://localhost:8173"
echo "  2. 检查视频列表 FPS 是否正常（10-30 范围）"
echo "  3. 测试宠物管理功能"
echo "  4. 查看日志: tail -f backend/logs/app.log"
echo ""
echo "📂 备份文件: $BACKUP_PATH"
echo ""
echo "⚠️  如果遇到问题："
echo "  - 查看日志: tail -f backend/logs/app.log"
echo "  - 回滚数据库: cp $BACKUP_PATH backend/database/history.db"
echo "  - 重启服务: ./stop_all.sh && ./start_all.sh"
echo ""
echo "======================================================================"
