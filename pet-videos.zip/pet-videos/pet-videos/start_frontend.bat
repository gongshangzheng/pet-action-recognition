@echo off
set "ROOT=%~dp0"
cd /d "%ROOT%frontend"

echo ===================================================
echo   Starting Frontend Dev Server...
echo ===================================================

:: If project local Node.js exists, use it
if exist "..\use_local_node.bat" (
    call ..\use_local_node.bat
    echo [INFO] Using project local Node.js
)

node --version
npm run dev
