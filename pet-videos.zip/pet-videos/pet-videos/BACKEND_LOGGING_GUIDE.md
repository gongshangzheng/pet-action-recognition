# Backend 日志排查指南

## 已添加的日志点

### 1. 数据库层 (`backend/models/db.py`)
启动时输出：
- 数据库路径
- 数据库目录
- 数据库文件是否存在
- 数据库引擎创建信息

```
[Backend/DB] 数据库路径: backend/database/history.db
[Backend/DB] 数据库目录: backend/database
[Backend/DB] 数据库文件存在: True
[Backend/DB] 数据库引擎已创建: sqlite:///backend/database/history.db
```

### 2. 应用启动 (`backend/main.py`)
启动时检查：
- 数据库路径和文件存在性
- pets表是否存在
- pets表的字段列表
- pets表的id和avatar_color字段
- pets表的记录数

```
[Backend/启动] 数据库路径: backend/database/history.db
[Backend/启动] 数据库文件存在: True
[Backend/启动] pets表存在: True
[Backend/启动] pets表字段: id, did, pet_name, pet_type, breed, gender, birth_date, weight, color, avatar_url, description, created_at, updated_at, avatar_color
[Backend/启动] pets表有id字段: True
[Backend/启动] pets表有avatar_color字段: True
[Backend/启动] pets表记录数: 1
```

### 3. 宠物API (`backend/api/pets.py`)

#### 查询列表 (`/api/internal/pets/`)
```
[Backend/Pets] 获取宠物列表请求: did=20000000060148
[Backend/Pets] 查询用户宠物: did=20000000060148
[Backend/Pets] 查询成功: 返回 1 条记录
[Backend/Pets] 宠物数据: id=1, did=20000000060148, name=测试狗子, avatar_color=#E5E7EB
[Backend/Pets] 响应数据: total=1, pets_count=1
```

#### 通过ID查询 (`/api/internal/pets/by-id/{pet_id}`)
```
[Backend/Pets] 通过ID获取宠物: pet_id=1, did=20000000060148
[Backend/Pets] 查询成功: id=1, name=测试狗子, avatar_color=#E5E7EB
```

#### 创建宠物 (`POST /api/internal/pets/`)
```
[Backend/Pets] 创建宠物请求: did=20000000060148, pet_name=小黑
[Backend/Pets] 请求数据: {'pet_name': '小黑', 'pet_type': 'dog', ...}
[Backend/Pets] 准备插入数据: {'pet_name': '小黑', ...}
[Backend/Pets] 创建成功: id=2, did=20000000060148, pet_name=小黑, avatar_color=#E5E7EB
```

#### 更新宠物 (`PUT /api/internal/pets/by-id/{pet_id}`)
```
[Backend/Pets] 更新宠物请求: pet_id=1, did=20000000060148
[Backend/Pets] 更新数据: {'breed': '金毛', 'avatar_color': '#FF0000'}
[Backend/Pets] 更新前: id=1, name=测试狗子, avatar_color=#E5E7EB
[Backend/Pets] 更新成功: id=1, name=测试狗子, avatar_color=#FF0000
```

#### 删除宠物 (`DELETE /api/internal/pets/by-id/{pet_id}`)
```
[Backend/Pets] 删除宠物请求: pet_id=1, did=20000000060148
[Backend/Pets] 删除前: id=1, name=测试狗子
[Backend/Pets] 删除成功: pet_id=1, did=20000000060148
```

#### 错误情况
```
[Backend/Pets] 查询失败: OperationalError: no such column: pets.avatar_color
[Backend/Pets] 堆栈:
Traceback (most recent call last):
  File "backend/api/pets.py", line 165
    ...
```

## 如何查看日志

### 本地开发

#### 1. 控制台输出
直接在启动Backend的终端查看实时日志：

```bash
cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos
python -m uvicorn backend.main:app --host 0.0.0.0 --port 8002
```

#### 2. 日志文件
查看日志文件（根据.env配置）：

```bash
# 查看最新100行
tail -100 logs/app.log

# 实时跟踪
tail -f logs/app.log

# 搜索特定关键词
grep "Backend/Pets" logs/app.log
grep "ERROR" logs/app.log
```

### 服务器部署

#### 1. 查看实时日志

```bash
# 如果使用 supervisord
supervisorctl tail -f backend

# 或查看日志文件
tail -f /data/pet-videos/logs/backend.log
tail -f /data/pet-videos/logs/app.log
```

#### 2. 搜索错误

```bash
# 查看最近的错误
grep "ERROR" /data/pet-videos/logs/backend.log | tail -20

# 查看宠物相关错误
grep "Backend/Pets" /data/pet-videos/logs/backend.log | grep "ERROR"

# 查看数据库相关错误
grep "Backend/DB\|Backend/启动" /data/pet-videos/logs/backend.log
```

#### 3. 按时间查找

```bash
# 查看今天的日志
grep "2026-02-06" /data/pet-videos/logs/backend.log

# 查看特定时间段
grep "2026-02-06 17:" /data/pet-videos/logs/backend.log
```

## 常见错误及排查

### 错误1：no such table: pets

**日志特征**：
```
[Backend/启动] pets表存在: False
[Backend/Pets] 查询失败: OperationalError: no such table: pets
```

**排查**：
1. 检查数据库路径是否正确
2. 确认是否执行了迁移脚本
3. 查看 `[Backend/启动]` 日志中的数据库路径

**解决**：
```bash
# 执行初始化迁移
python3 backend/migrations/migrate_init_all.py
```

### 错误2：no such column: pets.id 或 pets.avatar_color

**日志特征**：
```
[Backend/启动] pets表有id字段: False
[Backend/启动] pets表有avatar_color字段: False
[Backend/Pets] 查询失败: OperationalError: no such column: pets.id
```

**排查**：
1. 查看启动日志中的字段列表
2. 确认表结构是否更新

**解决**：
```bash
# 执行升级迁移
python3 backend/migrations/migrate_pets_upgrade.py
```

### 错误3：数据库路径不存在

**日志特征**：
```
[Backend/启动] 数据库文件存在: False
[Backend/启动] 数据库路径: database/server/history.db
```

**排查**：
1. 检查 `.env` 中的 `DATABASE_PATH` 配置
2. 确认数据库文件位置

**解决**：
```bash
# 更新 .env
DATABASE_PATH=backend/database/history.db

# 重启Backend
```

### 错误4：宠物列表为空但数据库有数据

**日志特征**：
```
[Backend/Pets] 获取宠物列表请求: did=20000000060148
[Backend/Pets] 查询成功: 返回 0 条记录
```

**排查**：
1. 检查did是否匹配
2. 查看数据库实际数据

```bash
sqlite3 backend/database/history.db "SELECT did, pet_name FROM pets;"
```

## 调试技巧

### 1. 增加SQL日志

如需查看实际执行的SQL语句，修改 `backend/models/db.py`：

```python
engine = create_engine(
    f"sqlite:///{settings.database_path}",
    connect_args={"check_same_thread": False},
    echo=True  # 改为True，输出所有SQL
)
```

### 2. 临时增加更多日志

在需要调试的地方添加：

```python
logger.info(f"[DEBUG] 变量值: {variable}")
logger.info(f"[DEBUG] 对象内容: {obj.__dict__}")
```

### 3. 查看HTTP请求

Service调用Backend时的日志（在Service日志中）：

```
[Backend调用] URL: http://localhost:8002/api/internal/pets/?did=20000000060148
[Backend响应] Status: 200
[Backend响应] Body: {"pets": [...], "total": 1}
```

## 提交日志时的注意事项

排查问题时，请提供：

1. **Backend启动日志**（包含数据库检查）
2. **具体API调用的日志**（从请求到响应）
3. **错误堆栈**（如果有）
4. **数据库实际状态**（表结构和数据）

示例命令：

```bash
# 获取完整诊断信息
echo "=== Backend启动日志 ===" 
grep "Backend/启动\|Backend/DB" logs/backend.log | tail -20

echo "=== 宠物API日志 ==="
grep "Backend/Pets" logs/backend.log | tail -50

echo "=== 数据库检查 ==="
sqlite3 backend/database/history.db "PRAGMA table_info(pets);"
sqlite3 backend/database/history.db "SELECT COUNT(*) FROM pets;"
```
