@echo off
setlocal EnableDelayedExpansion

echo ===================================================
echo   Stopping Pet Videos Analysis System...
echo ===================================================

:: 1. Stop Backend service (port 8002)
echo [INFO] Looking for Backend process...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8002 ^| findstr LISTENING') do (
    echo [INFO] Stopping Backend process PID:%%a
    taskkill /F /PID %%a >nul 2>&1
    if !errorlevel! equ 0 (
        echo [SUCCESS] Backend service stopped.
    )
)

:: 2. Stop Frontend service (port 5173)
echo [INFO] Looking for Frontend process...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :5173 ^| findstr LISTENING') do (
    echo [INFO] Stopping Frontend process PID:%%a
    taskkill /F /PID %%a >nul 2>&1
    if !errorlevel! equ 0 (
        echo [SUCCESS] Frontend service stopped.
    )
)

:: 3. Stop Service API (port 8006)
echo [INFO] Looking for Service API process...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8006 ^| findstr LISTENING') do (
    echo [INFO] Stopping Service API process PID:%%a
    taskkill /F /PID %%a >nul 2>&1
    if !errorlevel! equ 0 (
        echo [SUCCESS] Service API stopped.
    )
)

:: 4. Close command windows
echo [INFO] Closing related command windows...
taskkill /F /FI "WINDOWTITLE eq Pet-Videos*" >nul 2>&1

echo ===================================================
echo   All services stopped.
echo ===================================================
pause
