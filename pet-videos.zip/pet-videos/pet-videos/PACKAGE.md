# 打包脚本使用说明

## 快速开始

### 在 Mac/Linux 上打包

```bash
cd /path/to/pet-videos
./package.sh
```

### 在 Windows 上打包

```bat
cd D:\pet-videos
package.bat
```

## 生成的文件

打包后会生成一个带时间戳的 zip 文件：

```
pet-videos-source-20260115-171657.zip
```

文件大小：约 100KB - 5MB（仅包含源码）

## 打包内容

### ✅ 包含的文件

- **后端源码** (`backend/`)
  - Python 源代码
  - API 路由
  - 数据模型
  - 业务逻辑
  - 配置文件

- **前端源码** (`frontend/`)
  - React 组件
  - TypeScript 代码
  - Vite 配置
  - package.json

- **脚本文件**
  - `*.bat` - Windows 脚本
  - `*.sh` - Linux/Mac 脚本
  - `*.py` - Python 工具脚本

- **配置和文档**
  - `env.example` - 环境配置示例
  - `README.md` - 项目说明
  - `DEPLOY.md` - 部署指南
  - `SECURITY.md` - 安全说明
  - `CHANGELOG.md` - 更新日志

### ❌ 排除的文件

- **依赖包**（约 500MB）
  - `backend/venv/` - Python 虚拟环境
  - `frontend/node_modules/` - Node.js 依赖

- **运行时文件**
  - `backend/database/` - SQLite 数据库
  - `backend/logs/` - 日志文件

- **缓存文件**
  - `__pycache__/` - Python 字节码缓存
  - `frontend/.vite/` - Vite 构建缓存
  - `frontend/dist/` - 前端构建产物

- **系统文件**
  - `.git/` - Git 仓库
  - `.vscode/` - VS Code 配置
  - `.DS_Store` - Mac 系统文件
  - `.env` - 环境变量（包含敏感信息）

## 部署流程

### 1. 开发环境打包

```bash
# Mac/Linux
./package.sh

# Windows
package.bat
```

### 2. 上传到服务器

通过 FTP、SCP 或其他方式上传生成的 zip 文件到目标服务器

### 3. 在服务器上解压

```bat
# Windows Server
解压到: D:\pet-videos\
```

### 4. 首次部署

```bat
# 1. 配置环境变量
copy env.example .env
notepad .env

# 2. 安装依赖
install.bat

# 3. 启动服务
start_all.bat
```

### 5. 更新部署

```bat
# 覆盖旧文件后
quick_deploy.bat
start_all.bat
```

## 文件大小对比

| 打包方式 | 文件大小 | 上传时间 | 适用场景 |
|---------|---------|---------|---------|
| **源码打包** | ~100KB-5MB | <1分钟 | ✅ 推荐 |
| 完整打包（含依赖） | ~500MB | 10-30分钟 | ❌ 不推荐 |

## 常见问题

### Q: 为什么要排除依赖？
A: 
- 依赖文件占用约 500MB 空间
- 上传耗时长
- 不同操作系统的依赖不兼容（如 Windows/Linux）
- 使用 `install.bat` 可快速安装依赖

### Q: 打包后缺少某些文件怎么办？
A: 
检查脚本中的排除规则，如果需要包含特定文件，修改脚本：

**package.sh (Mac/Linux)**:
```bash
# 在 [3/5] 复制配置和脚本文件 部分添加
cp your-file "$TEMP_DIR/"
```

**package.bat (Windows)**:
```bat
REM 在 [3/5] 复制配置和脚本文件 部分添加
copy /Y "your-file" "%TEMP_DIR%\" >nul
```

### Q: 如何验证打包内容？
A:

**Mac/Linux**:
```bash
unzip -l pet-videos-source-*.zip | less
```

**Windows**:
```bat
右键 zip 文件 → 打开 → 检查内容
```

### Q: 可以在 Mac 上打包，然后部署到 Windows 吗？
A: 
✅ **可以！** 这正是推荐的做法：
- Mac 开发：使用 `package.sh` 打包
- Windows 部署：使用 `install.bat` 安装依赖

源码是跨平台的，依赖在目标服务器上安装即可。

## 自动化脚本对比

| 脚本 | 平台 | 功能 |
|------|------|------|
| `package.sh` | Mac/Linux | 打包源码 |
| `package.bat` | Windows | 打包源码 |
| `install.bat` | Windows | 安装依赖 |
| `start_all.bat` | Windows | 启动服务 |
| `stop_all.bat` | Windows | 停止服务 |
| `quick_deploy.bat` | Windows | 快速更新 |

## 技术细节

### Mac/Linux 打包流程

```bash
#!/bin/bash
1. 创建临时目录 /tmp/pet-videos-package
2. 复制源码文件（backend/, frontend/）
3. 复制脚本和配置
4. 清理不需要的文件
5. 使用 zip 命令压缩
6. 清理临时目录
```

### Windows 打包流程

```bat
@echo off
1. 创建临时目录 %TEMP%\pet-videos-package
2. 复制源码文件（backend\, frontend\）
3. 复制脚本和配置
4. 清理不需要的文件
5. 使用 PowerShell Compress-Archive 压缩
6. 清理临时目录
```

## 安全提示

⚠️ **重要**：打包前确保：
- `.env` 文件已被排除（包含敏感信息）
- 数据库文件已被排除（可能包含用户数据）
- 日志文件已被排除（可能包含敏感日志）

打包脚本默认会排除这些文件，但请检查确认。

## 更多信息

- 完整部署指南：[DEPLOY.md](DEPLOY.md)
- 安全说明：[SECURITY.md](SECURITY.md)
- 更新日志：[CHANGELOG.md](CHANGELOG.md)

---

**最后更新**: 2026-01-15
