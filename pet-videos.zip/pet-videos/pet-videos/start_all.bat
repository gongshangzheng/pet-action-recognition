@echo off
set "ROOT=%~dp0"
cd /d "%ROOT%"

echo ===================================================
echo   Starting Pet Videos Analysis System...
echo ===================================================

start "Pet-Videos Backend" cmd /k "start_backend.bat"
timeout /t 5
start "Pet-Videos Frontend" cmd /k "start_frontend.bat"

echo [SUCCESS] Services started.
echo Backend:  http://localhost:8002
echo Frontend: http://localhost:5173
echo ===================================================
