# PowerShell script to start Service API
# UTF-8 encoding, no encoding issues

$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ROOT

Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "  Pet-Videos Service API" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host ""

# Set Noah environment variable
$env:_NOAHEE_INSTANCEID = "5.android-container.licai-licai"
Write-Host "[INFO] Noah instance ID set" -ForegroundColor Green

# Check and activate virtual environment
if (Test-Path "backend\venv\Scripts\Activate.ps1") {
    Write-Host "[INFO] Activating backend virtual environment..." -ForegroundColor Green
    & "backend\venv\Scripts\Activate.ps1"
} elseif (Test-Path "service\venv\Scripts\Activate.ps1") {
    Write-Host "[INFO] Activating service virtual environment..." -ForegroundColor Green
    & "service\venv\Scripts\Activate.ps1"
} else {
    Write-Host "[WARN] Virtual environment not found, using system Python" -ForegroundColor Yellow
}

# Check Python
try {
    $pythonVersion = python --version
    Write-Host "[OK] $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Python not found" -ForegroundColor Red
    exit 1
}

# Start service
Write-Host ""
Write-Host "Starting Service API..." -ForegroundColor Green
Write-Host "----------------------------------------" -ForegroundColor Gray
Write-Host "Listen: http://0.0.0.0:8006" -ForegroundColor Yellow
Write-Host "Health: http://localhost:8006/pet/health" -ForegroundColor Yellow
Write-Host "Test:   http://localhost:8006/pet/api/test" -ForegroundColor Yellow
Write-Host "Docs:   See service/appdoc/API接口文档.md" -ForegroundColor Yellow
Write-Host "----------------------------------------" -ForegroundColor Gray
Write-Host ""
Write-Host "Press Ctrl+C to stop" -ForegroundColor Cyan
Write-Host ""

python -m service.app
