# 服务器数据库修复指南

## 问题诊断

### 1. 检查服务器数据库状态

服务器上发现 `database/server/history.db` 中有 `pets_new` 表（迁移中断），缺少 `pets` 表和 `avatar_color` 字段。

```bash
# 检查表结构
sqlite3 database/server/history.db "SELECT name FROM sqlite_master WHERE type='table';"
```

## 解决方案

### 方式一：使用修复脚本（推荐）

已创建专用修复脚本 `backend/migrations/migrate_fix_server_database.py`，自动完成：
- 将 `pets_new` 重命名为 `pets`
- 添加 `avatar_color` 字段
- 创建必要的索引

**执行步骤**：

```bash
# 1. 确保代码已更新
cd /data/pet-videos  # 或你的服务器路径
git pull

# 2. 指定数据库路径执行修复
DATABASE_PATH=database/server/history.db python3 backend/migrations/migrate_fix_server_database.py
```

### 方式二：如果已有正确数据库

如果 `backend/database/history.db` 已包含正确的pets数据（有id、avatar_color字段），直接复制：

```bash
# 备份当前数据库
cp database/server/history.db database/server/history.db.backup_$(date +%Y%m%d_%H%M%S)

# 复制正确的数据库
cp backend/database/history.db database/server/history.db
```

## 服务器数据库路径说明

### 当前配置

根据 `.env` 配置：
```bash
DATABASE_PATH=backend/database/history.db
```

### 服务器部署时的选择

**选项A：使用 `backend/database/history.db`（推荐）**
- 与代码结构一致
- 配置文件无需修改
- 备份和迁移更方便

```bash
# 服务器 .env 配置
DATABASE_PATH=backend/database/history.db
```

**选项B：使用 `database/server/history.db`**
- 数据与代码分离
- 需要修改 `.env` 配置

```bash
# 服务器 .env 配置
DATABASE_PATH=database/server/history.db
```

## 验证数据库

执行以下命令验证数据库结构：

```bash
# 检查表结构
sqlite3 <数据库路径> "PRAGMA table_info(pets);"

# 应包含以下字段：
# - id (INTEGER, 主键, 自增)
# - did (VARCHAR(50))
# - pet_name (VARCHAR(100))
# - pet_type (VARCHAR(50))
# - breed (VARCHAR(100))
# - gender (VARCHAR(10))
# - birth_date (VARCHAR(10))
# - weight (REAL)
# - color (VARCHAR(100))
# - avatar_url (VARCHAR(500))
# - avatar_color (VARCHAR(10))  ← 必须有
# - description (TEXT)
# - created_at (DATETIME)
# - updated_at (DATETIME)

# 检查数据
sqlite3 <数据库路径> "SELECT id, did, pet_name, avatar_color FROM pets LIMIT 3;"
```

## 修复完成后

### 1. 重启服务

```bash
# Backend
cd /data/pet-videos
source backend/venv/bin/activate
python -m uvicorn backend.app:app --host 0.0.0.0 --port 8002

# Service
python -m service.app
```

### 2. 验证API

```bash
# 测试获取宠物列表（需要有效token）
curl -X GET "http://服务器IP:8006/pet/api/pet/list" \
  -H "Cookie: openbduss=xxx; stoken=xxx"
```

## 故障排查

### 问题1：仍然报 "no such table: pets"

**原因**：数据库路径配置不正确

**解决**：
1. 检查 `.env` 中的 `DATABASE_PATH`
2. 确认服务启动时读取的配置文件
3. 使用绝对路径测试

### 问题2：pets表存在但缺少字段

**原因**：迁移未完成或版本不匹配

**解决**：
```bash
# 手动添加缺失字段
sqlite3 <数据库路径> "ALTER TABLE pets ADD COLUMN avatar_color VARCHAR(10);"
sqlite3 <数据库路径> "UPDATE pets SET avatar_color = '#E5E7EB' WHERE avatar_color IS NULL;"
```

### 问题3：有pets_new但没有pets

**原因**：上次迁移中断

**解决**：执行修复脚本（见上文）

## 迁移脚本对比

| 脚本名称 | 适用场景 | 说明 |
|---------|---------|------|
| `migrate_fix_server_database.py` | **服务器数据库修复** | 修复中断的迁移（pets_new → pets） |
| `migrate_pets_upgrade.py` | 已有旧版pets表 | 添加id和avatar_color字段 |
| `migrate_init_all.py` | 全新部署 | 从零创建完整的pets表 |

## 检查清单

部署前确认：

- [ ] 代码已更新到最新版本（`git pull`）
- [ ] `.env` 配置正确（DATABASE_PATH）
- [ ] 数据库包含正确的 pets 表结构
- [ ] pets 表有 id（主键）和 avatar_color 字段
- [ ] 必要的索引已创建
- [ ] Backend 和 Service 已重启
- [ ] API 接口测试通过

## 本地测试结果

```bash
# 测试修复脚本
DATABASE_PATH=database/server/history.db python3 backend/migrations/migrate_fix_server_database.py

# 输出：
✓ 重命名 pets_new -> pets
✓ avatar_color字段添加成功
✓ 索引创建成功
✓ 数据同步完成（1条记录）
```
