#!/bin/bash

set -e  # 遇到错误立即退出

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "============================================================"
echo "  Pet-Videos 源码打包工具"
echo "============================================================"
echo ""

# 生成打包文件名（带时间戳）
TIMESTAMP=$(date +"%Y%m%d-%H%M%S")
PACKAGE_NAME="pet-videos-source-${TIMESTAMP}.zip"
OUTPUT_DIR="$ROOT/output"

echo "[1/6] 准备打包目录..."
TEMP_DIR="/tmp/pet-videos-package"
rm -rf "$TEMP_DIR"
mkdir -p "$TEMP_DIR"
mkdir -p "$OUTPUT_DIR"

echo "[2/6] 复制源码文件..."
echo "  复制后端源码..."
cp -r backend "$TEMP_DIR/"
echo "  复制服务层源码..."
cp -r service "$TEMP_DIR/"
echo "  复制前端源码..."
cp -r frontend "$TEMP_DIR/"
echo "  复制切片脚本..."
cp -r scripts "$TEMP_DIR/"
echo "  复制 YOLOv13 源码（可选）..."
# cp -r yolov13 "$TEMP_DIR/" 2>/dev/null || true  # 取消注释以打包 yolov13 源码

echo "[3/6] 复制配置和脚本文件..."
# 复制启动和安装脚本
cp *.bat "$TEMP_DIR/" 2>/dev/null || true
cp start*.sh "$TEMP_DIR/" 2>/dev/null || true
cp env.example "$TEMP_DIR/"

# 从根目录复制主文档
[ -f README.md ] && cp README.md "$TEMP_DIR/"
[ -f PACKAGE.md ] && cp PACKAGE.md "$TEMP_DIR/"

echo "[4/6] 复制关键文档..."
# 从 docs/ 目录复制关键部署文档
mkdir -p "$TEMP_DIR/docs"
[ -f docs/DEPLOY.md ] && cp docs/DEPLOY.md "$TEMP_DIR/docs/"
[ -f docs/SECURITY.md ] && cp docs/SECURITY.md "$TEMP_DIR/docs/"
[ -f docs/INSTALL_FFMPEG.md ] && cp docs/INSTALL_FFMPEG.md "$TEMP_DIR/docs/"
[ -f docs/SCRIPT_SELECTION.md ] && cp docs/SCRIPT_SELECTION.md "$TEMP_DIR/docs/"
[ -f docs/VIDEO_ENCODING.md ] && cp docs/VIDEO_ENCODING.md "$TEMP_DIR/docs/"
# 其他技术文档可选复制（取消注释以包含）
# cp docs/*.md "$TEMP_DIR/docs/" 2>/dev/null || true

echo "[5/6] 清理不必要的文件..."
# 删除后端虚拟环境和缓存
rm -rf "$TEMP_DIR/backend/venv"
rm -rf "$TEMP_DIR/backend/database"
rm -rf "$TEMP_DIR/backend/logs"
find "$TEMP_DIR/backend" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "$TEMP_DIR/backend" -type d -name "*.egg-info" -exec rm -rf {} + 2>/dev/null || true

# 删除服务层缓存
rm -rf "$TEMP_DIR/service/logs"
find "$TEMP_DIR/service" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "$TEMP_DIR/service" -type d -name "*.egg-info" -exec rm -rf {} + 2>/dev/null || true

# 删除前端依赖和缓存
rm -rf "$TEMP_DIR/frontend/node_modules"
rm -rf "$TEMP_DIR/frontend/dist"
rm -rf "$TEMP_DIR/frontend/.vite"

# 删除测试和临时文件（test/ 目录已被排除，不会复制）
# 删除其他不必要的文件
rm -rf "$TEMP_DIR/node-local"
rm -f "$TEMP_DIR/use_local_node.bat"
rm -f "$TEMP_DIR/.env"
rm -rf "$TEMP_DIR/.git"
rm -rf "$TEMP_DIR/.vscode"
rm -f "$TEMP_DIR/.DS_Store"
find "$TEMP_DIR" -name ".DS_Store" -delete 2>/dev/null || true

echo "[6/6] 压缩打包..."
echo "  正在创建: $PACKAGE_NAME"

cd "$TEMP_DIR"
zip -r -q "$OUTPUT_DIR/$PACKAGE_NAME" .
cd "$ROOT"

if [ -f "$OUTPUT_DIR/$PACKAGE_NAME" ]; then
    echo ""
    echo "============================================================"
    echo "  打包成功！"
    echo "============================================================"
    echo "  文件位置: $OUTPUT_DIR/$PACKAGE_NAME"
    
    # 计算文件大小
    SIZE=$(du -h "$OUTPUT_DIR/$PACKAGE_NAME" | cut -f1)
    echo "  文件大小: $SIZE"
    
    echo ""
    echo "  打包内容:"
    echo "    - 后端源码 (backend/)"
    echo "    - 服务层源码 (service/)"
    echo "    - 前端源码 (frontend/)"
    echo "    - 切片脚本 (scripts/ - PyAV版本 + 传统版本)"
    echo "    - YOLO 模型 (scripts/yolov13n.pt)"
    echo "    - 启动脚本 (start_all.bat, install.bat等)"
    echo "    - 配置示例 (env.example)"
    echo "    - 核心文档 (docs/ - 部署、安全、编码等关键文档)"
    echo "    - README.md, PACKAGE.md"
    echo ""
    echo "  已排除:"
    echo "    - 测试目录 (test/ - 测试脚本和临时文件)"
    echo "    - Python 虚拟环境 (venv/)"
    echo "    - Node.js 依赖 (node_modules/)"
    echo "    - 数据库文件 (database/)"
    echo "    - 日志文件 (logs/)"
    echo "    - 缓存文件 (__pycache__, .vite, dist)"
    echo "    - 技术细节文档 (docs/ 中的修复和调试文档)"
    echo ""
    echo "  部署说明:"
    echo "    1. 将 $PACKAGE_NAME 上传到目标服务器"
    echo "    2. 解压到目标目录 (如 D:\pet-videos 或 /opt/pet-videos)"
    echo "    3. 复制 env.example 为 .env 并配置"
    echo "    4. 安装依赖: 运行 install.bat (Windows) 或参考 docs/DEPLOY.md"
    echo "    5. 运行 start_all.bat (Windows) 或 start_all.sh (Linux) 启动服务"
    echo "    6. 详细文档参考 docs/DEPLOY.md"
    echo ""
    echo "  关键文档:"
    echo "    - docs/DEPLOY.md - 部署指南"
    echo "    - docs/SECURITY.md - 安全配置"
    echo "    - docs/SCRIPT_SELECTION.md - 脚本选择指南"
    echo "    - docs/INSTALL_FFMPEG.md - FFmpeg安装（如需要）"
    echo "============================================================"
else
    echo ""
    echo "[错误] 打包失败！"
    echo "请确保有足够的磁盘空间，并且已安装 zip 命令。"
    exit 1
fi

# 清理临时目录
rm -rf "$TEMP_DIR"

echo ""
