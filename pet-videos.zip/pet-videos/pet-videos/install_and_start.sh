#!/bin/bash
# 安装依赖并启动后端

set -e

echo "============================================"
echo "  安装依赖并启动后端"
echo "============================================"

cd /Users/dxm/code/dxm/fsg-fbfe/pet-videos

echo ""
echo "[1/5] 安装核心依赖..."
pip3 install fastapi uvicorn[standard] pydantic python-dotenv sqlalchemy || {
    echo "错误：安装失败"
    exit 1
}

echo ""
echo "[2/5] 安装认证相关依赖..."
pip3 install python-multipart PyJWT passlib[bcrypt] pydantic-settings || {
    echo "错误：安装失败"
    exit 1
}

echo ""
echo "[3/5] 验证安装..."
python3 -c "import fastapi, uvicorn; print('✓ FastAPI和Uvicorn已安装')" || {
    echo "错误：验证失败"
    exit 1
}

echo ""
echo "[4/7] 创建必要目录..."
mkdir -p logs database
chmod 755 logs database
echo "✓ 目录已创建"

echo ""
echo "[5/7] 设置虚拟环境（用于监控脚本）..."
if [ ! -d "backend/venv" ]; then
    echo "创建虚拟环境..."
    python3 -m venv backend/venv
fi
echo "✓ 虚拟环境已就绪"

echo ""
echo "[6/7] 安装监控脚本依赖到 venv..."
backend/venv/bin/python3 -m pip install --upgrade pip -i https://pypi.tuna.tsinghua.edu.cn/simple > /dev/null 2>&1
backend/venv/bin/python3 -m pip install -r backend/requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple || {
    echo "警告：requirements.txt 安装部分失败，继续..."
}
backend/venv/bin/python3 -m pip install av opencv-python numpy -i https://pypi.tuna.tsinghua.edu.cn/simple || {
    echo "警告：监控依赖安装失败"
}

# 下载并安装 yolov13 的 ultralytics
if [ ! -d "yolov13" ]; then
    echo "正在克隆 yolov13 项目..."
    git clone https://gitee.com/zhanghui_china/yolov13.git || {
        echo "警告：yolov13 克隆失败，YOLO 检测将不可用"
    }
fi

if [ -d "yolov13" ]; then
    echo "安装 yolov13 ultralytics..."
    cd yolov13
    ../backend/venv/bin/python3 -m pip install -e . -i https://pypi.tuna.tsinghua.edu.cn/simple > /dev/null 2>&1
    cd ..
    echo "✓ YOLOv13 已安装"
else
    echo "警告：yolov13 目录不存在，跳过安装"
fi

echo ""
echo "[7/7] 停止旧进程并启动后端..."
pkill -f "uvicorn.*backend.main" 2>/dev/null || true
sleep 1

echo ""
echo "正在启动后端服务..."
python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8002 --reload &
BACKEND_PID=$!
echo "后端进程 PID: $BACKEND_PID"

echo ""
echo "等待后端启动..."
sleep 3

echo ""
echo "============================================"
echo "  测试后端连接"
echo "============================================"

# 测试健康检查
if curl -s http://localhost:8002/health > /dev/null 2>&1; then
    echo "✓ 后端健康检查通过"
else
    echo "✗ 后端健康检查失败"
fi

# 测试登录
echo ""
echo "测试登录..."
RESPONSE=$(curl -s -X POST http://localhost:8002/api/auth/login \
    -H "Content-Type: application/json" \
    -d '{"username":"admin","password":"petadmin@20260115"}')

if echo "$RESPONSE" | grep -q "access_token"; then
    echo "✓ 登录成功！"
    echo "Token: $(echo $RESPONSE | python3 -c 'import sys, json; print(json.load(sys.stdin).get("access_token","")[:50])...')"
else
    echo "✗ 登录失败"
    echo "响应: $RESPONSE"
fi

echo ""
echo "============================================"
echo "  启动完成"
echo "============================================"
echo "  API 文档: http://localhost:8002/docs"
echo "  前端地址: http://localhost:8173/"
echo ""
echo "  登录凭证:"
echo "    用户名: admin"
echo "    密码: petadmin@20260115"
echo ""
echo "  查看日志: tail -f logs/app.log"
echo "  停止服务: pkill -f 'uvicorn.*backend.main'"
echo "============================================"
