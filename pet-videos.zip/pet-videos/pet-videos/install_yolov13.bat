@echo off
REM YOLOv13 安装脚本 - Windows
REM 在 pet-videos 目录下运行此脚本

echo ================================================================================
echo YOLOv13 自定义模块安装
echo ================================================================================
echo.

REM 1. 检查虚拟环境
if not exist "backend\venv\Scripts\python.exe" (
    echo [错误] 虚拟环境不存在: backend\venv
    echo 请先运行 backend\setup.bat 创建虚拟环境
    pause
    exit /b 1
)

echo [1/3] 检查 YOLOv13 目录...
if not exist "yolov13\pyproject.toml" (
    echo [错误] YOLOv13 目录不存在或不完整
    echo 请确保 yolov13 目录在当前目录下
    pause
    exit /b 1
)
echo OK - YOLOv13 目录存在

echo.
echo [2/3] 卸载现有的 ultralytics（如果存在）...
backend\venv\Scripts\python.exe -m pip uninstall -y ultralytics
echo OK

echo.
echo [3/3] 安装 YOLOv13（开发模式）...
cd yolov13
..\backend\venv\Scripts\python.exe -m pip install -e .
if errorlevel 1 (
    echo.
    echo [错误] 安装失败
    cd ..
    pause
    exit /b 1
)
cd ..

echo.
echo ================================================================================
echo 安装完成！
echo ================================================================================
echo.
echo 验证安装:
backend\venv\Scripts\python.exe -c "from ultralytics.nn.modules.block import DSC3k2; print('✓ DSC3k2 模块可用')"
if errorlevel 1 (
    echo.
    echo [警告] 验证失败，请检查安装日志
) else (
    echo.
    echo ✓ YOLOv13 自定义模块已成功安装
    echo ✓ 现在可以使用 yolov13n.pt 模型了
)

echo.
pause
